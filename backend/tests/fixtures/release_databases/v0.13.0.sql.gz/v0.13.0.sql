-- Inventari v0.13.0: the database the release leaves on disk.
-- Cut by scripts/release-db-snapshot.sh from 208c4f2791bbf5f468bb21386b828b196827539d.
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: audit_log_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_log_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_log rows are immutable: % operation not allowed', TG_OP;
    RETURN NULL;
END;
$$;


--
-- Name: stock_holds_within_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_holds_within_stock() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    DECLARE
        g_anchor uuid;
        g_lot uuid;
        g_owner uuid;
        anchor stock_anchors%ROWTYPE;
        held numeric;
        on_hand numeric;
    BEGIN
        IF TG_TABLE_NAME = 'stock_reservations' THEN
            g_anchor := NEW.anchor_id;
            g_lot := NEW.lot_id;
            g_owner := NEW.owner_id;
        ELSE
            SELECT id INTO g_anchor FROM stock_anchors
             WHERE organization_id = OLD.organization_id
               AND product_template_id = OLD.template_id
               AND storage_location_id = OLD.storage_location_id;
            g_lot := OLD.lot_id;
            g_owner := OLD.owner_id;
        END IF;
        -- A group with no anchor has no reservation rows to hold it.
        IF g_anchor IS NULL THEN
            RETURN NULL;
        END IF;
    
        SELECT coalesce(sum(quantity), 0) INTO held
          FROM stock_reservations
         WHERE anchor_id = g_anchor
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner;
        IF held = 0 THEN
            RETURN NULL;
        END IF;
    
        SELECT * INTO anchor FROM stock_anchors WHERE id = g_anchor;
        SELECT coalesce(sum(nullif(quantity, 'NaN'::numeric)), 0) INTO on_hand
          FROM items
         WHERE organization_id = anchor.organization_id
           AND template_id = anchor.product_template_id
           AND storage_location_id = anchor.storage_location_id
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner
           AND is_deleted IS FALSE;
    
        IF held > on_hand THEN
            RAISE EXCEPTION
                'ck_stock_holds_within_stock: % reserved of a grain holding %',
                held, on_hand
            USING ERRCODE = 'check_violation',
                  CONSTRAINT = 'ck_stock_holds_within_stock',
                  DETAIL = format(
                      'product %s, shelf %s, batch %s, owner %s',
                      anchor.product_template_id,
                      anchor.storage_location_id,
                      coalesce(g_lot::text, '-'),
                      coalesce(g_owner::text, '-')
                  );
        END IF;
        RETURN NULL;
    END $$;


--
-- Name: stock_ledger_totals_follow_moves(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_ledger_totals_follow_moves() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    BEGIN
        IF TG_OP IN ('INSERT', 'UPDATE') THEN
            INSERT INTO stock_ledger_totals AS t
                (organization_id, product_template_id, storage_location_id, quantity)
            SELECT organization_id, product_template_id, location_id, sum(qty)
            FROM (
                SELECT organization_id, product_template_id,
                       to_location_id AS location_id, quantity AS qty
                FROM new_moves
                WHERE state = 'done' AND to_location_id IS NOT NULL
                UNION ALL
                SELECT organization_id, product_template_id,
                       from_location_id, -quantity
                FROM new_moves
                WHERE state = 'done' AND from_location_id IS NOT NULL
            ) AS sides
            GROUP BY organization_id, product_template_id, location_id
            ORDER BY organization_id, product_template_id, location_id
            ON CONFLICT (organization_id, product_template_id, storage_location_id)
            DO UPDATE SET quantity = t.quantity + EXCLUDED.quantity;
        END IF;

        IF TG_OP IN ('UPDATE', 'DELETE') THEN
            WITH gone AS (
                SELECT organization_id, product_template_id, location_id,
                       sum(qty) AS qty
                FROM (
                    SELECT organization_id, product_template_id,
                           to_location_id AS location_id, quantity AS qty
                    FROM old_moves
                    WHERE state = 'done' AND to_location_id IS NOT NULL
                    UNION ALL
                    SELECT organization_id, product_template_id,
                           from_location_id, -quantity
                    FROM old_moves
                    WHERE state = 'done' AND from_location_id IS NOT NULL
                ) AS sides
                GROUP BY organization_id, product_template_id, location_id

            ), locked AS (
                SELECT t.organization_id, t.product_template_id,
                       t.storage_location_id, gone.qty
                FROM stock_ledger_totals AS t
                JOIN gone
                  ON t.organization_id = gone.organization_id
                 AND t.product_template_id = gone.product_template_id
                 AND t.storage_location_id = gone.location_id
                ORDER BY t.organization_id, t.product_template_id,
                         t.storage_location_id
                FOR UPDATE OF t
            )
            UPDATE stock_ledger_totals AS t
            SET quantity = t.quantity - locked.qty
            FROM locked
            WHERE t.organization_id = locked.organization_id
              AND t.product_template_id = locked.product_template_id
              AND t.storage_location_id = locked.storage_location_id;
        END IF;

        RETURN NULL;
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_connections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    api_key_enc character varying DEFAULT ''::character varying NOT NULL,
    api_base_url character varying(512) DEFAULT ''::character varying NOT NULL,
    model_name character varying(255) DEFAULT ''::character varying NOT NULL,
    temperature double precision,
    max_tokens integer,
    top_p double precision,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    capability_checks jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage_logs (
    id uuid NOT NULL,
    user_id uuid,
    organization_id uuid NOT NULL,
    model_name character varying(255) NOT NULL,
    provider character varying(100),
    prompt_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    total_tokens integer NOT NULL,
    estimated_cost_usd numeric(16,10),
    cost_is_estimated boolean DEFAULT false NOT NULL,
    action_type character varying(100),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_api_keys (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_approvals (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_equipment (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_example_widgets (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_maker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_maker (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_printing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_printing (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_purchase_orders (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_recipes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_shopping_lists (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_stock_takes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_warehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_warehouse (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_webhooks (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) NOT NULL,
    active_from timestamp with time zone NOT NULL,
    active_until timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    hashed_key character varying(64) NOT NULL,
    key_prefix character varying(15) NOT NULL,
    is_active boolean NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    scope_names jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: approval_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_decisions (
    id uuid NOT NULL,
    approval_request_id uuid NOT NULL,
    stage_order integer NOT NULL,
    approver_id uuid,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    notes text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    current_stage integer DEFAULT 1 NOT NULL,
    total_stages integer NOT NULL,
    created_by uuid NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    consumed_by uuid
);


--
-- Name: approval_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_workflows (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    stages json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    archived_at timestamp with time zone,
    requester_scope jsonb DEFAULT '{"everyone": true}'::jsonb NOT NULL
);


--
-- Name: audit_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_campaigns (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    scope_type character varying(20) NOT NULL,
    scope_filter_id uuid,
    launched_at timestamp with time zone,
    deadline timestamp with time zone NOT NULL,
    reminder_days_before integer NOT NULL,
    last_reminder_sent_at timestamp with time zone,
    status character varying(20) NOT NULL,
    email_subject character varying(255),
    email_body text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    snapshot json,
    reason character varying(500),
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_response_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_response_items (
    id uuid NOT NULL,
    response_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    item_id uuid NOT NULL,
    item_name character varying(255) NOT NULL,
    serial_number character varying(100),
    status character varying(20) NOT NULL,
    dispute_type character varying(30),
    dispute_reason text,
    created_at timestamp with time zone NOT NULL,
    responded_at timestamp with time zone
);


--
-- Name: audit_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_responses (
    id uuid NOT NULL,
    campaign_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    assignment_id uuid,
    assignee_email character varying(255) NOT NULL,
    assignee_name character varying(255) NOT NULL,
    token character varying(86) NOT NULL,
    token_expires_at timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    responded_at timestamp with time zone,
    dispute_reason text,
    dispute_type character varying(30),
    response_ip character varying(45),
    response_user_agent character varying(500),
    email_sent_at timestamp with time zone,
    reminder_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    code character varying(100),
    context_tag character varying(100),
    group_label character varying(50),
    icon character varying(100),
    emoji character varying(32),
    color character varying(16),
    sort_order integer NOT NULL,
    meta_data jsonb,
    default_removal_strategy character varying(10),
    module_name character varying(50),
    is_active boolean NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL
);


--
-- Name: cycle_count_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cycle_count_schedules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    frequency character varying(20) NOT NULL,
    scope character varying(20) NOT NULL,
    scope_filter json,
    sample_size integer,
    tolerance_percent numeric(5,2),
    is_active boolean NOT NULL,
    last_run_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_cycle_count_schedules_frequency CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying])::text[]))),
    CONSTRAINT ck_cycle_count_schedules_scope CHECK (((scope)::text = ANY ((ARRAY['all'::character varying, 'zone'::character varying, 'category'::character varying])::text[])))
);


--
-- Name: document_cost_variances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_cost_variances (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    reason character varying(255) NOT NULL,
    occurred_on date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_cost_variances_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_extra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extra_costs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    allocation_method character varying(10) DEFAULT 'value'::character varying NOT NULL,
    note character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_extra_costs_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_lines (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    item_id uuid,
    product_template_id uuid,
    name character varying(255),
    brand character varying(255),
    barcode character varying(50),
    quantity numeric(12,3) NOT NULL,
    expected_quantity numeric(12,3) NOT NULL,
    done_quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    batch_number character varying(100),
    serial_number character varying(100),
    expiry_date date,
    notes text,
    discrepancy_code character varying(50),
    discrepancy_reason text,
    unit_price numeric(12,2),
    tax_rate numeric(5,2),
    line_value numeric(14,2),
    line_tax numeric(14,2),
    line_gross numeric(14,2),
    currency character varying(3),
    line_number integer NOT NULL,
    source_po_line_id uuid,
    product_snapshot jsonb,
    executed_location_id uuid,
    corrects_line_id uuid,
    target_location_id uuid,
    held_quantity numeric(12,3) DEFAULT 0 NOT NULL,
    source_location_id uuid,
    puts_away_line_id uuid,
    meta_data jsonb,
    expected_is_count boolean DEFAULT false NOT NULL
);


--
-- Name: document_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_number_sequences (
    organization_id uuid NOT NULL,
    prefix character varying(120) NOT NULL,
    next_value integer DEFAULT 1 NOT NULL
);


--
-- Name: document_package_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_package_lines (
    id uuid NOT NULL,
    document_package_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_document_package_lines_quantity CHECK ((quantity > (0)::numeric))
);


--
-- Name: document_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_packages (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    number integer NOT NULL,
    weight_kg numeric(10,3),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_packages_weight CHECK ((weight_kg > (0)::numeric))
);


--
-- Name: document_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    value_tracking_enabled boolean NOT NULL,
    tax_handling character varying(20) NOT NULL,
    default_tax_rate numeric(5,2),
    require_partner_tax_id boolean,
    numbering_format character varying(100) NOT NULL,
    type_labels json,
    default_unit character varying(20) NOT NULL,
    visible_line_fields json,
    print_template character varying(50) NOT NULL,
    default_currency character varying(3),
    default_template_id uuid,
    approval_threshold numeric(14,2),
    approval_required_for_types json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    number_padding smallint NOT NULL,
    require_unit_price boolean DEFAULT false NOT NULL,
    confirm_shelf_by_scan boolean DEFAULT false NOT NULL,
    tracking_url_templates json,
    quarantine_location_id uuid,
    pick_order_strategy character varying(50)
);


--
-- Name: document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_relations (
    id uuid NOT NULL,
    source_document_id uuid NOT NULL,
    target_document_id uuid NOT NULL,
    relation_type character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_shipments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    carrier character varying(100) NOT NULL,
    tracking_number character varying(100),
    shipped_at timestamp with time zone NOT NULL,
    shipped_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    module character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(50) NOT NULL,
    body_html text NOT NULL,
    version integer NOT NULL,
    source_builtin character varying(255),
    source_checksum character varying(64),
    is_default boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: document_type_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_type_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_type character varying(15) NOT NULL,
    default_source_location_id uuid,
    default_target_location_id uuid,
    sequence_format character varying(50) NOT NULL,
    require_partner boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_warehouse_receiving; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_warehouse_receiving (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    two_step boolean DEFAULT false NOT NULL,
    receiving_location_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    free_placement boolean DEFAULT false NOT NULL
);


--
-- Name: document_work_item_overlays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_work_item_overlays (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    source_kind character varying(48) NOT NULL,
    source_id uuid,
    assignee_id uuid,
    title character varying(200),
    due_date date,
    done_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    type character varying(15) NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    source_location_id uuid,
    target_location_id uuid,
    scheduled_date date,
    notes text,
    external_reference character varying(100),
    partner_snapshot jsonb,
    corrects_document_id uuid,
    backorder_id uuid,
    total_net numeric(14,2),
    total_tax numeric(14,2),
    total_gross numeric(14,2),
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    completed_at timestamp with time zone,
    reason_code character varying(50),
    is_opening boolean DEFAULT false NOT NULL,
    stock_already_applied boolean DEFAULT false NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    complete_on_approval boolean DEFAULT false NOT NULL,
    post_key character varying(64),
    held_by character varying(64),
    meta_data jsonb,
    print_snapshot jsonb
);


--
-- Name: email_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_jobs (
    id uuid NOT NULL,
    organization_id uuid,
    to_email character varying(320) NOT NULL,
    subject character varying(500) NOT NULL,
    html_content text NOT NULL,
    attachment_bytes bytea,
    attachment_filename character varying(255),
    smtp_config_enc text,
    failure_notice_enc text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone
);


--
-- Name: equipment_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    assignee_partner_id uuid,
    checkout_location_id uuid,
    assigned_to_name character varying(255) NOT NULL,
    assigned_to_email character varying(255),
    checked_out_at timestamp with time zone NOT NULL,
    expected_return_at timestamp with time zone,
    checked_in_at timestamp with time zone,
    checked_out_by uuid NOT NULL,
    checked_in_by uuid,
    checkout_notes text,
    checkin_notes text,
    checkin_condition character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_type character varying(30) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_maintenance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_maintenance_logs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    maintenance_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    cost numeric(10,2),
    currency character varying(3),
    performed_at date NOT NULL,
    performed_by character varying(255),
    service_partner_id uuid,
    next_maintenance_at date,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_deliveries (
    id uuid NOT NULL,
    event_id character varying(64) NOT NULL,
    event character varying(100) NOT NULL,
    handler character varying(255) NOT NULL,
    organization_id uuid,
    payload jsonb NOT NULL,
    status character varying(16) NOT NULL,
    attempts integer NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_outbox (
    id uuid NOT NULL,
    organization_id uuid,
    event character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    emitter_module character varying(64),
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    published_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.example_widgets (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(30) DEFAULT 'blue'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ingredient_nutrition_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_nutrition_defaults (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    calories_kcal numeric(8,2) NOT NULL,
    protein_g numeric(8,2),
    fat_g numeric(8,2),
    carbs_g numeric(8,2),
    fiber_g numeric(8,2),
    sugar_g numeric(8,2),
    salt_g numeric(8,2),
    source character varying(50) NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_periods (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    reopened_at timestamp with time zone,
    reopened_by uuid,
    notes text
);


--
-- Name: item_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_attachments (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_history (
    id uuid NOT NULL,
    organization_id uuid,
    item_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    changes json,
    source_document_id uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_import_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    total integer NOT NULL,
    processed integer NOT NULL,
    result json,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    category_id uuid,
    module_name character varying(50),
    name character varying(255) NOT NULL,
    brand character varying(255),
    description character varying(500),
    uom_id uuid,
    template_id uuid,
    quantity numeric(12,3) NOT NULL,
    barcode character varying(50),
    serial_number character varying(100),
    added_date date NOT NULL,
    expiry_date date,
    shelf_location character varying(255),
    image_url character varying(500),
    meta_data jsonb,
    purchase_price numeric(10,2),
    currency character varying(3),
    is_deleted boolean NOT NULL,
    is_catalog_entry boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    label_code character varying(20),
    partner_id uuid,
    lot_id uuid,
    owner_id uuid,
    source_document_id uuid,
    CONSTRAINT ck_items_quantity_nonneg CHECK ((quantity >= (0)::numeric))
);


--
-- Name: label_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_pool (
    id uuid NOT NULL,
    short_code character varying(100) NOT NULL,
    is_assigned boolean NOT NULL,
    assigned_at timestamp with time zone,
    item_id uuid,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    label_type character varying(50) NOT NULL,
    description character varying(255),
    target_storage_location_id uuid,
    context_tag character varying(50),
    created_at timestamp with time zone NOT NULL,
    printed_at timestamp with time zone,
    scan_count integer NOT NULL,
    last_scanned_at timestamp with time zone
);


--
-- Name: location_relocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_relocations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid,
    location_name character varying(255) NOT NULL,
    from_parent_id uuid,
    to_parent_id uuid,
    from_path text,
    to_path text,
    moved_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: maker_bom_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_bom_lines (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_template_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    unit character varying(8) NOT NULL,
    yield_loss_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id uuid NOT NULL,
    qty_per_batch numeric(12,4) NOT NULL,
    uom_id uuid,
    make_fresh boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_bom_no_self CHECK ((parent_template_id <> child_template_id)),
    CONSTRAINT ck_bom_qty CHECK ((qty_per_batch > (0)::numeric)),
    CONSTRAINT ck_bom_yield_range CHECK (((yield_loss_pct >= (0)::numeric) AND (yield_loss_pct <= (100)::numeric)))
);


--
-- Name: maker_ingredient_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_ingredient_prices (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: maker_label_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_label_facts (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    label_name character varying(255),
    allergens jsonb,
    may_contain jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: maker_module_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_module_settings (
    organization_id uuid NOT NULL,
    reference_direction character varying(10) DEFAULT 'MARGIN'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    allow_overproduction boolean DEFAULT true NOT NULL,
    availability_check_scope character varying(15) DEFAULT 'GLOBAL'::character varying NOT NULL,
    create_on_shortage_strategy character varying(10) DEFAULT 'WARN'::character varying NOT NULL,
    labor_hourly_rate numeric(12,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: maker_production_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: maker_production_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_order_lines (
    id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    consumed_qty numeric(12,4) NOT NULL,
    unit character varying(8) NOT NULL,
    source_storage_location_id uuid,
    unit_cost_snapshot numeric(12,4),
    cost_source character varying(16),
    shortfall_qty numeric(12,4),
    estimated_qty numeric(12,4),
    estimated_unit_cost_snapshot numeric(12,4)
);


--
-- Name: maker_production_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    planned_qty numeric(12,3) NOT NULL,
    output_storage_location_id uuid NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    total_cost numeric(12,2),
    production_date date,
    notes character varying(500),
    created_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    cancel_reason character varying(500),
    produced_item_id uuid,
    recipe_id uuid,
    actual_qty numeric(12,3),
    overproduced boolean DEFAULT false NOT NULL,
    scrap_qty numeric(12,3),
    unit_cost_snapshot numeric(12,4),
    reference_price_snapshot numeric(12,2),
    result_per_unit numeric(12,2),
    result_per_batch numeric(12,2),
    number character varying(32),
    short_at_create boolean DEFAULT false NOT NULL,
    output_lot_name character varying(100),
    estimated_total_cost numeric(12,2),
    output_lot_id uuid,
    started_on date,
    started_at timestamp with time zone,
    material_cost numeric(12,2),
    unshelved_cost numeric(12,2),
    steps jsonb,
    planned_for date,
    output_layer_id uuid
);


--
-- Name: maker_production_portions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_portions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    qty numeric(12,3) NOT NULL,
    made_on date NOT NULL,
    lot_name character varying(100),
    item_id uuid,
    unit_cost numeric(12,4),
    layer_id uuid,
    created_by uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: maker_recipe_cost_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipe_cost_lines (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    label character varying(120) NOT NULL,
    amount numeric(12,2) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: maker_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    batch_yield_qty numeric(12,4) DEFAULT '1'::numeric NOT NULL,
    batch_yield_uom_id uuid,
    process_steps jsonb,
    reference_price numeric(12,2),
    is_default boolean DEFAULT false NOT NULL,
    source_recipe_id uuid,
    source_snapshot_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maker_shelf_lives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_shelf_lives (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    shelf_life_days integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_maker_shelf_life_positive CHECK ((shelf_life_days > 0))
);


--
-- Name: meal_plan_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_entries (
    id uuid NOT NULL,
    meal_plan_id uuid NOT NULL,
    date date NOT NULL,
    slot character varying(20) NOT NULL,
    recipe_id uuid NOT NULL,
    servings integer,
    notes text,
    "order" integer NOT NULL,
    CONSTRAINT ck_meal_plan_entries_slot CHECK (((slot)::text = ANY ((ARRAY['LUNCH'::character varying, 'BREAKFAST'::character varying, 'DINNER'::character varying, 'SNACK'::character varying])::text[])))
);


--
-- Name: meal_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plans (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255),
    start_date date NOT NULL,
    end_date date NOT NULL,
    enabled_slots jsonb NOT NULL,
    default_servings integer,
    shopping_list_id uuid,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    listed_meals jsonb
);


--
-- Name: module_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_installations (
    id uuid NOT NULL,
    module_name character varying(100) NOT NULL,
    installed_version character varying(50) NOT NULL,
    installed_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(1000) NOT NULL,
    type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    link character varying(255),
    meta_data jsonb
);


--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_invitations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    code character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    is_used boolean NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    role_id uuid,
    invited_email character varying(255),
    used_by_user_id uuid,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid,
    enabled_modules json NOT NULL,
    allowed_modules json,
    settings json NOT NULL,
    short_id character varying(20),
    active_profile_id character varying(50),
    onboarding_completed boolean DEFAULT false,
    focus_module character varying(50),
    pre_focus_enabled_modules json,
    pre_onboarding_manual_modules json,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'UTC'::character varying NOT NULL,
    tax_id character varying(50),
    country character varying(2),
    print_page_size character varying(10),
    address json,
    logo_url character varying(500)
);


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    type character varying(30) NOT NULL,
    tax_id character varying(50),
    is_consumer boolean DEFAULT false NOT NULL,
    email character varying(255),
    phone character varying(50),
    website character varying(500),
    contact_person character varying(255),
    address jsonb,
    notes text,
    is_active boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: picking_session_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_session_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    ingredient_id uuid,
    item_id uuid,
    quantity_consumed numeric(10,3),
    picked_items jsonb,
    consumed_valuation_rate numeric(12,2),
    status character varying(20) NOT NULL,
    ingredient_name character varying(255),
    required_quantity numeric(10,3),
    required_uom_symbol character varying(10)
);


--
-- Name: picking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    user_id uuid NOT NULL,
    servings integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    rating integer,
    scale numeric(10,3),
    meal_plan_entry_id uuid
);


--
-- Name: po_partner_pricelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_partner_pricelist (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    uom_id uuid,
    min_quantity numeric(12,3),
    valid_from date NOT NULL,
    valid_to date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_partner_pricelist_min_qty_positive CHECK (((min_quantity IS NULL) OR (min_quantity > (0)::numeric))),
    CONSTRAINT ck_po_partner_pricelist_unit_price_positive CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT ck_po_partner_pricelist_valid_range CHECK (((valid_to IS NULL) OR (valid_to >= valid_from)))
);


--
-- Name: po_reorder_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_reorder_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    min_quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    safety_stock numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    preferred_partner_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_reorder_rules_max_ge_min CHECK ((max_quantity >= min_quantity)),
    CONSTRAINT ck_po_reorder_rules_min_nonneg CHECK ((min_quantity >= (0)::numeric)),
    CONSTRAINT ck_po_reorder_rules_safety_nonneg CHECK ((safety_stock >= (0)::numeric))
);


--
-- Name: po_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    approval_threshold numeric(14,2),
    approval_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: print_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_agents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    printer_type character varying(50) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_version character varying(50),
    protocol_version integer
);


--
-- Name: print_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    labels jsonb NOT NULL,
    created_by uuid,
    attempts integer NOT NULL,
    lease_until timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    width_mm double precision DEFAULT 50.0 NOT NULL,
    height_mm double precision DEFAULT 24.0 NOT NULL,
    scale double precision,
    read_permissions jsonb NOT NULL
);


--
-- Name: product_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_templates (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    brand character varying(255),
    barcode character varying(50),
    sku character varying(50),
    uom_id uuid,
    weight_value numeric(14,6),
    weight_uom_id uuid,
    volume_value numeric(14,6),
    volume_uom_id uuid,
    image_url character varying(500),
    description character varying(500),
    min_quantity double precision,
    removal_strategy character varying(10),
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_lines (
    id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_template_id uuid,
    name character varying(255) NOT NULL,
    quantity_ordered numeric(12,3) NOT NULL,
    quantity_received numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_price numeric(12,2),
    uom_id uuid,
    tax_rate numeric(5,2),
    line_number integer NOT NULL,
    notes text,
    source_reorder_rule_id uuid
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    scheduled_date date,
    notes text,
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_capacity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_capacity (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_home_silenced; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_home_silenced (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_location_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_location_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    single_product boolean DEFAULT false NOT NULL
);


--
-- Name: putaway_rule_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rule_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    location_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: putaway_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    context_tag character varying(100),
    storage_type_code character varying(50),
    priority integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_putaway_rules_at_least_one_match CHECK (((product_template_id IS NOT NULL) OR (category_id IS NOT NULL) OR (context_tag IS NOT NULL) OR (storage_type_code IS NOT NULL)))
);


--
-- Name: recipe_collection_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collection_members (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(64),
    parent_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    template_id uuid,
    name character varying(255) NOT NULL,
    display_text character varying(500),
    ingredient_group_name character varying(100),
    quantity numeric(10,3) NOT NULL,
    uom_id uuid,
    original_quantity numeric(10,3),
    original_unit_text character varying(50),
    is_optional boolean NOT NULL,
    picking_skip boolean,
    sort_order integer NOT NULL,
    calories_kcal_per_100g numeric(8,2),
    price numeric(10,2),
    price_uom_id uuid,
    price_currency character varying(3),
    allergens jsonb NOT NULL,
    is_spice boolean NOT NULL
);


--
-- Name: recipe_tag_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_tag_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    instructions text,
    servings integer NOT NULL,
    prep_time_minutes integer,
    image_url text,
    source_url text,
    tags jsonb,
    is_favorite boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_requests (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    token character varying(255),
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    accepted_at timestamp with time zone,
    rejected_at timestamp with time zone,
    is_rejected boolean DEFAULT false NOT NULL,
    approved_by_id uuid
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shopping_exclusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_exclusions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    template_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_history (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    original_list_id uuid NOT NULL,
    original_list_name character varying(255) NOT NULL,
    item_name character varying(255) NOT NULL,
    quantity numeric(12,3) DEFAULT 1 NOT NULL,
    estimated_price numeric(10,2),
    purchased_at timestamp with time zone,
    purchased_by uuid,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_items (
    id uuid NOT NULL,
    shopping_list_id uuid NOT NULL,
    item_id uuid,
    category_id uuid,
    name character varying(255) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    notes text,
    estimated_price numeric(10,2),
    is_purchased boolean NOT NULL,
    purchased_at timestamp with time zone,
    purchased_by uuid,
    source character varying(50) NOT NULL,
    priority integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_id uuid,
    note_data jsonb
);


--
-- Name: shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_lists (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    completed_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_anchors (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_ledger_totals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_ledger_totals (
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    quantity numeric(18,3) NOT NULL
);


--
-- Name: stock_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_lots (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    is_serial boolean NOT NULL,
    expiry_date date,
    production_date date,
    use_by_date date,
    removal_strategy character varying(10) NOT NULL,
    status character varying(20) NOT NULL,
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: stock_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_moves (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    from_location_id uuid,
    to_location_id uuid,
    quantity numeric(12,3) NOT NULL,
    lot_id uuid,
    owner_id uuid,
    expiry_date date,
    state character varying(20) DEFAULT 'done'::character varying NOT NULL,
    reference_type character varying(20),
    reference_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_stock_moves_at_least_one_location CHECK (((from_location_id IS NOT NULL) OR (to_location_id IS NOT NULL))),
    CONSTRAINT ck_stock_moves_qty_positive CHECK ((quantity > (0)::numeric))
);


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    document_line_id uuid,
    anchor_id uuid NOT NULL,
    lot_id uuid,
    owner_id uuid,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_quants_from_records; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.stock_quants_from_records AS
 SELECT (md5((((((((((organization_id)::text || '/'::text) || (product_template_id)::text) || '/'::text) || COALESCE((storage_location_id)::text, '-'::text)) || '/'::text) || COALESCE((lot_id)::text, '-'::text)) || '/'::text) || COALESCE((owner_id)::text, '-'::text))))::uuid AS id,
    organization_id,
    product_template_id,
    storage_location_id,
    lot_id,
    owner_id,
    (COALESCE(sum(quantity), (0)::numeric))::numeric(12,3) AS quantity,
    (COALESCE(sum(reserved_quantity), (0)::numeric))::numeric(12,3) AS reserved_quantity,
    'FIFO'::character varying(10) AS removal_strategy,
    min(created_at) AS created_at,
    max(updated_at) AS updated_at
   FROM ( SELECT i.organization_id,
            i.template_id AS product_template_id,
            i.storage_location_id,
            i.lot_id,
            i.owner_id,
            NULLIF(i.quantity, 'NaN'::numeric) AS quantity,
            NULL::numeric AS reserved_quantity,
            i.created_at,
            i.updated_at
           FROM public.items i
          WHERE ((i.is_deleted IS FALSE) AND (i.template_id IS NOT NULL))
        UNION ALL
         SELECT a.organization_id,
            a.product_template_id,
            a.storage_location_id,
            r.lot_id,
            r.owner_id,
            NULL::numeric AS "numeric",
            r.quantity,
            r.created_at,
            r.created_at
           FROM (public.stock_reservations r
             JOIN public.stock_anchors a ON ((a.id = r.anchor_id)))) sides
  GROUP BY organization_id, product_template_id, storage_location_id, lot_id, owner_id;


--
-- Name: stock_take_closed_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_closed_locations (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    storage_location_id uuid,
    path text NOT NULL,
    empty boolean DEFAULT false NOT NULL,
    closed_by uuid,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_counts (
    id uuid NOT NULL,
    stock_take_item_id uuid NOT NULL,
    sequence integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    counted_by uuid,
    counted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_items (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    item_id uuid,
    item_name character varying(255) NOT NULL,
    item_brand character varying(255),
    uom_id uuid,
    assignee_id uuid,
    lot_id uuid,
    system_quantity numeric(12,3),
    counted_quantity numeric(10,3),
    location_in_storage character varying(255),
    notes text,
    discrepancy_reason character varying(255),
    is_discrepancy integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discrepancy_reason_code character varying(50),
    recount_requested boolean DEFAULT false NOT NULL,
    storage_location_id uuid,
    expected_location_id uuid
);


--
-- Name: stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_takes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    blind_mode boolean NOT NULL,
    require_full_count boolean NOT NULL,
    tolerance_percent numeric(5,2),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule_id uuid,
    adjustment_document_id uuid,
    CONSTRAINT ck_stock_takes_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: stock_valuation_layers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_valuation_layers (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    document_line_id uuid,
    quantity numeric(12,3) NOT NULL,
    remaining_qty numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    total_value numeric(14,2) NOT NULL,
    document_date date,
    currency character varying(3),
    direction character varying(10) NOT NULL,
    cost_basis character varying(10) NOT NULL,
    reason character varying(30),
    item_id uuid,
    created_at timestamp with time zone NOT NULL,
    revalued_at timestamp with time zone,
    unit_cost_before numeric(12,4),
    cost_basis_before character varying(10),
    internal boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_svl_remaining_not_negative CHECK ((remaining_qty >= (0)::numeric))
);


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_id uuid,
    storage_type_id uuid,
    context_schema json DEFAULT '[]'::json NOT NULL,
    behavior_mode character varying(50) DEFAULT 'STOCK'::character varying NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    location_details character varying(255),
    short_code character varying(100),
    sequence integer,
    usage character varying(50) DEFAULT 'internal'::character varying NOT NULL,
    context_tag character varying(50),
    settings json,
    warehouse_config jsonb,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL
);


--
-- Name: storage_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_types (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    type_code character varying(50) NOT NULL,
    behavior_mode character varying(50) NOT NULL,
    context_schema json DEFAULT '[]'::json NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    icon character varying(100),
    is_system boolean NOT NULL,
    created_by uuid,
    default_settings json
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by uuid
);


--
-- Name: tax_rate_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    tax_rate_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    CONSTRAINT ck_tax_rate_assignments_one_target CHECK ((num_nonnulls(product_template_id, category_id) = 1))
);


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    rate numeric(5,2) NOT NULL,
    code character varying(10),
    country character varying(2),
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: unit_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_conversions (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    ingredient_key character varying(100) NOT NULL,
    ingredient_name character varying(200) NOT NULL,
    source_unit character varying(50) NOT NULL,
    metric_quantity numeric(10,3) NOT NULL,
    metric_unit character varying(10) NOT NULL,
    category character varying(50) NOT NULL,
    is_system boolean NOT NULL
);


--
-- Name: uom_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom_categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(50) NOT NULL
);


--
-- Name: uoms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uoms (
    id uuid NOT NULL,
    organization_id uuid,
    category_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL,
    factor numeric(18,9) NOT NULL,
    is_reference boolean NOT NULL,
    is_system boolean NOT NULL,
    rounding numeric(12,6) NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    blocking_reason character varying(500),
    failed_login_count bigint DEFAULT 0,
    locked_until timestamp with time zone,
    organization_id uuid
);


--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_delivery_logs (
    id uuid NOT NULL,
    webhook_endpoint_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload_json jsonb NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    attempt_number integer DEFAULT 1 NOT NULL,
    next_retry_at timestamp with time zone,
    delivery_status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    delivery_id character varying(36),
    abandon_reason character varying(40),
    last_attempt_at timestamp with time zone
);


--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_endpoints (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2048) NOT NULL,
    secret character varying(512),
    http_method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    event_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    retry_backoff_seconds integer DEFAULT 10 NOT NULL,
    timeout_seconds integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp with time zone,
    last_status_code integer,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auto_disabled_at timestamp with time zone
);


--
-- Name: wms_pick_line_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_line_lots (
    pick_line_id uuid NOT NULL,
    lot_id uuid NOT NULL,
    lot_name character varying(100) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_lines (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    pick_order integer NOT NULL,
    status character varying(20) NOT NULL,
    picked_quantity numeric(12,3) NOT NULL,
    bin_location character varying(255),
    product_name character varying(255),
    lot_name character varying(100),
    expected_quantity numeric(12,3) NOT NULL,
    uom_symbol character varying(10),
    anchor_id uuid,
    lot_id uuid,
    location_id uuid,
    expiry_date date
);


--
-- Name: wms_pick_session_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_session_documents (
    session_id uuid NOT NULL,
    document_id uuid NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    assigned_to uuid,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    meta_data jsonb,
    last_activity_at timestamp with time zone
);


--
-- Data for Name: ai_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version (version_num) VALUES ('spoons01');


--
-- Data for Name: alembic_version_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_api_keys (version_num) VALUES ('009_key_prefix_column_narrows');


--
-- Data for Name: alembic_version_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_approvals (version_num) VALUES ('007_workflow_requester_scope');


--
-- Data for Name: alembic_version_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_equipment (version_num) VALUES ('011_campaign_closed_at');


--
-- Data for Name: alembic_version_example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_example_widgets (version_num) VALUES ('001_initial');


--
-- Data for Name: alembic_version_maker; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_maker (version_num) VALUES ('023_output_cost_layer');


--
-- Data for Name: alembic_version_printing; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_printing (version_num) VALUES ('007_job_read_permission');


--
-- Data for Name: alembic_version_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_purchase_orders (version_num) VALUES ('po_tzaware01');


--
-- Data for Name: alembic_version_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_recipes (version_num) VALUES ('014_backfill_imported_allergens');


--
-- Data for Name: alembic_version_shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_shopping_lists (version_num) VALUES ('007_history_quantity_default');


--
-- Data for Name: alembic_version_stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_stock_takes (version_num) VALUES ('014_enums_are_text');


--
-- Data for Name: alembic_version_warehouse; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_warehouse (version_num) VALUES ('doc_cost_variance01');


--
-- Data for Name: alembic_version_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_webhooks (version_num) VALUES ('005_timestamps_carry_their_zone');


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('f34b23f1-96bb-4f56-8f8e-7a0716ec6617', '1159a748-450f-4982-8eb4-9a25cf4b7599', 1, '3138d71e-a910-424a-81fe-5d36ad73454b', 'APPROVED', NULL, '2026-11-20 03:55:22.740971+00', '2026-11-20 03:55:22.740971+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('6d337e84-60f1-40aa-997a-8a529040a6e8', '1159a748-450f-4982-8eb4-9a25cf4b7599', 2, NULL, 'PENDING', NULL, NULL, '2026-11-20 00:55:22.740971+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('c46540b6-4df9-41e7-97cf-b0c5409c5bbf', '18e42d79-79c4-4883-b5d1-58de7afbce24', 1, '3138d71e-a910-424a-81fe-5d36ad73454b', 'APPROVED', NULL, '2026-11-13 03:55:22.740971+00', '2026-11-13 03:55:22.740971+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('469bed1d-608f-4fae-84f0-05dca86606cc', '18e42d79-79c4-4883-b5d1-58de7afbce24', 2, '88e78ef1-115e-465e-a474-c66b601da4b0', 'APPROVED', NULL, '2026-11-13 06:55:22.740971+00', '2026-11-13 06:55:22.740971+00');


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('1159a748-450f-4982-8eb4-9a25cf4b7599', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '37605283-8706-48ce-a1a7-a042bda2eb98', 'purchase_order', '323c9e0d-f84b-443f-b864-fead074b6985', 'IN_PROGRESS', 2, 2, '72354123-6bc0-4834-8870-3e0faad5b922', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-11-20 00:55:22.740971+00', NULL, NULL);
INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('18e42d79-79c4-4883-b5d1-58de7afbce24', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '37605283-8706-48ce-a1a7-a042bda2eb98', 'purchase_order', 'ebece7de-f8d4-4a0e-9535-19de5524103b', 'APPROVED', 2, 2, '72354123-6bc0-4834-8870-3e0faad5b922', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-11-13 00:55:22.740971+00', NULL, NULL);


--
-- Data for Name: approval_workflows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_workflows (id, organization_id, target_type, name, stages, is_active, created_at, updated_at, archived_at, requester_scope) VALUES ('37605283-8706-48ce-a1a7-a042bda2eb98', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'purchase_order', 'Purchase orders over 10,000', '[{"order": 1, "role": "manager", "label": "Team lead", "approver_user_ids": []}, {"order": 2, "role": "admin", "label": "Finance", "approver_user_ids": []}]', true, '2026-11-22 23:55:23.892038+00', NULL, NULL, '{"everyone": true}');


--
-- Data for Name: audit_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_campaigns (id, organization_id, name, description, scope_type, scope_filter_id, launched_at, deadline, reminder_days_before, last_reminder_sent_at, status, email_subject, email_body, created_by, created_at, updated_at, closed_at) VALUES ('812e907d-b685-46d6-b0db-747796d12350', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Autumn equipment check', 'Confirm you still hold the equipment issued to you.', 'ALL', NULL, '2026-11-18 23:55:24.442304+00', '2026-12-09 23:59:00+00', 3, NULL, 'ACTIVE', NULL, NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-18 22:55:24.442304+00', '2026-11-22 23:55:24.444401+00', NULL);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9f028c07-8ea8-44e6-97a3-c1de4961b80e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'module', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '{"name": "equipment", "subject": "profile:equipment_wms", "before": {"maintenance_warning_days": 7, "warranty_warning_days": 30}, "after": {"maintenance_warning_days": 14, "warranty_warning_days": 60}}', NULL, 'null', '2026-11-22 23:55:18.205212+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('298a78bc-67c4-4915-8423-6d8c8a319751', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', '1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', '{"name": "UHT Milk 3.2%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "48.000", "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "storage_location_name": "Fridge A - Top Shelf", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:55:20.892298+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9c921456-a881-4b2e-a1a0-26b377930388', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', '551aad3c-b30e-4762-ad04-cfea8036881a', '{"name": "Natural Yoghurt 400g", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "24.000", "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "storage_location_name": "Fridge A - Top Shelf", "category_id": "71b9b964-6cbf-428f-9057-f1f5c32f6d3b", "category_name": "Dairy", "category_code": "dairy", "module_name": null}', NULL, 'null', '2026-11-22 23:55:20.892302+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('bc02048e-171e-448c-8b1f-0ffd6ebbd0ed', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', 'c87084e4-384e-4373-ac63-57b0cc965c18', '{"name": "Butter Extra 82%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "36.000", "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "storage_location_name": "Fridge A - Top Shelf", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:55:20.892303+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('7289fb39-4f7b-4b18-9bd2-8ae4a64b885c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', 'a42208bc-6386-443e-a9b2-66013333f26b', '{"name": "Gouda Cheese", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "60.000", "storage_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a", "storage_location_name": "Fridge A - Door", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:55:20.975086+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('234be5cb-3650-4201-8e7f-6197d68bd2ee', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', 'ca258923-6a9d-4a48-937b-4212d28aa570', '{"name": "Sour Cream 18%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "20.000", "storage_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a", "storage_location_name": "Fridge A - Door", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:55:20.975089+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4fa72982-e3dd-4467-963f-053b47add7eb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', '424dc8dc-2d1e-4093-86a3-8928bf10e574', '{"name": "Dell Latitude 5540", "brand": "Dell", "barcode": null, "sku": null, "quantity": "5.000", "storage_location_id": "83b8311b-2dba-4f56-b373-dae82336eda7", "storage_location_name": "Server Rack A", "category_id": "61904b9c-083e-498a-aeae-c000b670bbd4", "category_name": "Laptop", "category_code": "LAPTOP", "module_name": "equipment"}', NULL, 'null', '2026-11-22 23:55:21.021702+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('002d9c41-3a4b-496b-b77d-26fe9ea72929', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', '6116d429-2c1c-473b-bcc7-965e860f1eb1', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": "3.000", "storage_location_id": "83b8311b-2dba-4f56-b373-dae82336eda7", "storage_location_name": "Server Rack A", "category_id": "61904b9c-083e-498a-aeae-c000b670bbd4", "category_name": "Laptop", "category_code": "LAPTOP", "module_name": "equipment"}', NULL, 'null', '2026-11-22 23:55:21.021703+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('735836e0-dce0-4957-80ee-d7a924b2c8f6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', '1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', '{"name": "UHT Milk 3.2%", "before": {"quantity": "48.000"}, "after": {"quantity": "36.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "07c60117-499a-49d7-9c54-bae39d30641c"}', '2026-11-22 23:55:21.15211+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5c8176de-95d3-4215-be86-a1c8b0966af9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', 'c87084e4-384e-4373-ac63-57b0cc965c18', '{"name": "Butter Extra 82%", "before": {"quantity": "36.000"}, "after": {"quantity": "28.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "07c60117-499a-49d7-9c54-bae39d30641c"}', '2026-11-22 23:55:21.152113+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('44202a95-a21a-40d2-bfc4-27e4c699aeba', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "wms_session_id": "f05133de-797e-4093-922e-0b1fb14df75d", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:55:21.65855+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('0330e980-9f68-4d68-a99b-e124de148ba9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'e16e2475-b69e-4715-883b-f18f7de2a781', '{"number": "OUT/2026/004", "wms_session_id": "f05133de-797e-4093-922e-0b1fb14df75d", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:55:21.660566+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9eb8cfc8-6e71-479f-a22d-c05495cc300c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "wms_session_id": "f05133de-797e-4093-922e-0b1fb14df75d", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:55:21.875331+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f6e2c761-87b8-4f82-a016-089cedf87cb0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'e16e2475-b69e-4715-883b-f18f7de2a781', '{"number": "OUT/2026/004", "wms_session_id": "f05133de-797e-4093-922e-0b1fb14df75d", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:55:21.876316+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e9d68303-dbfb-4cc7-ad4c-c30c192da0ca', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "weight_value": null}', NULL, 'null', '2026-11-22 23:55:21.909638+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5b726ec6-6318-4d73-a4a3-e6397a9e3cc4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "name": "Natural Yoghurt 400g", "quantity": "6", "old_quantity": "0"}', NULL, 'null', '2026-11-22 23:55:22.259475+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5982fa76-ac49-456b-93fd-9d2508d1dd37', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "weight_value": null}', NULL, 'null', '2026-11-22 23:55:22.280039+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9217f516-bb50-48ca-ab79-143431e70d9e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "name": "Butter Extra 82%", "quantity": "4", "old_quantity": "0"}', NULL, 'null', '2026-11-22 23:55:22.302779+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('711905e9-3be0-4a99-a598-d612f9cbc0d9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', '551aad3c-b30e-4762-ad04-cfea8036881a', '{"name": "Natural Yoghurt 400g", "before": {"quantity": "24.000"}, "after": {"quantity": "18.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "ae284308-57ae-455c-9c4c-5e8b5d0a9b3a"}', '2026-11-22 23:55:22.568894+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('61b7a8b3-16ef-486a-960c-71466e10a162', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', 'c87084e4-384e-4373-ac63-57b0cc965c18', '{"name": "Butter Extra 82%", "before": {"quantity": "28.000"}, "after": {"quantity": "24.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "ae284308-57ae-455c-9c4c-5e8b5d0a9b3a"}', '2026-11-22 23:55:22.568897+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('78f13878-21e3-47a2-9766-0315465d4ecf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '{"number": "OUT/2026/003", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-22 23:55:22.568897+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('907e21d4-15d4-4996-9149-49e6cb091ad9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', 'a42208bc-6386-443e-a9b2-66013333f26b', '{"name": "Gouda Cheese", "before": {"quantity": "60.000"}, "after": {"quantity": "50.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "e16e2475-b69e-4715-883b-f18f7de2a781"}', '2026-11-22 23:55:22.694913+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4af02a00-335a-4b56-ba47-11da28fe754c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', 'ca258923-6a9d-4a48-937b-4212d28aa570', '{"name": "Sour Cream 18%", "before": {"quantity": "20.000"}, "after": {"quantity": "15.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "e16e2475-b69e-4715-883b-f18f7de2a781"}', '2026-11-22 23:55:22.694915+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('300d1678-cd24-46e2-bfd4-9f705fdd7e7f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'document', 'e16e2475-b69e-4715-883b-f18f7de2a781', '{"number": "OUT/2026/004", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-22 23:55:22.694916+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4ebbf374-1d13-4e11-b64a-8307fa49ae2d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', 'd537ba4a-9505-473d-82ba-b71766bc4cd4', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": "3.000", "storage_location_id": "83b8311b-2dba-4f56-b373-dae82336eda7", "storage_location_name": "Server Rack A", "category_id": "61904b9c-083e-498a-aeae-c000b670bbd4", "category_name": "Laptop", "category_code": "LAPTOP", "module_name": "equipment"}', NULL, 'null', '2026-11-22 23:55:23.148266+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e5600c31-d6cf-4ac8-a35b-0c0ec5a1ff67', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'maker_production_order', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '{"name": "PR/2026/0001", "status": "DRAFT", "output": "Plum Butter", "planned_qty": "12.000"}', NULL, 'null', '2026-11-22 23:55:23.502816+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('6e74bb42-61ff-43b3-8f92-cf7261dd05a9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', '25464f0a-2193-4630-9427-9954b1b2f859', '{"name": "Damson Plums", "before": {"quantity": "40.000"}, "after": {"quantity": "13.600"}}', 'production_run', '{"production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628", "production_order_number": "PR/2026/0001"}', '2026-11-22 23:55:23.612778+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('eb2b6c9e-ce93-4372-bc5e-b0a2659c1508', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', 'e37f1382-b999-493a-9a1b-a5a94d039c98', '{"name": "White Sugar", "before": {"quantity": "25.000"}, "after": {"quantity": "21.220"}}', 'production_run', '{"production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628", "production_order_number": "PR/2026/0001"}', '2026-11-22 23:55:23.655771+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('a9f774d4-9364-4d26-8a7a-18b8df4ba5e0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGE', 'item', '186e287f-bc5d-445d-880a-403060f87da0', '{"name": "Cassia Cinnamon", "before": {"quantity": "0.500"}, "after": {"quantity": "0.440"}}', 'production_run', '{"production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628", "production_order_number": "PR/2026/0001"}', '2026-11-22 23:55:23.68263+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f5818a25-fa87-4121-ad79-472051c57b44', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATE', 'item', 'ab8cb88f-18ca-4c40-bfce-aaac53c56c9b', '{"name": "Plum Butter", "brand": null, "barcode": null, "sku": "PLB-001", "quantity": "11.400", "storage_location_id": "ad2b79f3-8d9b-4c0c-a7b5-29a88f054195", "storage_location_name": "Shelf A - Bottom", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:55:23.728144+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('95cc941f-2d56-4ad9-8801-2ced486b5bae', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'UPDATE', 'maker_production_order', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '{"name": "PR/2026/0001", "old_status": "DRAFT", "new_status": "COMPLETED", "output": "Plum Butter", "quantity": "11.400", "total_cost": "95.36"}', NULL, 'null', '2026-11-22 23:55:23.741044+00');


--
-- Data for Name: audit_response_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('8cdaa4e9-1ab3-42ae-97a6-28750da79a22', '89e8a97e-1819-4d7b-88d8-04a00f35b08b', '685d702d-17d5-456c-8d50-445f470c0584', '13a59844-a2f1-4ef7-96ff-2da1f2257822', 'iPhone 15 Pro', 'SN-100040', 'CONFIRMED', NULL, NULL, '2026-11-22 23:55:24.44939+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('10b5f2a7-8567-4787-bbdc-2a7600fd0094', 'ff6b2e7f-e9e3-4f6c-a10e-c39a534262a5', 'fb89623e-f936-498b-8921-beda74b2fd56', '3ae1b665-4adf-49b8-8c00-435345364f34', 'ThinkPad T14s Gen 4', 'SN-100004', 'DISPUTED', 'DAMAGED', 'The hinge on the lid is cracked and the screen flickers.', '2026-11-22 23:55:24.449395+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('ecb99f63-f1c1-4fad-86a2-225d972cfb14', 'f1898ee8-0f2d-40b1-84f4-23671abd5966', '3e13764f-63d9-4822-b34f-f74bc67f9337', 'e6ee5ee4-9c7b-438d-be16-866aedf19b27', 'ThinkPad T14s Gen 4', 'SN-100005', 'PENDING', NULL, NULL, '2026-11-22 23:55:24.449396+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('09cccdad-1312-4283-812d-62deb3d5cf1f', '8aaae212-5d12-4537-8e60-b3a94b117146', '47aa3b76-7d55-4cb2-a39e-a527cace4d96', 'c7ec15e4-4eb6-4c3f-a3a0-f1816b4fb2d3', 'ThinkPad T14s Gen 4', 'SN-100006', 'PENDING', NULL, NULL, '2026-11-22 23:55:24.449396+00', NULL);


--
-- Data for Name: audit_responses; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('89e8a97e-1819-4d7b-88d8-04a00f35b08b', '812e907d-b685-46d6-b0db-747796d12350', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, 'admin@example.com', 'Demo Administrator', 'OEJZQeNxbSw0Zo9IYUP8V8_ZZg_PXE3WhZO34TUAwmHHtgiavbHue2F_bEFt9Bf30TH9fFOUKQhZ_BGA7-gGcA', '2026-12-09 23:59:00+00', 'CONFIRMED', '2026-11-19 23:55:24.442304+00', NULL, NULL, NULL, NULL, '2026-11-18 23:55:24.442304+00', NULL, '2026-11-22 23:55:24.446296+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('ff6b2e7f-e9e3-4f6c-a10e-c39a534262a5', '812e907d-b685-46d6-b0db-747796d12350', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, 'priya.raman@example.com', 'Priya Raman', '1Ty9earenZ-oTMq6A0-KeY68YLdPhEuRB-RkMZHPdMisE5aZ1wwXuzYN4lhi5nAXVIk-bzCNNZenHq72wn5usQ', '2026-12-09 23:59:00+00', 'DISPUTED', '2026-11-20 00:55:24.442304+00', 'The hinge on the lid is cracked and the screen flickers.', 'DAMAGED', NULL, NULL, '2026-11-18 23:55:24.442304+00', NULL, '2026-11-22 23:55:24.4463+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('f1898ee8-0f2d-40b1-84f4-23671abd5966', '812e907d-b685-46d6-b0db-747796d12350', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, 'marcus.webb@example.com', 'Marcus Webb', 'fWphzN1mjC50i5oK-z30BcAa_KrDR7fNcA3DwWreGqfURW-6RXwwt6oLx6HCDDIx0MZvUsoh8ZOUcxEw2BRWpw', '2026-12-09 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-11-18 23:55:24.442304+00', NULL, '2026-11-22 23:55:24.446301+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('8aaae212-5d12-4537-8e60-b3a94b117146', '812e907d-b685-46d6-b0db-747796d12350', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, 'ava.brennan@example.com', 'Ava Brennan', '3YAqas0235O_F1ttvOLI-dNsl34_14L8i3VGazjQ8ckHBCMiC1eTYFuK4Imoimc1izbYTeJiR5-h4FS4f_0CtQ', '2026-12-09 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-11-18 23:55:24.442304+00', NULL, '2026-11-22 23:55:24.446301+00');


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('61904b9c-083e-498a-aeae-c000b670bbd4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Laptop', 'LAPTOP', 'equipment', NULL, 'laptop', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "os", "type": "text", "label": "Operating System", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('fb238063-3876-4e73-837e-6b7bd2b4b21f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Desktop Computer', 'DESKTOP', 'equipment', NULL, 'monitor', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Monitor / Display', 'MONITOR', 'equipment', NULL, 'monitor-smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "size_inches", "type": "number", "label": "Screen Size (inches)", "visible": true, "required": false, "is_system": true}, {"key": "resolution", "type": "text", "label": "Resolution", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 7, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a193579d-5de1-4f07-bbbb-4cd5df727c37', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Phone / Tablet', 'PHONE', 'equipment', NULL, 'smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "imei", "type": "text", "label": "IMEI", "visible": true, "required": false, "is_system": true}, {"key": "phone_number", "type": "text", "label": "Phone Number", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 3, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('49ff6c0c-6550-4947-9387-a5660ed854af', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fish', 'fish', 'cold_storage', 'FREEZER', 'Fish', NULL, NULL, 4, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('35ed1153-2ed2-434e-a2d6-2c292ed829fe', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Seafood', 'seafood', 'cold_storage', 'FREEZER', 'Shell', NULL, NULL, 5, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('db4d152b-48fd-4875-a40f-5e01f1587213', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen meals', 'frozen_meals', 'cold_storage', 'FREEZER', 'Soup', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('0812b800-44c3-49e5-8c83-cea06ab9688b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen vegetables', 'frozen_vegetables', 'cold_storage', 'FREEZER', 'LeafyGreen', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Network Device', 'NETWORK_DEVICE', 'equipment', NULL, 'wifi', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "mac_address", "type": "text", "label": "MAC Address", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 8, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('434d3e26-b741-4d48-b5b0-9681f5d49739', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Peripheral', 'PERIPHERAL', 'equipment', NULL, 'mouse', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 4, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('3687ac11-5d17-430a-8f30-9cd8fa2fdfad', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Server', 'SERVER', 'equipment', NULL, 'server', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "rack_position", "type": "text", "label": "Rack Position", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "cpu", "type": "text", "label": "CPU", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 10, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Other Equipment', 'OTHER_EQUIPMENT', 'equipment', NULL, 'package', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('e839dce2-3f71-4842-b562-8f04a2c0da27', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Pork', 'pork', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8dd70af9-2ef3-4f4a-a377-6fcab60aad90', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Beef', 'beef', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('489aea56-7437-4065-a509-6d89b419b29c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Poultry', 'poultry', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 3, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('c103f1c9-26bf-47c1-8b45-4443fe1e57fc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen fruits', 'frozen_fruits', 'cold_storage', 'FREEZER', 'Apple', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('12937faa-ab6a-463e-ac4f-5c1e9d8db266', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Ice cream and desserts', 'ice_cream', 'cold_storage', 'FREEZER', 'IceCream', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('283e4305-4d0b-4254-8489-bceee4320a78', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen pizza', 'frozen_pizza', 'cold_storage', 'FREEZER', 'Pizza', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('71b9b964-6cbf-428f-9057-f1f5c32f6d3b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dairy', 'dairy', 'cold_storage', 'FRIDGE', 'Milk', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('758319d9-550b-45ad-8dde-b8995417d9e7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cheese', 'cheese', 'cold_storage', 'FRIDGE', 'Cheese', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('bfc5f32c-be24-4954-ae02-05e460df74b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Deli', 'deli', 'cold_storage', 'FRIDGE', 'Beef', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('dc1568c3-60a8-48ca-b481-9145e63d17c6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Eggs', 'eggs', 'cold_storage', 'FRIDGE', 'Egg', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('be04a701-984b-4adf-a908-af12c3a83aa4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fresh vegetables', 'fresh_vegetables', 'cold_storage', 'FRIDGE', 'LeafyGreen', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('59875da7-b51f-4136-baa7-eacab468e3c1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fresh fruits', 'fresh_fruits', 'cold_storage', 'FRIDGE', 'Apple', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8d28ae6b-0e59-4485-8dc7-6e01f3add6d1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Drinks', 'drinks', 'cold_storage', 'FRIDGE', 'GlassWater', NULL, NULL, 7, NULL, NULL, NULL, true, '[{"key": "abv", "is_system": true, "label": "Alcohol content (ABV %)", "type": "number", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('20280c90-a025-4974-aa06-1e1de62e929e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Sauces and dips', 'sauces', 'cold_storage', 'FRIDGE', 'Pint', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ae92838a-ae6e-48de-9cb4-7e21f98fdf9d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fresh meat', 'fresh_meat', 'cold_storage', 'FRIDGE', 'Drumstick', NULL, NULL, 9, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('722b9d8b-316b-48b6-9f06-923730cc1901', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fresh meals', 'fresh_meals', 'cold_storage', 'FRIDGE', 'CookingPot', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('78f8a4a3-1062-4c17-85e5-a9010abf0c84', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dry products', 'dry_products', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 1, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a0794190-7d38-4dbe-ae36-db5d77916170', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Pasta', 'pasta', 'dry_goods', 'PANTRY', 'Utensils', NULL, NULL, 2, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('9c888290-7fd3-4078-be8d-69e17b29f4c7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Rice and grains', 'rice_grains', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('551d2e41-6689-48be-b57d-262162057ef2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Canned goods', 'canned_goods', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('4f6dfb5b-4b79-4f89-ab60-e5c29c250f32', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Spices and herbs', 'spices_herbs', 'dry_goods', 'PANTRY', 'Leaf', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('7b5fb8c3-f647-4538-a3af-42c3f7c0cb44', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Oils and vinegars', 'oils_vinegars', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('cbddef66-e7ba-42ac-9699-41918ff30f85', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Flours and sugars', 'flours_sugars', 'dry_goods', 'PANTRY', 'Box', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8e28b173-e576-4313-a217-7b275f8a314e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Snacks', 'snacks', 'dry_goods', 'PANTRY', 'Cookie', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('c6ad93d5-21d5-400c-84f2-c103c5ef42c6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Sweets', 'sweets', 'dry_goods', 'PANTRY', 'Candy', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('13d869c0-0add-492e-9dab-a48e9f00f81d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Beverages (non-refrigerated)', 'beverages', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d0f10943-9d54-4cd8-bb52-f1baf64f5c01', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tea and coffee', 'tea_coffee', 'dry_goods', 'PANTRY', 'Coffee', NULL, NULL, 11, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8a9fc351-7741-4779-b17e-93b195b58a5f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cans and jars', 'cans_jars', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 12, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('0169f40a-dc78-4ac6-ae25-8794e3b00fbd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Other', 'other', NULL, NULL, 'Archive', NULL, NULL, 100, NULL, NULL, NULL, true, '[]');


--
-- Data for Name: cycle_count_schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_cost_variances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_extra_costs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('a8fc3e33-a921-4d2f-baad-8ead6f5884b5', '47063b9c-29bb-4ad4-9ff8-e5555b5b512c', '0a398e3e-b4f1-48ef-9ebe-f713d8e1eca8', '2f65f021-681a-4ecb-af6f-4a5d9b667e72', 'Soy Sauce', 'Harvest Row', '2000000000725', 5.000, 5.000, 0.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 11.50, NULL, 57.50, NULL, 57.50, 'USD', 1, NULL, '{"name": "Soy Sauce", "seed": "SEED-DOC", "brand": "Harvest Row"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('bb40bac4-83f5-4f64-b280-42ca57f8c8b3', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', '88596313-affa-43ae-ba60-be8ddcdea620', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 48.000, 48.000, 48.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 216.00, NULL, 216.00, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('5ac8dab1-fdaa-4170-a6ce-beace999d4ff', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '551aad3c-b30e-4762-ad04-cfea8036881a', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 24.000, 24.000, 24.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, NULL, 124.80, NULL, 124.80, 'USD', 2, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('b443948f-1571-4fea-8972-4f853c3c55f2', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', 'c87084e4-384e-4373-ac63-57b0cc965c18', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 36.000, 36.000, 36.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 320.40, NULL, 320.40, 'USD', 3, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('fc05d041-b5c6-43c2-a2a9-1d9bba1e55ef', 'b5959924-e568-46f1-9632-b5f12dcf9d6d', 'a42208bc-6386-443e-a9b2-66013333f26b', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 'Gouda Cheese', 'Meadowlane', '2000000000046', 60.000, 60.000, 60.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 750.00, NULL, 750.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('344d45dc-b8a7-4762-8cfe-61fa4f2c65f1', 'b5959924-e568-46f1-9632-b5f12dcf9d6d', 'ca258923-6a9d-4a48-937b-4212d28aa570', '186a8072-74b4-4c27-9623-5dc3fe827303', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 20.000, 20.000, 20.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 82.00, NULL, 82.00, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('9a579d97-3fc0-4d88-8ce7-087f6afdabca', 'a8f85246-f3f1-4791-b0d1-115dd7eeb216', '424dc8dc-2d1e-4093-86a3-8928bf10e574', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 'Dell Latitude 5540', 'Dell', '2000000010014', 5.000, 5.000, 5.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 4200.00, NULL, 21000.00, NULL, 21000.00, 'USD', 1, NULL, '{"name": "Dell Latitude 5540", "seed": "SEED-DOC", "brand": "Dell"}', '83b8311b-2dba-4f56-b373-dae82336eda7', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('889df13f-fcd5-4268-8293-a9a52822ecfa', 'a8f85246-f3f1-4791-b0d1-115dd7eeb216', '6116d429-2c1c-473b-bcc7-965e860f1eb1', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 'ThinkPad T14s Gen 4', 'Lenovo', '2000000010021', 3.000, 3.000, 3.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, NULL, 17400.00, NULL, 17400.00, 'USD', 2, NULL, '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC", "brand": "Lenovo"}', '83b8311b-2dba-4f56-b373-dae82336eda7', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('c19b2d5d-bb15-4fd9-8c4d-295f20578196', '07c60117-499a-49d7-9c54-bae39d30641c', '1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', '88596313-affa-43ae-ba60-be8ddcdea620', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 12.000, 12.000, 12.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 54.00, NULL, 54.00, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('2f62a817-8d4e-4a54-b1f8-ca45eca5e156', '07c60117-499a-49d7-9c54-bae39d30641c', 'c87084e4-384e-4373-ac63-57b0cc965c18', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 8.000, 8.000, 8.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 71.20, NULL, 71.20, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('3fda14e8-ce91-4743-91cc-4cadcb71a9ef', '0156a326-f4ec-4e77-a326-c90b005c512e', 'a42208bc-6386-443e-a9b2-66013333f26b', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 0.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 125.00, NULL, 125.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('fa026dd6-28bc-4b7f-99d6-e19700779ec5', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '551aad3c-b30e-4762-ad04-cfea8036881a', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 6.000, 6.000, 6.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, NULL, 31.20, NULL, 31.20, 'USD', 1, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('c44e5b41-0afb-46e7-a735-0d0d1b85e5b7', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', 'c87084e4-384e-4373-ac63-57b0cc965c18', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 4.000, 4.000, 4.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 35.60, NULL, 35.60, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('46b59b90-f9da-44c4-afd5-b85d6ffb2dcc', '054cddf7-389d-4924-8f21-f2fed4a146b3', 'd537ba4a-9505-473d-82ba-b71766bc4cd4', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 'ThinkPad T14s Gen 4', NULL, NULL, 3.000, 3.000, 3.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, NULL, 17400.00, NULL, 17400.00, 'USD', 1, 'ba60c0b0-6aeb-4565-ab94-5ec7a4dc340c', '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC"}', '83b8311b-2dba-4f56-b373-dae82336eda7', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('73d9c273-4508-499f-8af1-99af8757c564', 'abf6e7e0-2e80-471f-9dcc-b89bf39c6998', 'a42208bc-6386-443e-a9b2-66013333f26b', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 'Gouda Cheese', 'Meadowlane', '2000000000046', 8.000, 8.000, 0.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 100.00, NULL, 100.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('e86b79db-9e46-4da5-98d2-168350aa084e', 'abf6e7e0-2e80-471f-9dcc-b89bf39c6998', 'ca258923-6a9d-4a48-937b-4212d28aa570', '186a8072-74b4-4c27-9623-5dc3fe827303', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 4.000, 4.000, 0.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 16.40, NULL, 16.40, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('fc7e010e-0f01-4ee1-8a77-7c6c57123333', 'e16e2475-b69e-4715-883b-f18f7de2a781', 'a42208bc-6386-443e-a9b2-66013333f26b', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 10.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 125.00, NULL, 125.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('cac18786-a772-468e-9a41-ceec3add8c6f', 'e16e2475-b69e-4715-883b-f18f7de2a781', 'ca258923-6a9d-4a48-937b-4212d28aa570', '186a8072-74b4-4c27-9623-5dc3fe827303', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 5.000, 5.000, 5.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 20.50, NULL, 20.50, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);


--
-- Data for Name: document_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_number_sequences (organization_id, prefix, next_value) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'PR/2026/', 2);


--
-- Data for Name: document_package_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('5710d237-7cd8-4fa4-83d8-0e6bffc54649', '829b374b-594c-4221-8caa-e2a4bebc1075', 'fa026dd6-28bc-4b7f-99d6-e19700779ec5', 6.000, '2026-11-22 23:55:21.358254+00');
INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('714e5930-2dd6-4879-a6d3-78bda4f989b1', 'e455e089-83c1-4450-bbdb-faaea5bd115f', 'c44e5b41-0afb-46e7-a735-0d0d1b85e5b7', 4.000, '2026-11-22 23:55:21.358254+00');


--
-- Data for Name: document_packages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('829b374b-594c-4221-8caa-e2a4bebc1075', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', 1, NULL, '2026-11-22 23:55:21.358254+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('e455e089-83c1-4450-bbdb-faaea5bd115f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', 2, NULL, '2026-11-22 23:55:21.358254+00', '88e78ef1-115e-465e-a474-c66b601da4b0');


--
-- Data for Name: document_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_profiles (id, organization_id, name, value_tracking_enabled, tax_handling, default_tax_rate, require_partner_tax_id, numbering_format, type_labels, default_unit, visible_line_fields, print_template, default_currency, default_template_id, approval_threshold, approval_required_for_types, created_at, updated_at, number_padding, require_unit_price, confirm_shelf_by_scan, tracking_url_templates, quarantine_location_id, pick_order_strategy) VALUES ('2ebcc5a8-450d-4d71-86c0-bdff115ceb1e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Full Value', true, 'SIMPLE_RATE', NULL, NULL, '{TYPE}/{YEAR}/{SEQ:03d}', 'null', 'pcs', '[]', 'auto', NULL, NULL, NULL, NULL, '2026-11-22 23:55:18.217945+00', '2026-11-22 23:55:18.24987+00', 3, false, false, NULL, 'f1b9eb42-4d1e-4eba-808a-57c4efa60fcb', NULL);


--
-- Data for Name: document_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_shipments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_shipments (id, organization_id, document_id, carrier, tracking_number, shipped_at, shipped_by, notes, created_at) VALUES ('572238b0-cd56-401f-be95-68738a42459a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', 'InPost', '620012345678901234567890', '2026-11-22 23:55:22.395072+00', '88e78ef1-115e-465e-a474-c66b601da4b0', NULL, '2026-11-22 23:55:22.32331+00');


--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_type_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_warehouse_receiving; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_work_item_overlays; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('0156a326-f4ec-4e77-a326-c90b005c512e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'OUT', 'OUT/2026/002', 'CONFIRMED', 'd96cd013-1110-4c9f-8169-3686a1151079', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, '2026-11-20', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 125.00, 0.00, 125.00, 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', NULL, '2026-11-20 11:20:00+00', '2026-11-22 23:55:24.376936+00', '2026-11-20 12:30:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('054cddf7-389d-4924-8f21-f2fed4a146b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'IN', 'IN/2026/001', 'COMPLETED', '6b1d2f12-5af0-4dba-bae0-a4aee0af02e1', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-05', NULL, 'PO/2026/003', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 17400.00, 0.00, 17400.00, 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-05 10:50:00+00', '2026-11-22 23:55:24.377544+00', '2026-11-05 12:00:00+00', '2026-11-05 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('07c60117-499a-49d7-9c54-bae39d30641c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'OUT', 'OUT/2026/001', 'COMPLETED', 'bd9bf7a4-6db4-46b1-a27d-3e6799325bb1', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, '2026-11-18', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 125.20, 0.00, 125.20, 'USD', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-18 08:10:00+00', '2026-11-22 23:55:24.377546+00', '2026-11-18 09:20:00+00', '2026-11-18 10:50:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('47063b9c-29bb-4ad4-9ff8-e5555b5b512c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'INT', 'INT/2026/001', 'DRAFT', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '2026-11-21', NULL, NULL, 'null', NULL, NULL, 57.50, 0.00, 57.50, 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', NULL, NULL, '2026-11-21 08:10:00+00', '2026-11-22 23:55:24.378625+00', NULL, NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('a8f85246-f3f1-4791-b0d1-115dd7eeb216', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'IN', 'IN/2026/004', 'COMPLETED', '6b1d2f12-5af0-4dba-bae0-a4aee0af02e1', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-20', NULL, 'Delivery note 7313', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 38400.00, 0.00, 38400.00, 'USD', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-20 12:05:00+00', '2026-11-22 23:55:24.379021+00', '2026-11-20 13:15:00+00', '2026-11-20 14:45:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('abf6e7e0-2e80-471f-9dcc-b89bf39c6998', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'OUT', 'OUT/2026/005', 'CONFIRMED', 'bd9bf7a4-6db4-46b1-a27d-3e6799325bb1', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, '2026-11-21', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 116.40, 0.00, 116.40, 'USD', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', NULL, '2026-11-21 12:05:00+00', '2026-11-22 23:55:24.37932+00', '2026-11-21 13:15:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'OUT', 'OUT/2026/003', 'COMPLETED', 'bd9bf7a4-6db4-46b1-a27d-3e6799325bb1', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, '2026-11-21', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 66.80, 0.00, 66.80, 'USD', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-21 10:50:00+00', '2026-11-22 23:55:24.379634+00', '2026-11-21 12:00:00+00', '2026-11-21 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('b5959924-e568-46f1-9632-b5f12dcf9d6d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'IN', 'IN/2026/003', 'COMPLETED', 'bd53abd8-5ba9-4dac-a492-ed8e5ae1f52b', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', '2026-11-15', NULL, 'Delivery note 7312', '{"code": "MCC-005", "name": "Bulkline Cash & Carry"}', NULL, NULL, 832.00, 0.00, 832.00, 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-15 09:35:00+00', '2026-11-22 23:55:24.379636+00', '2026-11-15 10:45:00+00', '2026-11-15 12:15:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('e16e2475-b69e-4715-883b-f18f7de2a781', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'OUT', 'OUT/2026/004', 'COMPLETED', 'd96cd013-1110-4c9f-8169-3686a1151079', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, '2026-11-21', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 145.50, 0.00, 145.50, 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-21 11:20:00+00', '2026-11-22 23:55:24.379636+00', '2026-11-21 12:30:00+00', '2026-11-21 14:00:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'IN', 'IN/2026/002', 'COMPLETED', 'b77b5d06-5fa1-43ba-877c-f17d5f6ae5fe', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', '2026-11-13', NULL, 'Delivery note 7311', '{"code": "FFD-004", "name": "Freshfield Wholesale"}', NULL, NULL, 661.20, 0.00, 661.20, 'USD', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-13 09:35:00+00', '2026-11-22 23:55:24.379637+00', '2026-11-13 10:45:00+00', '2026-11-13 12:15:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);


--
-- Data for Name: email_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('47aa3b76-7d55-4cb2-a39e-a527cace4d96', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c7ec15e4-4eb6-4c3f-a3a0-f1816b4fb2d3', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 'Ava Brennan', 'ava.brennan@example.com', '2026-11-08 23:55:23.342147+00', '2027-05-21 23:55:23.342156+00', NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-22 23:55:23.346078+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('3e13764f-63d9-4822-b34f-f74bc67f9337', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e6ee5ee4-9c7b-438d-be16-866aedf19b27', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 'Marcus Webb', 'marcus.webb@example.com', '2026-10-30 23:55:23.342273+00', '2027-05-21 23:55:23.342275+00', NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-22 23:55:23.346082+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('fb89623e-f936-498b-8921-beda74b2fd56', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3ae1b665-4adf-49b8-8c00-435345364f34', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 'Priya Raman', 'priya.raman@example.com', '2026-10-21 23:55:23.342306+00', '2027-05-21 23:55:23.342308+00', NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-22 23:55:23.346083+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('685d702d-17d5-456c-8d50-445f470c0584', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '13a59844-a2f1-4ef7-96ff-2da1f2257822', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 'Demo Administrator', 'admin@example.com', '2026-10-13 23:55:24.411609+00', NULL, NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', NULL, 'Work phone, with case and charger.', NULL, NULL, '2026-11-22 23:55:24.421529+00');


--
-- Data for Name: equipment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_maintenance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('4a30e520-371a-4887-9201-d9d607197ee9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bb52314-35a1-4636-b7a7-cdc75a65c89a', 'REPAIR', 'Replace failed PSU', 'Redundant power supply 2 reported a fault; unit sent to the vendor.', NULL, 'USD', '2026-11-19', 'Northgate IT Distribution', NULL, NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.885807+00', '2026-11-22 23:55:23.885811+00');
INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('b2e20129-34c7-4436-b091-5aeb8b7e9e20', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bc5c4a83-beef-4986-a506-3f25d376505c', 'INSPECTION', 'Battery self-test and runtime check', 'Runtime at full load 11 min, within spec. Batteries due next year.', 120.00, 'USD', '2026-10-13', 'Northgate IT Distribution', NULL, '2027-10-13', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.885813+00', '2026-11-22 23:55:23.885814+00');


--
-- Data for Name: event_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: event_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('48f7f211-598e-4a07-b38b-857b2ae7e84c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "48.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:20.849089+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.849092+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "88596313-affa-43ae-ba60-be8ddcdea620", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:20.899675+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('1803f99d-0dc4-419f-8d38-337b52ce473a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "551aad3c-b30e-4762-ad04-cfea8036881a", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:20.877114+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.877116+00:00", "category_id": "71b9b964-6cbf-428f-9057-f1f5c32f6d3b", "description": null, "expiry_date": null, "module_name": null, "template_id": "5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:20.900915+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('1d16bbfd-c1e4-44b2-97a6-78ae12cace04', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "c87084e4-384e-4373-ac63-57b0cc965c18", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:20.887443+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.887446+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "5c7f5c89-263e-4c53-a993-aeb411b6719e", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:20.90098+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('80956c27-306c-46d2-a41c-3ecd3355c37e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "a42208bc-6386-443e-a9b2-66013333f26b", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "60.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:20.961481+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.961487+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "8bfaab13-de1b-4c44-a5ee-2234005caa20", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:20.977198+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('b58a9ab5-1d7d-4540-b29e-113c1e988c67', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "ca258923-6a9d-4a48-937b-4212d28aa570", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "20.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:20.971747+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.971749+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "186a8072-74b4-4c27-9623-5dc3fe827303", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:20.977255+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('67b0f99e-c5ec-4318-8ada-32d661815e65', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "424dc8dc-2d1e-4093-86a3-8928bf10e574", "name": "Dell Latitude 5540", "brand": "Dell", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "5.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:21.010120+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:21.010123+00:00", "category_id": "61904b9c-083e-498a-aeae-c000b670bbd4", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "38f3a4bc-637c-4187-9ece-bd77b31c2574", "serial_number": null, "purchase_price": "4200.00", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "83b8311b-2dba-4f56-b373-dae82336eda7"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:21.023506+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('ac92eaa6-df36-465a-a2df-16d6eb0b05bc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "6116d429-2c1c-473b-bcc7-965e860f1eb1", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:21.018603+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:21.018606+00:00", "category_id": "61904b9c-083e-498a-aeae-c000b670bbd4", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "dee901bb-0d39-486d-9b0b-a527dd72ccee", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "83b8311b-2dba-4f56-b373-dae82336eda7"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:21.023544+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('ba70796b-0973-4e36-93ce-e0f779ce5f20', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.917526+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "88596313-affa-43ae-ba60-be8ddcdea620", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "changes": {"quantity": 36.0}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:21.153378+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('e866aa98-3455-45a0-83f1-95ffc4a0c906', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "c87084e4-384e-4373-ac63-57b0cc965c18", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "28.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.917526+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "5c7f5c89-263e-4c53-a993-aeb411b6719e", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "changes": {"quantity": 28.0}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:21.1536+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('1a482957-bac8-4c46-bc1e-46246af25473', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "551aad3c-b30e-4762-ad04-cfea8036881a", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "18.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.917526+00:00", "category_id": "71b9b964-6cbf-428f-9057-f1f5c32f6d3b", "description": null, "expiry_date": null, "module_name": null, "template_id": "5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "changes": {"quantity": 18.0}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:22.572+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('dddc6e9b-cb74-4f96-aa3e-f425ffa8e5cf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "c87084e4-384e-4373-ac63-57b0cc965c18", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:21.143662+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "5c7f5c89-263e-4c53-a993-aeb411b6719e", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc"}, "changes": {"quantity": 24.0}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:22.572304+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('0495ebad-0db3-435f-b40b-42dc1884c0b0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'document.completed', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5", "product_code": null, "done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null, "source_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "target_location_id": null, "source_location_code": "SEED-LZCK", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "5c7f5c89-263e-4c53-a993-aeb411b6719e", "product_code": null, "done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null, "source_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "target_location_id": null, "source_location_code": "SEED-LZCK", "target_location_code": null}], "document_id": "ae284308-57ae-455c-9c4c-5e8b5d0a9b3a", "document_type": "OUT", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:22.57234+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('8545ddeb-f1f9-42b0-a3ba-9e647e4288ee', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'document.shipped', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5", "product_code": null, "done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null, "source_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "target_location_id": null, "source_location_code": "SEED-LZCK", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "5c7f5c89-263e-4c53-a993-aeb411b6719e", "product_code": null, "done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null, "source_location_id": "7502d679-f52e-4208-9a0a-6628c5c836fc", "target_location_id": null, "source_location_code": "SEED-LZCK", "target_location_code": null}], "carrier": "InPost", "shipped_at": "2026-11-22T23:55:22.395072+00:00", "document_id": "ae284308-57ae-455c-9c4c-5e8b5d0a9b3a", "tracking_url": "https://inpost.pl/sledzenie-przesylek?number=620012345678901234567890", "document_type": "OUT", "package_count": 2, "document_number": "OUT/2026/003", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "tracking_number": "620012345678901234567890"}', NULL, '2026-11-22 23:55:22.572385+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('1ddc914f-e28e-4c9a-8fc5-d1d09e7f4ef2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "a42208bc-6386-443e-a9b2-66013333f26b", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "50.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-15", "created_at": "2026-11-15 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.982319+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "8bfaab13-de1b-4c44-a5ee-2234005caa20", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a"}, "changes": {"quantity": 50.0}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:22.696192+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('740aaf54-50ae-4a1e-97b1-69e5e1bdff36', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "ca258923-6a9d-4a48-937b-4212d28aa570", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "15.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-15", "created_at": "2026-11-15 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:20.982319+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "186a8072-74b4-4c27-9623-5dc3fe827303", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a"}, "changes": {"quantity": 15.0}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:22.696244+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('af0b41a1-0102-445f-b87d-3ba8cd11c5b0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'document.completed', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "8bfaab13-de1b-4c44-a5ee-2234005caa20", "product_code": null, "done_quantity": 10.0, "expected_quantity": 10.0, "source_po_line_id": null, "source_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a", "target_location_id": null, "source_location_code": "SEED-ZP4U", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "186a8072-74b4-4c27-9623-5dc3fe827303", "product_code": null, "done_quantity": 5.0, "expected_quantity": 5.0, "source_po_line_id": null, "source_location_id": "204807e1-19ac-4a98-a1f5-c89edca8f69a", "target_location_id": null, "source_location_code": "SEED-ZP4U", "target_location_code": null}], "document_id": "e16e2475-b69e-4715-883b-f18f7de2a781", "document_type": "OUT", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:22.696299+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('092243fd-b5fe-4751-98f3-c1ff404f0cd0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "d537ba4a-9505-473d-82ba-b71766bc4cd4", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "b549fb66-cccc-47ea-91f6-a70b2bf9d481", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:23.140724+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:23.140727+00:00", "category_id": "61904b9c-083e-498a-aeae-c000b670bbd4", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "dee901bb-0d39-486d-9b0b-a527dd72ccee", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "83b8311b-2dba-4f56-b373-dae82336eda7"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:23.153612+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('488dd637-8baf-44a4-8131-0fb137f6a6ff', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "25464f0a-2193-4630-9427-9954b1b2f859", "name": "Damson Plums", "brand": "Green Acre", "lot_id": null, "uom_id": "b2625fa3-6f97-4778-9084-c3f6ae2518a9", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "13.600", "image_key": null, "meta_data": null, "added_date": "2026-11-19", "created_at": "2026-11-22 23:55:19.349748+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:23.606478+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "9f643356-0703-44da-bb04-066a379d074a", "serial_number": null, "purchase_price": "3.40", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "807c8e83-690e-46ff-9dfa-e2b8021a074c"}, "changes": {"quantity": 13.6}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:23.615135+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('70aed262-9916-4208-9fd6-3269a59bfc74', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "e37f1382-b999-493a-9a1b-a5a94d039c98", "name": "White Sugar", "brand": "Harvest Row", "lot_id": null, "uom_id": "b2625fa3-6f97-4778-9084-c3f6ae2518a9", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "21.220", "image_key": null, "meta_data": null, "added_date": "2026-11-02", "created_at": "2026-11-22 23:55:19.349754+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:23.653535+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "456bf028-a84f-48ed-a91d-14650d05dcf7", "serial_number": null, "purchase_price": "1.10", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "ad2b79f3-8d9b-4c0c-a7b5-29a88f054195"}, "changes": {"quantity": 21.22}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:23.656987+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('4470953d-e1f1-4bee-a4ac-ca0cbc7dd958', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.updated', '{"item": {"id": "186e287f-bc5d-445d-880a-403060f87da0", "name": "Cassia Cinnamon", "brand": "Saltmill", "lot_id": null, "uom_id": "b2625fa3-6f97-4778-9084-c3f6ae2518a9", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "0.440", "image_key": null, "meta_data": null, "added_date": "2026-10-19", "created_at": "2026-11-22 23:55:19.349755+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:23.680632+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "7c5611bc-acc4-4a97-9f38-62de7bf9faf2", "serial_number": null, "purchase_price": "24.00", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "ad2b79f3-8d9b-4c0c-a7b5-29a88f054195"}, "changes": {"quantity": 0.44}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:23.683655+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('c74edea2-9f9d-46bd-8b53-127c118a4fd7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'item.created', '{"item": {"id": "ab8cb88f-18ca-4c40-bfce-aaac53c56c9b", "name": "Plum Butter", "brand": null, "lot_id": "25ac7c8c-d075-45f0-bceb-475f5ee558ae", "uom_id": "b2625fa3-6f97-4778-9084-c3f6ae2518a9", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "11.400", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:55:23.723595+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:55:23.723597+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "2610b247-12e7-4f9d-adb4-76679eac607b", "serial_number": null, "purchase_price": "8.36", "shelf_location": null, "deletion_reason": null, "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "ad2b79f3-8d9b-4c0c-a7b5-29a88f054195"}, "user_id": "88e78ef1-115e-465e-a474-c66b601da4b0", "organization_id": "b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9"}', NULL, '2026-11-22 23:55:23.730177+00', NULL, 0);


--
-- Data for Name: example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ingredient_nutrition_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_periods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('cc8b681d-0ed2-4ec6-9ab3-b16ac4bf3a53', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '25464f0a-2193-4630-9427-9954b1b2f859', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGED', '{"old": "40.000", "new": "13.600", "reason": "production_run", "production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-22 23:55:23.6098+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d8623a79-999f-4892-af20-55837a925ade', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e37f1382-b999-493a-9a1b-a5a94d039c98', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGED', '{"old": "25.000", "new": "21.220", "reason": "production_run", "production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-22 23:55:23.654789+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('f04a6a7a-1ad9-4073-84cc-dec8dc4109a2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186e287f-bc5d-445d-880a-403060f87da0', '88e78ef1-115e-465e-a474-c66b601da4b0', 'QUANTITY_CHANGED', '{"old": "0.500", "new": "0.440", "reason": "production_run", "production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-22 23:55:23.681744+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('a2824967-1c6e-4de1-9274-077959549999', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ab8cb88f-18ca-4c40-bfce-aaac53c56c9b', '88e78ef1-115e-465e-a474-c66b601da4b0', 'CREATED', '{"created": true, "reason": "production_run", "production_order_id": "1a2f5a6c-e031-4007-840f-9e5fb0192628"}', NULL, '2026-11-22 23:55:23.728987+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('f180e674-5325-41b5-9b02-bd5c8dc45c1c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd537ba4a-9505-473d-82ba-b71766bc4cd4', '72354123-6bc0-4834-8870-3e0faad5b922', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/004", "from_template": "dee901bb-0d39-486d-9b0b-a527dd72ccee"}', '054cddf7-389d-4924-8f21-f2fed4a146b3', '2026-11-22 23:55:23.150513+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('4ccaea1c-f516-4c7a-8dad-3f2bf81d5e50', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', '3138d71e-a910-424a-81fe-5d36ad73454b', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "88596313-affa-43ae-ba60-be8ddcdea620"}', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '2026-11-22 23:55:20.895227+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('3d93a6e0-e63d-445c-8208-68b45eda3003', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '551aad3c-b30e-4762-ad04-cfea8036881a', '3138d71e-a910-424a-81fe-5d36ad73454b', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5"}', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '2026-11-22 23:55:20.895231+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('cc3cf6d6-a2c3-4bfd-83b1-d8acd18fc6af', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c87084e4-384e-4373-ac63-57b0cc965c18', '3138d71e-a910-424a-81fe-5d36ad73454b', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "5c7f5c89-263e-4c53-a993-aeb411b6719e"}', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '2026-11-22 23:55:20.895231+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('b07a3565-f864-45dc-9ad5-458a9c90efb8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'a42208bc-6386-443e-a9b2-66013333f26b', '72354123-6bc0-4834-8870-3e0faad5b922', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "8bfaab13-de1b-4c44-a5ee-2234005caa20"}', 'b5959924-e568-46f1-9632-b5f12dcf9d6d', '2026-11-22 23:55:20.975995+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('81e50f76-2889-46fc-be97-86ccc72586bc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ca258923-6a9d-4a48-937b-4212d28aa570', '72354123-6bc0-4834-8870-3e0faad5b922', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "186a8072-74b4-4c27-9623-5dc3fe827303"}', 'b5959924-e568-46f1-9632-b5f12dcf9d6d', '2026-11-22 23:55:20.975998+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('309989c8-1deb-4a61-a612-8c3014230cbe', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', '3138d71e-a910-424a-81fe-5d36ad73454b', 'QUANTITY_CHANGED', '{"old": "48.000", "new": "36.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', '07c60117-499a-49d7-9c54-bae39d30641c', '2026-11-22 23:55:21.150743+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('b3625961-9dc3-4c43-b7ab-9b4b566bc407', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c87084e4-384e-4373-ac63-57b0cc965c18', '3138d71e-a910-424a-81fe-5d36ad73454b', 'QUANTITY_CHANGED', '{"old": "36.000", "new": "28.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', '07c60117-499a-49d7-9c54-bae39d30641c', '2026-11-22 23:55:21.150746+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('57fcec5b-ba28-4afe-8417-5792ee0a6b79', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '424dc8dc-2d1e-4093-86a3-8928bf10e574', '3138d71e-a910-424a-81fe-5d36ad73454b', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "38f3a4bc-637c-4187-9ece-bd77b31c2574"}', 'a8f85246-f3f1-4791-b0d1-115dd7eeb216', '2026-11-22 23:55:21.022509+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('85bd079c-9283-4f12-b028-fc7858f67e13', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6116d429-2c1c-473b-bcc7-965e860f1eb1', '3138d71e-a910-424a-81fe-5d36ad73454b', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "dee901bb-0d39-486d-9b0b-a527dd72ccee"}', 'a8f85246-f3f1-4791-b0d1-115dd7eeb216', '2026-11-22 23:55:21.022511+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('ee4144c4-dade-4efd-a103-3e75a4764f67', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '551aad3c-b30e-4762-ad04-cfea8036881a', '3138d71e-a910-424a-81fe-5d36ad73454b', 'QUANTITY_CHANGED', '{"old": "24.000", "new": "18.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '2026-11-22 23:55:22.565948+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1308fcf9-296b-4db2-941a-80ac47147c21', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c87084e4-384e-4373-ac63-57b0cc965c18', '3138d71e-a910-424a-81fe-5d36ad73454b', 'QUANTITY_CHANGED', '{"old": "28.000", "new": "24.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '2026-11-22 23:55:22.565953+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('c32ba65b-a2eb-4ef6-a308-c60fe1359254', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'a42208bc-6386-443e-a9b2-66013333f26b', '72354123-6bc0-4834-8870-3e0faad5b922', 'QUANTITY_CHANGED', '{"old": "60.000", "new": "50.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', 'e16e2475-b69e-4715-883b-f18f7de2a781', '2026-11-22 23:55:22.693627+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('e986f4e7-c5c6-4ea4-bb8f-b497e8856f27', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ca258923-6a9d-4a48-937b-4212d28aa570', '72354123-6bc0-4834-8870-3e0faad5b922', 'QUANTITY_CHANGED', '{"old": "20.000", "new": "15.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', 'e16e2475-b69e-4715-883b-f18f7de2a781', '2026-11-22 23:55:22.693631+00');


--
-- Data for Name: item_import_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d3ad0f44-d78c-4621-aef7-4f55460a3103', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e4293c9f-f235-4c74-90cf-43104beff987', '9c888290-7fd3-4078-be8d-69e17b29f4c7', NULL, 'Buckwheat Groats', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', 5.000, NULL, NULL, '2026-11-15', '2027-03-27', NULL, NULL, NULL, 5.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176439+00', '2026-11-22 23:55:19.176444+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0a398e3e-b4f1-48ef-9ebe-f713d8e1eca8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '712b1b64-be5a-468e-bb71-1c466b34dca1', '7b5fb8c3-f647-4538-a3af-42c3f7c0cb44', NULL, 'Soy Sauce', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '2f65f021-681a-4ecb-af6f-4a5d9b667e72', 10.000, NULL, NULL, '2026-11-04', '2027-11-19', NULL, NULL, NULL, 5.30, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176445+00', '2026-11-22 23:55:19.176446+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('65d82134-c64d-4b36-95b5-d925f663aa95', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0030fd00-2868-4ed0-a979-8db88009383a', '8a9fc351-7741-4779-b17e-93b195b58a5f', NULL, 'Tomato Paste', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', 5.000, NULL, NULL, '2026-10-24', '2026-11-22', NULL, NULL, NULL, 4.87, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176447+00', '2026-11-22 23:55:19.176447+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7a5ca430-8e74-4e4a-9663-00288ab1c481', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '20280c90-a025-4974-aa06-1e1de62e929e', NULL, 'Classic Hummus', 'Green Acre', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '3d1e4140-1051-4a9a-9ea0-6c944531f395', 1.000, NULL, NULL, '2026-11-16', '2026-11-19', NULL, NULL, NULL, 5.04, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176448+00', '2026-11-22 23:55:19.176449+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dfba2f92-9196-47e4-ba46-85ca729ef700', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 'e839dce2-3f71-4842-b562-8f04a2c0da27', NULL, 'Minced Pork', 'Fellbrook Farms', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '79c6276d-bdee-4313-bfe6-617ce82fff58', 2.900, NULL, NULL, '2026-11-17', '2026-11-26', NULL, NULL, NULL, 5.56, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176449+00', '2026-11-22 23:55:19.17645+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('abfc7d55-9b4f-484c-ac4b-99f374f0ab76', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0030fd00-2868-4ed0-a979-8db88009383a', '78f8a4a3-1062-4c17-85e5-a9010abf0c84', NULL, 'Baking Powder', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '54a70fb6-27f4-4f28-b22f-1b4929f83ae5', 3.000, NULL, NULL, '2026-09-21', NULL, NULL, NULL, NULL, 5.29, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176451+00', '2026-11-22 23:55:19.176451+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8a9dd754-8204-440f-995b-0ba70726ca49', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b1a280e0-0b57-4555-bff2-9b35db52d777', 'bfc5f32c-be24-4954-ae02-05e460df74b3', NULL, 'Chicken Ham', 'Fellbrook Farms', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '6b4ab39c-bb30-4758-aa0d-15032b0f20ee', 5.500, NULL, NULL, '2026-11-18', '2026-11-21', NULL, NULL, NULL, 5.09, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176452+00', '2026-11-22 23:55:19.176453+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5af4148e-307e-4d85-bbe8-cdd87a229943', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f8525b6-79bd-411d-97d5-b50f45190369', '0812b800-44c3-49e5-8c83-cea06ab9688b', NULL, 'Frozen Chips', 'Northwind Frozen', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 'c15de66e-9440-4a41-bad5-855060db64bd', 4.000, NULL, NULL, '2026-11-02', '2027-08-11', NULL, NULL, NULL, 4.80, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176454+00', '2026-11-22 23:55:19.176454+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('94c145af-cc95-43e5-a73e-785d902dc299', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bba8efb-ff55-4ddf-b46c-ecb4ff175be5', '20280c90-a025-4974-aa06-1e1de62e929e', NULL, 'Classic Hummus', 'Green Acre', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '3d1e4140-1051-4a9a-9ea0-6c944531f395', 1.000, NULL, NULL, '2026-11-19', '2026-11-25', NULL, NULL, NULL, 4.55, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176455+00', '2026-11-22 23:55:19.176455+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f8f03ff9-8986-4b9a-8d87-dbfc7ce2a9cc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e4293c9f-f235-4c74-90cf-43104beff987', '9c888290-7fd3-4078-be8d-69e17b29f4c7', NULL, 'Buckwheat Groats', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', 2.000, NULL, NULL, '2026-10-11', '2027-01-28', NULL, NULL, NULL, 4.44, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176456+00', '2026-11-22 23:55:19.176456+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dbd995f2-669e-4db7-b8bf-f9193b1686a1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e4293c9f-f235-4c74-90cf-43104beff987', '551d2e41-6689-48be-b57d-262162057ef2', NULL, 'Canned Chickpeas', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'd9db61c5-d00b-489f-a1a8-8950a8b4c361', 5.000, NULL, NULL, '2026-09-30', NULL, NULL, NULL, NULL, 5.46, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176457+00', '2026-11-22 23:55:19.176458+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('38eb4f22-5460-41b7-be14-d84c7d7f337a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '712b1b64-be5a-468e-bb71-1c466b34dca1', '8a9fc351-7741-4779-b17e-93b195b58a5f', NULL, 'Tomato Paste', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', 4.000, NULL, NULL, '2026-09-19', '2027-10-06', NULL, NULL, NULL, 4.81, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176459+00', '2026-11-22 23:55:19.176459+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('15a2c318-6a95-48b0-8d69-6073ac5b5576', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '78f8a4a3-1062-4c17-85e5-a9010abf0c84', NULL, 'Instant Tomato Soup', 'Harvest Row', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '581cf261-3985-40ed-84d0-c2fe77f87c04', 3.000, NULL, NULL, '2026-11-11', NULL, NULL, NULL, NULL, 4.79, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.17646+00', '2026-11-22 23:55:19.17646+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3b7c24b2-57cd-4db9-887d-401eb9f8f34c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 'c6ad93d5-21d5-400c-84f2-c103c5ef42c6', NULL, 'Strawberry Jam', 'Orchard & Oak', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fbe3f002-b295-4dd5-b447-33a543fde207', 3.000, NULL, NULL, '2026-10-31', '2027-09-17', NULL, NULL, NULL, 5.03, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176461+00', '2026-11-22 23:55:19.176462+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9187b27d-211d-4566-81f5-2cb2eb2cc966', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '712b1b64-be5a-468e-bb71-1c466b34dca1', '7b5fb8c3-f647-4538-a3af-42c3f7c0cb44', NULL, 'Extra Virgin Olive Oil', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', 9.000, NULL, NULL, '2026-10-20', NULL, NULL, NULL, NULL, 4.69, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176463+00', '2026-11-22 23:55:19.176463+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e1766c5a-9356-47b3-994f-bca1df101f05', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', '8e28b173-e576-4313-a217-7b275f8a314e', NULL, 'Butter Biscuits', 'Orchard & Oak', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 'fd3f8548-b4e0-4ae1-9271-a9492edc6996', 6.000, NULL, NULL, '2026-10-09', '2027-09-27', NULL, NULL, NULL, 5.47, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176464+00', '2026-11-22 23:55:19.176464+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('acdd3997-5ace-4ddf-b501-9ceab886be7e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 'be04a701-984b-4adf-a908-af12c3a83aa4', NULL, 'Carrots 1kg', 'Green Acre', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '9942d546-729a-47e0-978a-c21cdca4a522', 6.800, NULL, NULL, '2026-11-17', '2026-11-22', NULL, NULL, NULL, 4.58, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176465+00', '2026-11-22 23:55:19.176466+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('90054f3d-0f4e-423c-a970-7baf9e9c3995', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', '4f6dfb5b-4b79-4f89-ab60-e5c29c250f32', NULL, 'Iodised Salt', 'Saltmill', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fba93956-79a6-4711-ac06-13306f0838de', 4.000, NULL, NULL, '2026-09-17', '2027-03-05', NULL, NULL, NULL, 4.39, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176466+00', '2026-11-22 23:55:19.176467+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dee0c03e-c83e-4925-a3f9-f25631351b46', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '712b1b64-be5a-468e-bb71-1c466b34dca1', 'c6ad93d5-21d5-400c-84f2-c103c5ef42c6', NULL, 'Wildflower Honey', 'Orchard & Oak', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '859d2067-5f56-4be6-bc03-2bdd56619331', 9.000, NULL, NULL, '2026-11-09', '2026-11-29', NULL, NULL, NULL, 4.27, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176467+00', '2026-11-22 23:55:19.176468+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6caf2b25-74ad-474e-ba57-439be9dc8faf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '71b9b964-6cbf-428f-9057-f1f5c32f6d3b', NULL, 'Natural Yoghurt 400g', 'Meadowlane', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 4.000, NULL, NULL, '2026-11-20', '2026-11-24', NULL, NULL, NULL, 4.70, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176468+00', '2026-11-22 23:55:19.176469+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('97015753-8bb6-4973-9769-2e8160c297fc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0030fd00-2868-4ed0-a979-8db88009383a', 'cbddef66-e7ba-42ac-9699-41918ff30f85', NULL, 'Wheat Flour Type 550', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', 1.000, NULL, NULL, '2026-10-18', '2027-09-01', NULL, NULL, NULL, 4.28, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.17647+00', '2026-11-22 23:55:19.17647+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('58e27714-0750-43d2-9e13-5783bddcddf2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0030fd00-2868-4ed0-a979-8db88009383a', '78f8a4a3-1062-4c17-85e5-a9010abf0c84', NULL, 'Chicken Stock', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '6cbd3ad9-9f78-4bbd-8d0b-47665fbd3f82', 7.000, NULL, NULL, '2026-10-07', '2027-05-20', NULL, NULL, NULL, 5.08, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176471+00', '2026-11-22 23:55:19.176472+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('460fdc77-b291-445a-a255-75c264823ce5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '4f6dfb5b-4b79-4f89-ab60-e5c29c250f32', NULL, 'Dried Basil', 'Saltmill', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'e06824d7-d9d2-4ae5-8117-51df6760f021', 4.000, NULL, NULL, '2026-09-26', NULL, NULL, NULL, NULL, 4.84, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176472+00', '2026-11-22 23:55:19.176473+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('81912555-6efd-4a4f-93cb-a2266dd31ea4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', '551d2e41-6689-48be-b57d-262162057ef2', NULL, 'Canned White Beans', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'ddcadb51-4a46-4841-8200-9675e2e35903', 2.000, NULL, NULL, '2026-09-15', '2027-11-21', NULL, NULL, NULL, 5.24, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176474+00', '2026-11-22 23:55:19.176474+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('badb991d-3d7b-4ba5-92e9-939424b9c11d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f8525b6-79bd-411d-97d5-b50f45190369', '0812b800-44c3-49e5-8c83-cea06ab9688b', NULL, 'Frozen Green Peas', 'Northwind Frozen', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '30cb162e-2e0a-4ea5-9069-4ed172550821', 7.000, NULL, NULL, '2026-11-07', '2027-08-02', NULL, NULL, NULL, 5.37, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176475+00', '2026-11-22 23:55:19.176476+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('780aebe6-e9c9-4570-973d-9d33317a415a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e4293c9f-f235-4c74-90cf-43104beff987', 'cbddef66-e7ba-42ac-9699-41918ff30f85', NULL, 'Vanilla Sugar', 'Harvest Row', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 'e6232713-61fb-4305-b9db-cca330549b49', 3.000, NULL, NULL, '2026-10-27', '2027-04-13', NULL, NULL, NULL, 5.06, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176476+00', '2026-11-22 23:55:19.176477+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5fc4d3e6-4016-4ad2-a66d-77c3a06cfaaa', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 'c6ad93d5-21d5-400c-84f2-c103c5ef42c6', NULL, 'Dark Chocolate 85%', 'Orchard & Oak', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8ae42709-47ed-4252-823b-e3ed5e15ca4f', 8.000, NULL, NULL, '2026-10-16', NULL, NULL, NULL, NULL, 4.85, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176477+00', '2026-11-22 23:55:19.176478+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fae08a81-aab0-43ab-a205-bedcd9e052d6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '712b1b64-be5a-468e-bb71-1c466b34dca1', 'c6ad93d5-21d5-400c-84f2-c103c5ef42c6', NULL, 'Strawberry Jam', 'Orchard & Oak', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fbe3f002-b295-4dd5-b447-33a543fde207', 8.000, NULL, NULL, '2026-10-05', '2027-08-31', NULL, NULL, NULL, 5.73, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176478+00', '2026-11-22 23:55:19.176479+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6743ae73-3697-468a-818a-f9620778d161', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e4293c9f-f235-4c74-90cf-43104beff987', '4f6dfb5b-4b79-4f89-ab60-e5c29c250f32', NULL, 'Ground Cinnamon', 'Saltmill', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7aab2368-ac5e-4b7d-985b-e1da592941bf', 7.000, NULL, NULL, '2026-09-24', '2027-08-21', NULL, NULL, NULL, 4.54, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176479+00', '2026-11-22 23:55:19.17648+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f3aee863-ff80-4f37-9dd0-d8028f1c8db3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 'a0794190-7d38-4dbe-ae36-db5d77916170', NULL, 'Fusilli Pasta', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'ffe885f7-cb4f-45f6-aeaa-e1878f19917c', 2.000, NULL, NULL, '2026-09-13', '2027-10-28', NULL, NULL, NULL, 5.30, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.17648+00', '2026-11-22 23:55:19.176481+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('86e13756-35a0-4139-a7c5-f3972a563e34', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '807c8e83-690e-46ff-9dfa-e2b8021a074c', '59875da7-b51f-4136-baa7-eacab468e3c1', NULL, 'Bananas', 'Green Acre', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '59f96aaa-d5ee-4513-8932-3108a32beeff', 1.800, NULL, NULL, '2026-11-20', '2026-11-23', NULL, NULL, NULL, 4.59, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176481+00', '2026-11-22 23:55:19.176482+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('86563fcc-3a4c-481f-8a45-82f66b56795e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '8a9fc351-7741-4779-b17e-93b195b58a5f', NULL, 'Tomato Paste', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', 6.000, NULL, NULL, '2026-10-25', '2027-06-13', NULL, NULL, NULL, 4.69, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176482+00', '2026-11-22 23:55:19.176483+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b623d8a3-f5be-41bd-aa6e-58e36597abf5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '551d2e41-6689-48be-b57d-262162057ef2', NULL, 'Tuna in Oil', 'Bluewater', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '1d3df1d3-df66-4f30-95bf-9021f2568949', 8.000, NULL, NULL, '2026-10-14', '2027-09-15', NULL, NULL, NULL, 5.15, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176483+00', '2026-11-22 23:55:19.176483+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0caeac27-c0cb-4a6e-b83f-bfbd82e0e383', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7502d679-f52e-4208-9a0a-6628c5c836fc', 'dc1568c3-60a8-48ca-b481-9145e63d17c6', NULL, 'Eggs Medium 10pk', 'Fellbrook Farms', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '29a30a7b-4336-4185-9036-ece90fd01b8c', 6.000, NULL, NULL, '2026-11-18', '2026-11-27', NULL, NULL, NULL, 4.94, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176484+00', '2026-11-22 23:55:19.176484+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f7f0c2ba-5dc8-44e9-bc69-fa9f2b32027a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0030fd00-2868-4ed0-a979-8db88009383a', '78f8a4a3-1062-4c17-85e5-a9010abf0c84', NULL, 'Instant Tomato Soup', 'Harvest Row', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '581cf261-3985-40ed-84d0-c2fe77f87c04', 6.000, NULL, NULL, '2026-09-22', '2027-06-02', NULL, NULL, NULL, 5.57, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176485+00', '2026-11-22 23:55:19.176485+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('03f5811c-b3d3-4e1b-9f5b-fd091633aea7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7954e058-ee63-4bde-9395-af27e73cebcf', '8d28ae6b-0e59-4485-8dc7-6e01f3add6d1', NULL, 'Orange Juice NFC', 'Orchard & Oak', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '350b92a4-09a5-4f3e-b6cb-6a302b6b57e4', 8.000, NULL, NULL, '2026-11-14', NULL, NULL, NULL, NULL, 5.55, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176486+00', '2026-11-22 23:55:19.176486+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2aee48b0-be8a-4d7f-9db1-9605706175aa', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e4293c9f-f235-4c74-90cf-43104beff987', '8e28b173-e576-4313-a217-7b275f8a314e', NULL, 'Walnuts', 'Green Acre', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', 6.000, NULL, NULL, '2026-11-03', '2026-11-28', NULL, NULL, NULL, 5.65, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176487+00', '2026-11-22 23:55:19.176487+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('763cce76-3c47-4b67-aae3-f86ba2b17658', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '712b1b64-be5a-468e-bb71-1c466b34dca1', '8e28b173-e576-4313-a217-7b275f8a314e', NULL, 'Rice Cakes', 'Harvest Row', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '77cd9fe9-d3c2-4ef5-a867-fbc64022e6ee', 6.000, NULL, NULL, '2026-10-23', '2027-01-16', NULL, NULL, NULL, 5.07, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176488+00', '2026-11-22 23:55:19.176488+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7a55e37c-506c-466b-b954-ed79034b0135', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f8525b6-79bd-411d-97d5-b50f45190369', '0812b800-44c3-49e5-8c83-cea06ab9688b', NULL, 'Frozen Green Peas', 'Northwind Frozen', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', '30cb162e-2e0a-4ea5-9069-4ed172550821', 3.000, NULL, NULL, '2026-10-12', '2028-04-23', NULL, NULL, NULL, 4.34, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.176489+00', '2026-11-22 23:55:19.176489+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fcb2eda8-ef56-4cac-8e52-0639bba736d2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0030fd00-2868-4ed0-a979-8db88009383a', '78f8a4a3-1062-4c17-85e5-a9010abf0c84', NULL, 'Corn Flakes', 'Harvest Row', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '49e687bc-7914-4f53-b2e4-7059b36825c2', 10.000, NULL, NULL, '2026-10-01', '2027-02-09', NULL, NULL, NULL, 4.46, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.17649+00', '2026-11-22 23:55:19.17649+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('81e5dc07-9ef5-4e20-b054-2ddc518ac726', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 1.000, NULL, 'SN-100000', '2026-10-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-10-08", "warranty_until": "2029-10-07", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-08 09:00:00+00', '2026-11-22 23:55:19.293731+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a8135f8e-e887-4ea7-985f-3397fdf546a6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 1.000, NULL, 'SN-100001', '2026-07-03', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-03", "warranty_until": "2029-07-02", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-03 09:00:00+00', '2026-11-22 23:55:19.293737+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fbfe196b-d4e3-404c-9bd1-7b87a99a663a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 1.000, NULL, 'SN-100003', '2025-12-21', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-21", "warranty_until": "2028-12-20", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-21 09:00:00+00', '2026-11-22 23:55:19.293739+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c2b76e60-1eba-444c-a624-82f96b89e3b2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', 1.000, NULL, 'SN-100007', '2024-11-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-28", "warranty_until": "2027-11-28", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-28 09:00:00+00', '2026-11-22 23:55:19.293744+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('157fa9d1-f99f-4338-9cf7-7c830dd26057', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', 1.000, NULL, 'SN-100008', '2024-08-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-23", "warranty_until": "2027-08-23", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-23 09:00:00+00', '2026-11-22 23:55:19.293745+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7c7fdece-5d6f-4405-bbe9-0660f3d76acc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', 1.000, NULL, 'SN-100009', '2024-05-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-18", "warranty_until": "2027-05-18", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-18 09:00:00+00', '2026-11-22 23:55:19.293746+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('edb1ae45-7638-4ce1-b7a0-8018e99099ce', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '393624e7-5c8a-4381-b6b2-48854ca15fc6', 1.000, NULL, 'SN-100010', '2024-02-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-11", "warranty_until": "2027-02-10", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-11 09:00:00+00', '2026-11-22 23:55:19.293748+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('48490e5e-3871-4a9c-9acb-f5a8818a870a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '393624e7-5c8a-4381-b6b2-48854ca15fc6', 1.000, NULL, 'SN-100011', '2023-11-06', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-06", "warranty_until": "2026-11-05", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-06 09:00:00+00', '2026-11-22 23:55:19.293749+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('aab4e633-6bf4-464e-b5c2-1da211c7befe', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '393624e7-5c8a-4381-b6b2-48854ca15fc6', 1.000, NULL, 'SN-100012', '2026-08-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-05", "warranty_until": "2029-08-04", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-05 09:00:00+00', '2026-11-22 23:55:19.29375+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('99f1251e-7127-4227-ae77-845c8b0e1a91', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '393624e7-5c8a-4381-b6b2-48854ca15fc6', 1.000, NULL, 'SN-100013', '2026-04-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-30", "warranty_until": "2029-04-29", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-30 09:00:00+00', '2026-11-22 23:55:19.293752+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('33729033-025c-4be1-a170-11aa9a80e866', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 1.000, NULL, 'SN-100014', '2026-01-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-23", "warranty_until": "2029-01-22", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-23 09:00:00+00', '2026-11-22 23:55:19.293753+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('af5bb75b-cf85-4ae3-90e5-c70b80704e45', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '970f90c8-b151-4998-aa91-2c3da24502e3', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 1.000, NULL, 'SN-100015', '2025-10-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-18", "warranty_until": "2028-10-17", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-18 09:00:00+00', '2026-11-22 23:55:19.293754+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4310af98-5caf-4086-8a38-7bf13e55dc01', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 1.000, NULL, 'SN-100016', '2025-07-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-13", "warranty_until": "2028-07-12", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-13 09:00:00+00', '2026-11-22 23:55:19.293755+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f42e056d-455b-4e1e-b0b3-a942954bc1b6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 1.000, NULL, 'SN-100018', '2024-12-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-31", "warranty_until": "2027-12-31", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-31 09:00:00+00', '2026-11-22 23:55:19.293758+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b66ae4bd-ae3f-4d84-a7b5-90fd18830f6f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '1d134e16-fb90-40c5-9d82-6fcde5310d40', 1.000, NULL, 'SN-100019', '2024-09-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-25", "warranty_until": "2027-09-25", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-25 09:00:00+00', '2026-11-22 23:55:19.293759+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8febdf7d-9a03-4016-90d6-4429d7fbe13b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '1d134e16-fb90-40c5-9d82-6fcde5310d40', 1.000, NULL, 'SN-100020', '2024-06-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-20", "warranty_until": "2027-06-20", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-20 09:00:00+00', '2026-11-22 23:55:19.29376+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e58e7310-c395-446f-8e56-715b565aa3a8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '1d134e16-fb90-40c5-9d82-6fcde5310d40', 1.000, NULL, 'SN-100021', '2024-03-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-15", "warranty_until": "2027-03-15", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-15 09:00:00+00', '2026-11-22 23:55:19.293761+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4d791e4d-c29b-4204-8d97-6c7e10ea8772', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '970f90c8-b151-4998-aa91-2c3da24502e3', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', 1.000, NULL, 'SN-100022', '2023-12-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-09", "warranty_until": "2026-12-08", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-09 09:00:00+00', '2026-11-22 23:55:19.293762+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('12cd3ca4-33d7-44f3-8e3c-bd0842cbd2f0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 1.000, NULL, 'SN-100002', '2026-03-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-28", "warranty_until": "2029-03-27", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-28 09:00:00+00', '2026-11-22 23:55:24.473262+00', 'STM-TQ98', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2b966f52-a764-46af-afab-74cdfe2f9581', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 1.000, NULL, 'SN-100017', '2025-04-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-07", "warranty_until": "2028-04-06", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-07 09:00:00+00', '2026-11-22 23:55:24.473266+00', 'STM-541J', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b713a9e4-08a4-4d8d-817d-00c38c0d8ccc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', 1.000, NULL, 'SN-100023', '2026-09-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-07", "warranty_until": "2029-09-06", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-07 09:00:00+00', '2026-11-22 23:55:19.293763+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8f47f4fb-43bf-4688-9837-f1d5151211d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', 1.000, NULL, 'SN-100024', '2026-06-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-02", "warranty_until": "2029-06-01", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-02 09:00:00+00', '2026-11-22 23:55:19.293764+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e7103f6c-cd93-4bcb-8a43-4d19e99dca52', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 'fb238063-3876-4e73-837e-6b7bd2b4b21f', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', 1.000, NULL, 'SN-100025', '2026-02-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-25", "warranty_until": "2029-02-24", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-25 09:00:00+00', '2026-11-22 23:55:19.293764+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('03c0bb6a-8b87-4eb6-b771-06e6e65fdc3c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'de374e76-b529-47e6-99d2-eb12e9edea81', 1.000, NULL, 'SN-100026', '2025-11-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-20", "warranty_until": "2028-11-19", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-20 09:00:00+00', '2026-11-22 23:55:19.293765+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a5622924-d731-4178-b40d-1c8037ce3a6c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'de374e76-b529-47e6-99d2-eb12e9edea81', 1.000, NULL, 'SN-100027', '2025-08-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-15", "warranty_until": "2028-08-14", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-15 09:00:00+00', '2026-11-22 23:55:19.293766+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('cf7812b9-80d5-4993-a664-a4fd3257ca05', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'de374e76-b529-47e6-99d2-eb12e9edea81', 1.000, NULL, 'SN-100028', '2025-05-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-10", "warranty_until": "2028-05-09", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-10 09:00:00+00', '2026-11-22 23:55:19.293767+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0e2154b7-446a-4c1c-b4fc-d15de164cbdc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'LG 27UK850-W', 'LG', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'f5a92539-d900-4300-a545-c226bf03942f', 1.000, NULL, 'SN-100029', '2025-02-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-02", "warranty_until": "2028-02-02", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-02 09:00:00+00', '2026-11-22 23:55:19.293768+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c21296d5-4c03-4e55-a171-77ff81b889a6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'LG 27UK850-W', 'LG', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'f5a92539-d900-4300-a545-c226bf03942f', 1.000, NULL, 'SN-100030', '2024-10-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-28", "warranty_until": "2027-10-28", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-28 09:00:00+00', '2026-11-22 23:55:19.293769+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7adaf469-6026-455f-81a1-6c85923ff491', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'LG 27UK850-W', 'LG', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'f5a92539-d900-4300-a545-c226bf03942f', 1.000, NULL, 'SN-100031', '2024-07-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-23", "warranty_until": "2027-07-23", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-23 09:00:00+00', '2026-11-22 23:55:19.29377+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('72e7da27-fe1f-4ade-836f-c2240288f1b1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'LG 27UK850-W', 'LG', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'f5a92539-d900-4300-a545-c226bf03942f', 1.000, NULL, 'SN-100032', '2024-04-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-17", "warranty_until": "2027-04-17", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-17 09:00:00+00', '2026-11-22 23:55:19.293771+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f00375b9-583a-492f-b89b-112eedc4a840', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7d9039c2-0886-4803-882e-08d9150b2ffa', 1.000, NULL, 'SN-100033', '2024-01-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-11", "warranty_until": "2027-01-10", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-11 09:00:00+00', '2026-11-22 23:55:19.293772+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2d00e434-51f2-48f7-9a9e-509d29b1392c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7d9039c2-0886-4803-882e-08d9150b2ffa', 1.000, NULL, 'SN-100034', '2023-10-06', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-06", "warranty_until": "2026-10-05", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-06 09:00:00+00', '2026-11-22 23:55:19.293773+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('87c5e848-f535-4fa7-af30-1364bb7dc02a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7d9039c2-0886-4803-882e-08d9150b2ffa', 1.000, NULL, 'SN-100035', '2026-07-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-05", "warranty_until": "2029-07-04", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-05 09:00:00+00', '2026-11-22 23:55:19.293774+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ecbb4d7e-c16c-4651-bfc8-e42b4192fee1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', 'ba837c3f-ab21-40f7-9b45-4015d263bf2a', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7d9039c2-0886-4803-882e-08d9150b2ffa', 1.000, NULL, 'SN-100036', '2026-03-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-30", "warranty_until": "2029-03-29", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-30 09:00:00+00', '2026-11-22 23:55:19.293775+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('be8d8557-0b3b-4e1c-b6c9-6684fc58cc46', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 1.000, NULL, 'SN-100037', '2025-12-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-23", "warranty_until": "2028-12-22", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-23 09:00:00+00', '2026-11-22 23:55:19.293776+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('53c1b3e0-0898-4f8b-9ef0-35b2707900ea', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 1.000, NULL, 'SN-100038', '2025-09-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-17", "warranty_until": "2028-09-16", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-17 09:00:00+00', '2026-11-22 23:55:19.293777+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('54bd6daf-0c44-4894-999a-cdefe1a4e280', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 1.000, NULL, 'SN-100039', '2025-06-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-12", "warranty_until": "2028-06-11", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-12 09:00:00+00', '2026-11-22 23:55:19.293778+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9813e9f0-a897-48cd-8ef2-3f88aa0158ad', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '970f90c8-b151-4998-aa91-2c3da24502e3', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '26e19db4-a097-438b-8061-4514b12b7a20', 1.000, NULL, 'SN-100041', '2024-11-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-30", "warranty_until": "2027-11-30", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-30 09:00:00+00', '2026-11-22 23:55:19.29378+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('cf7295bd-cc09-4865-ba18-87352ff36c55', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'iPad Air M2', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8b051841-964b-49ea-be34-235b9fe7344e', 1.000, NULL, 'SN-100042', '2024-08-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-25", "warranty_until": "2027-08-25", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-25 09:00:00+00', '2026-11-22 23:55:19.293781+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('77baf5e9-ed00-44fa-8241-713eaeb73625', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'iPad Air M2', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8b051841-964b-49ea-be34-235b9fe7344e', 1.000, NULL, 'SN-100043', '2024-05-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-20", "warranty_until": "2027-05-20", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-20 09:00:00+00', '2026-11-22 23:55:19.293782+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4491f476-cb7b-4864-9688-ab2c3a36ae39', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 1.000, NULL, 'SN-100044', '2024-02-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-13", "warranty_until": "2027-02-12", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-13 09:00:00+00', '2026-11-22 23:55:19.293783+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d8d53a94-2e2e-4265-af1e-3d6a159a13c2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 1.000, NULL, 'SN-100046', '2026-08-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-07", "warranty_until": "2029-08-06", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-07 09:00:00+00', '2026-11-22 23:55:19.293786+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4e9fbd3c-7b50-4011-8ba7-e5e88bdad26f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 1.000, NULL, 'SN-100047', '2026-05-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-02", "warranty_until": "2029-05-01", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-02 09:00:00+00', '2026-11-22 23:55:19.293787+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ac72159a-fd26-4ef4-9f7d-d4ae7cd18005', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '970f90c8-b151-4998-aa91-2c3da24502e3', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 1.000, NULL, 'SN-100048', '2026-01-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-25", "warranty_until": "2029-01-24", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-25 09:00:00+00', '2026-11-22 23:55:19.293788+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('506857e2-db57-406f-a6e0-637b78b83cef', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '3c2c7245-6264-4871-b2e3-3d7950b14a50', 1.000, NULL, 'SN-100049', '2025-10-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-20", "warranty_until": "2028-10-19", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-20 09:00:00+00', '2026-11-22 23:55:19.293788+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0b274131-585c-46e2-96ee-98febe6e845b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '3c2c7245-6264-4871-b2e3-3d7950b14a50', 1.000, NULL, 'SN-100050', '2025-07-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-15", "warranty_until": "2028-07-14", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-15 09:00:00+00', '2026-11-22 23:55:19.29379+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b3bf91cf-3dfd-4b2e-afab-d1b8d6b3e9b1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '53275f12-8e84-4169-88a2-d3c82e75559d', 1.000, NULL, 'SN-100051', '2025-04-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-09", "warranty_until": "2028-04-08", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-09 09:00:00+00', '2026-11-22 23:55:19.293791+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('938d9c41-86d2-4702-ab17-2a8b71cd3fe7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '53275f12-8e84-4169-88a2-d3c82e75559d', 1.000, NULL, 'SN-100052', '2025-01-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-02", "warranty_until": "2028-01-02", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-02 09:00:00+00', '2026-11-22 23:55:19.293792+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2691904e-364e-47a1-bc18-aee286f6d521', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '53275f12-8e84-4169-88a2-d3c82e75559d', 1.000, NULL, 'SN-100053', '2024-09-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-27", "warranty_until": "2027-09-27", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-27 09:00:00+00', '2026-11-22 23:55:19.293793+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('21a2ed3d-078f-40dd-8c0e-007e4e5d84b4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '53275f12-8e84-4169-88a2-d3c82e75559d', 1.000, NULL, 'SN-100054', '2024-06-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-22", "warranty_until": "2027-06-22", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-22 09:00:00+00', '2026-11-22 23:55:19.293794+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fabe2104-00f8-4b9a-a9d1-edf5fd5cb3b9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 1.000, NULL, 'SN-100055', '2024-03-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-17", "warranty_until": "2027-03-17", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-17 09:00:00+00', '2026-11-22 23:55:19.293795+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f4af99c1-41e0-4ef6-b2a0-7978d9206733', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 1.000, NULL, 'SN-100056', '2023-12-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-11", "warranty_until": "2026-12-10", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-11 09:00:00+00', '2026-11-22 23:55:19.293796+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f7d2ef2b-b813-43e1-95ad-83241701dcc4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 1.000, NULL, 'SN-100057', '2026-09-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-09", "warranty_until": "2029-09-08", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-09 09:00:00+00', '2026-11-22 23:55:19.293796+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ffd544c7-4657-47b9-84d2-c45de26f026e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 1.000, NULL, 'SN-100059', '2026-02-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-27", "warranty_until": "2029-02-26", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-27 09:00:00+00', '2026-11-22 23:55:19.293798+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5130b8be-1a70-4d66-a102-6d0eee37e550', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 1.000, NULL, 'SN-100060', '2025-11-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-22", "warranty_until": "2028-11-21", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-22 09:00:00+00', '2026-11-22 23:55:19.293799+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('45223c3d-9e4e-4991-8609-35e7cbb68e2e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 1.000, NULL, 'SN-100061', '2025-08-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-17", "warranty_until": "2028-08-16", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-17 09:00:00+00', '2026-11-22 23:55:19.2938+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ff50009f-7684-47d5-a847-b0f6995eb8d5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 1.000, NULL, 'SN-100062', '2025-05-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-12", "warranty_until": "2028-05-11", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-12 09:00:00+00', '2026-11-22 23:55:19.293801+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a0a99f71-12fb-4d17-907a-2e230d156fef', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 1.000, NULL, 'SN-100063', '2025-02-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-04", "warranty_until": "2028-02-04", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-04 09:00:00+00', '2026-11-22 23:55:19.293802+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0b4daaee-7527-4b34-8612-a961b7584e49', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'd74363d9-3e93-47e0-beda-2766cc739703', 1.000, NULL, 'SN-100064', '2024-10-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-30", "warranty_until": "2027-10-30", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-30 09:00:00+00', '2026-11-22 23:55:19.293802+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ec4e9cb2-815a-429d-af47-d64de86ed749', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'd74363d9-3e93-47e0-beda-2766cc739703', 1.000, NULL, 'SN-100065', '2024-07-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-25", "warranty_until": "2027-07-25", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-25 09:00:00+00', '2026-11-22 23:55:19.293804+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('37010b24-1516-47a4-8e99-740e91d5d9e9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'd74363d9-3e93-47e0-beda-2766cc739703', 1.000, NULL, 'SN-100066', '2024-04-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-19", "warranty_until": "2027-04-19", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-19 09:00:00+00', '2026-11-22 23:55:19.293805+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8153f4a8-eecf-46df-b589-941a3dbb1495', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'd74363d9-3e93-47e0-beda-2766cc739703', 1.000, NULL, 'SN-100067', '2024-01-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-13", "warranty_until": "2027-01-12", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-13 09:00:00+00', '2026-11-22 23:55:19.293806+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9c970d67-66b9-4a48-955f-05bcf14b3e9f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'd74363d9-3e93-47e0-beda-2766cc739703', 1.000, NULL, 'SN-100068', '2023-10-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-08", "warranty_until": "2026-10-07", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-08 09:00:00+00', '2026-11-22 23:55:19.293807+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d989641a-1ac8-418d-89f6-fed92863c529', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '970f90c8-b151-4998-aa91-2c3da24502e3', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 1.000, NULL, 'SN-100069', '2026-07-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-07", "warranty_until": "2029-07-06", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-07 09:00:00+00', '2026-11-22 23:55:19.293808+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4404533f-b7a9-43c2-ac86-b38e8f08e32a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 1.000, NULL, 'SN-100070', '2026-04-01', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-01", "warranty_until": "2029-03-31", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-01 09:00:00+00', '2026-11-22 23:55:19.29381+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('138f8ad8-5073-47ed-be5c-2d235c71ca4e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 1.000, NULL, 'SN-100071', '2025-12-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-25", "warranty_until": "2028-12-24", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-25 09:00:00+00', '2026-11-22 23:55:19.29381+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('66c97f74-5ae4-483b-8e84-5a0ee2799b7d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 1.000, NULL, 'SN-100072', '2025-09-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-19", "warranty_until": "2028-09-18", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-19 09:00:00+00', '2026-11-22 23:55:19.293811+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2cc6f509-7b9f-4633-b98b-b086255f4075', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 1.000, NULL, 'SN-100073', '2025-06-14', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-14", "warranty_until": "2028-06-13", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-14 09:00:00+00', '2026-11-22 23:55:19.293812+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('813de566-72ce-419e-9676-8d21992312fc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 1.000, NULL, 'SN-100074', '2025-03-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-09", "warranty_until": "2028-03-08", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-09 09:00:00+00', '2026-11-22 23:55:19.293813+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f134a795-b79b-4b74-ade6-0628250f653f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '970f90c8-b151-4998-aa91-2c3da24502e3', '434d3e26-b741-4d48-b5b0-9681f5d49739', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 1.000, NULL, 'SN-100075', '2024-12-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-02", "warranty_until": "2027-12-02", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-02 09:00:00+00', '2026-11-22 23:55:19.293813+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7e22cfc8-0b71-45ee-a174-ba7994ea558d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '3687ac11-5d17-430a-8f30-9cd8fa2fdfad', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', 1.000, NULL, 'SN-100077', '2024-05-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-22", "warranty_until": "2027-05-22", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-22 09:00:00+00', '2026-11-22 23:55:19.293815+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f917bb8e-9743-4720-ad2f-752205873b5f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '3687ac11-5d17-430a-8f30-9cd8fa2fdfad', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', 1.000, NULL, 'SN-100078', '2024-02-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-15", "warranty_until": "2027-02-14", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-15 09:00:00+00', '2026-11-22 23:55:19.293816+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('429988a7-f3b7-4a1f-9328-9aad65e614f8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9d1de691-d507-46d0-b247-f87b130a9cd9', '3687ac11-5d17-430a-8f30-9cd8fa2fdfad', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', 1.000, NULL, 'SN-100079', '2023-11-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-10", "warranty_until": "2026-11-09", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-10 09:00:00+00', '2026-11-22 23:55:19.293817+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b8c0d0fd-64c2-4b2b-95f9-0ba3f8485920', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '3687ac11-5d17-430a-8f30-9cd8fa2fdfad', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'e1a2786b-5308-4a11-9da4-23f1a60f88a3', 1.000, NULL, 'SN-100080', '2026-08-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-09", "warranty_until": "2029-08-08", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-09 09:00:00+00', '2026-11-22 23:55:19.293818+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bc5c4a83-beef-4986-a506-3f25d376505c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4b222d05-5c00-439a-bd4d-7c886003b303', 1.000, NULL, 'SN-100081', '2026-05-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-04", "warranty_until": "2029-05-03", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-04 09:00:00+00', '2026-11-22 23:55:19.293818+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6fe58941-a6ac-40b1-8cd8-9fcd440bc2a1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4b222d05-5c00-439a-bd4d-7c886003b303', 1.000, NULL, 'SN-100082', '2026-01-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-27", "warranty_until": "2029-01-26", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-27 09:00:00+00', '2026-11-22 23:55:19.293819+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9b11e9c7-5756-4729-9b79-aa6c808c2ab5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4b222d05-5c00-439a-bd4d-7c886003b303', 1.000, NULL, 'SN-100083', '2025-10-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-22", "warranty_until": "2028-10-21", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-22 09:00:00+00', '2026-11-22 23:55:19.29382+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3589f947-2b28-4085-82a7-6341cb251076', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4b222d05-5c00-439a-bd4d-7c886003b303', 1.000, NULL, 'SN-100084', '2025-07-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-17", "warranty_until": "2028-07-16", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-17 09:00:00+00', '2026-11-22 23:55:19.293821+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d1d81756-7e4a-4673-8f2a-36a16791f867', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'cea951fa-5471-49de-ae33-003d5fc04dc5', 1.000, NULL, 'SN-100086', '2025-01-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-04", "warranty_until": "2028-01-04", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-04 09:00:00+00', '2026-11-22 23:55:19.293822+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0c70387b-af0f-49a0-8753-9881c880fe60', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'cea951fa-5471-49de-ae33-003d5fc04dc5', 1.000, NULL, 'SN-100087', '2024-09-29', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-29", "warranty_until": "2027-09-29", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-29 09:00:00+00', '2026-11-22 23:55:19.293823+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('551aad3c-b30e-4762-ad04-cfea8036881a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7502d679-f52e-4208-9a0a-6628c5c836fc', '71b9b964-6cbf-428f-9057-f1f5c32f6d3b', NULL, 'Natural Yoghurt 400g', 'Meadowlane', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 18.000, NULL, NULL, '2026-11-13', NULL, NULL, NULL, '{}', 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-11-13 12:15:00+00', '2026-11-22 23:55:22.497356+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3ae1b665-4adf-49b8-8c00-435345364f34', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 1.000, NULL, 'SN-100004', '2025-09-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-15", "warranty_until": "2028-09-14", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-15 09:00:00+00', '2026-11-22 23:55:23.343167+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c7ec15e4-4eb6-4c3f-a3a0-f1816b4fb2d3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 1.000, NULL, 'SN-100006', '2025-03-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-05", "warranty_until": "2028-03-04", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-05 09:00:00+00', '2026-11-22 23:55:23.343168+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('25464f0a-2193-4630-9427-9954b1b2f859', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '807c8e83-690e-46ff-9dfa-e2b8021a074c', NULL, NULL, 'Damson Plums', 'Green Acre', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '9f643356-0703-44da-bb04-066a379d074a', 13.600, NULL, NULL, '2026-11-19', NULL, NULL, NULL, NULL, 3.40, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.349748+00', '2026-11-22 23:55:23.606478+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e37f1382-b999-493a-9a1b-a5a94d039c98', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', NULL, NULL, 'White Sugar', 'Harvest Row', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '456bf028-a84f-48ed-a91d-14650d05dcf7', 21.220, NULL, NULL, '2026-11-02', NULL, NULL, NULL, NULL, 1.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.349754+00', '2026-11-22 23:55:23.653535+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2bb65ea2-29ac-43b0-b43e-5ccfc398db3a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '694f32e6-bdb5-4ede-9476-026ffbdb4ff0', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4b222d05-5c00-439a-bd4d-7c886003b303', 1.000, NULL, 'SN-100085', '2025-04-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-11", "warranty_until": "2028-04-10", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-11 09:00:00+00', '2026-11-22 23:55:24.473266+00', 'STM-S6H0', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('424dc8dc-2d1e-4093-86a3-8928bf10e574', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 5.000, NULL, NULL, '2026-11-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-20", "warranty_until": "2029-11-19", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-20 14:45:00+00', '2026-11-22 23:55:21.045279+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6116d429-2c1c-473b-bcc7-965e860f1eb1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 3.000, NULL, NULL, '2026-11-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-20", "warranty_until": "2029-11-19", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-20 14:45:00+00', '2026-11-22 23:55:21.045283+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1bec4f57-fe7e-4e3a-9e60-7445bb65e5c7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, NULL, 'UHT Milk 3.2%', 'Meadowlane', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '88596313-affa-43ae-ba60-be8ddcdea620', 36.000, NULL, NULL, '2026-11-13', NULL, NULL, NULL, '{}', 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-13 12:15:00+00', '2026-11-22 23:55:21.109316+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c87084e4-384e-4373-ac63-57b0cc965c18', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, NULL, 'Butter Extra 82%', 'Meadowlane', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 24.000, NULL, NULL, '2026-11-13', NULL, NULL, NULL, '{}', 8.90, 'USD', false, false, NULL, NULL, NULL, '2026-11-13 12:15:00+00', '2026-11-22 23:55:22.528981+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a42208bc-6386-443e-a9b2-66013333f26b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, NULL, 'Gouda Cheese', 'Meadowlane', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 50.000, NULL, NULL, '2026-11-15', NULL, NULL, NULL, '{}', 12.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-15 12:15:00+00', '2026-11-22 23:55:22.660785+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ca258923-6a9d-4a48-937b-4212d28aa570', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, NULL, 'Sour Cream 18%', 'Meadowlane', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '186a8072-74b4-4c27-9623-5dc3fe827303', 15.000, NULL, NULL, '2026-11-15', NULL, NULL, NULL, '{}', 4.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-15 12:15:00+00', '2026-11-22 23:55:22.68448+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d537ba4a-9505-473d-82ba-b71766bc4cd4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '83b8311b-2dba-4f56-b373-dae82336eda7', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 3.000, NULL, NULL, '2026-11-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-05", "warranty_until": "2029-11-04", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-05 13:30:00+00', '2026-11-22 23:55:23.188547+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e6ee5ee4-9c7b-438d-be16-866aedf19b27', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '61904b9c-083e-498a-aeae-c000b670bbd4', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 1.000, NULL, 'SN-100005', '2025-06-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-10", "warranty_until": "2028-06-09", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-10 09:00:00+00', '2026-11-22 23:55:23.343169+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('186e287f-bc5d-445d-880a-403060f87da0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', NULL, NULL, 'Cassia Cinnamon', 'Saltmill', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 0.440, NULL, NULL, '2026-10-19', NULL, NULL, NULL, NULL, 24.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:19.349755+00', '2026-11-22 23:55:23.680632+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ab8cb88f-18ca-4c40-bfce-aaac53c56c9b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', NULL, NULL, 'Plum Butter', NULL, NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', '2610b247-12e7-4f9d-adb4-76679eac607b', 11.400, NULL, NULL, '2026-11-22', NULL, NULL, NULL, '{}', 8.36, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:55:23.723595+00', '2026-11-22 23:55:23.723597+00', NULL, NULL, '25ac7c8c-d075-45f0-bceb-475f5ee558ae', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('13a59844-a2f1-4ef7-96ff-2da1f2257822', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2963e348-5403-4a11-acf1-8ea9a41f3812', 'a193579d-5de1-4f07-bbbb-4cd5df727c37', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 1.000, NULL, 'SN-100040', '2025-03-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-07", "warranty_until": "2028-03-06", "equipment_status": "DEPLOYED"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-07 09:00:00+00', '2026-11-22 23:55:24.420437+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('20ffdbbe-fbd4-4188-9a29-e815607350d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 1.000, NULL, 'SN-100045', '2023-11-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-08", "warranty_until": "2026-11-07", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-08 09:00:00+00', '2026-11-22 23:55:24.473265+00', 'STM-MY8F', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('43cd42fe-2d34-4919-a459-53b29ffa7e5c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c29e334b-7662-4015-9afe-8b3526e33065', '96ffee76-e4bb-4acf-a447-6e3fa60dbe11', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 1.000, NULL, 'SN-100058', '2026-06-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-04", "warranty_until": "2029-06-03", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-04 09:00:00+00', '2026-11-22 23:55:24.473267+00', 'STM-BUZD', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8bb52314-35a1-4636-b7a7-cdc75a65c89a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '3687ac11-5d17-430a-8f30-9cd8fa2fdfad', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', '1a2901a8-a6dc-4fed-98b3-ba109ce2c2d4', 1.000, NULL, 'SN-100076', '2024-08-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-27", "warranty_until": "2027-08-27", "equipment_status": "MAINTENANCE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-27 09:00:00+00', '2026-11-22 23:55:24.473268+00', 'STM-BIE0', NULL, NULL, NULL, NULL);


--
-- Data for Name: label_pool; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('b3a92538-fedf-4780-8da7-147a422dbe16', 'STM-S6H0', true, '2026-11-11 23:55:24.471274+00', '2bb65ea2-29ac-43b0-b43e-5ccfc398db3a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('809c95a8-45bf-4e18-bef5-f4e91b71fffb', 'STM-MY8F', true, '2026-11-11 23:55:24.471274+00', '20ffdbbe-fbd4-4188-9a29-e815607350d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('cd636dc0-c069-409f-ac00-cacb68577650', 'STM-BUZD', true, '2026-11-11 23:55:24.471274+00', '43cd42fe-2d34-4919-a459-53b29ffa7e5c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('60ba0a91-c679-4ff8-97bb-84a8b900d15d', 'STM-TQ98', true, '2026-11-11 23:55:24.471274+00', '12cd3ca4-33d7-44f3-8e3c-bd0842cbd2f0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('565ae30c-9501-4e0a-a723-0a7dce7311c6', 'STM-541J', true, '2026-11-11 23:55:24.471274+00', '2b966f52-a764-46af-afab-74cdfe2f9581', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('1f3c8bc6-aa5c-46c0-b509-c3d3674fe304', 'STM-BIE0', true, '2026-11-11 23:55:24.471274+00', '8bb52314-35a1-4636-b7a7-cdc75a65c89a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('d10576b8-f49b-49b6-881f-5bbc0fae2585', 'STM-V4GD', false, NULL, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('b087b8fa-dafa-45f7-b055-ba036c34eca0', 'STM-E1ZN', false, NULL, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('1a484268-a54c-4ef9-869d-b1001f0cd880', 'STM-93MY', false, NULL, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('0ad020f4-099f-4ae0-9645-10f276f5c564', 'STM-X94J', false, NULL, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('d4f1bf3a-8991-487e-980c-2c7b77025ee0', 'STM-WI0K', false, NULL, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('6da65204-6f3c-4f35-a0da-19d61d55245e', 'STM-T4P6', false, NULL, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88e78ef1-115e-465e-a474-c66b601da4b0', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:55:24.471274+00', '2026-11-10 23:55:24.471274+00', 0, NULL);


--
-- Data for Name: location_relocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_bom_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id, make_fresh) VALUES ('7098d7ac-5bee-43c1-bc19-95da9f0f4aab', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', '9f643356-0703-44da-bb04-066a379d074a', 'kg', 10.00, 'stone fruit', '2026-11-22 23:55:19.023417+00', '2026-11-22 23:55:19.023422+00', 'aaa8257a-357e-4ae5-a5b4-bb96b1537714', 2.0000, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', false);
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id, make_fresh) VALUES ('9f50cedd-cf28-49f5-b546-d98c7a26b976', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', '456bf028-a84f-48ed-a91d-14650d05dcf7', 'kg', 5.00, 'sweetener', '2026-11-22 23:55:19.023426+00', '2026-11-22 23:55:19.023426+00', 'aaa8257a-357e-4ae5-a5b4-bb96b1537714', 0.3000, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', false);
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id, make_fresh) VALUES ('85428670-6b20-4273-a6e7-8280140a613c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 'kg', 0.00, 'spice', '2026-11-22 23:55:19.023428+00', '2026-11-22 23:55:19.023428+00', 'aaa8257a-357e-4ae5-a5b4-bb96b1537714', 0.0050, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', false);


--
-- Data for Name: maker_ingredient_prices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_label_facts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_module_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_module_settings (organization_id, reference_direction, created_at, updated_at, allow_overproduction, availability_check_scope, create_on_shortage_strategy, labor_hourly_rate) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'MARGIN', '2026-11-22 23:55:23.430757+00', '2026-11-22 23:55:23.430762+00', true, 'GLOBAL', 'WARN', 0.00);


--
-- Data for Name: maker_production_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_production_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty, estimated_qty, estimated_unit_cost_snapshot) VALUES ('9e925102-0241-4f1f-a369-d704b6663f7c', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '9f643356-0703-44da-bb04-066a379d074a', 26.4000, 'kg', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 3.4000, 'fifo', NULL, 25.0800, 3.4000);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty, estimated_qty, estimated_unit_cost_snapshot) VALUES ('dfeb81de-e5ce-457e-b9f2-c306426186a0', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '456bf028-a84f-48ed-a91d-14650d05dcf7', 3.7800, 'kg', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 1.1000, 'fifo', NULL, 3.5910, 1.1000);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty, estimated_qty, estimated_unit_cost_snapshot) VALUES ('368ce83d-89d3-4429-9de1-f7f8dae5e184', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 0.0600, 'kg', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 24.0000, 'fifo', NULL, 0.0570, 24.0000);


--
-- Data for Name: maker_production_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_orders (id, organization_id, output_template_id, planned_qty, output_storage_location_id, status, total_cost, production_date, notes, created_by, completed_by, created_at, completed_at, cancel_reason, produced_item_id, recipe_id, actual_qty, overproduced, scrap_qty, unit_cost_snapshot, reference_price_snapshot, result_per_unit, result_per_batch, number, short_at_create, output_lot_name, estimated_total_cost, output_lot_id, started_on, started_at, material_cost, unshelved_cost, steps, planned_for, output_layer_id) VALUES ('1a2f5a6c-e031-4007-840f-9e5fb0192628', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', 12.000, 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 'COMPLETED', 95.36, '2026-11-22', 'Autumn batch, first of the season.', '88e78ef1-115e-465e-a474-c66b601da4b0', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.499357+00', '2026-11-22 23:55:23.740457+00', NULL, 'ab8cb88f-18ca-4c40-bfce-aaac53c56c9b', 'aaa8257a-357e-4ae5-a5b4-bb96b1537714', 11.400, false, 0.600, 8.3647, 18.00, 9.64, 9.64, 'PR/2026/0001', false, '20261122-1', 90.59, '25ac7c8c-d075-45f0-bceb-475f5ee558ae', NULL, NULL, NULL, NULL, NULL, NULL, '489c87b6-c11d-4680-aabc-4d3687636387');


--
-- Data for Name: maker_production_portions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipe_cost_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_recipes (id, organization_id, output_template_id, name, batch_yield_qty, batch_yield_uom_id, process_steps, reference_price, is_default, source_recipe_id, source_snapshot_at, created_at, updated_at) VALUES ('aaa8257a-357e-4ae5-a5b4-bb96b1537714', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', 'Plum Butter', 1.0000, NULL, NULL, 18.00, true, NULL, NULL, '2026-11-22 23:55:19.004452+00', '2026-11-22 23:55:19.004457+00');


--
-- Data for Name: maker_shelf_lives; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: meal_plan_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('1fa04af1-fab6-405a-bbbc-d337b4eedd9e', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-16', 'BREAKFAST', '99c61dfa-4136-43a0-87a0-b11f561b043a', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('bedd96ba-fd59-4b54-94ba-73996be9cd42', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-16', 'DINNER', 'b24b81d2-31ee-4760-8e97-af323f78a386', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('5abeeda8-453a-45c8-8fed-2043320027c7', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-17', 'DINNER', '9bf707b1-ad29-41dd-bb22-3ed6d808bd75', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('c272d66d-c2b4-45b3-9a0b-9b7383eae983', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-18', 'BREAKFAST', '99c61dfa-4136-43a0-87a0-b11f561b043a', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('95049ccb-fd42-44a9-9235-db61526648a8', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-18', 'DINNER', '49a53c66-486c-49f4-b2d3-ca245afe1bd7', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('7a5dab39-2b37-4d95-91a1-7b3c4d9ff5b2', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-19', 'DINNER', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('17c70576-6fef-427b-a5c1-12a9f1362c9a', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-20', 'DINNER', '626b082d-3f9a-4d5f-a2ef-591295da5557', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('d2717804-ebf8-42a8-9f75-4b3077634350', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-21', 'BREAKFAST', '2895a983-1ba4-42d7-bf18-72d7e88727c9', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('a6951c0d-099a-4869-a38c-2b9cad6e70ae', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-21', 'DINNER', 'a7812cf8-8320-4e1f-80b1-b5bc1958bd43', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('84b750d6-bd7b-4a52-8488-5864fdaa1f93', 'f39ec37f-7a4b-4122-8507-bf471dec48a5', '2026-11-22', 'BREAKFAST', '455af4ce-708a-4e75-a489-dadfbad5e0f7', NULL, NULL, 0);


--
-- Data for Name: meal_plans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plans (id, organization_id, name, start_date, end_date, enabled_slots, default_servings, shopping_list_id, notes, created_by, created_at, updated_at, listed_meals) VALUES ('f39ec37f-7a4b-4122-8507-bf471dec48a5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'This week', '2026-11-16', '2026-11-22', '["BREAKFAST", "DINNER"]', NULL, '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.847727+00', '2026-11-22 23:55:23.847731+00', NULL);


--
-- Data for Name: module_installations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.organizations (id, name, created_at, created_by, enabled_modules, allowed_modules, settings, short_id, active_profile_id, onboarding_completed, focus_module, pre_focus_enabled_modules, pre_onboarding_manual_modules, currency, timezone, tax_id, country, print_page_size, address, logo_url) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Larkspur Trading Co.', '2026-11-22 23:55:17.984543+00', '88e78ef1-115e-465e-a474-c66b601da4b0', '["announcements", "locations", "partners", "approvals", "maker", "warehouse", "api_keys", "core", "mcp_server", "categories", "printing", "recipes", "purchase_orders", "stock_takes", "shopping_lists", "nutrition", "items", "stats", "equipment"]', NULL, '{"module:equipment": {"warranty_warning_days": 60, "maintenance_warning_days": 14, "__schema_version": 1}, "module:stats": {"enable_analytics": true, "show_inventory_value": true, "__schema_version": 1}, "show_module_data": true, "module:approvals": {"allow_admin_self_approve": true}, "demo_last_reset_at": "2026-11-22T23:55:24.775383+00:00"}', NULL, 'equipment_wms', true, NULL, NULL, NULL, 'USD', 'UTC', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('6b1d2f12-5af0-4dba-bae0-a4aee0af02e1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Eurodata Systems', 'SUP-001', 'SUPPLIER', NULL, false, 'orders@eurodata.example.com', '+44 20 7946 0101', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034092+00', '2026-11-22 23:55:19.034097+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('1ffca832-7eb6-4d75-999b-5ca28121e297', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Northgate IT Distribution', 'ITD-002', 'SUPPLIER', NULL, false, 'sales@northgate-it.example.com', '+44 20 7946 0102', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034099+00', '2026-11-22 23:55:19.034099+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('8422568e-14d5-4924-988e-36ee9e285aed', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'TechSupply Europe', 'TSE-003', 'SUPPLIER', NULL, false, 'orders@techsupply.example.net', '+44 20 7946 0103', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.0341+00', '2026-11-22 23:55:19.034101+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('b77b5d06-5fa1-43ba-877c-f17d5f6ae5fe', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Freshfield Wholesale', 'FFD-004', 'SUPPLIER', NULL, false, 'orders@freshfield.example.com', '+44 20 7946 0104', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034101+00', '2026-11-22 23:55:19.034102+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('bd53abd8-5ba9-4dac-a492-ed8e5ae1f52b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Bulkline Cash & Carry', 'MCC-005', 'SUPPLIER', NULL, false, 'b2b@bulkline.example.com', '+44 20 7946 0105', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034102+00', '2026-11-22 23:55:19.034103+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('9e838ad6-5004-4202-9d40-d4b4a8b95424', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cornerstore Deliveries', 'ZAB-006', 'SUPPLIER', NULL, false, 'deliveries@cornerstore.example.com', '+44 20 7946 0106', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034104+00', '2026-11-22 23:55:19.034104+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('08475ecb-220a-4626-b492-0ab0f6d37e11', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cisco Systems', 'CSC-007', 'MANUFACTURER', NULL, false, 'enterprise@cisco.example.com', '+44 20 7946 0107', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034105+00', '2026-11-22 23:55:19.034105+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('13e8a1fa-dfaa-4885-b580-1242bff89dbb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dell Technologies', 'DLL-008', 'MANUFACTURER', NULL, false, 'enterprise@dell.example.com', '+44 20 7946 0108', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034106+00', '2026-11-22 23:55:19.034106+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('10422fca-da24-43d2-b209-daa383939263', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Hewlett Packard Enterprise', 'HPE-009', 'MANUFACTURER', NULL, false, 'sales@hpe.example.com', '+44 20 7946 0109', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034107+00', '2026-11-22 23:55:19.034108+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('9b438f34-146c-4271-970f-2daf91ac126d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Apple', 'APL-010', 'MANUFACTURER', NULL, false, 'business@apple.example.com', '+44 20 7946 0110', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034109+00', '2026-11-22 23:55:19.034109+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('bd9bf7a4-6db4-46b1-a27d-3e6799325bb1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Harper Catering', 'CUS-011', 'CUSTOMER', NULL, false, 'orders@harpercatering.example.com', '+44 20 7946 0111', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.03411+00', '2026-11-22 23:55:19.034111+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('d96cd013-1110-4c9f-8169-3686a1151079', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Officeworks Services', 'CUS-012', 'CUSTOMER', NULL, false, 'office@officeworks.example.net', '+44 20 7946 0112', NULL, NULL, NULL, NULL, true, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:19.034111+00', '2026-11-22 23:55:19.034112+00');


--
-- Data for Name: picking_session_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: picking_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: po_partner_pricelist; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('50bc087a-bb45-4ce6-ae56-a82a071a5f50', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b77b5d06-5fa1-43ba-877c-f17d5f6ae5fe', '9f643356-0703-44da-bb04-066a379d074a', 3.2000, 'USD', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:55:24.524429+00', '2026-11-22 23:55:24.524433+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('87806d3c-d3c1-4959-92b1-a643d659fb70', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bd53abd8-5ba9-4dac-a492-ed8e5ae1f52b', '456bf028-a84f-48ed-a91d-14650d05dcf7', 1.0500, 'USD', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:55:24.524434+00', '2026-11-22 23:55:24.524434+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('fd1da3d8-04e0-4ab3-8cd0-949266655475', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bd53abd8-5ba9-4dac-a492-ed8e5ae1f52b', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 22.5000, 'USD', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:55:24.524435+00', '2026-11-22 23:55:24.524435+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('6a93bb73-8144-4474-a137-a898836ab7e2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6b1d2f12-5af0-4dba-bae0-a4aee0af02e1', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 4100.0000, 'USD', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:55:24.524436+00', '2026-11-22 23:55:24.524436+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('2b1449a6-7e1b-4670-a536-fc6b49a9f374', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1ffca832-7eb6-4d75-999b-5ca28121e297', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 4180.0000, 'USD', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:55:24.524436+00', '2026-11-22 23:55:24.524437+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('b51b8eab-9d74-484d-84e3-440b51b38fec', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1ffca832-7eb6-4d75-999b-5ca28121e297', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 5650.0000, 'USD', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:55:24.524437+00', '2026-11-22 23:55:24.524438+00');


--
-- Data for Name: po_reorder_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('86ccaca1-17aa-4bdf-88a9-06a13e7bc5cf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 20.000, 40.000, 10.000, 'b77b5d06-5fa1-43ba-877c-f17d5f6ae5fe', NULL, '2026-11-22 23:55:24.51233+00', '2026-11-22 23:55:24.512335+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('75a9952c-42cd-4cce-a11d-92d4494d206b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 5.000, 25.000, 2.000, 'bd53abd8-5ba9-4dac-a492-ed8e5ae1f52b', NULL, '2026-11-22 23:55:24.512336+00', '2026-11-22 23:55:24.512336+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('09b38a81-8d1a-4ed6-b421-59fe04733f00', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 0.100, 0.500, 0.100, 'bd53abd8-5ba9-4dac-a492-ed8e5ae1f52b', NULL, '2026-11-22 23:55:24.512337+00', '2026-11-22 23:55:24.512338+00');


--
-- Data for Name: po_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_settings (id, organization_id, approval_threshold, approval_required, created_at, updated_at) VALUES ('e341743a-f649-4e8f-99bf-f0853a225da2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 10000.00, false, '2026-11-22 23:55:24.400365+00', '2026-11-22 23:55:24.40037+00');


--
-- Data for Name: print_agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: print_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('88596313-affa-43ae-ba60-be8ddcdea620', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.2, "carbs_g": 4.8, "protein_g": 3.2, "calories_kcal": 62}}', '2026-11-22 23:55:18.967781+00', '2026-11-22 23:55:18.967788+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 7.5, "protein_g": 4.0, "calories_kcal": 67}}', '2026-11-22 23:55:18.96779+00', '2026-11-22 23:55:18.967791+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5c7f5c89-263e-4c53-a993-aeb411b6719e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Butter Extra 82%', 'Meadowlane', '2000000000039', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 200.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 82.0, "carbs_g": 0.8, "protein_g": 0.5, "calories_kcal": 748}}', '2026-11-22 23:55:18.967792+00', '2026-11-22 23:55:18.967793+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8bfaab13-de1b-4c44-a5ee-2234005caa20', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Gouda Cheese', 'Meadowlane', '2000000000046', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 300.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 1.3, "protein_g": 24.0, "calories_kcal": 356}}', '2026-11-22 23:55:18.967794+00', '2026-11-22 23:55:18.967795+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('186a8072-74b4-4c27-9623-5dc3fe827303', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Sour Cream 18%', 'Meadowlane', '2000000000053', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 300.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 18.0, "carbs_g": 3.4, "protein_g": 2.5, "calories_kcal": 182}}', '2026-11-22 23:55:18.967796+00', '2026-11-22 23:55:18.967797+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('94b38469-1085-42a3-b35e-0993f63cb873', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cottage Cheese', 'Meadowlane', '2000000000060', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 200.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 5.0, "protein_g": 9.0, "calories_kcal": 125}}', '2026-11-22 23:55:18.967798+00', '2026-11-22 23:55:18.967798+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('18ca310d-375b-440d-b5b3-103375645b97', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Lean Quark', 'Meadowlane', '2000000000077', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 250.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 3.5, "protein_g": 18.0, "calories_kcal": 85}}', '2026-11-22 23:55:18.967799+00', '2026-11-22 23:55:18.9678+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('29a30a7b-4336-4185-9036-ece90fd01b8c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Eggs Medium 10pk', 'Fellbrook Farms', '2000000000084', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 600.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 1.1, "protein_g": 13.0, "calories_kcal": 155}}', '2026-11-22 23:55:18.967801+00', '2026-11-22 23:55:18.967802+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6b4ab39c-bb30-4758-aa0d-15032b0f20ee', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Chicken Ham', 'Fellbrook Farms', '2000000000091', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 4.5, "carbs_g": 1.0, "protein_g": 16.0, "calories_kcal": 110}}', '2026-11-22 23:55:18.967804+00', '2026-11-22 23:55:18.967804+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1eeec954-bd5c-4e4b-9d6c-7a1ef248e151', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Pork Frankfurters', 'Fellbrook Farms', '2000000000107', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 22.0, "carbs_g": 2.0, "protein_g": 12.0, "calories_kcal": 253}}', '2026-11-22 23:55:18.967805+00', '2026-11-22 23:55:18.967806+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b5777f97-e3a2-4323-811b-de421dd9bddb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Smoked Sausage', 'Fellbrook Farms', '2000000000114', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 3.0, "protein_g": 12.0, "calories_kcal": 301}}', '2026-11-22 23:55:18.967807+00', '2026-11-22 23:55:18.967807+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9b9a3bf9-0541-4563-800a-bcbd0e2c203a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Smoked Bacon', 'Fellbrook Farms', '2000000000121', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 38.0, "carbs_g": 1.0, "protein_g": 12.0, "calories_kcal": 393}}', '2026-11-22 23:55:18.967808+00', '2026-11-22 23:55:18.967809+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('dcb0e7fc-e8ed-4efb-b6c1-ff3fb3f7c843', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Chicken Breast Fillet', 'Fellbrook Farms', '2000000000138', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 600.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.2, "carbs_g": 0.0, "protein_g": 23.0, "calories_kcal": 110}}', '2026-11-22 23:55:18.96781+00', '2026-11-22 23:55:18.967811+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4e0d3f82-9bba-4bcd-b32f-ea051c50424c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Smoked Salmon', 'Bluewater', '2000000000145', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 150.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 13.0, "carbs_g": 0.0, "protein_g": 20.0, "calories_kcal": 196}}', '2026-11-22 23:55:18.967812+00', '2026-11-22 23:55:18.967812+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c8aa39a3-302c-470b-81c2-36e3470fe1a2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Mayonnaise', 'Harvest Row', '2000000000152', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 300.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 79.0, "carbs_g": 1.0, "protein_g": 1.0, "calories_kcal": 714}}', '2026-11-22 23:55:18.967813+00', '2026-11-22 23:55:18.967814+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c66e542e-9b7c-4824-bb2b-ff2aa8cd01ab', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tomato Ketchup', 'Harvest Row', '2000000000169', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 26.0, "protein_g": 1.0, "calories_kcal": 112}}', '2026-11-22 23:55:18.967814+00', '2026-11-22 23:55:18.967815+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('350b92a4-09a5-4f3e-b6cb-6a302b6b57e4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Orange Juice NFC', 'Orchard & Oak', '2000000000176', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.7, "calories_kcal": 45}}', '2026-11-22 23:55:18.967816+00', '2026-11-22 23:55:18.967816+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7cf16784-7618-4faf-8939-3df71da02629', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Chocolate Milk Drink', 'Meadowlane', '2000000000183', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 14.0, "protein_g": 3.2, "calories_kcal": 84}}', '2026-11-22 23:55:18.967817+00', '2026-11-22 23:55:18.967817+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3d1e4140-1051-4a9a-9ea0-6c944531f395', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Classic Hummus', 'Green Acre', '2000000000190', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 200.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 14.0, "carbs_g": 14.0, "protein_g": 7.0, "calories_kcal": 215}}', '2026-11-22 23:55:18.967818+00', '2026-11-22 23:55:18.967819+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3ff4ff9a-eb60-43f9-bf93-75e78ea86aae', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Red Pesto', 'Harvest Row', '2000000000206', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 190.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 25.0, "carbs_g": 5.0, "protein_g": 3.0, "calories_kcal": 267}}', '2026-11-22 23:55:18.967819+00', '2026-11-22 23:55:18.96782+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6b82f029-6abe-4e7f-9d73-a4e0f24070cf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Broccoli', 'Green Acre', '7671591271129', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 7.0, "protein_g": 2.8, "calories_kcal": 34}}', '2026-11-22 23:55:18.967823+00', '2026-11-22 23:55:18.967823+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('73a461e7-221b-4a78-bbb0-87a265426b07', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cherry Tomatoes', 'Green Acre', '1461382306422', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 3.9, "protein_g": 0.9, "calories_kcal": 18}}', '2026-11-22 23:55:18.967824+00', '2026-11-22 23:55:18.967825+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b3a366b8-8cb2-42cb-bba8-cbbfab3632a7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cucumber', 'Green Acre', '3824875293377', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 300.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 3.6, "protein_g": 0.7, "calories_kcal": 16}}', '2026-11-22 23:55:18.967826+00', '2026-11-22 23:55:18.967826+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cdaae6ff-5aa7-4feb-b4b4-196bca3399db', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fuji Apples', 'Green Acre', '0774915747311', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 14.0, "protein_g": 0.3, "calories_kcal": 52}}', '2026-11-22 23:55:18.967827+00', '2026-11-22 23:55:18.967828+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('72881321-0c14-453e-9ecb-e8d106a2e2b7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Green Grapes', 'Green Acre', '2178682164889', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 18.0, "protein_g": 0.7, "calories_kcal": 69}}', '2026-11-22 23:55:18.967829+00', '2026-11-22 23:55:18.967829+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e43e6c31-9675-4fbb-8114-d7e936436234', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Strawberries', 'Green Acre', '9922816702736', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 7.7, "protein_g": 0.7, "calories_kcal": 32}}', '2026-11-22 23:55:18.96783+00', '2026-11-22 23:55:18.967831+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('59f96aaa-d5ee-4513-8932-3108a32beeff', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Bananas', 'Green Acre', '6348208271001', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 23.0, "protein_g": 1.1, "calories_kcal": 89}}', '2026-11-22 23:55:18.967832+00', '2026-11-22 23:55:18.967833+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8f809a6d-ac55-48db-ac03-d499f3f08fc8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Vanilla Ice Cream', 'Northwind Frozen', '2000000000299', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 24.0, "protein_g": 3.5, "calories_kcal": 207}}', '2026-11-22 23:55:18.967834+00', '2026-11-22 23:55:18.967834+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b05647a1-7409-43bd-a03d-0a486582cd83', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen Pepperoni Pizza', 'Northwind Frozen', '2000000000305', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 350.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 12.0, "carbs_g": 28.0, "protein_g": 11.0, "calories_kcal": 266}}', '2026-11-22 23:55:18.967835+00', '2026-11-22 23:55:18.967836+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8f66cb5b-3646-4e1e-bc24-924205606d61', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Potato and Cheese Dumplings', 'Northwind Frozen', '2000000000312', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 600.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 28.0, "protein_g": 5.0, "calories_kcal": 196}}', '2026-11-22 23:55:18.967837+00', '2026-11-22 23:55:18.967837+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('351d6707-bae4-4480-948c-14e51721580c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fish Fingers', 'Bluewater', '2000000000329', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 10.0, "carbs_g": 22.0, "protein_g": 10.0, "calories_kcal": 215}}', '2026-11-22 23:55:18.967838+00', '2026-11-22 23:55:18.967838+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6a29f480-20d7-448f-902b-a7db92d3b29e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen Mixed Vegetables', 'Northwind Frozen', '2000000000336', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 750.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 5.0, "protein_g": 2.0, "calories_kcal": 35}}', '2026-11-22 23:55:18.967839+00', '2026-11-22 23:55:18.96784+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('30cb162e-2e0a-4ea5-9069-4ed172550821', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen Green Peas', 'Northwind Frozen', '2000000000343', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 450.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 14.0, "protein_g": 5.0, "calories_kcal": 81}}', '2026-11-22 23:55:18.96784+00', '2026-11-22 23:55:18.967841+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3566ff7c-c43f-460f-9e4e-a78d7732c3f5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen Blueberries', 'Northwind Frozen', '2000000000367', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 14.0, "protein_g": 0.7, "calories_kcal": 57}}', '2026-11-22 23:55:18.967843+00', '2026-11-22 23:55:18.967844+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a109b065-01f6-40d1-afdf-d0ed9b27b5e6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen Sour Cherries', 'Northwind Frozen', '2000000000374', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 12.0, "protein_g": 1.0, "calories_kcal": 50}}', '2026-11-22 23:55:18.967845+00', '2026-11-22 23:55:18.967845+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('79c6276d-bdee-4313-bfe6-617ce82fff58', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Minced Pork', 'Fellbrook Farms', '2000000000381', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 19.0, "carbs_g": 0.0, "protein_g": 15.0, "calories_kcal": 242}}', '2026-11-22 23:55:18.967847+00', '2026-11-22 23:55:18.967847+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('76c742c2-5e38-4dd3-acdb-6b25bc731476', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Spaghetti 500g', 'Harvest Row', '2000000000398', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-22 23:55:18.967848+00', '2026-11-22 23:55:18.967849+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8ef0b432-23f3-4dfc-bd43-86aca0fa71ba', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Penne Pasta', 'Harvest Row', '2000000000404', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-22 23:55:18.967849+00', '2026-11-22 23:55:18.96785+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ffe885f7-cb4f-45f6-aeaa-e1878f19917c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fusilli Pasta', 'Harvest Row', '2000000000411', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-22 23:55:18.967851+00', '2026-11-22 23:55:18.967851+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f12e974e-4a96-43e7-8648-67a321aa68b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Jasmine Rice 1kg', 'Harvest Row', '2000000000428', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 78.0, "protein_g": 7.0, "calories_kcal": 348}}', '2026-11-22 23:55:18.967852+00', '2026-11-22 23:55:18.967853+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Buckwheat Groats', 'Harvest Row', '2000000000435', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.0, "carbs_g": 62.0, "protein_g": 12.0, "calories_kcal": 343}}', '2026-11-22 23:55:18.967854+00', '2026-11-22 23:55:18.967854+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ea8f033e-70ea-4253-9469-c10743fc574e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Rolled Oats', 'Harvest Row', '2000000000442', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 68.0, "protein_g": 13.0, "calories_kcal": 379}}', '2026-11-22 23:55:18.967855+00', '2026-11-22 23:55:18.967855+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b101a1ef-2778-4aee-b005-4500809682a2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fruit Muesli', 'Harvest Row', '2000000000459', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 67.0, "protein_g": 9.0, "calories_kcal": 398}}', '2026-11-22 23:55:18.967856+00', '2026-11-22 23:55:18.967857+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('49e687bc-7914-4f53-b2e4-7059b36825c2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Corn Flakes', 'Harvest Row', '2000000000466', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 375.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 84.0, "protein_g": 6.0, "calories_kcal": 361}}', '2026-11-22 23:55:18.967858+00', '2026-11-22 23:55:18.967859+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Wheat Flour Type 550', 'Harvest Row', '2000000000473', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 72.0, "protein_g": 10.0, "calories_kcal": 341}}', '2026-11-22 23:55:18.967859+00', '2026-11-22 23:55:18.96786+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1a24394d-7540-45ea-a737-aee4ea4e0557', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'White Sugar 1kg', 'Harvest Row', '2000000000480', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 100.0, "protein_g": 0.0, "calories_kcal": 387}}', '2026-11-22 23:55:18.967861+00', '2026-11-22 23:55:18.967862+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fba93956-79a6-4711-ac06-13306f0838de', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Iodised Salt', 'Saltmill', '2000000000497', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967862+00', '2026-11-22 23:55:18.967863+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e6d97a63-b566-4e5d-8c0e-6ca93712066b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Ground Black Pepper', 'Saltmill', '2000000000503', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 40.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967864+00', '2026-11-22 23:55:18.967865+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('90c8d962-e581-4480-a1fc-d64a4e2083d5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dried Oregano', 'Saltmill', '2000000000510', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 15.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967866+00', '2026-11-22 23:55:18.967866+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e06824d7-d9d2-4ae5-8117-51df6760f021', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dried Basil', 'Saltmill', '2000000000527', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 10.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967867+00', '2026-11-22 23:55:18.967867+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('451e32f2-f5b1-4448-bb7b-db55f638122d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Granulated Garlic', 'Saltmill', '2000000000534', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 25.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967868+00', '2026-11-22 23:55:18.967868+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Extra Virgin Olive Oil', 'Harvest Row', '2000000000541', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 750.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-22 23:55:18.967869+00', '2026-11-22 23:55:18.96787+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('225088ae-d208-43c6-bc3b-c0ec878222d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Sunflower Oil', 'Harvest Row', '2000000000558', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-22 23:55:18.967871+00', '2026-11-22 23:55:18.967871+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fd8f78d2-6828-4f3b-841e-f1e7c1f1d917', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tomato Passata', 'Harvest Row', '2000000000565', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 700.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 5.5, "protein_g": 1.5, "calories_kcal": 32}}', '2026-11-22 23:55:18.967872+00', '2026-11-22 23:55:18.967873+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8a2f3373-f1b6-469a-bae2-f50d43e34a60', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Peeled Tomatoes 400g', 'Harvest Row', '2000000000572', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 4.0, "protein_g": 1.2, "calories_kcal": 26}}', '2026-11-22 23:55:18.967873+00', '2026-11-22 23:55:18.967874+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d9db61c5-d00b-489f-a1a8-8950a8b4c361', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Canned Chickpeas', 'Harvest Row', '2000000000589', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.6, "carbs_g": 27.0, "protein_g": 9.0, "calories_kcal": 164}}', '2026-11-22 23:55:18.967875+00', '2026-11-22 23:55:18.967876+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ddcadb51-4a46-4841-8200-9675e2e35903', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Canned White Beans', 'Harvest Row', '2000000000596', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 400.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 25.0, "protein_g": 9.0, "calories_kcal": 139}}', '2026-11-22 23:55:18.967876+00', '2026-11-22 23:55:18.967877+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('20bb2adc-cd78-4a9d-ac06-a87502b33a96', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Canned Sweetcorn', 'Harvest Row', '2000000000602', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 340.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 19.0, "protein_g": 3.0, "calories_kcal": 96}}', '2026-11-22 23:55:18.967878+00', '2026-11-22 23:55:18.967878+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1d3df1d3-df66-4f30-95bf-9021f2568949', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tuna in Oil', 'Bluewater', '2000000000619', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 160.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 0.0, "protein_g": 26.0, "calories_kcal": 198}}', '2026-11-22 23:55:18.967879+00', '2026-11-22 23:55:18.967879+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6cbd3ad9-9f78-4bbd-8d0b-47665fbd3f82', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Chicken Stock', 'Harvest Row', '2000000000626', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 120.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967881+00', '2026-11-22 23:55:18.967881+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ea54ffed-4914-471e-a2f0-cf62e79de51e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Earl Grey Tea', 'Orchard & Oak', '2000000000633', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 50.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967882+00', '2026-11-22 23:55:18.967882+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('74f3b6ab-103d-4f7e-96f9-096379f102d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Ground Coffee', 'Orchard & Oak', '2000000000640', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 250.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967883+00', '2026-11-22 23:55:18.967883+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0f18a578-a022-4b3c-803f-6978c152c386', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Coffee Beans', 'Orchard & Oak', '2000000000657', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967884+00', '2026-11-22 23:55:18.967884+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fbe3f002-b295-4dd5-b447-33a543fde207', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Strawberry Jam', 'Orchard & Oak', '2000000000664', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 350.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 65.0, "protein_g": 0.5, "calories_kcal": 264}}', '2026-11-22 23:55:18.967885+00', '2026-11-22 23:55:18.967885+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('bb1b0d07-c57e-4fc9-93e1-fd6eadaaa13e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Peanut Butter', 'Orchard & Oak', '2000000000671', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 250.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 20.0, "protein_g": 25.0, "calories_kcal": 588}}', '2026-11-22 23:55:18.967886+00', '2026-11-22 23:55:18.967886+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8ae42709-47ed-4252-823b-e3ed5e15ca4f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dark Chocolate 85%', 'Orchard & Oak', '2000000000688', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 100.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 44.0, "carbs_g": 39.0, "protein_g": 8.0, "calories_kcal": 598}}', '2026-11-22 23:55:18.967887+00', '2026-11-22 23:55:18.967888+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('32df701a-dee4-4481-bc82-c64fa9c1cbc0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Salted Potato Crisps', 'Orchard & Oak', '2000000000695', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 165.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 35.0, "carbs_g": 53.0, "protein_g": 4.0, "calories_kcal": 536}}', '2026-11-22 23:55:18.967888+00', '2026-11-22 23:55:18.967889+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('77cd9fe9-d3c2-4ef5-a867-fbc64022e6ee', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Rice Cakes', 'Harvest Row', '2000000000701', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 120.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.0, "carbs_g": 82.0, "protein_g": 7.0, "calories_kcal": 387}}', '2026-11-22 23:55:18.96789+00', '2026-11-22 23:55:18.96789+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2f65f021-681a-4ecb-af6f-4a5d9b667e72', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Soy Sauce', 'Harvest Row', '2000000000725', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 250.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 5.0, "protein_g": 8.0, "calories_kcal": 53}}', '2026-11-22 23:55:18.967892+00', '2026-11-22 23:55:18.967892+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c920ba79-51d4-4691-b3ed-04baa2b19da4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tomato Paste', 'Harvest Row', '2000000000732', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 170.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 9.0, "protein_g": 3.0, "calories_kcal": 55}}', '2026-11-22 23:55:18.967893+00', '2026-11-22 23:55:18.967894+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3228a057-452f-439a-a69b-5e533e374849', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Potato Starch', 'Harvest Row', '2000000000749', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 500.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 85.0, "protein_g": 0.5, "calories_kcal": 341}}', '2026-11-22 23:55:18.967894+00', '2026-11-22 23:55:18.967895+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('54a70fb6-27f4-4f28-b22f-1b4929f83ae5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Baking Powder', 'Harvest Row', '2000000000756', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 50.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967895+00', '2026-11-22 23:55:18.967896+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6dd0da7c-8052-478b-824d-87524fad1dc4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dry Yeast', 'Harvest Row', '2000000000763', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 14.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967897+00', '2026-11-22 23:55:18.967897+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e6232713-61fb-4305-b9db-cca330549b49', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Vanilla Sugar', 'Harvest Row', '2000000000770', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 32.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967898+00', '2026-11-22 23:55:18.967898+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7aab2368-ac5e-4b7d-985b-e1da592941bf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Ground Cinnamon', 'Saltmill', '2000000000787', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 20.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967899+00', '2026-11-22 23:55:18.9679+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b28d523a-4675-4cbe-8eee-975d4c9f75bd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Sweet Paprika', 'Saltmill', '2000000000794', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 30.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.9679+00', '2026-11-22 23:55:18.967901+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e875b64c-5ee4-496c-b747-19a602e14812', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Curry Powder', 'Saltmill', '2000000000800', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 25.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967901+00', '2026-11-22 23:55:18.967902+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b3f0e263-5037-46ee-826e-abd12b32fba3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Ground Ginger', 'Saltmill', '2000000000817', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 20.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967903+00', '2026-11-22 23:55:18.967903+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('859d2067-5f56-4be6-bc03-2bdd56619331', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Wildflower Honey', 'Orchard & Oak', '2000000000824', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 82.0, "protein_g": 0.3, "calories_kcal": 304}}', '2026-11-22 23:55:18.967904+00', '2026-11-22 23:55:18.967904+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Walnuts', 'Green Acre', '2000000000831', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 200.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 65.0, "carbs_g": 14.0, "protein_g": 15.0, "calories_kcal": 654}}', '2026-11-22 23:55:18.967905+00', '2026-11-22 23:55:18.967905+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('54f675d6-71a2-4e05-9ac6-d0996715c5e2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Almonds', 'Green Acre', '2000000000848', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 200.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 22.0, "protein_g": 21.0, "calories_kcal": 579}}', '2026-11-22 23:55:18.967906+00', '2026-11-22 23:55:18.967906+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('581cf261-3985-40ed-84d0-c2fe77f87c04', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Instant Tomato Soup', 'Harvest Row', '2000000000855', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 85.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:55:18.967907+00', '2026-11-22 23:55:18.967908+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('85953d2b-1306-4e9a-8a90-7092bc67bd4a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cocoa Powder', 'Orchard & Oak', '2000000000862', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 100.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 15.0, "carbs_g": 36.0, "protein_g": 24.0, "calories_kcal": 348}}', '2026-11-22 23:55:18.967909+00', '2026-11-22 23:55:18.967909+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('38f3a4bc-637c-4187-9ece-bd77b31c2574', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dell Latitude 5540', 'Dell', '2000000010014', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-1345U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-22 23:55:18.987738+00', '2026-11-22 23:55:18.987744+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('dee901bb-0d39-486d-9b0b-a527dd72ccee', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ThinkPad T14s Gen 4', 'Lenovo', '2000000010021', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "AMD Ryzen 7 PRO", "ram": "32GB", "storage": "1TB SSD"}}', '2026-11-22 23:55:18.987745+00', '2026-11-22 23:55:18.987745+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'MacBook Pro 14 M3', 'Apple', '2000000010038', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Apple M3 Pro", "ram": "18GB", "storage": "512GB SSD"}}', '2026-11-22 23:55:18.987746+00', '2026-11-22 23:55:18.987747+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('393624e7-5c8a-4381-b6b2-48854ca15fc6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'HP EliteBook 840 G10', 'HP', '2000000010045', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-1365U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-22 23:55:18.987747+00', '2026-11-22 23:55:18.987748+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dell OptiPlex 7010', 'Dell', '2000000010052', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-13500", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-22 23:55:18.987748+00', '2026-11-22 23:55:18.987749+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1d134e16-fb90-40c5-9d82-6fcde5310d40', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'HP ProDesk 400 G9', 'HP', '2000000010069', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-12500", "ram": "8GB", "storage": "256GB SSD"}}', '2026-11-22 23:55:18.987749+00', '2026-11-22 23:55:18.98775+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2d084bd0-d5f8-49e1-963e-16626d5a55b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Lenovo ThinkCentre M90q', 'Lenovo', '2000000010076', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-13700", "ram": "16GB", "storage": "1TB SSD"}}', '2026-11-22 23:55:18.987751+00', '2026-11-22 23:55:18.987751+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('de374e76-b529-47e6-99d2-eb12e9edea81', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dell UltraSharp U2723QE', 'Dell', '2000000010083', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-22 23:55:18.987752+00', '2026-11-22 23:55:18.987753+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f5a92539-d900-4300-a545-c226bf03942f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'LG 27UK850-W', 'LG', '2000000010090', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-22 23:55:18.987753+00', '2026-11-22 23:55:18.987754+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7d9039c2-0886-4803-882e-08d9150b2ffa', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Samsung Odyssey G5', 'Samsung', '2000000010106', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "32\"", "panel": "VA", "resolution": "2560x1440"}}', '2026-11-22 23:55:18.987755+00', '2026-11-22 23:55:18.987755+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4ade99c5-2d1b-467c-8c09-ca23702f3596', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'iPhone 15 Pro', 'Apple', '2000000010113', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Natural Titanium", "storage": "256GB"}}', '2026-11-22 23:55:18.987756+00', '2026-11-22 23:55:18.987756+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('26e19db4-a097-438b-8061-4514b12b7a20', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Samsung Galaxy S24', 'Samsung', '2000000010120', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Phantom Black", "storage": "128GB"}}', '2026-11-22 23:55:18.987757+00', '2026-11-22 23:55:18.987757+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8b051841-964b-49ea-be34-235b9fe7344e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'iPad Air M2', 'Apple', '2000000010137', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Space Gray", "storage": "128GB"}}', '2026-11-22 23:55:18.987758+00', '2026-11-22 23:55:18.987758+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('77b59a7a-b8d4-40a9-8615-116be7a0169c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cisco Catalyst 9200L', 'Cisco', '2000000010144', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE", "management": "DNA Center"}}', '2026-11-22 23:55:18.987759+00', '2026-11-22 23:55:18.987759+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3c2c7245-6264-4871-b2e3-3d7950b14a50', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', '2000000010151', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "48x 1GbE + 4x 10GbE"}}', '2026-11-22 23:55:18.98776+00', '2026-11-22 23:55:18.987761+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('53275f12-8e84-4169-88a2-d3c82e75559d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'TP-Link TL-SG3428', 'TP-Link', '2000000010168', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE + 4x SFP"}}', '2026-11-22 23:55:18.987761+00', '2026-11-22 23:55:18.987762+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8f8295c2-51b8-4c32-a88d-27f91ed0093d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cisco Meraki MR46', 'Cisco', '2000000010175', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"speed": "AX5400", "standard": "Wi-Fi 6"}}', '2026-11-22 23:55:18.987762+00', '2026-11-22 23:55:18.987763+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fd203d50-c0a9-4a16-96ac-e2f47246aca8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Logitech MX Keys S', 'Logitech', '2000000010182', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Mechanical", "layout": "US"}}', '2026-11-22 23:55:18.987763+00', '2026-11-22 23:55:18.987764+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d74363d9-3e93-47e0-beda-2766cc739703', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Logitech MX Master 3S', 'Logitech', '2000000010199', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"dpi": 8000, "buttons": 7}}', '2026-11-22 23:55:18.987764+00', '2026-11-22 23:55:18.987765+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Logitech C920 HD Pro', 'Logitech', '2000000010205', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"fps": 30, "resolution": "1080p"}}', '2026-11-22 23:55:18.987766+00', '2026-11-22 23:55:18.987766+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7df8a934-580b-42fe-9f18-bdaa89b6c55e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Jabra Evolve2 65', 'Jabra', '2000000010212', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Headset", "connection": "Bluetooth"}}', '2026-11-22 23:55:18.987767+00', '2026-11-22 23:55:18.987767+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1a2901a8-a6dc-4fed-98b3-ba109ce2c2d4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Dell PowerEdge R750', 'Dell', '2000000010229', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4314", "ram": "64GB", "storage": "2x 480GB SSD"}}', '2026-11-22 23:55:18.987768+00', '2026-11-22 23:55:18.987768+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('65ad9f0b-3a48-48ea-9840-ac19cecb55b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'HPE ProLiant DL380 Gen10', 'HPE', '2000000010236', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Gold 5318Y", "ram": "128GB", "storage": "4x 960GB SSD"}}', '2026-11-22 23:55:18.987769+00', '2026-11-22 23:55:18.987769+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e1a2786b-5308-4a11-9da4-23f1a60f88a3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Supermicro SYS-1029U', 'Supermicro', '2000000010243', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4214", "ram": "96GB", "storage": "2x 1TB SSD"}}', '2026-11-22 23:55:18.98777+00', '2026-11-22 23:55:18.987771+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4b222d05-5c00-439a-bd4d-7c886003b303', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'APC Smart-UPS 3000VA', 'APC', '2000000010250', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"runtime": "~15min at full load", "capacity": "3000VA/2700W"}}', '2026-11-22 23:55:18.987771+00', '2026-11-22 23:55:18.987772+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cea951fa-5471-49de-ae33-003d5fc04dc5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Rack 42U Open Frame', 'Rittal', '2000000010267', NULL, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "42U", "width": "19 inch"}}', '2026-11-22 23:55:18.987772+00', '2026-11-22 23:55:18.987773+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2610b247-12e7-4f9d-adb4-76679eac607b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Plum Butter', 'Hollow Lane Orchard', '2000000009018', 'PLB-001', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:55:18.99957+00', '2026-11-22 23:55:18.999575+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9f643356-0703-44da-bb04-066a379d074a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Damson Plums', 'Green Acre', '2000000009025', 'PLM-001', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:55:18.999576+00', '2026-11-22 23:55:18.999576+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('456bf028-a84f-48ed-a91d-14650d05dcf7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'White Sugar', 'Harvest Row', '2000000009032', 'SUG-001', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:55:18.999577+00', '2026-11-22 23:55:18.999578+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Cassia Cinnamon', 'Saltmill', '2000000009049', 'CIN-001', 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:55:18.999578+00', '2026-11-22 23:55:18.999579+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9942d546-729a-47e0-978a-c21cdca4a522', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Carrots 1kg', 'Green Acre', '4651922764332', NULL, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', 1000.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 6.8, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.9, "calories_kcal": 41}}', '2026-11-22 23:55:18.967821+00', '2026-11-22 23:55:19.173274+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c15de66e-9440-4a41-bad5-855060db64bd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Frozen Chips', 'Northwind Frozen', '2000000000350', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 750.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 4, NULL, '{"nutrition": {"fat_g": 5.0, "carbs_g": 24.0, "protein_g": 2.5, "calories_kcal": 152}}', '2026-11-22 23:55:18.967842+00', '2026-11-22 23:55:19.17328+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fd3f8548-b4e0-4ae1-9271-a9492edc6996', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Butter Biscuits', 'Orchard & Oak', '2000000000718', NULL, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', 200.000000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, NULL, NULL, 6, NULL, '{"nutrition": {"fat_g": 17.0, "carbs_g": 71.0, "protein_g": 6.0, "calories_kcal": 454}}', '2026-11-22 23:55:18.967891+00', '2026-11-22 23:55:19.173281+00');


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('cdb083be-f932-423a-8245-509efcc631f3', '323c9e0d-f84b-443f-b864-fead074b6985', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 'Dell Latitude 5540', 4.000, 0.000, 4200.00, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('2da3d7e5-47ca-4491-bad7-3db3c322c7b5', 'ebece7de-f8d4-4a0e-9535-19de5524103b', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 'Dell Latitude 5540', 6.000, 0.000, 4200.00, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('09b5b12a-203d-4603-b0cc-f836a3b8cbfb', 'ebece7de-f8d4-4a0e-9535-19de5524103b', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 'ThinkPad T14s Gen 4', 2.000, 0.000, 5800.00, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, 2, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('ba60c0b0-6aeb-4565-ab94-5ec7a4dc340c', 'c2bf388b-dd10-49a3-b6c2-e015bf5c5f99', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 'ThinkPad T14s Gen 4', 5.000, 3.000, 5800.00, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, 1, NULL, NULL);


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('c2bf388b-dd10-49a3-b6c2-e015bf5c5f99', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'PO/2026/003', 'CONFIRMED', '6b1d2f12-5af0-4dba-bae0-a4aee0af02e1', '2026-11-09', 'Partly delivered; the rest is on back order with the supplier.', 'USD', '88e78ef1-115e-465e-a474-c66b601da4b0', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-02 23:55:22.740971+00', NULL, NULL, '2026-11-02 23:55:22.740971+00', '2026-11-22 23:55:23.96488+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('323c9e0d-f84b-443f-b864-fead074b6985', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'PO/2026/001', 'PENDING_APPROVAL', '1ffca832-7eb6-4d75-999b-5ca28121e297', '2026-11-26', 'Laptops for the two November starters and two for the loan pool.', 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', NULL, NULL, NULL, NULL, '2026-11-19 23:55:22.740971+00', '2026-11-22 23:55:24.4044+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('ebece7de-f8d4-4a0e-9535-19de5524103b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'PO/2026/002', 'CONFIRMED', '1ffca832-7eb6-4d75-999b-5ca28121e297', '2026-11-19', 'Quarterly refresh of the support desk.', 'USD', '72354123-6bc0-4834-8870-3e0faad5b922', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-13 07:55:22.740971+00', NULL, NULL, '2026-11-12 23:55:22.740971+00', '2026-11-22 23:55:24.405074+00');


--
-- Data for Name: putaway_capacity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_home_silenced; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_location_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_rule_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('d057160c-d6f1-4c18-b83c-aeb89071f4d9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '07deea73-54a2-4daf-974e-15f353a7edbd', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('3748c106-0d0f-4e77-b273-852840abc1cc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '07deea73-54a2-4daf-974e-15f353a7edbd', '204807e1-19ac-4a98-a1f5-c89edca8f69a', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('95fe7baa-4477-492d-b01f-7ed2c6de0395', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '291eaa6f-1ccb-4755-87f1-63f51f7a7d6f', '2f8525b6-79bd-411d-97d5-b50f45190369', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('386b51c4-5224-4876-bc87-79d950e52ee4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '291eaa6f-1ccb-4755-87f1-63f51f7a7d6f', '22896f78-dbe8-43c4-9ba3-413f627abccd', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('474ceaab-6275-44c2-92fd-653af1f896f6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bb6f6c8f-1334-4397-9608-e59c5ef38487', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('fda91f3c-2a37-4021-8429-3e544350374b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'bb6f6c8f-1334-4397-9608-e59c5ef38487', '204807e1-19ac-4a98-a1f5-c89edca8f69a', 1);


--
-- Data for Name: putaway_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('07deea73-54a2-4daf-974e-15f353a7edbd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '71b9b964-6cbf-428f-9057-f1f5c32f6d3b', NULL, NULL, 50, true, '2026-11-22 23:55:23.892038+00', '2026-11-22 23:55:23.892038+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('291eaa6f-1ccb-4755-87f1-63f51f7a7d6f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, 'db4d152b-48fd-4875-a40f-5e01f1587213', NULL, NULL, 50, true, '2026-11-22 23:55:23.892038+00', '2026-11-22 23:55:23.892038+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('bb6f6c8f-1334-4397-9608-e59c5ef38487', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', NULL, NULL, NULL, 10, true, '2026-11-22 23:55:23.892038+00', '2026-11-22 23:55:23.892038+00');


--
-- Data for Name: recipe_collection_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('7498b385-8453-49cd-b541-ceb98f1aa5ba', 'b24b81d2-31ee-4760-8e97-af323f78a386', 'd9db61c5-d00b-489f-a1a8-8950a8b4c361', 'Canned Chickpeas', NULL, NULL, 2.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b16c729a-448d-44cf-89bd-6de76a2bb7be', 'b24b81d2-31ee-4760-8e97-af323f78a386', 'fd8f78d2-6828-4f3b-841e-f1e7c1f1d917', 'Tomato Passata', NULL, NULL, 500.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a068f0ee-32da-4b72-a6e5-a7881da8c09d', 'b24b81d2-31ee-4760-8e97-af323f78a386', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('464dd5b8-c1db-4edb-b5b1-0e778d29dfe8', 'b24b81d2-31ee-4760-8e97-af323f78a386', 'b28d523a-4675-4cbe-8eee-975d4c9f75bd', 'Sweet Paprika', NULL, NULL, 3.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('9fb77b7d-cf09-4d66-b0fb-1adee5a07c98', '9bf707b1-ad29-41dd-bb22-3ed6d808bd75', '76c742c2-5e38-4dd3-acdb-6b25bc731476', 'Spaghetti 500g', NULL, NULL, 200.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6c443216-cfe2-4df6-be4c-a826a674e4e4', '9bf707b1-ad29-41dd-bb22-3ed6d808bd75', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', 'Extra Virgin Olive Oil', NULL, NULL, 40.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('7ed673cc-9acc-45ea-aba5-c673a1544ece', '9bf707b1-ad29-41dd-bb22-3ed6d808bd75', '451e32f2-f5b1-4448-bb7b-db55f638122d', 'Granulated Garlic', NULL, NULL, 3.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0d9f0249-932d-4b54-af96-645f79247c76', '9bf707b1-ad29-41dd-bb22-3ed6d808bd75', 'fba93956-79a6-4711-ac06-13306f0838de', 'Iodised Salt', NULL, NULL, 10.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b78edf67-bb56-4922-8b4a-5a400a3ddbb4', '49a53c66-486c-49f4-b2d3-ca245afe1bd7', 'dcb0e7fc-e8ed-4efb-b6c1-ff3fb3f7c843', 'Chicken Breast Fillet', NULL, NULL, 600.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('934b213a-fabe-46fb-802c-2c192e0a66b4', '49a53c66-486c-49f4-b2d3-ca245afe1bd7', 'f12e974e-4a96-43e7-8648-67a321aa68b3', 'Jasmine Rice 1kg', NULL, NULL, 300.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c3762187-7253-47c3-8ca8-591bf638ed73', '49a53c66-486c-49f4-b2d3-ca245afe1bd7', 'e875b64c-5ee4-496c-b747-19a602e14812', 'Curry Powder', NULL, NULL, 10.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('30f85b2d-1d12-4e66-9c55-231ec1dccf99', '49a53c66-486c-49f4-b2d3-ca245afe1bd7', '8a2f3373-f1b6-469a-bae2-f50d43e34a60', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ccd95ce5-f744-406b-8fec-ef8ecc4117e9', '49a53c66-486c-49f4-b2d3-ca245afe1bd7', NULL, 'Coconut Milk', NULL, NULL, 400.000, '316076fd-0ba0-4d03-b49a-c6651154898a', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('cce4727e-e660-4f09-b5a3-1df9afa85ea7', '626b082d-3f9a-4d5f-a2ef-591295da5557', '8ef0b432-23f3-4dfc-bd43-86aca0fa71ba', 'Penne Pasta', NULL, NULL, 200.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('281c960a-97d3-4601-8435-0eca5c4c3412', '626b082d-3f9a-4d5f-a2ef-591295da5557', '3ff4ff9a-eb60-43f9-bf93-75e78ea86aae', 'Red Pesto', NULL, NULL, 90.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('53f3fc87-f2e8-48e4-b7be-e9d172665f33', '626b082d-3f9a-4d5f-a2ef-591295da5557', '73a461e7-221b-4a78-bbb0-87a265426b07', 'Cherry Tomatoes', NULL, NULL, 250.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('18b344b0-dbc1-47e8-bafe-66ce62c75991', '626b082d-3f9a-4d5f-a2ef-591295da5557', NULL, 'Parmesan', NULL, NULL, 40.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('85df9d43-8b74-4fe0-a5d2-6e83d4bb0c13', '99c61dfa-4136-43a0-87a0-b11f561b043a', 'ea8f033e-70ea-4253-9469-c10743fc574e', 'Rolled Oats', NULL, NULL, 100.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bc84798a-1d15-4212-b759-e94ae625d48e', '99c61dfa-4136-43a0-87a0-b11f561b043a', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 'Natural Yoghurt 400g', NULL, NULL, 300.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f993b380-aee4-402d-a002-fcbea874cedd', '99c61dfa-4136-43a0-87a0-b11f561b043a', '3566ff7c-c43f-460f-9e4e-a78d7732c3f5', 'Frozen Blueberries', NULL, NULL, 120.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('fed05db5-ccc9-4a7a-a871-199ffb22e9db', '99c61dfa-4136-43a0-87a0-b11f561b043a', '859d2067-5f56-4be6-bc03-2bdd56619331', 'Wildflower Honey', NULL, NULL, 20.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bc239fdc-9762-490a-ba87-b577196ee7d0', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '59f96aaa-d5ee-4513-8932-3108a32beeff', 'Bananas', NULL, NULL, 500.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('04b2b60d-7bdc-4e39-8236-4f42e4cce5ea', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', 'Wheat Flour Type 550', NULL, NULL, 250.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('2b18b39e-762a-487a-9ff0-24be4857dba9', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '1a24394d-7540-45ea-a737-aee4ea4e0557', 'White Sugar 1kg', NULL, NULL, 150.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('e736a06c-ac77-42d2-b054-29b3edcc0bab', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '29a30a7b-4336-4185-9036-ece90fd01b8c', 'Eggs Medium 10pk', NULL, NULL, 1.000, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f356dd3f-0d66-4f5b-8b6a-ab344eab0623', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 'Butter Extra 82%', NULL, NULL, 100.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('9df25d02-99bb-4bf6-be8d-f42eb059b552', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '54a70fb6-27f4-4f28-b22f-1b4929f83ae5', 'Baking Powder', NULL, NULL, 8.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6241cd03-b9cd-4ee9-828f-642467ba4e66', '455af4ce-708a-4e75-a489-dadfbad5e0f7', '7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', 'Walnuts', NULL, NULL, 100.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 6, NULL, NULL, NULL, NULL, '["nuts"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('4d2b3711-3175-498c-b4ac-bdcd8f9ea85b', 'a7812cf8-8320-4e1f-80b1-b5bc1958bd43', '29a30a7b-4336-4185-9036-ece90fd01b8c', 'Eggs Medium 10pk', NULL, NULL, 1.000, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0d77c913-9baa-4f59-95f0-d4f7bad2c5dd', 'a7812cf8-8320-4e1f-80b1-b5bc1958bd43', '8a2f3373-f1b6-469a-bae2-f50d43e34a60', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0c8171e1-f8c0-42cb-b6a3-a92e4200e78d', 'a7812cf8-8320-4e1f-80b1-b5bc1958bd43', 'b28d523a-4675-4cbe-8eee-975d4c9f75bd', 'Sweet Paprika', NULL, NULL, 3.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('277938a1-4a43-4e44-b08a-b0ca4851aff8', 'a7812cf8-8320-4e1f-80b1-b5bc1958bd43', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('aa7ad830-2c29-4e2a-b6b1-9a4e101ab10c', 'a7812cf8-8320-4e1f-80b1-b5bc1958bd43', NULL, 'Onion', NULL, NULL, 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('8a8d3062-9384-405c-b63d-c4c4cbae7cb0', '2895a983-1ba4-42d7-bf18-72d7e88727c9', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', 'Wheat Flour Type 550', NULL, NULL, 250.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b0ae74d6-f7c7-4ac2-b510-90b097396a2b', '2895a983-1ba4-42d7-bf18-72d7e88727c9', '88596313-affa-43ae-ba60-be8ddcdea620', 'UHT Milk 3.2%', NULL, NULL, 500.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ef399b15-1f0a-4036-b54a-763aa5694ad3', '2895a983-1ba4-42d7-bf18-72d7e88727c9', '29a30a7b-4336-4185-9036-ece90fd01b8c', 'Eggs Medium 10pk', NULL, NULL, 1.000, 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b5ffae41-ce33-4f57-80fc-5c085bcbfa31', '2895a983-1ba4-42d7-bf18-72d7e88727c9', 'e43e6c31-9675-4fbb-8114-d7e936436234', 'Strawberries', NULL, NULL, 300.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('7d371b4c-fa0a-4e31-9fce-d5c6388667d4', '2895a983-1ba4-42d7-bf18-72d7e88727c9', '225088ae-d208-43c6-bc3b-c0ec878222d7', 'Sunflower Oil', NULL, NULL, 25.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f9ad7a12-4bf9-4c12-b039-304264aafebf', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', 'ffe885f7-cb4f-45f6-aeaa-e1878f19917c', 'Fusilli Pasta', NULL, NULL, 300.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c4a04c3a-aa96-4af6-82c4-064dce0e679f', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', '1d3df1d3-df66-4f30-95bf-9021f2568949', 'Tuna in Oil', NULL, NULL, 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["fish"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0c817915-b414-4145-ba10-f42ba4bf7099', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', '20bb2adc-cd78-4a9d-ac06-a87502b33a96', 'Canned Sweetcorn', NULL, NULL, 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a48214fa-eaa6-4380-98ae-89b59ab91464', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', 'c8aa39a3-302c-470b-81c2-36e3470fe1a2', 'Mayonnaise', NULL, NULL, 75.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a084a05b-d460-4d55-b9a6-1a1809ce9f97', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', 'b3a366b8-8cb2-42cb-bba8-cbbfab3632a7', 'Cucumber', NULL, NULL, 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('250e9255-9ea9-44e2-9f6c-9a1264291dbc', 'a17d91d9-217e-4d66-987a-27ecaa8d5639', NULL, 'Fresh Basil', NULL, NULL, 10.000, '517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);


--
-- Data for Name: recipe_tag_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('2895a983-1ba4-42d7-bf18-72d7e88727c9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Pancakes with Strawberries', 'Saturday breakfast, twelve thin pancakes.', '1. Whisk the flour, milk and eggs into a thin batter; rest it ten minutes.
2. Fry in a lightly oiled pan, a ladle at a time.
3. Serve with sliced strawberries.', 4, 30, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/2895a983-1ba4-42d7-bf18-72d7e88727c9/cover.3882e8b3d23f.jpg', NULL, '["breakfast"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.827381+00', '2026-11-22 23:55:24.734822+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('455af4ce-708a-4e75-a489-dadfbad5e0f7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Banana Bread', 'What the bananas going brown on the counter are for.', '1. Mash the bananas and beat in the melted butter, sugar and eggs.
2. Fold in the flour, baking powder and chopped walnuts.
3. Bake in a lined loaf tin at 175 C for about an hour.', 8, 70, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/455af4ce-708a-4e75-a489-dadfbad5e0f7/cover.3af478a733d8.jpg', NULL, '["baking"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.822489+00', '2026-11-22 23:55:24.734828+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('49a53c66-486c-49f4-b2d3-ca245afe1bd7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Chicken Curry with Jasmine Rice', 'A weeknight curry from the freezer and the spice drawer.', '1. Brown the diced chicken, then stir in the curry powder.
2. Add the tomatoes and coconut milk; simmer for twenty minutes.
3. Serve over the rice.', 4, 40, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/49a53c66-486c-49f4-b2d3-ca245afe1bd7/cover.7dc6671c2bc9.jpg', NULL, '["dinner"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.814259+00', '2026-11-22 23:55:24.734829+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('626b082d-3f9a-4d5f-a2ef-591295da5557', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Penne with Red Pesto', 'Fifteen minutes, one pan, no chopping board.', '1. Cook the penne.
2. Halve the tomatoes and warm them in the pesto.
3. Toss with the pasta and finish with grated parmesan.', 2, 15, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/626b082d-3f9a-4d5f-a2ef-591295da5557/cover.a2c6108f9a7c.jpg', NULL, '["quick", "pasta", "vegetarian"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.817674+00', '2026-11-22 23:55:24.734829+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('99c61dfa-4136-43a0-87a0-b11f561b043a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Overnight Oats with Blueberries', 'Made the evening before, eaten on the way out.', '1. Stir the oats into the yoghurt with a spoon of honey.
2. Fold in the blueberries straight from the freezer.
3. Cover and leave in the fridge overnight.', 2, 10, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/99c61dfa-4136-43a0-87a0-b11f561b043a/cover.dfc3aa2068eb.jpg', NULL, '["breakfast", "vegetarian"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.820221+00', '2026-11-22 23:55:24.73483+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('9bf707b1-ad29-41dd-bb22-3ed6d808bd75', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Spaghetti with Garlic and Oil', 'The five-ingredient supper worth knowing by heart.', '1. Cook the spaghetti in well-salted water.
2. Warm the oil gently with the garlic; do not let it brown.
3. Toss the drained pasta in the oil with a splash of cooking water.', 2, 20, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/9bf707b1-ad29-41dd-bb22-3ed6d808bd75/cover.02cc9ab66567.jpg', NULL, '["quick", "pasta"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.808549+00', '2026-11-22 23:55:24.734831+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('a17d91d9-217e-4d66-987a-27ecaa8d5639', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tuna Pasta Salad', 'A lunchbox that keeps until Wednesday.', '1. Cook the fusilli and cool it under running water.
2. Mix with the tuna, sweetcorn, diced cucumber and mayonnaise.
3. Tear the basil over the top before serving.', 3, 20, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/a17d91d9-217e-4d66-987a-27ecaa8d5639/cover.f2cb55c523ee.jpg', NULL, '["quick", "pasta"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.829594+00', '2026-11-22 23:55:24.734831+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('a7812cf8-8320-4e1f-80b1-b5bc1958bd43', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Shakshuka', 'Eggs poached in a spiced tomato sauce, straight from the pan.', '1. Soften the sliced onion in the oil with the paprika.
2. Add the tomatoes and simmer until thick.
3. Make four wells, crack in the eggs, cover and cook until set.', 2, 25, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/a7812cf8-8320-4e1f-80b1-b5bc1958bd43/cover.f495462017a6.jpg', NULL, '["breakfast", "vegetarian"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.824883+00', '2026-11-22 23:55:24.734832+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('b24b81d2-31ee-4760-8e97-af323f78a386', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tomato and Chickpea Stew', 'One pot, thirty minutes, everything from the pantry shelf.', '1. Warm the oil and toast the paprika for thirty seconds.
2. Add the passata and the drained chickpeas.
3. Simmer for twenty minutes, season and serve with bread.', 4, 30, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9/recipes/b24b81d2-31ee-4760-8e97-af323f78a386/cover.a73330974669.jpg', NULL, '["quick", "vegetarian"]', false, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.802566+00', '2026-11-22 23:55:24.734832+00');


--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_exclusions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('d6bded53-2e89-4071-bfaf-171573890d2b', '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, NULL, 'Coconut Milk', 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'For the curry on Wednesday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:55:23.849314+00', '2026-11-22 23:55:23.849317+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('82305ee2-47e7-4d7a-8f19-8107087b5688', '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, NULL, 'Parmesan', 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'For the penne on Friday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:55:23.849318+00', '2026-11-22 23:55:23.849319+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('96d81d4f-e1d9-4621-8923-e156456c8ac2', '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, NULL, 'Onion', 3.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'Shakshuka on Saturday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:55:23.84932+00', '2026-11-22 23:55:23.84932+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('79832ea9-6b27-4131-b6b8-6f9c1d79ba25', '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, NULL, 'Fresh Basil', 1.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', 'Tuna pasta salad', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:55:23.849321+00', '2026-11-22 23:55:23.849321+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('04910de1-0f90-4942-908e-8d36abecd888', '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, NULL, 'UHT Milk 3.2%', 2.000, 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:55:23.849322+00', '2026-11-22 23:55:23.849323+00', '88596313-affa-43ae-ba60-be8ddcdea620', NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('2d541cc3-584b-47e4-b2a5-1a445949af39', '4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', NULL, NULL, 'Bananas', 1.000, 'b2625fa3-6f97-4778-9084-c3f6ae2518a9', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:55:23.849323+00', '2026-11-22 23:55:23.849324+00', '59f96aaa-d5ee-4513-8932-3108a32beeff', NULL);


--
-- Data for Name: shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_lists (id, organization_id, name, status, completed_at, archived_at, created_by, created_at, updated_at) VALUES ('4aad0d1e-3412-4b04-bc1a-c08a9d20fedb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Weekly shop', 'active', NULL, NULL, '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.844691+00', '2026-11-22 23:55:23.844695+00');


--
-- Data for Name: stock_anchors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('619454d0-c1be-4a50-8989-cc8d69422b96', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', 'e4293c9f-f235-4c74-90cf-43104beff987', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cae45638-2e15-4569-8e76-3c74ae8a9cda', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f65f021-681a-4ecb-af6f-4a5d9b667e72', '712b1b64-be5a-468e-bb71-1c466b34dca1', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9b414b65-819b-42dc-8786-8effedabadfa', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', '0030fd00-2868-4ed0-a979-8db88009383a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('67332a57-fbc4-4a75-a41a-6444c524fd3a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3866bae3-6e34-4574-a8e6-c080e7deb20e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '79c6276d-bdee-4313-bfe6-617ce82fff58', '807c8e83-690e-46ff-9dfa-e2b8021a074c', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2477ebbd-9656-43a5-afad-b0be397c4c98', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '54a70fb6-27f4-4f28-b22f-1b4929f83ae5', '0030fd00-2868-4ed0-a979-8db88009383a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('50c804a7-ad6b-49a7-8ab8-950d65051f6f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6b4ab39c-bb30-4758-aa0d-15032b0f20ee', 'b1a280e0-0b57-4555-bff2-9b35db52d777', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('388d906c-80cb-4be6-8e79-4af7b2e6abc9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c15de66e-9440-4a41-bad5-855060db64bd', '2f8525b6-79bd-411d-97d5-b50f45190369', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('482cb1b4-0ab6-4f12-9a39-8551b40b93a4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', '1bba8efb-ff55-4ddf-b46c-ecb4ff175be5', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e2061f1e-4451-4964-8ee0-bf3454679e7f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd9db61c5-d00b-489f-a1a8-8950a8b4c361', 'e4293c9f-f235-4c74-90cf-43104beff987', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bb1573d2-d60c-4aa6-9c24-e840b1a4e711', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', '712b1b64-be5a-468e-bb71-1c466b34dca1', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a112bed6-8c8d-48dd-a784-81687854d9b4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('465d4910-d886-4615-94e9-94da8655802c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('163ea9f9-744b-4a07-a5ae-b5bfa487b49f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', '712b1b64-be5a-468e-bb71-1c466b34dca1', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4da66eaa-4a16-430b-aadc-47c55efcb3dd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd3f8548-b4e0-4ae1-9271-a9492edc6996', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e35a73bd-de20-41ff-8ed2-ce8636e76023', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9942d546-729a-47e0-978a-c21cdca4a522', '807c8e83-690e-46ff-9dfa-e2b8021a074c', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e241d68d-7aec-4d6a-91f8-d3b7d3702708', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fba93956-79a6-4711-ac06-13306f0838de', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3f435fbf-f624-410d-a993-bda305e8c9f8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '859d2067-5f56-4be6-bc03-2bdd56619331', '712b1b64-be5a-468e-bb71-1c466b34dca1', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4546449c-b3c1-4d42-a884-11d72a6b4f6e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0e189b5d-9372-40eb-b156-87eade5ac445', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', '0030fd00-2868-4ed0-a979-8db88009383a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a5f33143-85dd-4934-95ae-65d5d2fb54fc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6cbd3ad9-9f78-4bbd-8d0b-47665fbd3f82', '0030fd00-2868-4ed0-a979-8db88009383a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e914f054-184a-45e2-a2f5-2d29b354bd75', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e06824d7-d9d2-4ae5-8117-51df6760f021', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('44d0c81d-9d4d-4311-a764-7b11d267c001', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ddcadb51-4a46-4841-8200-9675e2e35903', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e926a433-0d4b-4e54-9798-75b5a05376d2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '30cb162e-2e0a-4ea5-9069-4ed172550821', '2f8525b6-79bd-411d-97d5-b50f45190369', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d924d52f-898e-4214-a7b0-2bf85c73dcbb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e6232713-61fb-4305-b9db-cca330549b49', 'e4293c9f-f235-4c74-90cf-43104beff987', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c9bd2692-e886-419e-89e2-5070a547f8fc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8ae42709-47ed-4252-823b-e3ed5e15ca4f', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b4239ab3-3f5b-451e-8c96-449e7a77ce02', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', '712b1b64-be5a-468e-bb71-1c466b34dca1', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a1c02f51-87f9-480d-9918-e4d9d768fd25', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7aab2368-ac5e-4b7d-985b-e1da592941bf', 'e4293c9f-f235-4c74-90cf-43104beff987', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3b4c9dd7-b335-49d2-ad75-050393379427', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffe885f7-cb4f-45f6-aeaa-e1878f19917c', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0b42db88-ef77-4e94-998f-4c22cfa5a1aa', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '59f96aaa-d5ee-4513-8932-3108a32beeff', '807c8e83-690e-46ff-9dfa-e2b8021a074c', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7dc2b9d1-b94d-46ef-a735-d1b0fc200dc2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d2a4df95-b27d-4317-b858-739756369781', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d3df1d3-df66-4f30-95bf-9021f2568949', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bf1e4eb2-7d36-4bc9-8682-683088466801', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '29a30a7b-4336-4185-9036-ece90fd01b8c', '7502d679-f52e-4208-9a0a-6628c5c836fc', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c6d0fed4-e5a7-47db-8b63-7db73b77595e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', '0030fd00-2868-4ed0-a979-8db88009383a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c985f0c3-2b50-4d18-8f9c-2e65afba31bc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '350b92a4-09a5-4f3e-b6cb-6a302b6b57e4', '7954e058-ee63-4bde-9395-af27e73cebcf', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('54c627ca-e06f-4c6c-9d14-7cf88356d303', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', 'e4293c9f-f235-4c74-90cf-43104beff987', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('753126d0-9f7e-4dd7-aa0d-2908477bbb71', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77cd9fe9-d3c2-4ef5-a867-fbc64022e6ee', '712b1b64-be5a-468e-bb71-1c466b34dca1', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fd6b3d04-876b-4f1a-9fa9-b97ef6df36ea', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '49e687bc-7914-4f53-b2e4-7059b36825c2', '0030fd00-2868-4ed0-a979-8db88009383a', '2026-11-22 23:55:19.046673+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9efdea69-4d62-4b8b-a6a1-7b5336e7a74b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2eb10c0e-bac3-4195-b513-8a6655484cb3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bb0e9d5b-0552-484f-b610-b2398a647c0f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('02f81609-c087-44be-a155-18106bc381bf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8cf43d32-8e1d-414a-9a04-036546ca4193', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a85f24f8-5bc6-4392-b35d-af0556c58339', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('784dd07b-14f5-41ff-95f6-320b1232fee1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('101509c4-a50f-447e-a170-1bdcc8c60352', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('79286fa1-3adf-49d4-bb76-6d277d89d769', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('062937f2-6ab0-410f-834f-440a96b3c213', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('576d305a-4d94-42d4-b46e-274fc71596bb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('364aa624-5b46-4c55-9a65-4e23d1dadade', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ed751b13-fa0f-4c63-a9cf-3c6b5626635e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5e7ee300-113b-4b70-89f2-05ada181b5e3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', '970f90c8-b151-4998-aa91-2c3da24502e3', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('97fbaa0c-2cbd-48d5-bb0f-b512e94ca5b0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9cdf4bed-db88-40c4-97ba-1bc56ad2efc1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('226ea599-4d99-4b35-bf24-efe81de5b9d4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('78c949a8-be59-48a3-a964-1096905cd1bc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0344dc32-b621-4116-b3f3-76c95b9c8b76', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '970f90c8-b151-4998-aa91-2c3da24502e3', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4ddb8144-e737-469e-82f5-e975bae0b14d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('699b2d93-6a6a-4363-a5bd-6749eddac551', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('36a9c40b-2737-4da6-8529-372761949a59', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2e35b1aa-8bad-4e32-ab07-fb64924d6837', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2172b3c0-c505-4c30-8fdd-fe58b7563f68', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a43be84c-3301-4115-80bd-340ae042ea9b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f0fb473d-9e9e-4f30-8756-49532a83e4c8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0e6a1ede-1930-4bcf-8d57-467a1416de9a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('356fb9ed-82d3-4df4-99eb-34809c5d2b09', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('18c91901-431c-4754-8caf-5c9d5a434705', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('71be4e39-08af-473b-b875-f3d8260fc297', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e0046b18-c778-4dc4-841b-16d5b0905c79', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fc7c1999-789a-4a65-883e-b194599a90ef', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('424d8cba-1c10-4d07-968a-725de2bc1db0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2ae01c2e-769e-414d-bd8e-86bba4d93cd9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5646028c-577e-44f5-abf3-fee5478bec93', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('322058dd-0df8-4d54-9356-c1e2e5b70393', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('18c627a8-c5c7-47a9-8bcf-c26b06cc6538', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26e19db4-a097-438b-8061-4514b12b7a20', '970f90c8-b151-4998-aa91-2c3da24502e3', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('83a5c804-00ff-4130-9488-d7a150cd9bc0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('27d0a18e-1db2-4ce6-8ca9-9a503e4b8898', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6376785e-bb93-47e8-b4dd-b7dfaf7cd067', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b7615d9f-44a6-4a27-bf6b-d83313e9c94d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e2a81b94-1331-452d-8f40-d6cb7bd4c176', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0f8523f0-7fec-492f-9e63-bbb2e61f1bb1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', '970f90c8-b151-4998-aa91-2c3da24502e3', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6113df4d-a42c-4df6-b749-0cf5887f154b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('28eb7bcb-c9f0-4d30-854b-dd5d2bbf327c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0ce533ee-2226-4b82-8c1e-813982f8e3d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3415be80-fce2-4b30-baae-d3e51d5a9d14', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('45ae2e07-552d-4a5f-bba4-7d3918b8777f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e154d1fa-67af-4019-9096-1eeb386b8c30', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6f21197b-ec6a-416c-81e3-e35f9ca43299', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1ba73c1b-673e-4a50-a4ab-4dfbcf9d6726', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('078b7dbf-5ced-4ffa-9c36-90e26c4ef73f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c91dac43-f8ff-4e13-8694-21a631d1df7b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fd10682a-0926-49ae-8dfd-c46772c9cc0e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5a4ed4d9-d04a-4b8a-9e68-9d05880c31ae', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7696cad1-b195-466b-8008-64701639e253', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4a286f19-a227-4f76-bd7a-0f5a9d4139dc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c8f50f2c-d2d6-4d21-8e02-1c9eb9ab3ce3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f81fcf6c-4abc-46bb-8f3c-00a6edd377ca', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('832eb6be-5468-4b8a-a828-908f47ddf59d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('be03fd22-f89b-49a0-abfe-01d8e048c70d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f4df9a41-cdf1-439b-ad1e-27498ea30425', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ea4ec9a0-3dee-42c7-ac18-67c6253d32a2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', '970f90c8-b151-4998-aa91-2c3da24502e3', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('91b9fb2d-5790-44f7-b623-b091d15d0100', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0ee43cfa-0fdd-436f-a5db-65ebc8ee0d2c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 'c29e334b-7662-4015-9afe-8b3526e33065', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b8ff56be-bdd4-4521-8b25-3735a3ecf6c5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c4214f9f-9784-43a6-b8fa-799af52d5946', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bfd13277-20cb-442b-9323-29c6d4691589', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', '970f90c8-b151-4998-aa91-2c3da24502e3', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7f2b1dbf-d078-4db0-8848-3d66378c27f5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1a2901a8-a6dc-4fed-98b3-ba109ce2c2d4', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ef5aea8f-f996-4d8c-8d29-f45a7223e3cf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9da33290-e777-4632-a8c8-813e15912d70', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('11e93cb8-52a5-40e5-961b-cceeaa99815e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', '9d1de691-d507-46d0-b247-f87b130a9cd9', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2a1b88dc-0666-4ad5-bc9a-9ffcaa21884f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e1a2786b-5308-4a11-9da4-23f1a60f88a3', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3f99e522-aaa0-4adc-ada0-a2145ce9a249', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a895e6c6-85a3-4359-9845-9e73ca3d1a45', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('24492e34-0de7-43b7-ba90-638b5252a837', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4b617082-a452-4f1d-85bd-681af43a6279', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e2721a6b-e585-4e49-90d0-e02bafdc93dc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', '2963e348-5403-4a11-acf1-8ea9a41f3812', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('613631f2-7ed3-4fee-b5f1-85d60ad071e0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', '1bae33a4-33be-44f1-9f97-0839a8caa08b', '2026-11-22 23:55:19.194196+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c388ea24-f69c-4eb8-a904-ac9d76f55aa5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', '807c8e83-690e-46ff-9dfa-e2b8021a074c', '2026-11-22 23:55:19.322068+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('10769088-c26d-4833-aedc-72b0ed87677a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', '2026-11-22 23:55:19.322068+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b78ea633-eef1-46da-b77e-51111e1cf0b4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', '2026-11-22 23:55:19.322068+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6f7ed610-af94-4137-b559-70ce2c066c4e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', '7502d679-f52e-4208-9a0a-6628c5c836fc', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0c217898-c9d4-4678-a812-2f8f7b18369c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', '7502d679-f52e-4208-9a0a-6628c5c836fc', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bb029174-88c3-40e4-a226-a2c10f02da42', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88596313-affa-43ae-ba60-be8ddcdea620', '7502d679-f52e-4208-9a0a-6628c5c836fc', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('db936426-2a5d-4ff7-a454-9e9ab786bc9b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186a8072-74b4-4c27-9623-5dc3fe827303', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a1f0d76f-21e1-4a08-afdc-f3c166c05e53', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bfaab13-de1b-4c44-a5ee-2234005caa20', '204807e1-19ac-4a98-a1f5-c89edca8f69a', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('93960df3-8354-486f-8064-129441446a1f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c379b524-8381-4cef-8f1c-db0919a217eb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '83b8311b-2dba-4f56-b373-dae82336eda7', '2026-11-22 23:55:20.502664+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('88bcae70-f9cb-4d59-b413-0f3ba1e841e8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', '2026-11-22 23:55:23.389654+00');


--
-- Data for Name: stock_ledger_totals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1a2901a8-a6dc-4fed-98b3-ba109ce2c2d4', '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', '83b8311b-2dba-4f56-b373-dae82336eda7', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26e19db4-a097-438b-8061-4514b12b7a20', '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', '83b8311b-2dba-4f56-b373-dae82336eda7', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', 'c29e334b-7662-4015-9afe-8b3526e33065', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', '83b8311b-2dba-4f56-b373-dae82336eda7', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e1a2786b-5308-4a11-9da4-23f1a60f88a3', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '9d1de691-d507-46d0-b247-f87b130a9cd9', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f65f021-681a-4ecb-af6f-4a5d9b667e72', '712b1b64-be5a-468e-bb71-1c466b34dca1', 10.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', '0030fd00-2868-4ed0-a979-8db88009383a', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', '204807e1-19ac-4a98-a1f5-c89edca8f69a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '79c6276d-bdee-4313-bfe6-617ce82fff58', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 2.900);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '54a70fb6-27f4-4f28-b22f-1b4929f83ae5', '0030fd00-2868-4ed0-a979-8db88009383a', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6b4ab39c-bb30-4758-aa0d-15032b0f20ee', 'b1a280e0-0b57-4555-bff2-9b35db52d777', 5.500);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c15de66e-9440-4a41-bad5-855060db64bd', '2f8525b6-79bd-411d-97d5-b50f45190369', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', '1bba8efb-ff55-4ddf-b46c-ecb4ff175be5', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 13.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', 'e4293c9f-f235-4c74-90cf-43104beff987', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd9db61c5-d00b-489f-a1a8-8950a8b4c361', 'e4293c9f-f235-4c74-90cf-43104beff987', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', '712b1b64-be5a-468e-bb71-1c466b34dca1', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', '712b1b64-be5a-468e-bb71-1c466b34dca1', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd3f8548-b4e0-4ae1-9271-a9492edc6996', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9942d546-729a-47e0-978a-c21cdca4a522', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 6.800);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fba93956-79a6-4711-ac06-13306f0838de', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '859d2067-5f56-4be6-bc03-2bdd56619331', '712b1b64-be5a-468e-bb71-1c466b34dca1', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', '204807e1-19ac-4a98-a1f5-c89edca8f69a', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', '0030fd00-2868-4ed0-a979-8db88009383a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6cbd3ad9-9f78-4bbd-8d0b-47665fbd3f82', '0030fd00-2868-4ed0-a979-8db88009383a', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e06824d7-d9d2-4ae5-8117-51df6760f021', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ddcadb51-4a46-4841-8200-9675e2e35903', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e6232713-61fb-4305-b9db-cca330549b49', 'e4293c9f-f235-4c74-90cf-43104beff987', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8ae42709-47ed-4252-823b-e3ed5e15ca4f', '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', '712b1b64-be5a-468e-bb71-1c466b34dca1', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7aab2368-ac5e-4b7d-985b-e1da592941bf', 'e4293c9f-f235-4c74-90cf-43104beff987', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffe885f7-cb4f-45f6-aeaa-e1878f19917c', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '59f96aaa-d5ee-4513-8932-3108a32beeff', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 1.800);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d3df1d3-df66-4f30-95bf-9021f2568949', 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '29a30a7b-4336-4185-9036-ece90fd01b8c', '7502d679-f52e-4208-9a0a-6628c5c836fc', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', '0030fd00-2868-4ed0-a979-8db88009383a', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '350b92a4-09a5-4f3e-b6cb-6a302b6b57e4', '7954e058-ee63-4bde-9395-af27e73cebcf', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', 'e4293c9f-f235-4c74-90cf-43104beff987', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77cd9fe9-d3c2-4ef5-a867-fbc64022e6ee', '712b1b64-be5a-468e-bb71-1c466b34dca1', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '30cb162e-2e0a-4ea5-9069-4ed172550821', '2f8525b6-79bd-411d-97d5-b50f45190369', 10.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '49e687bc-7914-4f53-b2e4-7059b36825c2', '0030fd00-2868-4ed0-a979-8db88009383a', 10.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 21.220);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 0.440);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 11.400);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88596313-affa-43ae-ba60-be8ddcdea620', '7502d679-f52e-4208-9a0a-6628c5c836fc', 36.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '83b8311b-2dba-4f56-b373-dae82336eda7', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '83b8311b-2dba-4f56-b373-dae82336eda7', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', '7502d679-f52e-4208-9a0a-6628c5c836fc', 24.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', '7502d679-f52e-4208-9a0a-6628c5c836fc', 18.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186a8072-74b4-4c27-9623-5dc3fe827303', '204807e1-19ac-4a98-a1f5-c89edca8f69a', 15.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bfaab13-de1b-4c44-a5ee-2234005caa20', '204807e1-19ac-4a98-a1f5-c89edca8f69a', 50.000);


--
-- Data for Name: stock_lots; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_lots (id, organization_id, product_template_id, name, is_serial, expiry_date, production_date, use_by_date, removal_strategy, status, meta_data, created_at) VALUES ('25ac7c8c-d075-45f0-bceb-475f5ee558ae', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', '20261122-1', false, NULL, '2026-11-22', NULL, 'FIFO', 'active', NULL, '2026-11-22 23:55:23.713805+00');


--
-- Data for Name: stock_moves; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('837f48c2-3d94-43f5-90c4-915c73122512', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2d00e434-51f2-48f7-9a9e-509d29b1392c', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-10-06 07:00:00+00', '2026-11-22 23:55:19.396123+00', '2023-10-06 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e774e9ce-7f88-40fe-9637-c5a1228b6f95', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9c970d67-66b9-4a48-955f-05bcf14b3e9f', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-10-08 08:07:00+00', '2026-11-22 23:55:19.416453+00', '2023-10-08 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('effa05a7-d1c0-405c-a97e-4b7d4b9db259', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '48490e5e-3871-4a9c-9acb-f5a8818a870a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-11-06 09:14:00+00', '2026-11-22 23:55:19.426579+00', '2023-11-06 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b1bb1dfc-01c1-40fa-8b72-0e44dd63b814', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '20ffdbbe-fbd4-4188-9a29-e815607350d7', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-11-08 10:21:00+00', '2026-11-22 23:55:19.433387+00', '2023-11-08 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('44bf1240-4f31-463a-b725-1995e4220ca2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '429988a7-f3b7-4a1f-9328-9aad65e614f8', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-11-10 11:28:00+00', '2026-11-22 23:55:19.442029+00', '2023-11-10 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ea140cef-35d5-4e1e-a14a-4e30d2041c15', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4d791e4d-c29b-4204-8d97-6c7e10ea8772', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-12-09 12:35:00+00', '2026-11-22 23:55:19.449495+00', '2023-12-09 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('29bfdbdc-1cc1-49f9-b16a-4d44677841d5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f4af99c1-41e0-4ef6-b2a0-7978d9206733', '88e78ef1-115e-465e-a474-c66b601da4b0', '2023-12-11 13:42:00+00', '2026-11-22 23:55:19.458148+00', '2023-12-11 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d8fb996c-195f-4e43-b3f6-f8d8117ce420', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f00375b9-583a-492f-b89b-112eedc4a840', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-01-11 14:49:00+00', '2026-11-22 23:55:19.464695+00', '2024-01-11 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5c0654c1-ef93-4fb3-bb2b-5c32c7dc1354', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8153f4a8-eecf-46df-b589-941a3dbb1495', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-01-13 15:56:00+00', '2026-11-22 23:55:19.47121+00', '2024-01-13 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6dfeb3e8-f1ae-44c4-a4da-1aef37e52a24', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'edb1ae45-7638-4ce1-b7a0-8018e99099ce', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-02-11 16:03:00+00', '2026-11-22 23:55:19.477372+00', '2024-02-11 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e4b8551f-35e8-4e2c-982d-5194722de34b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4491f476-cb7b-4864-9688-ab2c3a36ae39', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-02-13 07:10:00+00', '2026-11-22 23:55:19.483116+00', '2024-02-13 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('400cb774-4dc4-4aea-8ff9-bdef81e88dc3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f917bb8e-9743-4720-ad2f-752205873b5f', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-02-15 08:17:00+00', '2026-11-22 23:55:19.488786+00', '2024-02-15 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2a068807-7149-4c02-98d2-4d2d040f362f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', NULL, '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e58e7310-c395-446f-8e56-715b565aa3a8', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-03-15 09:24:00+00', '2026-11-22 23:55:19.494334+00', '2024-03-15 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e100e19e-5c2b-4798-a135-57f9f995f87a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fabe2104-00f8-4b9a-a9d1-edf5fd5cb3b9', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-03-17 10:31:00+00', '2026-11-22 23:55:19.499755+00', '2024-03-17 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8fb422ed-b596-4824-8f3c-c6cd01470624', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '72e7da27-fe1f-4ade-836f-c2240288f1b1', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-04-17 11:38:00+00', '2026-11-22 23:55:19.505469+00', '2024-04-17 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b2f891ef-25c8-41fe-acd6-c85ba6429e71', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '37010b24-1516-47a4-8e99-740e91d5d9e9', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-04-19 12:45:00+00', '2026-11-22 23:55:19.511558+00', '2024-04-19 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1d33865f-a43e-4009-b368-d83a40992fd9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', NULL, 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7c7fdece-5d6f-4405-bbe9-0660f3d76acc', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-05-18 13:52:00+00', '2026-11-22 23:55:19.517975+00', '2024-05-18 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1a2097e8-3589-4695-ad46-4e791091c006', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '77baf5e9-ed00-44fa-8241-713eaeb73625', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-05-20 14:59:00+00', '2026-11-22 23:55:19.523728+00', '2024-05-20 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3ccb8831-1117-4d4d-af39-0c3c7a748d85', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7e22cfc8-0b71-45ee-a174-ba7994ea558d', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-05-22 15:06:00+00', '2026-11-22 23:55:19.529416+00', '2024-05-22 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('04025a58-d30a-49bf-b91f-3d2756156393', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8febdf7d-9a03-4016-90d6-4429d7fbe13b', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-06-20 16:13:00+00', '2026-11-22 23:55:19.535336+00', '2024-06-20 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('eb69141c-34a3-4566-b2e5-73110bc7e52b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '21a2ed3d-078f-40dd-8c0e-007e4e5d84b4', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-06-22 07:20:00+00', '2026-11-22 23:55:19.541741+00', '2024-06-22 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8f3b7a80-4221-4a14-89bd-b450192e44a6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7adaf469-6026-455f-81a1-6c85923ff491', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-07-23 08:27:00+00', '2026-11-22 23:55:19.548719+00', '2024-07-23 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6161a7e8-b79a-4331-9cf2-5f9d76a01483', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ec4e9cb2-815a-429d-af47-d64de86ed749', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-07-25 09:34:00+00', '2026-11-22 23:55:19.555648+00', '2024-07-25 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('64ce3e6f-0412-45d0-a85f-9feed5ce5339', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '157fa9d1-f99f-4338-9cf7-7c830dd26057', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-08-23 10:41:00+00', '2026-11-22 23:55:19.56211+00', '2024-08-23 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2df70b15-6814-48fa-87a5-5cc5adcd4727', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'cf7295bd-cc09-4865-ba18-87352ff36c55', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-08-25 11:48:00+00', '2026-11-22 23:55:19.568426+00', '2024-08-25 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7b58a707-c3a9-48b6-9909-a988f9e4c1d8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1a2901a8-a6dc-4fed-98b3-ba109ce2c2d4', NULL, '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8bb52314-35a1-4636-b7a7-cdc75a65c89a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-08-27 12:55:00+00', '2026-11-22 23:55:19.574588+00', '2024-08-27 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9c422aa7-8135-4624-884f-228c4feb1dce', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', NULL, '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b66ae4bd-ae3f-4d84-a7b5-90fd18830f6f', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-09-25 13:02:00+00', '2026-11-22 23:55:19.579559+00', '2024-09-25 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0d53c9d6-4378-4898-8a9e-cdc741c0b756', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2691904e-364e-47a1-bc18-aee286f6d521', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-09-27 14:09:00+00', '2026-11-22 23:55:19.58592+00', '2024-09-27 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('947e88ca-6e2e-4830-9e99-c435155640a2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', NULL, '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0c70387b-af0f-49a0-8753-9881c880fe60', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-09-29 15:16:00+00', '2026-11-22 23:55:19.59219+00', '2024-09-29 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dd067a6b-204d-4f8e-a3a9-4d99c6034b67', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c21296d5-4c03-4e55-a171-77ff81b889a6', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-10-28 16:23:00+00', '2026-11-22 23:55:19.597508+00', '2024-10-28 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('13d30b5f-4d4e-4c1d-972a-b4bc86802331', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0b4daaee-7527-4b34-8612-a961b7584e49', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-10-30 07:30:00+00', '2026-11-22 23:55:19.603699+00', '2024-10-30 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('936b3f31-6654-4abf-a2d9-e195284c8f51', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c2b76e60-1eba-444c-a624-82f96b89e3b2', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-11-28 08:37:00+00', '2026-11-22 23:55:19.609825+00', '2024-11-28 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('25090766-a008-4043-a24c-f73fdfbc3335', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26e19db4-a097-438b-8061-4514b12b7a20', NULL, '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9813e9f0-a897-48cd-8ef2-3f88aa0158ad', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-11-30 09:44:00+00', '2026-11-22 23:55:19.61576+00', '2024-11-30 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3f436a30-bfd1-49eb-b0b2-817b78a4a752', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', NULL, '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f134a795-b79b-4b74-ade6-0628250f653f', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-12-02 10:51:00+00', '2026-11-22 23:55:19.622251+00', '2024-12-02 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('92a81387-8176-4950-baa1-b3c56b5b652b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f42e056d-455b-4e1e-b0b3-a942954bc1b6', '88e78ef1-115e-465e-a474-c66b601da4b0', '2024-12-31 11:58:00+00', '2026-11-22 23:55:19.628536+00', '2024-12-31 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c9eee885-763a-44d9-854e-1c6b18602334', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '938d9c41-86d2-4702-ab17-2a8b71cd3fe7', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-01-02 12:05:00+00', '2026-11-22 23:55:19.634617+00', '2025-01-02 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('593f50b8-3be9-4ac8-a216-e973b4927e56', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd1d81756-7e4a-4673-8f2a-36a16791f867', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-01-04 13:12:00+00', '2026-11-22 23:55:19.641226+00', '2025-01-04 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('443e4e9a-c3d5-47e9-ae0b-c0099f7430a9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0e2154b7-446a-4c1c-b4fc-d15de164cbdc', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-02-02 14:19:00+00', '2026-11-22 23:55:19.648214+00', '2025-02-02 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8d83436d-1727-4eb5-95bd-2d64166ad58c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a0a99f71-12fb-4d17-907a-2e230d156fef', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-02-04 15:26:00+00', '2026-11-22 23:55:19.655102+00', '2025-02-04 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e71cee99-9862-4588-96df-4436f5a7bb7c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c7ec15e4-4eb6-4c3f-a3a0-f1816b4fb2d3', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-03-05 16:33:00+00', '2026-11-22 23:55:19.66167+00', '2025-03-05 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('11cdfb49-6adb-430a-b220-d5b2c95a7f68', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '13a59844-a2f1-4ef7-96ff-2da1f2257822', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-03-07 07:40:00+00', '2026-11-22 23:55:19.668074+00', '2025-03-07 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9688e6ce-0e08-48ea-816a-08779a897536', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '813de566-72ce-419e-9676-8d21992312fc', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-03-09 08:47:00+00', '2026-11-22 23:55:19.674559+00', '2025-03-09 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('808ac9ab-67ae-41f8-a033-25171ac5acc0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2b966f52-a764-46af-afab-74cdfe2f9581', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-04-07 09:54:00+00', '2026-11-22 23:55:19.680958+00', '2025-04-07 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('459ae0ee-9018-4a00-934e-08584c9a4277', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b3bf91cf-3dfd-4b2e-afab-d1b8d6b3e9b1', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-04-09 10:01:00+00', '2026-11-22 23:55:19.688191+00', '2025-04-09 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('45bfe53c-8f77-4472-b674-1fc3e738e1df', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2bb65ea2-29ac-43b0-b43e-5ccfc398db3a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-04-11 11:08:00+00', '2026-11-22 23:55:19.698645+00', '2025-04-11 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bdb07d9e-22aa-4ad9-a492-1f5d54006a66', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'cf7812b9-80d5-4993-a664-a4fd3257ca05', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-05-10 12:15:00+00', '2026-11-22 23:55:19.705932+00', '2025-05-10 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d881eb7f-4a55-4c91-8cdc-c72f8f1a7152', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ff50009f-7684-47d5-a847-b0f6995eb8d5', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-05-12 13:22:00+00', '2026-11-22 23:55:19.712611+00', '2025-05-12 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b7e15be7-3a00-4715-9d5c-392a54d420ba', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e6ee5ee4-9c7b-438d-be16-866aedf19b27', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-06-10 14:29:00+00', '2026-11-22 23:55:19.719036+00', '2025-06-10 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ebacd4be-6372-4a05-9e11-c27d8332f05b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '54bd6daf-0c44-4894-999a-cdefe1a4e280', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-06-12 15:36:00+00', '2026-11-22 23:55:19.725551+00', '2025-06-12 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8c225935-11fc-4fc0-99a0-875c64f9cdd0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2cc6f509-7b9f-4633-b98b-b086255f4075', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-06-14 16:43:00+00', '2026-11-22 23:55:19.732425+00', '2025-06-14 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b898e3d3-2a63-422e-858b-73fb331c6b64', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4310af98-5caf-4086-8a38-7bf13e55dc01', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-07-13 07:50:00+00', '2026-11-22 23:55:19.739704+00', '2025-07-13 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('828b9487-42b5-4ed6-aff0-0524194631f1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0b274131-585c-46e2-96ee-98febe6e845b', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-07-15 08:57:00+00', '2026-11-22 23:55:19.746651+00', '2025-07-15 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('00e6f44b-8c23-4254-ac73-e7f3c5fd1e0f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3589f947-2b28-4085-82a7-6341cb251076', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-07-17 09:04:00+00', '2026-11-22 23:55:19.751902+00', '2025-07-17 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('eb8cc1c6-fd0e-4244-8474-e523ccb55fa2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a5622924-d731-4178-b40d-1c8037ce3a6c', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-08-15 10:11:00+00', '2026-11-22 23:55:19.758672+00', '2025-08-15 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('14b5d609-88d1-4d63-af3f-a292b9ae42c7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '45223c3d-9e4e-4991-8609-35e7cbb68e2e', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-08-17 11:18:00+00', '2026-11-22 23:55:19.765211+00', '2025-08-17 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('53942a23-9cfd-413d-ba19-e1efbc64400c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3ae1b665-4adf-49b8-8c00-435345364f34', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-09-15 12:25:00+00', '2026-11-22 23:55:19.771689+00', '2025-09-15 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('01e653d2-1752-4400-9279-f27622d3774b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '53c1b3e0-0898-4f8b-9ef0-35b2707900ea', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-09-17 13:32:00+00', '2026-11-22 23:55:19.778085+00', '2025-09-17 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('53d4485c-4021-4c1b-9049-2a377362ab42', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '66c97f74-5ae4-483b-8e84-5a0ee2799b7d', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-09-19 14:39:00+00', '2026-11-22 23:55:19.784617+00', '2025-09-19 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1b6d02e8-dacc-4dd5-82f6-6567405a4e35', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'af5bb75b-cf85-4ae3-90e5-c70b80704e45', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-10-18 15:46:00+00', '2026-11-22 23:55:19.791196+00', '2025-10-18 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e356146d-9e58-4cd0-b1c8-0f5475e23bad', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', NULL, '1bae33a4-33be-44f1-9f97-0839a8caa08b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '506857e2-db57-406f-a6e0-637b78b83cef', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-10-20 16:53:00+00', '2026-11-22 23:55:19.802163+00', '2025-10-20 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2cb5f112-a195-4ef0-96b4-024bc72d7b8b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9b11e9c7-5756-4729-9b79-aa6c808c2ab5', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-10-22 07:00:00+00', '2026-11-22 23:55:19.808201+00', '2025-10-22 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bfcfbc48-d8d6-4a75-b8a8-fb51149e2226', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '03c0bb6a-8b87-4eb6-b771-06e6e65fdc3c', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-11-20 08:07:00+00', '2026-11-22 23:55:19.814401+00', '2025-11-20 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f5d313d3-2f4d-46ec-bc4c-540ef2505ed5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5130b8be-1a70-4d66-a102-6d0eee37e550', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-11-22 09:14:00+00', '2026-11-22 23:55:19.820685+00', '2025-11-22 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b7a03dd7-eff9-499d-9cea-e4785c3f0767', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fbfe196b-d4e3-404c-9bd1-7b87a99a663a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-12-21 10:21:00+00', '2026-11-22 23:55:19.827257+00', '2025-12-21 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0f70d28b-9bcb-47c5-8777-ec3563659b11', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'be8d8557-0b3b-4e1c-b6c9-6684fc58cc46', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-12-23 11:28:00+00', '2026-11-22 23:55:19.833353+00', '2025-12-23 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4250d18e-544c-4b1a-9cb5-f71c1536290f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '138f8ad8-5073-47ed-be5c-2d235c71ca4e', '88e78ef1-115e-465e-a474-c66b601da4b0', '2025-12-25 12:35:00+00', '2026-11-22 23:55:19.839656+00', '2025-12-25 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dce3c597-2043-4ffa-9155-7a5b9d7272bc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 'ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '33729033-025c-4be1-a170-11aa9a80e866', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-01-23 13:42:00+00', '2026-11-22 23:55:19.844461+00', '2026-01-23 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('36595627-50fb-4952-9773-fd4f8e0a5844', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ac72159a-fd26-4ef4-9f7d-d4ae7cd18005', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-01-25 14:49:00+00', '2026-11-22 23:55:19.850523+00', '2026-01-25 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9682e913-72fb-4ba2-a805-87c3ba4a9bdb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6fe58941-a6ac-40b1-8cd8-9fcd440bc2a1', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-01-27 15:56:00+00', '2026-11-22 23:55:19.856553+00', '2026-01-27 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('753df320-d521-4a50-801b-107dcba4903d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e7103f6c-cd93-4bcb-8a43-4d19e99dca52', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-02-25 16:03:00+00', '2026-11-22 23:55:19.863855+00', '2026-02-25 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('adac3c86-2bba-4086-8eb1-bc5b80edd1f6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ffd544c7-4657-47b9-84d2-c45de26f026e', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-02-27 07:10:00+00', '2026-11-22 23:55:19.870487+00', '2026-02-27 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3e74ebba-feb2-4974-89e0-d4aee8a94ce3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '12cd3ca4-33d7-44f3-8e3c-bd0842cbd2f0', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-03-28 08:17:00+00', '2026-11-22 23:55:19.876913+00', '2026-03-28 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('46bbd0a5-4dbd-41d5-821f-84f1c8d21401', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ecbb4d7e-c16c-4651-bfc8-e42b4192fee1', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-03-30 09:24:00+00', '2026-11-22 23:55:19.88326+00', '2026-03-30 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a22d1fba-43ae-4154-b9f4-4beb4dd11b39', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4404533f-b7a9-43c2-ac86-b38e8f08e32a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-04-01 10:31:00+00', '2026-11-22 23:55:19.888509+00', '2026-04-01 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3bd845bc-74a1-46d5-bb3a-8206df42a0c9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '99f1251e-7127-4227-ae77-845c8b0e1a91', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-04-30 11:38:00+00', '2026-11-22 23:55:19.894811+00', '2026-04-30 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7056fcfc-7579-4c90-ac1f-e4b2877faf3f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4e9fbd3c-7b50-4011-8ba7-e5e88bdad26f', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-05-02 12:45:00+00', '2026-11-22 23:55:19.902523+00', '2026-05-02 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('362623a5-e464-4a44-b8af-c2ab6796515f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bc5c4a83-beef-4986-a506-3f25d376505c', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-05-04 13:52:00+00', '2026-11-22 23:55:19.909954+00', '2026-05-04 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6c0e84ae-777b-487c-9931-bcc4670c285f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, '2963e348-5403-4a11-acf1-8ea9a41f3812', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8f47f4fb-43bf-4688-9837-f1d5151211d7', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-06-02 14:59:00+00', '2026-11-22 23:55:19.918219+00', '2026-06-02 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ad134bc1-30aa-4def-9797-2f63735bac26', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 'c29e334b-7662-4015-9afe-8b3526e33065', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '43cd42fe-2d34-4919-a459-53b29ffa7e5c', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-06-04 15:06:00+00', '2026-11-22 23:55:19.931403+00', '2026-06-04 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('37c8901d-e4ad-4a75-8f14-95698a300a9f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, 'fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a8135f8e-e887-4ea7-985f-3397fdf546a6', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-07-03 16:13:00+00', '2026-11-22 23:55:19.940769+00', '2026-07-03 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cd11e322-0987-4a5b-9276-9fbaafce6e04', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 'edb27e2e-8de8-418f-98a4-09f9f1a868cc', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '87c5e848-f535-4fa7-af30-1364bb7dc02a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-07-05 07:20:00+00', '2026-11-22 23:55:19.947352+00', '2026-07-05 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9f20e3e7-c1c6-4a8a-b885-364c285b454b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, '970f90c8-b151-4998-aa91-2c3da24502e3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd989641a-1ac8-418d-89f6-fed92863c529', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-07-07 08:27:00+00', '2026-11-22 23:55:19.953292+00', '2026-07-07 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8aa76de9-ada7-41f0-abd6-7df301b3d1d4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, '42ca38f2-ad9e-451b-9a9f-ad53900d3500', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'aab4e633-6bf4-464e-b5c2-1da211c7befe', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-08-05 09:34:00+00', '2026-11-22 23:55:19.959327+00', '2026-08-05 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b5bcaad0-a7d7-4a29-8520-3976ae875f0a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd8d53a94-2e2e-4265-af1e-3d6a159a13c2', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-08-07 10:41:00+00', '2026-11-22 23:55:19.96526+00', '2026-08-07 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('595dd2aa-f879-4277-9da9-fe7072cef0c6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e1a2786b-5308-4a11-9da4-23f1a60f88a3', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b8c0d0fd-64c2-4b2b-95f9-0ba3f8485920', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-08-09 11:48:00+00', '2026-11-22 23:55:19.972059+00', '2026-08-09 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('25b50a53-f329-4d23-94f1-e5a4788ee97d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b713a9e4-08a4-4d8d-817d-00c38c0d8ccc', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-07 12:55:00+00', '2026-11-22 23:55:19.978525+00', '2026-09-07 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ce4f3a2f-6d42-4a22-8442-94121a0271d6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, '8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f7d2ef2b-b813-43e1-95ad-83241701dcc4', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-09 13:02:00+00', '2026-11-22 23:55:19.984921+00', '2026-09-09 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1157a93d-ca2e-4cc6-9558-33ec27145979', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, '9d1de691-d507-46d0-b247-f87b130a9cd9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '81e5dc07-9ef5-4e20-b054-2ddc518ac726', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-08 14:09:00+00', '2026-11-22 23:55:19.98992+00', '2026-10-08 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6db63d7c-1fbb-44d6-8a14-117e756fe5d7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', NULL, 'e4293c9f-f235-4c74-90cf-43104beff987', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd3ad0f44-d78c-4621-aef7-4f55460a3103', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-15 15:16:00+00', '2026-11-22 23:55:19.996924+00', '2026-11-15 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('247d8464-08e7-4fa9-a770-da2f8fb7bf13', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f65f021-681a-4ecb-af6f-4a5d9b667e72', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', 10.000, NULL, NULL, NULL, 'done', 'opening_balance', '0a398e3e-b4f1-48ef-9ebe-f713d8e1eca8', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-04 16:23:00+00', '2026-11-22 23:55:20.005026+00', '2026-11-04 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f6b44392-1f97-48ee-84b3-63bb57bc365c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', NULL, '0030fd00-2868-4ed0-a979-8db88009383a', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '65d82134-c64d-4b36-95b5-d925f663aa95', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-24 07:30:00+00', '2026-11-22 23:55:20.013034+00', '2026-10-24 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('69aa01a4-8756-477e-8241-59494d5fec49', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7a5ca430-8e74-4e4a-9663-00288ab1c481', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-16 08:37:00+00', '2026-11-22 23:55:20.020449+00', '2026-11-16 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a29859c4-381b-4b8e-85c4-9cf3ff64022a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '79c6276d-bdee-4313-bfe6-617ce82fff58', NULL, '807c8e83-690e-46ff-9dfa-e2b8021a074c', 2.900, NULL, NULL, NULL, 'done', 'opening_balance', 'dfba2f92-9196-47e4-ba46-85ca729ef700', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-17 09:44:00+00', '2026-11-22 23:55:20.027301+00', '2026-11-17 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f59128cd-3a52-4e83-850b-4a177cc87a21', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '54a70fb6-27f4-4f28-b22f-1b4929f83ae5', NULL, '0030fd00-2868-4ed0-a979-8db88009383a', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'abfc7d55-9b4f-484c-ac4b-99f374f0ab76', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-21 10:51:00+00', '2026-11-22 23:55:20.03486+00', '2026-09-21 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9987e04b-b830-4134-b2b9-20727060f14b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6b4ab39c-bb30-4758-aa0d-15032b0f20ee', NULL, 'b1a280e0-0b57-4555-bff2-9b35db52d777', 5.500, NULL, NULL, NULL, 'done', 'opening_balance', '8a9dd754-8204-440f-995b-0ba70726ca49', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-18 11:58:00+00', '2026-11-22 23:55:20.042871+00', '2026-11-18 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1576053f-cdf4-4214-999c-9b5dc23a4927', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c15de66e-9440-4a41-bad5-855060db64bd', NULL, '2f8525b6-79bd-411d-97d5-b50f45190369', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '5af4148e-307e-4d85-bbe8-cdd87a229943', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-02 12:05:00+00', '2026-11-22 23:55:20.050906+00', '2026-11-02 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3a32c0d0-1c92-4bd8-b441-cae275ac689b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', NULL, '1bba8efb-ff55-4ddf-b46c-ecb4ff175be5', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '94c145af-cc95-43e5-a73e-785d902dc299', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-19 13:12:00+00', '2026-11-22 23:55:20.059604+00', '2026-11-19 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('87e7cd1a-03e8-4720-b330-2d491e85ab54', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', NULL, 'e4293c9f-f235-4c74-90cf-43104beff987', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f8f03ff9-8986-4b9a-8d87-dbfc7ce2a9cc', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-11 14:19:00+00', '2026-11-22 23:55:20.065814+00', '2026-10-11 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cc73c30d-9d51-46ab-8c11-8ae28c0703b6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd9db61c5-d00b-489f-a1a8-8950a8b4c361', NULL, 'e4293c9f-f235-4c74-90cf-43104beff987', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', 'dbd995f2-669e-4db7-b8bf-f9193b1686a1', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-30 15:26:00+00', '2026-11-22 23:55:20.074933+00', '2026-09-30 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cc3c622c-8c63-401a-97f1-d44f15365a03', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '38eb4f22-5460-41b7-be14-d84c7d7f337a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-19 16:33:00+00', '2026-11-22 23:55:20.082812+00', '2026-09-19 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('10d313c3-4642-448e-8fb7-ae3e658e5243', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', NULL, 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '15a2c318-6a95-48b0-8d69-6073ac5b5576', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-11 07:40:00+00', '2026-11-22 23:55:20.091333+00', '2026-11-11 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dbf0b417-0f2d-48ab-8399-5000e6669836', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', NULL, '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '3b7c24b2-57cd-4db9-887d-401eb9f8f34c', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-31 08:47:00+00', '2026-11-22 23:55:20.099181+00', '2026-10-31 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6ba052ff-afce-4649-83f9-2750db23ef28', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '9187b27d-211d-4566-81f5-2cb2eb2cc966', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-20 09:54:00+00', '2026-11-22 23:55:20.107102+00', '2026-10-20 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b8b51efc-6e55-44f0-bf88-9145a437ac0f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd3f8548-b4e0-4ae1-9271-a9492edc6996', NULL, '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e1766c5a-9356-47b3-994f-bca1df101f05', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-09 10:01:00+00', '2026-11-22 23:55:20.114945+00', '2026-10-09 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('37922faa-f76c-448e-8ed6-102d5197d879', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9942d546-729a-47e0-978a-c21cdca4a522', NULL, '807c8e83-690e-46ff-9dfa-e2b8021a074c', 6.800, NULL, NULL, NULL, 'done', 'opening_balance', 'acdd3997-5ace-4ddf-b501-9ceab886be7e', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-17 11:08:00+00', '2026-11-22 23:55:20.123035+00', '2026-11-17 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7284d4c1-0254-4656-a8a4-2f7374462948', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fba93956-79a6-4711-ac06-13306f0838de', NULL, '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '90054f3d-0f4e-423c-a970-7baf9e9c3995', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-17 12:15:00+00', '2026-11-22 23:55:20.131055+00', '2026-09-17 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3e82d178-a1d6-4d87-b2eb-be606a94fdce', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '859d2067-5f56-4be6-bc03-2bdd56619331', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', 'dee0c03e-c83e-4925-a3f9-f25631351b46', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-09 13:22:00+00', '2026-11-22 23:55:20.138852+00', '2026-11-09 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cb5ec82e-dca0-42d2-b718-8fdba75f4ee7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '6caf2b25-74ad-474e-ba57-439be9dc8faf', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-20 14:29:00+00', '2026-11-22 23:55:20.146855+00', '2026-11-20 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('24cf8cd8-e0ba-429d-bc4c-7ad5bedecef8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', NULL, '0030fd00-2868-4ed0-a979-8db88009383a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '97015753-8bb6-4973-9769-2e8160c297fc', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-18 15:36:00+00', '2026-11-22 23:55:20.154886+00', '2026-10-18 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4956d9f3-f30c-4d0a-ab4e-24968936f20d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6cbd3ad9-9f78-4bbd-8d0b-47665fbd3f82', NULL, '0030fd00-2868-4ed0-a979-8db88009383a', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '58e27714-0750-43d2-9e13-5783bddcddf2', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-07 16:43:00+00', '2026-11-22 23:55:20.162651+00', '2026-10-07 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9445306c-7ca9-48ea-bb6b-e9f242ee153f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e06824d7-d9d2-4ae5-8117-51df6760f021', NULL, 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '460fdc77-b291-445a-a255-75c264823ce5', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-26 07:50:00+00', '2026-11-22 23:55:20.170772+00', '2026-09-26 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('14129807-1c9e-44ee-b048-f8f310f0bf01', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ddcadb51-4a46-4841-8200-9675e2e35903', NULL, 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', '81912555-6efd-4a4f-93cb-a2266dd31ea4', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-15 08:57:00+00', '2026-11-22 23:55:20.179106+00', '2026-09-15 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1e6ebf59-3180-42da-afb2-40e387caaae8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '30cb162e-2e0a-4ea5-9069-4ed172550821', NULL, '2f8525b6-79bd-411d-97d5-b50f45190369', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', 'badb991d-3d7b-4ba5-92e9-939424b9c11d', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-07 09:04:00+00', '2026-11-22 23:55:20.187929+00', '2026-11-07 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d26447a5-1e30-4a98-a064-a601a28f1fd2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e6232713-61fb-4305-b9db-cca330549b49', NULL, 'e4293c9f-f235-4c74-90cf-43104beff987', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '780aebe6-e9c9-4570-973d-9d33317a415a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-27 10:11:00+00', '2026-11-22 23:55:20.19607+00', '2026-10-27 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('94fdca27-eacf-40d1-8589-cff7b68fd111', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8ae42709-47ed-4252-823b-e3ed5e15ca4f', NULL, '16a2d288-a0c3-4b12-b575-4b6373d8f95f', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '5fc4d3e6-4016-4ad2-a66d-77c3a06cfaaa', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-16 11:18:00+00', '2026-11-22 23:55:20.203905+00', '2026-10-16 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a13844c8-8c82-4cf0-a561-8ca624cc6037', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fae08a81-aab0-43ab-a205-bedcd9e052d6', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-05 12:25:00+00', '2026-11-22 23:55:20.211696+00', '2026-10-05 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('70c63d16-000c-4807-86d4-8da035acf865', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7aab2368-ac5e-4b7d-985b-e1da592941bf', NULL, 'e4293c9f-f235-4c74-90cf-43104beff987', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '6743ae73-3697-468a-818a-f9620778d161', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-24 13:32:00+00', '2026-11-22 23:55:20.219779+00', '2026-09-24 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c4f0fbb6-73a2-4929-b8ed-cf8ae8de5859', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffe885f7-cb4f-45f6-aeaa-e1878f19917c', NULL, 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f3aee863-ff80-4f37-9dd0-d8028f1c8db3', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-13 14:39:00+00', '2026-11-22 23:55:20.227719+00', '2026-09-13 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0c3959c1-dac9-4c0f-89d2-f81532913bd4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '59f96aaa-d5ee-4513-8932-3108a32beeff', NULL, '807c8e83-690e-46ff-9dfa-e2b8021a074c', 1.800, NULL, NULL, NULL, 'done', 'opening_balance', '86e13756-35a0-4139-a7c5-f3972a563e34', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-20 15:46:00+00', '2026-11-22 23:55:20.23604+00', '2026-11-20 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5340f70b-0c42-40c4-bf43-4a70cf8e4c5c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', NULL, 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '86563fcc-3a4c-481f-8a45-82f66b56795e', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-25 16:53:00+00', '2026-11-22 23:55:20.243755+00', '2026-10-25 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('adac7414-1e62-4d36-aeca-8010d887c35e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d3df1d3-df66-4f30-95bf-9021f2568949', NULL, 'bb860c6b-4b1d-405b-bad2-f62439ad9655', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b623d8a3-f5be-41bd-aa6e-58e36597abf5', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-14 07:00:00+00', '2026-11-22 23:55:20.251774+00', '2026-10-14 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b666036c-5eda-42c1-ade0-8ff26a45ba35', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '29a30a7b-4336-4185-9036-ece90fd01b8c', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '0caeac27-c0cb-4a6e-b83f-bfbd82e0e383', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-18 08:07:00+00', '2026-11-22 23:55:20.260018+00', '2026-11-18 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f4dbab50-fc58-433c-a67b-87b9c48ae3b6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', NULL, '0030fd00-2868-4ed0-a979-8db88009383a', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f7f0c2ba-5dc8-44e9-bc69-fa9f2b32027a', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-09-22 09:14:00+00', '2026-11-22 23:55:20.268383+00', '2026-09-22 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fce61ee8-34c1-4ac9-9e1d-a4e34af1f5c3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '350b92a4-09a5-4f3e-b6cb-6a302b6b57e4', NULL, '7954e058-ee63-4bde-9395-af27e73cebcf', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '03f5811c-b3d3-4e1b-9f5b-fd091633aea7', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-14 10:21:00+00', '2026-11-22 23:55:20.276379+00', '2026-11-14 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9f2eb72e-e330-4c14-91b7-3f76112bb2c6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', NULL, 'e4293c9f-f235-4c74-90cf-43104beff987', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '2aee48b0-be8a-4d7f-9db1-9605706175aa', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-03 11:28:00+00', '2026-11-22 23:55:20.284368+00', '2026-11-03 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('17f31f18-4b93-462b-95bc-f4f197115fab', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77cd9fe9-d3c2-4ef5-a867-fbc64022e6ee', NULL, '712b1b64-be5a-468e-bb71-1c466b34dca1', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '763cce76-3c47-4b67-aae3-f86ba2b17658', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-23 12:35:00+00', '2026-11-22 23:55:20.292315+00', '2026-10-23 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2023c884-efce-45fd-86e2-bf366d4aa304', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '30cb162e-2e0a-4ea5-9069-4ed172550821', NULL, '2f8525b6-79bd-411d-97d5-b50f45190369', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '7a55e37c-506c-466b-b954-ed79034b0135', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-12 13:42:00+00', '2026-11-22 23:55:20.298903+00', '2026-10-12 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('02e8bb8e-4242-4ea6-a063-1dcfdd5d8472', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '49e687bc-7914-4f53-b2e4-7059b36825c2', NULL, '0030fd00-2868-4ed0-a979-8db88009383a', 10.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fcb2eda8-ef56-4cac-8e52-0639bba736d2', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-01 14:49:00+00', '2026-11-22 23:55:20.306827+00', '2026-10-01 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('41613301-fd2b-4baf-b405-735121f530a7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', NULL, '807c8e83-690e-46ff-9dfa-e2b8021a074c', 40.000, NULL, NULL, NULL, 'done', 'opening_balance', '25464f0a-2193-4630-9427-9954b1b2f859', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-19 15:56:00+00', '2026-11-22 23:55:20.315406+00', '2026-11-19 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4ee6a29f-5b9e-49ea-99d4-e989de125100', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', NULL, 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 25.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e37f1382-b999-493a-9a1b-a5a94d039c98', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-02 16:03:00+00', '2026-11-22 23:55:20.323658+00', '2026-11-02 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('49477221-331f-407a-a6a9-3436b4e68ab6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', NULL, 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 0.500, NULL, NULL, NULL, 'done', 'opening_balance', '186e287f-bc5d-445d-880a-403060f87da0', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-10-19 07:10:00+00', '2026-11-22 23:55:20.331016+00', '2026-10-19 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c01e1dfb-ffdb-4f77-9e80-1f0876f5cab2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', '807c8e83-690e-46ff-9dfa-e2b8021a074c', NULL, 26.400, NULL, NULL, NULL, 'done', 'maker_production', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.618281+00', '2026-11-22 23:55:23.618284+00', '2026-11-22 23:55:23.617498+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3acd5ef4-3e9a-4744-b89c-5b225194ea93', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', NULL, 3.780, NULL, NULL, NULL, 'done', 'maker_production', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.658435+00', '2026-11-22 23:55:23.658437+00', '2026-11-22 23:55:23.658209+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ae1ab54f-fa4a-44c9-b339-bd7fe71fd998', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', NULL, 0.060, NULL, NULL, NULL, 'done', 'maker_production', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.685014+00', '2026-11-22 23:55:23.685015+00', '2026-11-22 23:55:23.684827+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9223c2d4-6381-4bb8-ba2a-743a3b334192', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', NULL, 'ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 11.400, '25ac7c8c-d075-45f0-bceb-475f5ee558ae', NULL, NULL, 'done', 'maker_production', '1a2f5a6c-e031-4007-840f-9e5fb0192628', '88e78ef1-115e-465e-a474-c66b601da4b0', '2026-11-22 23:55:23.73232+00', '2026-11-22 23:55:23.732322+00', '2026-11-22 23:55:23.731682+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cf94d788-a5a4-45d6-9447-b3e2e1a3a14c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 3.000, NULL, NULL, NULL, 'done', 'document', '054cddf7-389d-4924-8f21-f2fed4a146b3', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-05 13:30:00+00', '2026-11-22 23:55:24.356163+00', '2026-11-05 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('816b555f-5343-415f-83a9-699c295df5d0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88596313-affa-43ae-ba60-be8ddcdea620', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', 48.000, NULL, NULL, NULL, 'done', 'document', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-13 12:15:00+00', '2026-11-22 23:55:24.362789+00', '2026-11-13 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3bbf3b61-5244-4094-969e-ff6ce9d9b045', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', 24.000, NULL, NULL, NULL, 'done', 'document', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-13 12:15:00+00', '2026-11-22 23:55:24.362789+00', '2026-11-13 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f59a6607-c95f-414f-9e8c-5e8f158d98e2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', 36.000, NULL, NULL, NULL, 'done', 'document', 'f9c47d10-87e5-4b81-8fa2-1a1e11777d8c', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-13 12:15:00+00', '2026-11-22 23:55:24.362789+00', '2026-11-13 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('68617093-8fa4-418a-af65-eb43a3548d8a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bfaab13-de1b-4c44-a5ee-2234005caa20', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', 60.000, NULL, NULL, NULL, 'done', 'document', 'b5959924-e568-46f1-9632-b5f12dcf9d6d', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-15 12:15:00+00', '2026-11-22 23:55:24.365201+00', '2026-11-15 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d7b3712a-3e3d-453d-8380-290066ea626a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186a8072-74b4-4c27-9623-5dc3fe827303', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', 20.000, NULL, NULL, NULL, 'done', 'document', 'b5959924-e568-46f1-9632-b5f12dcf9d6d', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-15 12:15:00+00', '2026-11-22 23:55:24.365201+00', '2026-11-15 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0e2e55c3-ed13-41f2-a34e-da9470bfadbb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88596313-affa-43ae-ba60-be8ddcdea620', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, 12.000, NULL, NULL, NULL, 'done', 'document', '07c60117-499a-49d7-9c54-bae39d30641c', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-18 10:50:00+00', '2026-11-22 23:55:24.367186+00', '2026-11-18 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('444e0c5f-7332-4780-a8b1-18304906ca0d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, 8.000, NULL, NULL, NULL, 'done', 'document', '07c60117-499a-49d7-9c54-bae39d30641c', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-18 10:50:00+00', '2026-11-22 23:55:24.367186+00', '2026-11-18 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7dee3ee0-2d28-4b9b-b0a6-933d989786a8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 5.000, NULL, NULL, NULL, 'done', 'document', 'a8f85246-f3f1-4791-b0d1-115dd7eeb216', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-20 14:45:00+00', '2026-11-22 23:55:24.369725+00', '2026-11-20 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a843e92e-a38b-4823-babe-21ed8a44ac8b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, '83b8311b-2dba-4f56-b373-dae82336eda7', 3.000, NULL, NULL, NULL, 'done', 'document', 'a8f85246-f3f1-4791-b0d1-115dd7eeb216', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-20 14:45:00+00', '2026-11-22 23:55:24.369725+00', '2026-11-20 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('42db392f-4ea8-49a2-a8fa-548ff347b7dd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, 6.000, NULL, NULL, NULL, 'done', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-21 13:30:00+00', '2026-11-22 23:55:24.372008+00', '2026-11-21 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('08e3b4d9-1fda-4de8-a10b-b81c96d51c7d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL, 4.000, NULL, NULL, NULL, 'done', 'document', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '3138d71e-a910-424a-81fe-5d36ad73454b', '2026-11-21 13:30:00+00', '2026-11-22 23:55:24.372008+00', '2026-11-21 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1d31440d-9c52-4928-81e2-f621e39b6d87', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bfaab13-de1b-4c44-a5ee-2234005caa20', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, 10.000, NULL, NULL, NULL, 'done', 'document', 'e16e2475-b69e-4715-883b-f18f7de2a781', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-21 14:00:00+00', '2026-11-22 23:55:24.373663+00', '2026-11-21 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f6e88a9a-c156-4002-994c-5b2a7fb7ac45', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186a8072-74b4-4c27-9623-5dc3fe827303', '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL, 5.000, NULL, NULL, NULL, 'done', 'document', 'e16e2475-b69e-4715-883b-f18f7de2a781', '72354123-6bc0-4834-8870-3e0faad5b922', '2026-11-21 14:00:00+00', '2026-11-22 23:55:24.373663+00', '2026-11-21 14:00:00+00');


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('cd22f97e-bcdb-45ab-8674-33eaa22133c6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0156a326-f4ec-4e77-a326-c90b005c512e', '3fda14e8-ce91-4743-91cc-4cadcb71a9ef', 'a1f0d76f-21e1-4a08-afdc-f3c166c05e53', NULL, NULL, 10.000, '2026-11-22 23:55:21.202628+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('60738171-2f92-462d-a75f-9cd607d701d0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'abf6e7e0-2e80-471f-9dcc-b89bf39c6998', '73d9c273-4508-499f-8af1-99af8757c564', 'a1f0d76f-21e1-4a08-afdc-f3c166c05e53', NULL, NULL, 8.000, '2026-11-22 23:55:21.3062+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('cca8cd5c-3a2d-45cf-90c6-6fad7c7d51d1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'abf6e7e0-2e80-471f-9dcc-b89bf39c6998', 'e86b79db-9e46-4da5-98d2-168350aa084e', 'db936426-2a5d-4ff7-a454-9e9ab786bc9b', NULL, NULL, 4.000, '2026-11-22 23:55:21.321086+00');


--
-- Data for Name: stock_take_closed_locations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_counts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('259b4b42-c84f-4e00-91d1-2ed3c2a58e5c', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', 'd3ad0f44-d78c-4621-aef7-4f55460a3103', 'Buckwheat Groats', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 5.000, 4.000, NULL, NULL, NULL, 1, '2026-11-22 23:55:23.787615+00', '2026-11-22 23:55:23.787621+00', 'MISCOUNT', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('51b04eea-c108-4fae-a976-a1039f4f17ce', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', '0a398e3e-b4f1-48ef-9ebe-f713d8e1eca8', 'Soy Sauce', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 10.000, 10.000, NULL, NULL, NULL, 0, '2026-11-22 23:55:23.787622+00', '2026-11-22 23:55:23.787623+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('1a80b66e-c55b-43d2-8fe4-692a574a84cf', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', '65d82134-c64d-4b36-95b5-d925f663aa95', 'Tomato Paste', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 5.000, 5.000, NULL, NULL, NULL, 0, '2026-11-22 23:55:23.787624+00', '2026-11-22 23:55:23.787624+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('3ae2ae4b-2ed5-42c2-889b-e1e27d4c0687', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', 'abfc7d55-9b4f-484c-ac4b-99f374f0ab76', 'Baking Powder', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 3.000, 1.000, NULL, NULL, NULL, 1, '2026-11-22 23:55:23.787625+00', '2026-11-22 23:55:23.787625+00', 'DAMAGE', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('ca1ff7de-d7ba-4bd9-ae3d-34164ea54950', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', 'f8f03ff9-8986-4b9a-8d87-dbfc7ce2a9cc', 'Buckwheat Groats', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 2.000, 2.000, NULL, NULL, NULL, 0, '2026-11-22 23:55:23.787626+00', '2026-11-22 23:55:23.787627+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('f3cffa75-1d35-4c79-bda8-1573a9b1c36c', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', 'dbd995f2-669e-4db7-b8bf-f9193b1686a1', 'Canned Chickpeas', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 5.000, 6.000, NULL, NULL, NULL, 1, '2026-11-22 23:55:23.787627+00', '2026-11-22 23:55:23.787628+00', 'WRONG_LOCATION', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('a56f02d6-0814-4dad-b858-e8ff3b3d9877', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', '38eb4f22-5460-41b7-be14-d84c7d7f337a', 'Tomato Paste', 'Harvest Row', 'b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, NULL, 4.000, 4.000, NULL, NULL, NULL, 0, '2026-11-22 23:55:23.787629+00', '2026-11-22 23:55:23.787629+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('38835c86-d5ad-4319-829a-6e6f3bf06637', 'c86eacc5-6b1c-4364-b0b0-af8c44899d39', '15a2c318-6a95-48b0-8d69-6073ac5b5576', 'Instant Tomato Soup', 'Harvest Row', 'd9af3f8e-36d0-4be8-a4ba-d3182c069615', NULL, NULL, 3.000, 3.000, NULL, NULL, NULL, 0, '2026-11-22 23:55:23.78763+00', '2026-11-22 23:55:23.78763+00', NULL, false, NULL, NULL);


--
-- Data for Name: stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_takes (id, user_id, organization_id, storage_location_id, name, description, status, started_at, completed_at, notes, blind_mode, require_full_count, tolerance_percent, deleted_at, created_at, updated_at, schedule_id, adjustment_document_id) VALUES ('c86eacc5-6b1c-4364-b0b0-af8c44899d39', '88e78ef1-115e-465e-a474-c66b601da4b0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', 'Dry Goods count', 'Quarterly count of the dry goods shelves.', 'completed', '2026-11-19 21:55:23.7834+00', '2026-11-19 23:55:23.783437+00', NULL, false, true, 2.00, NULL, '2026-11-22 23:55:23.784428+00', '2026-11-22 23:55:23.965814+00', NULL, NULL);


--
-- Data for Name: stock_valuation_layers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a577d089-50af-4740-83b8-5371e0aa55f6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2023-10-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.410039+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c6fea0a7-a5f2-42dc-a43c-73b60f691f27', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, 1.000, 1.000, 400.0000, 400.00, '2023-10-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.423324+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('46914f65-2880-4e37-800a-d6bb9f911cdc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2023-11-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.430151+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('708e0a2f-ecc5-47a4-9b5e-765467888781', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2023-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.438475+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f5546710-706e-4024-a758-a293f7e0a655', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2023-11-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.44604+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('5fa3034d-979d-4a51-9af2-e47649baa492', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2023-12-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.454611+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('00e21c9c-cf9f-4c42-ace1-f6562d0b1d59', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2023-12-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.461647+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('eb38dc72-b63d-4120-9810-3a79a9e28dbc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2024-01-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.468166+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('2431f4ac-0d32-476f-a80f-06411f84c469', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-01-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.47463+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0bcc3e6a-17d1-4183-a64f-f42d8b2e296f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-02-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.4804+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('90fbe25b-46f8-4fd7-89ee-e491bf70d65b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-02-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.48609+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('43ce3886-aaed-4ddb-ae9e-0f12646b63b7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-02-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.491731+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bf395f13-6f81-4ce7-b993-c0e33cad09a9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-03-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.497209+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('eee9983f-7810-4e75-b913-c4c6a607e559', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-03-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.502736+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e6166243-2859-43b3-ad9c-86b17b4fa7ab', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2024-04-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.508777+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c210e0a7-d9d2-40eb-bd52-d226217a8a1d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-04-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.514805+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bb947280-4bd6-4a61-ba44-0ebfd8084540', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2024-05-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.520998+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f80a10da-9cca-4678-bea3-c530e1107171', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2024-05-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.52673+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b0a678f7-f91d-4ec1-98fa-29ddddb1051b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '65ad9f0b-3a48-48ea-9840-ac19cecb55b3', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-05-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.532441+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('88792055-4467-4978-bded-69508a7fe123', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-06-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.538681+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1b3923c8-84e4-4e8f-aa4c-4c0f598b67f3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, 1.000, 1.000, 950.0000, 950.00, '2024-06-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.545457+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('715b2719-20d5-4545-859f-94aa5265c850', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2024-07-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.552419+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f02c67f9-ccc4-472b-9d40-e04274e43e7f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-07-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.559066+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('db4a2653-3110-4e3e-b65a-4a9fe82723b7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2024-08-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.565419+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7b0c6f70-bdc5-4692-8b12-061c09f9570c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8b051841-964b-49ea-be34-235b9fe7344e', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2024-08-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.571645+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('57bf3de8-bcd8-4508-b9a0-50301736e509', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1a2901a8-a6dc-4fed-98b3-ba109ce2c2d4', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2024-08-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.577841+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1e282903-5974-4a5e-9648-45df2eb55fed', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d134e16-fb90-40c5-9d82-6fcde5310d40', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-09-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.582874+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('37d8e4c4-3e8e-4d1c-a131-04eea9c51799', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, 1.000, 1.000, 950.0000, 950.00, '2024-09-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.589313+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f3d52507-49f7-459a-9052-4ab3ff7c5058', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-09-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.595797+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('22e88267-dc64-4a05-abe7-3a9e581680af', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2024-10-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.60083+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ca593eb0-35f7-42dc-92cf-5831a1d32fec', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd74363d9-3e93-47e0-beda-2766cc739703', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-10-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.606898+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('14fddac4-15c3-4fdc-b689-540f0842e825', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '72c6e5bb-58b3-4f9f-99e4-e5134d12b8a8', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2024-11-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.612812+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('db19d787-9089-4092-ada5-958e010b59d2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26e19db4-a097-438b-8061-4514b12b7a20', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2024-11-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.61913+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d10fd0a4-e032-4bfa-bb59-5128f9db7687', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', NULL, 1.000, 1.000, 650.0000, 650.00, '2024-12-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.625469+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9956a768-d6c3-41a7-a5d4-3c197b3ca965', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2024-12-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.631766+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('116791b9-3e17-4988-96c9-8becda8be86f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, 1.000, 1.000, 950.0000, 950.00, '2025-01-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.638148+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e726ee6f-f451-4809-ae27-c093e4becf8d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'cea951fa-5471-49de-ae33-003d5fc04dc5', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-01-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.645174+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fca0b7c9-ebe1-4033-951f-80c66d68d03e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f5a92539-d900-4300-a545-c226bf03942f', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2025-02-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.651768+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('30bd10c6-e5a5-4309-af6c-6da9b2b80794', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-02-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.658559+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7502058b-1d63-4341-b504-bb9388b7b930', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-03-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.665179+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('90c72df4-6f77-4bbb-991b-0c6fa02b67e8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2025-03-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.671534+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('47a1eca1-0bcd-406f-93ba-e2fc8aa760f8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', NULL, 1.000, 1.000, 650.0000, 650.00, '2025-03-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.677957+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6004cef0-eeb4-4358-a29b-6dede56cc912', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-04-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.684441+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9cf44527-9631-4737-bb98-10b5433f0a3c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '53275f12-8e84-4169-88a2-d3c82e75559d', NULL, 1.000, 1.000, 950.0000, 950.00, '2025-04-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.694648+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8a2d877c-1dc4-473a-b477-554afa8bffac', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2025-04-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.702532+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('240f11b1-7cab-4545-90be-43e854af245c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2025-05-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.709574+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bbce8779-8309-44e7-aaaa-de055dda9c03', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-05-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.71602+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1ff78316-05a7-491c-b597-7dbf3a19bbcc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-06-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.72242+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a019c994-096c-485d-8439-bbd567e6188d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2025-06-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.72893+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('37a8e94c-20a8-47cc-959b-bd122dc06b0c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7df8a934-580b-42fe-9f18-bdaa89b6c55e', NULL, 1.000, 1.000, 650.0000, 650.00, '2025-06-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.736394+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('142e8ac1-c58a-43b4-8a9a-f10ce46eef3a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-07-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.743472+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7e1e2b68-ca06-478c-a4e6-6029ad0a40f4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-07-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.750057+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f94d06c0-5d99-4cd5-b2b0-45e3a946bd40', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2025-07-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.75545+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('66505926-7717-4f9e-b0f6-8fd2a37e7492', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2025-08-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.762045+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('49fed57d-02a0-4375-94ad-3801ad9de6a3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-08-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.768696+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('046b897d-4ecf-44ce-81b4-4a17a9febc65', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-09-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.77504+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('2506e279-f5cb-48d4-a6c9-e67683ecb490', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2025-09-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.781399+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1cc192b4-a78f-4f69-a2cd-718c37295c0e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, 1.000, 1.000, 350.0000, 350.00, '2025-09-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.788094+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ea8fe97f-bc43-443c-9992-1833d5453728', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-10-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.794492+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('df3809c0-2030-4305-beb8-d359540eeb16', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3c2c7245-6264-4871-b2e3-3d7950b14a50', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-10-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.805368+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('eabd9eb1-1462-48e6-8c6a-30b1d2879354', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2025-10-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.811347+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d2236f90-1bf5-4c7a-b4b5-f8ddb4e696c9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'de374e76-b529-47e6-99d2-eb12e9edea81', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2025-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.81765+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('17cd0d11-1f07-4d64-9d0c-2bb69d9e13ad', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd203d50-c0a9-4a16-96ac-e2f47246aca8', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-11-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.82443+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('45047314-0c8b-4ad0-9ea6-a1b0bb51f294', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2025-12-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.830416+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('508cb6f5-e4d8-4abe-90b0-f58ccd6c681a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4ade99c5-2d1b-467c-8c09-ca23702f3596', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2025-12-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.8367+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ab62da06-b9fc-4a4e-b67f-d0950ab4464f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, 1.000, 1.000, 350.0000, 350.00, '2025-12-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.842811+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d623a8a5-d173-485c-9198-4c02af0ef4b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '980f8931-99fb-4b5c-bf5d-c2b9226a27a1', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-01-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.847377+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6e25eb1d-95e4-4440-9e7f-619f37cec297', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2026-01-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.853581+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('5ade6fca-c954-46ab-9793-ec490ca31dd7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-01-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.859926+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('61d5dd7b-4d58-454a-bbc8-0de40c7dfc66', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2026-02-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.867544+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e48970ac-c045-4c67-ba20-b92b6c4d25fd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-02-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.87385+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('5ba8648b-ded3-4cd2-82ba-7c300891c6ba', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-03-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.880252+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('011a70ad-5d31-4eeb-9452-b401d3cb5e7c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2026-03-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.886631+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0f210284-c5d0-4806-9118-0fec7a7e6910', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, 1.000, 1.000, 350.0000, 350.00, '2026-04-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.891928+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('09317f9e-bb88-4bf9-8627-67d3f1feea6c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2026-04-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.898715+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0f19b718-e52e-465e-8755-a9b2d690beb8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2026-05-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.905867+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a8d7fa40-abec-4894-9a2a-0d849081b2e7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '4b222d05-5c00-439a-bd4d-7c886003b303', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-05-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.914338+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3c750ef0-8cbf-4015-b3ce-a95b51a5c0fd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2026-06-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.921675+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bd93e945-46ec-4895-8496-0e827669a35e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-06-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.936359+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c389ee1d-930f-488b-91f0-01cf6dd65095', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-07-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.944497+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ccc960ca-ff61-4eb3-bbfe-a978916e7a0b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7d9039c2-0886-4803-882e-08d9150b2ffa', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2026-07-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.950468+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f6bb8d32-e6f3-4371-8491-2cd91f803446', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '0914a0b4-7f84-4e5f-8739-5e4a6bdf691e', NULL, 1.000, 1.000, 350.0000, 350.00, '2026-07-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.956954+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f6e59a93-7c08-4b6b-bcd1-e6a55b6fb2ff', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '393624e7-5c8a-4381-b6b2-48854ca15fc6', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2026-08-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.963009+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0deabae1-2721-448f-b311-6b33004e0fc3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77b59a7a-b8d4-40a9-8615-116be7a0169c', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2026-08-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.968765+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9f331c8d-b1f4-46f4-acf9-f0a9a41e088d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e1a2786b-5308-4a11-9da4-23f1a60f88a3', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2026-08-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.975658+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('21a70ce3-e6c6-4702-8fda-989584d6c4dc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2d084bd0-d5f8-49e1-963e-16626d5a55b3', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2026-09-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.981397+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8cffea56-e585-40ef-9865-d6fa8ba71289', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8f8295c2-51b8-4c32-a88d-27f91ed0093d', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-09-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.988218+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dc804798-8101-47c2-a151-7400b5e18e76', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-10-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:19.993283+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('26b9dad7-c744-468c-bfc4-905b6c6932c8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', NULL, 5.000, 5.000, 5.0000, 25.00, '2026-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.00204+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b6504539-6afc-4b8c-b5f6-352cd704c391', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2f65f021-681a-4ecb-af6f-4a5d9b667e72', NULL, 10.000, 10.000, 5.3000, 53.00, '2026-11-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.009948+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6f45a20c-be34-4f19-8c70-29a207be2f81', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', NULL, 5.000, 5.000, 4.8700, 24.35, '2026-10-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.017129+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('469e9e75-0a10-4f67-9c11-2fb2d3e873b0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', NULL, 1.000, 1.000, 5.0400, 5.04, '2026-11-16', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.024362+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('10499470-b0ed-4a83-9261-99b30189232d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '79c6276d-bdee-4313-bfe6-617ce82fff58', NULL, 2.900, 2.900, 5.5600, 16.12, '2026-11-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.031752+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b31ed9b7-f144-4045-b470-0b32107a0bb2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '54a70fb6-27f4-4f28-b22f-1b4929f83ae5', NULL, 3.000, 3.000, 5.2900, 15.87, '2026-09-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.039329+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b64aba29-7bf1-4827-817e-2b7cf63edf13', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6b4ab39c-bb30-4758-aa0d-15032b0f20ee', NULL, 5.500, 5.500, 5.0900, 28.00, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.047959+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('103ea5dc-635c-4768-8554-f8945b96be76', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c15de66e-9440-4a41-bad5-855060db64bd', NULL, 4.000, 4.000, 4.8000, 19.20, '2026-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.056737+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e991c8a1-004c-4c0f-ac6d-573f38a5ed70', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '3d1e4140-1051-4a9a-9ea0-6c944531f395', NULL, 1.000, 1.000, 4.5500, 4.55, '2026-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.06367+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4455d10f-444a-42a5-941d-0bb5c3597b1b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e7b744bc-6ad6-49b8-9e1f-3f5cf83c2928', NULL, 2.000, 2.000, 4.4400, 8.88, '2026-10-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.070467+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('db935f01-61c2-436a-a420-9515fd7dd670', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'd9db61c5-d00b-489f-a1a8-8950a8b4c361', NULL, 5.000, 5.000, 5.4600, 27.30, '2026-09-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.079357+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fa35670a-13ee-49d8-95a8-b723ca03a05a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', NULL, 4.000, 4.000, 4.8100, 19.24, '2026-09-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.087991+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f135639c-2701-4d3d-93ca-43b0462b00d2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', NULL, 3.000, 3.000, 4.7900, 14.37, '2026-11-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.095763+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3346b24e-11ad-4602-94d8-eddf7273adf1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', NULL, 3.000, 3.000, 5.0300, 15.09, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.104007+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d6384e4b-ebc7-4b8f-acf9-3279f5266026', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b3a52fc1-e341-4bc3-9095-7d651bb7d0f4', NULL, 9.000, 9.000, 4.6900, 42.21, '2026-10-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.111465+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ce7d823a-d18b-440a-bea1-11c621224153', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fd3f8548-b4e0-4ae1-9271-a9492edc6996', NULL, 6.000, 6.000, 5.4700, 32.82, '2026-10-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.11983+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f3c7d971-26d0-45b6-81c2-4ebec61a3932', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9942d546-729a-47e0-978a-c21cdca4a522', NULL, 6.800, 6.800, 4.5800, 31.14, '2026-11-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.127669+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f0321532-c46f-4c06-9432-80f609595ccb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fba93956-79a6-4711-ac06-13306f0838de', NULL, 4.000, 4.000, 4.3900, 17.56, '2026-09-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.135689+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7219c5d3-bb4c-496c-b32f-acfa1c622acd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '859d2067-5f56-4be6-bc03-2bdd56619331', NULL, 9.000, 9.000, 4.2700, 38.43, '2026-11-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.143614+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('56212a2a-39eb-4d7d-b44a-13740d96e234', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', NULL, 4.000, 4.000, 4.7000, 18.80, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.15164+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6605fb8d-c30c-4128-9ac6-1b6ee42263cb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7af2a4d4-8aaf-4b4f-af9c-ab6a9c4f04f0', NULL, 1.000, 1.000, 4.2800, 4.28, '2026-10-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.159632+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0e985a16-ed94-4154-a169-2ade0b12631f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '6cbd3ad9-9f78-4bbd-8d0b-47665fbd3f82', NULL, 7.000, 7.000, 5.0800, 35.56, '2026-10-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.16748+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8b5330fd-defd-4c93-af7b-624ae83a103c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e06824d7-d9d2-4ae5-8117-51df6760f021', NULL, 4.000, 4.000, 4.8400, 19.36, '2026-09-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.175782+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('09aafd9e-3985-4662-bdd0-0d05be4da24e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ddcadb51-4a46-4841-8200-9675e2e35903', NULL, 2.000, 2.000, 5.2400, 10.48, '2026-09-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.184282+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('79c83156-b536-4c71-9d0e-f6a38e873a67', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '30cb162e-2e0a-4ea5-9069-4ed172550821', NULL, 7.000, 7.000, 5.3700, 37.59, '2026-11-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.192882+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7038557a-b3ac-4ac0-91fd-34ca548db59b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'e6232713-61fb-4305-b9db-cca330549b49', NULL, 3.000, 3.000, 5.0600, 15.18, '2026-10-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.200763+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dbdd66bb-752e-4f46-b595-1fecba093810', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8ae42709-47ed-4252-823b-e3ed5e15ca4f', NULL, 8.000, 8.000, 4.8500, 38.80, '2026-10-16', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.20848+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('394a6e23-8e5a-48ca-9f9b-2e3ba10eebb4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'fbe3f002-b295-4dd5-b447-33a543fde207', NULL, 8.000, 8.000, 5.7300, 45.84, '2026-10-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.216352+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('5dec0f79-6b56-46c2-bffc-09a626970c3c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7aab2368-ac5e-4b7d-985b-e1da592941bf', NULL, 7.000, 7.000, 4.5400, 31.78, '2026-09-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.224528+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7062a71f-a4dc-4e34-a500-7e5520f01328', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ffe885f7-cb4f-45f6-aeaa-e1878f19917c', NULL, 2.000, 2.000, 5.3000, 10.60, '2026-09-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.232903+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1e5f6887-6223-4a4a-8433-a2d063bc6d94', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '59f96aaa-d5ee-4513-8932-3108a32beeff', NULL, 1.800, 1.800, 4.5900, 8.26, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.240532+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('01cc76ce-699f-448f-91bb-96f3b5e60fe5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'c920ba79-51d4-4691-b3ed-04baa2b19da4', NULL, 6.000, 6.000, 4.6900, 28.14, '2026-10-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.24849+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('289dac89-d638-450a-9f9f-f1581adc3394', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '1d3df1d3-df66-4f30-95bf-9021f2568949', NULL, 8.000, 8.000, 5.1500, 41.20, '2026-10-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.256667+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('040c13e0-8eab-4a81-9169-a21392d76c5d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '29a30a7b-4336-4185-9036-ece90fd01b8c', NULL, 6.000, 6.000, 4.9400, 29.64, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.265017+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('64430283-87be-4501-abe8-e387872f3f18', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '581cf261-3985-40ed-84d0-c2fe77f87c04', NULL, 6.000, 6.000, 5.5700, 33.42, '2026-09-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.273153+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9884a9ef-3bda-471f-ae82-181241480358', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '350b92a4-09a5-4f3e-b6cb-6a302b6b57e4', NULL, 8.000, 8.000, 5.5500, 44.40, '2026-11-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.281093+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('799d8d53-bf05-446a-b1a3-0f7323340258', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7eeb7fbb-59af-4ac2-8f9e-d5d2eb4cf3a2', NULL, 6.000, 6.000, 5.6500, 33.90, '2026-11-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.28908+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e85ebd2d-0044-4755-a834-ae4bd60a9057', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '77cd9fe9-d3c2-4ef5-a867-fbc64022e6ee', NULL, 6.000, 6.000, 5.0700, 30.42, '2026-10-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.297051+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d72e028c-816c-48d4-9bfe-90b9d01a4e8f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '30cb162e-2e0a-4ea5-9069-4ed172550821', NULL, 3.000, 3.000, 4.3400, 13.02, '2026-10-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.303554+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7a9b6cdb-3da5-4125-8d78-fa03bcaae5b2', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '49e687bc-7914-4f53-b2e4-7059b36825c2', NULL, 10.000, 10.000, 4.4600, 44.60, '2026-10-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.311578+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ee9e61bf-4636-48ab-b968-51c8cadf60b3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '38f3a4bc-637c-4187-9ece-bd77b31c2574', '9a579d97-3fc0-4d88-8ce7-087f6afdabca', 5.000, 5.000, 4200.0000, 21000.00, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:21.024816+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9c11ea45-7bd7-493f-8924-94b22a130ea6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '889df13f-fcd5-4268-8293-a9a52822ecfa', 3.000, 3.000, 5800.0000, 17400.00, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:21.024818+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('82ba3ccf-2c6c-4b95-a4a0-8d4201b343f0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88596313-affa-43ae-ba60-be8ddcdea620', 'bb40bac4-83f5-4f64-b280-42ca57f8c8b3', 48.000, 36.000, 4.5000, 216.00, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.908172+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4d2a8a8f-6f61-45f5-90df-a492b38c542a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '88596313-affa-43ae-ba60-be8ddcdea620', 'c19b2d5d-bb15-4fd9-8c4d-295f20578196', 12.000, 0.000, 4.5000, 54.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:55:21.154379+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7d118078-39a0-49e3-ad0e-5dde12935967', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', '2f62a817-8d4e-4a54-b1f8-ca45eca5e156', 8.000, 0.000, 8.9000, 71.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:55:21.154383+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f62a09b4-6a8c-4822-bd22-e48ad90bf58e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', '5ac8dab1-fdaa-4170-a6ce-beace999d4ff', 24.000, 18.000, 5.2000, 124.80, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.908176+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f9d20242-5172-4be1-9c8e-5a218c6614ca', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 'b443948f-1571-4fea-8972-4f853c3c55f2', 36.000, 24.000, 8.9000, 320.40, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.908177+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0b514592-e96f-4a50-a494-d6fffbd0921a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5d5e814a-50d2-4e55-ba46-0d2ffdc7caf5', 'fa026dd6-28bc-4b7f-99d6-e19700779ec5', 6.000, 0.000, 5.2000, 31.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:55:22.573109+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b8967e51-36dc-4b0a-be65-58d2c05c7e37', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '5c7f5c89-263e-4c53-a993-aeb411b6719e', 'c44e5b41-0afb-46e7-a735-0d0d1b85e5b7', 4.000, 0.000, 8.9000, 35.60, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:55:22.573112+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('262c6680-2eb5-45f1-82a7-b7e680d50ad8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 'fc05d041-b5c6-43c2-a2a9-1d9bba1e55ef', 60.000, 50.000, 12.5000, 750.00, '2026-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.978703+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('92aab0c7-450a-4ffd-bee3-94486bd7bbf3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186a8072-74b4-4c27-9623-5dc3fe827303', '344d45dc-b8a7-4762-8cfe-61fa4f2c65f1', 20.000, 15.000, 4.1000, 82.00, '2026-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.978705+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a1be1db7-99a6-49af-9f2e-6049f4102b81', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '8bfaab13-de1b-4c44-a5ee-2234005caa20', 'fc7e010e-0f01-4ee1-8a77-7c6c57123333', 10.000, 0.000, 12.5000, 125.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:55:22.696615+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b9b73ef0-635a-48d7-96db-4a3aa96c0068', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '186a8072-74b4-4c27-9623-5dc3fe827303', 'cac18786-a772-468e-9a41-ceec3add8c6f', 5.000, 0.000, 4.1000, 20.50, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:55:22.696618+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dde08761-f418-4fdd-ad3a-1e7de68f6419', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'dee901bb-0d39-486d-9b0b-a527dd72ccee', '46b59b90-f9da-44c4-afd5-b85d6ffb2dcc', 3.000, 3.000, 5800.0000, 17400.00, '2026-11-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:23.158952+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c35725e5-717c-4c24-8509-15df326032b8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', NULL, 40.000, 13.600, 3.4000, 136.00, '2026-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.320161+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dfef0d3f-f8a3-4177-a1d2-ea55df9f20ba', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '9f643356-0703-44da-bb04-066a379d074a', NULL, 26.400, 0.000, 3.4000, 89.76, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-22 23:55:23.635891+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6b0c545e-83b3-495b-93c4-31cca0aecdd9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', NULL, 25.000, 21.220, 1.1000, 27.50, '2026-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.327916+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dfde6a55-63ad-4c72-aced-24a057980cb6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '456bf028-a84f-48ed-a91d-14650d05dcf7', NULL, 3.780, 0.000, 1.1000, 4.16, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-22 23:55:23.665993+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f6402449-3b0c-4825-aa62-0afcdf4ab7bb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', NULL, 0.500, 0.440, 24.0000, 12.00, '2026-10-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:20.334492+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dabfd690-4b44-4b00-a9e8-b20235d0e5a1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '7c5611bc-acc4-4a97-9f38-62de7bf9faf2', NULL, 0.060, 0.000, 24.0000, 1.44, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-22 23:55:23.691859+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('489c87b6-c11d-4680-aabc-4d3687636387', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '2610b247-12e7-4f9d-adb4-76679eac607b', NULL, 11.400, 11.400, 8.3647, 95.36, NULL, 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:55:23.739718+00', NULL, NULL, NULL, true);


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f93e7793-ba3e-4e98-82e4-cdb3ab9bad7e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, NULL, '[]', 'STOCK', '[]', 'Main Warehouse', 'Receiving and dispatch — shared by every module', NULL, NULL, 1, 'internal', NULL, '{"seed": {"code": "MAIN_WAREHOUSE", "name": "Main Warehouse"}}', NULL, '2026-11-22 23:55:18.193038+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('47e8d740-a6e2-4fac-acdc-58f9a41d7328', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '0395383d-d81d-4b19-94fd-172b0213dd9e', '[]', 'STOCK', '[]', 'Production (Virtual)', NULL, 'System location', NULL, 42, 'production', NULL, '{"seed": {"code": "PRODUCTION_VIRTUAL", "name": "Production (Virtual)"}}', NULL, '2026-11-22 23:55:18.238458+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('88fda6ed-7e44-4423-8ce5-794df01739a3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '0395383d-d81d-4b19-94fd-172b0213dd9e', '[]', 'STOCK', '[]', 'Inventory Loss (Virtual)', NULL, 'System location', NULL, 41, 'inventory', NULL, '{"seed": {"code": "LOSS_VIRTUAL", "name": "Inventory Loss (Virtual)"}}', NULL, '2026-11-22 23:55:18.236313+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('97259409-5042-41d1-815b-8fd2ddf999b4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, NULL, '[]', 'NONE', '[]', 'Server Room', 'Primary server room / data center', NULL, NULL, 44, 'internal', 'equipment', '{"seed": {"code": "SERVER_ROOM", "name": "Server Room"}}', NULL, '2026-11-22 23:55:18.193045+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0030fd00-2868-4ed0-a979-8db88009383a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Shelf B - Middle', NULL, NULL, 'F-05', 19, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.910956+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('b82f3ee3-7470-48a4-875d-acbd402b8c6f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, NULL, '[]', 'NONE', '[]', 'IT Storage', 'IT equipment storage and logistics warehouse', NULL, NULL, 40, 'internal', 'equipment', '{"seed": {"code": "IT_STORAGE", "name": "IT Storage"}}', NULL, '2026-11-22 23:55:18.193048+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('df787654-5616-4ff4-9a5e-4f1328b17ef9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '0395383d-d81d-4b19-94fd-172b0213dd9e', '[]', 'STOCK', '[]', 'Consumed (Virtual)', NULL, 'System location', NULL, 39, 'customer', NULL, '{"seed": {"code": "CONSUMED_VIRTUAL", "name": "Consumed (Virtual)"}}', NULL, '2026-11-22 23:55:18.233528+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f1b9eb42-4d1e-4eba-808a-57c4efa60fcb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '8b2d4e32-6060-4ccb-8197-57ec50cc56b6', '[]', 'STOCK', '[]', 'Quarantine', NULL, NULL, NULL, 43, 'internal', NULL, '{"seed": {"code": "QUARANTINE", "name": "Quarantine"}}', NULL, '2026-11-22 23:55:18.243992+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('00bcb04c-4044-4506-b5ab-52083ccd0076', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f93e7793-ba3e-4e98-82e4-cdb3ab9bad7e', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Cold Storage', NULL, NULL, 'A', 2, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.883586+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0ee87e89-0fce-426f-b380-2a46cdc215eb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '00bcb04c-4044-4506-b5ab-52083ccd0076', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Fridge B', NULL, NULL, 'A-02', 6, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.890761+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('10ff39ef-41e0-48ce-82d6-a57d75088fec', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '85d37c63-14f2-4d00-820d-ab10eb3597a0', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'STOCK', '[]', 'Beverages', NULL, NULL, 'G', 21, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.913667+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('16a2d288-a0c3-4b12-b575-4b6373d8f95f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Shelf A - Top', NULL, NULL, 'F-01', 15, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.905551+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('1bae33a4-33be-44f1-9f97-0839a8caa08b', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '51bf7795-61d1-4fd3-aa94-b6eb92b45d01', '8260bded-7482-4a09-9bf4-6f5acaf55170', '[]', 'STOCK', '[]', 'Server Rack B', NULL, NULL, 'C-02', 27, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.922439+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('1bba8efb-ff55-4ddf-b46c-ecb4ff175be5', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '00bcb04c-4044-4506-b5ab-52083ccd0076', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Walk-in Cooler', NULL, NULL, 'A-04', 8, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.894112+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('204807e1-19ac-4a98-a1f5-c89edca8f69a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Fridge A - Door', NULL, NULL, 'A-01-02', 5, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.889112+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('22896f78-dbe8-43c4-9ba3-413f627abccd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b7d8761c-25b5-4f09-b145-91d9b7365a16', '0bea43f1-8c3c-4357-b037-d34a26f74de9', '[]', 'FREEZING', '[]', 'Freezer 1', NULL, NULL, 'B-01', 10, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.897921+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('26357b3f-8dec-4df9-bc47-cd796c0eff8a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '132432e5-08e2-45b4-a84f-69943997b889', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'IT Workshop', NULL, NULL, 'D', 30, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.926495+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('2963e348-5403-4a11-acf1-8ea9a41f3812', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '76c0bf1e-c329-49d9-a457-1dfbfeb8f12a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Floor 1 - Row B', NULL, NULL, 'E-02', 36, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.934808+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('2f8525b6-79bd-411d-97d5-b50f45190369', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b7d8761c-25b5-4f09-b145-91d9b7365a16', '0bea43f1-8c3c-4357-b037-d34a26f74de9', '[]', 'FREEZING', '[]', 'Chest Freezer', NULL, NULL, 'B-03', 12, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.900861+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('39610437-ebe2-42e4-b6d3-44ade31c344d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'b7d8761c-25b5-4f09-b145-91d9b7365a16', '0bea43f1-8c3c-4357-b037-d34a26f74de9', '[]', 'FREEZING', '[]', 'Freezer 2', NULL, NULL, 'B-02', 11, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.899395+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('42ca38f2-ad9e-451b-9a9f-ad53900d3500', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '51bf7795-61d1-4fd3-aa94-b6eb92b45d01', '8260bded-7482-4a09-9bf4-6f5acaf55170', '[]', 'STOCK', '[]', 'UPS Bay', NULL, NULL, 'C-03', 28, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.923809+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('51bf7795-61d1-4fd3-aa94-b6eb92b45d01', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '132432e5-08e2-45b4-a84f-69943997b889', '8260bded-7482-4a09-9bf4-6f5acaf55170', '[]', 'STOCK', '[]', 'Server Room', NULL, NULL, 'C', 25, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.919671+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('712b1b64-be5a-468e-bb71-1c466b34dca1', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Shelf B - Bottom', NULL, NULL, 'F-06', 20, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.912331+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7502d679-f52e-4208-9a0a-6628c5c836fc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '807c8e83-690e-46ff-9dfa-e2b8021a074c', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Fridge A - Top Shelf', NULL, NULL, 'A-01-01', 4, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.887463+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('76c0bf1e-c329-49d9-a457-1dfbfeb8f12a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '132432e5-08e2-45b4-a84f-69943997b889', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Workstations', NULL, NULL, 'E', 34, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.932043+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7954e058-ee63-4bde-9395-af27e73cebcf', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '10ff39ef-41e0-48ce-82d6-a57d75088fec', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'STOCK', '[]', 'Beverage Rack 2', NULL, NULL, 'G-02', 23, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.916343+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('807c8e83-690e-46ff-9dfa-e2b8021a074c', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '00bcb04c-4044-4506-b5ab-52083ccd0076', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Fridge A', NULL, NULL, 'A-01', 3, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.885792+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('83b8311b-2dba-4f56-b373-dae82336eda7', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '51bf7795-61d1-4fd3-aa94-b6eb92b45d01', '8260bded-7482-4a09-9bf4-6f5acaf55170', '[]', 'STOCK', '[]', 'Server Rack A', NULL, NULL, 'C-01', 26, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.921048+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('8a7b7a5e-bf62-49db-ab8c-84c12ee0851f', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '76c0bf1e-c329-49d9-a457-1dfbfeb8f12a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Floor 1 - Row A', NULL, NULL, 'E-01', 35, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.933395+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('970f90c8-b151-4998-aa91-2c3da24502e3', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26357b3f-8dec-4df9-bc47-cd796c0eff8a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Workshop Shelf 2', NULL, NULL, 'D-02', 32, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.929322+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('9d1de691-d507-46d0-b247-f87b130a9cd9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '76c0bf1e-c329-49d9-a457-1dfbfeb8f12a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Floor 2 - Row B', NULL, NULL, 'E-04', 38, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.93755+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ad2b79f3-8d9b-4c0c-a7b5-29a88f054195', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Shelf A - Bottom', NULL, NULL, 'F-03', 17, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.908275+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('adf21422-eb5a-4ee6-9a1e-c66d99c4a687', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '85d37c63-14f2-4d00-820d-ab10eb3597a0', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Dry Goods', NULL, NULL, 'F', 14, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.90416+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('b1a280e0-0b57-4555-bff2-9b35db52d777', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '00bcb04c-4044-4506-b5ab-52083ccd0076', 'bf54790c-8f16-45a3-bd87-2e97558e219e', '[]', 'EXPIRY', '[]', 'Fridge C', NULL, NULL, 'A-03', 7, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.892402+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('b7d8761c-25b5-4f09-b145-91d9b7365a16', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'f93e7793-ba3e-4e98-82e4-cdb3ab9bad7e', '0bea43f1-8c3c-4357-b037-d34a26f74de9', '[]', 'FREEZING', '[]', 'Freezer Zone', NULL, NULL, 'B', 9, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.896345+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('bb860c6b-4b1d-405b-bad2-f62439ad9655', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Shelf B - Top', NULL, NULL, 'F-04', 18, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.909629+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c29e334b-7662-4015-9afe-8b3526e33065', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26357b3f-8dec-4df9-bc47-cd796c0eff8a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Spare Parts Bin', NULL, NULL, 'D-03', 33, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.930698+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('e4293c9f-f235-4c74-90cf-43104beff987', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'adf21422-eb5a-4ee6-9a1e-c66d99c4a687', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'EXPIRY', '[]', 'Shelf A - Middle', NULL, NULL, 'F-02', 16, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.906919+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('e52af118-7ac7-46ac-900c-29a956ca4e4a', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '10ff39ef-41e0-48ce-82d6-a57d75088fec', '49b8aae4-b624-4883-b637-75b8e8437cdd', '[]', 'STOCK', '[]', 'Beverage Rack 1', NULL, NULL, 'G-01', 22, 'internal', 'food', NULL, NULL, '2026-11-22 23:55:18.914986+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('edb27e2e-8de8-418f-98a4-09f9f1a868cc', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '26357b3f-8dec-4df9-bc47-cd796c0eff8a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Workshop Shelf 1', NULL, NULL, 'D-01', 31, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.927931+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('fb8cf452-07fc-4584-92fc-6b3791bfa5cb', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '51bf7795-61d1-4fd3-aa94-b6eb92b45d01', '8260bded-7482-4a09-9bf4-6f5acaf55170', '[]', 'STOCK', '[]', 'Patch Panel', NULL, NULL, 'C-04', 29, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.925131+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ffc7cde1-14ac-4cea-b1c7-7cb90af1a6f6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', '76c0bf1e-c329-49d9-a457-1dfbfeb8f12a', 'c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', '[]', 'STOCK', '[]', 'Floor 2 - Row A', NULL, NULL, 'E-03', 37, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.936218+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('132432e5-08e2-45b4-a84f-69943997b889', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '8b2d4e32-6060-4ccb-8197-57ec50cc56b6', '[]', 'STOCK', '[]', 'Office Building', NULL, NULL, 'LOC-F0PH', 24, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:55:18.918222+00', '88e78ef1-115e-465e-a474-c66b601da4b0');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('85d37c63-14f2-4d00-820d-ab10eb3597a0', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', NULL, '8b2d4e32-6060-4ccb-8197-57ec50cc56b6', '[]', 'STOCK', '[]', 'Pantry Building', NULL, NULL, 'LOC-R78D', 13, 'internal', NULL, NULL, NULL, '2026-11-22 23:55:18.902716+00', '88e78ef1-115e-465e-a474-c66b601da4b0');


--
-- Data for Name: storage_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('7aa93f39-9fbf-47a2-81b9-283177e6acea', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Shelf / Cabinet', 'SHELF', 'STOCK', '["quantity", "unit"]', '[]', 'BookOpen', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('8b2d4e32-6060-4ccb-8197-57ec50cc56b6', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Storage Room', 'STORAGE_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Warehouse', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('0395383d-d81d-4b19-94fd-172b0213dd9e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'System', 'SYSTEM', 'NONE', '[]', '[]', 'Settings', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('3a27bedb-060d-40d2-bc96-791f5b7df5d4', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Tool Room', 'TOOL_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Wrench', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('e92520e5-bd3e-4c88-af4c-2af42c4f3a42', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Maintenance Bay', 'MAINTENANCE_BAY', 'NONE', '["quantity", "unit"]', '[]', 'Hammer', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('8260bded-7482-4a09-9bf4-6f5acaf55170', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Server Room', 'SERVER_ROOM', 'NONE', '["serial_number", "manufacturer", "model", "ip_address", "equipment_status"]', '[]', 'server', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('c3ca3c0d-87a0-4197-b396-1e55f5aecaf8', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'IT Storage / Warehouse', 'IT_STORAGE', 'NONE', '["serial_number", "manufacturer", "model", "equipment_status"]', '[]', 'warehouse', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('0bea43f1-8c3c-4357-b037-d34a26f74de9', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Freezer', 'FREEZER', 'FREEZING', '[]', '[]', 'Snowflake', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('bf54790c-8f16-45a3-bd87-2e97558e219e', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Fridge', 'FRIDGE', 'EXPIRY', '[]', '[]', 'Refrigerator', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('49b8aae4-b624-4883-b637-75b8e8437cdd', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Pantry', 'PANTRY', 'EXPIRY', '[]', '[]', 'ShoppingBasket', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('f6520017-72af-4b8f-8b31-859dfc7b3929', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'Medicine Cabinet', 'MEDICINE_CABINET', 'EXPIRY', '[]', '[]', 'Cross', true, NULL, '{"check_expiry": true}');


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_settings (key, value, updated_at, updated_by) VALUES ('default_org_limits', '{"max_members": null, "max_products": null, "ai_scans_monthly": null, "ai_requests_monthly": 20}', '2026-11-22 23:55:24.769682+00', NULL);


--
-- Data for Name: tax_rate_assignments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unit_conversions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: uom_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('7a30ba23-f185-4019-83f8-db8cd7eb263e', NULL, 'Weight');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('fcd504f5-d85b-4170-a50d-c52a8107aae0', NULL, 'Volume');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('f9de78f0-5ddc-4bd1-84ef-c3c3f980fe6f', NULL, 'Unit');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('b2daef63-b847-4c5b-b285-d8d8873a7ffb', NULL, 'Length');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('66b18166-263a-409d-95fe-af4d4755997b', NULL, 'Pack');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('cd80187a-2019-4ff1-845e-6f0030116889', NULL, 'Can');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('9f88ee80-8270-4646-8b36-e387ba515845', NULL, 'Bottle');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('04122e28-1f84-4b48-85f5-cf6415e8a4aa', NULL, 'Box');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('60ae2c97-6b07-4682-8d72-4c1b23099b56', NULL, 'Bag');


--
-- Data for Name: uoms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('517fd19d-1acf-40ce-932e-62b5845b76b7', NULL, '7a30ba23-f185-4019-83f8-db8cd7eb263e', 'Gram', 'g', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('b2625fa3-6f97-4778-9084-c3f6ae2518a9', NULL, '7a30ba23-f185-4019-83f8-db8cd7eb263e', 'Kilogram', 'kg', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f956480a-52c2-463e-8103-7af519bc250b', NULL, '7a30ba23-f185-4019-83f8-db8cd7eb263e', 'Milligram', 'mg', 0.001000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('2645f7c7-cb63-43c9-8a41-31116c309c7a', NULL, '7a30ba23-f185-4019-83f8-db8cd7eb263e', 'Ounce', 'oz', 28.349500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('9cdfafdd-6a17-4bff-beec-01b40826c02e', NULL, '7a30ba23-f185-4019-83f8-db8cd7eb263e', 'Pound', 'lb', 453.592000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('316076fd-0ba0-4d03-b49a-c6651154898a', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Milliliter', 'ml', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('38eb047a-cc96-484f-a1c0-a59145e4e401', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Liter', 'l', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('b549fb66-cccc-47ea-91f6-a70b2bf9d481', NULL, 'f9de78f0-5ddc-4bd1-84ef-c3c3f980fe6f', 'Piece', 'pcs', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('d9af3f8e-36d0-4be8-a4ba-d3182c069615', NULL, '66b18166-263a-409d-95fe-af4d4755997b', 'Pack', 'pack', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('84333996-3328-4583-a543-9355446b9534', NULL, 'cd80187a-2019-4ff1-845e-6f0030116889', 'Can', 'can', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('7790689f-4727-4f2a-8353-46be75291404', NULL, '9f88ee80-8270-4646-8b36-e387ba515845', 'Bottle', 'bottle', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f983add1-3eb8-4f0e-b91a-de14ce3a2b4e', NULL, '04122e28-1f84-4b48-85f5-cf6415e8a4aa', 'Box', 'box', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('9c964d95-32f4-4959-bdeb-667ba85ffa58', NULL, '60ae2c97-6b07-4682-8d72-4c1b23099b56', 'Bag', 'bag', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('d291207a-aa29-4d84-93bb-d4dfb35fcae5', NULL, 'b2daef63-b847-4c5b-b285-d8d8873a7ffb', 'Centimeter', 'cm', 1.000000000, true, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('e848ac71-8290-4dd1-8ec0-ab4331cda348', NULL, 'b2daef63-b847-4c5b-b285-d8d8873a7ffb', 'Meter', 'm', 100.000000000, false, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('67acd375-5ac4-4960-9885-b99ea1dc63d1', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Fluid Ounce', 'fl oz', 29.573500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('5c9fb3f3-5310-4283-b87e-7d95d212b75f', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Cup (US)', 'cup', 236.588000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('b9b85442-aa7c-40c5-baf4-ec73190b1cc5', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Tablespoon', 'tbsp', 14.786800000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('d9da4f50-194b-4619-b1e0-efbf61581421', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Teaspoon', 'tsp', 4.928920000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8d858318-2eaf-419f-979d-00bdd85ed5e8', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Pint (US)', 'pt', 473.176000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('37a49cdc-0178-4bde-9ac9-f1183ecc261f', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Quart (US)', 'qt', 946.353000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('ba5e29d7-4493-4f6f-84fa-7c340bf25b27', NULL, 'fcd504f5-d85b-4170-a50d-c52a8107aae0', 'Gallon (US)', 'gal', 3785.410000000, false, true, 0.001000);


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('88e78ef1-115e-465e-a474-c66b601da4b0', 'admin@example.com', '$2b$12$wmnw40jeQyNEM.o6JNXeVeBRrKcANSOOzV4vW4u5zq1ip874IfhS6', 'Demo Administrator', '2026-11-22 23:55:17.9822+00', '2026-11-22 23:55:17.994496+00', 'en', 'admin', true, false, false, NULL, NULL, 0, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('72354123-6bc0-4834-8870-3e0faad5b922', 'ava.brennan@example.com', '$2b$12$WyQSwUSkofzmqPusXWklYejT1g51YFhZZM/cFas4SIMB5lLhhCdga', 'Ava Brennan', '2026-11-22 23:55:24.327767+00', '2026-11-22 23:55:24.327772+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('3138d71e-a910-424a-81fe-5d36ad73454b', 'marcus.webb@example.com', '$2b$12$e7KLpaFO/Y5QLrmExoS5I.09JCqWlCXA2Hckc/6eEgV8/zf1OViR2', 'Marcus Webb', '2026-11-22 23:55:24.327775+00', '2026-11-22 23:55:24.327775+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9');


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_line_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('2f688046-3838-4d1c-8cfc-bc20b5e5da91', 'f05133de-797e-4093-922e-0b1fb14df75d', 'cac18786-a772-468e-9a41-ceec3add8c6f', 3, 'picked', 5.000, 'A-01-02 · Fridge A - Door', 'Sour Cream 18%', NULL, 5.000, 'pcs', 'db936426-2a5d-4ff7-a454-9e9ab786bc9b', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('7bd9a137-816f-4428-b135-be099c2f90e3', 'f05133de-797e-4093-922e-0b1fb14df75d', 'fc7e010e-0f01-4ee1-8a77-7c6c57123333', 2, 'picked', 10.000, 'A-01-02 · Fridge A - Door', 'Gouda Cheese', NULL, 10.000, 'pcs', 'a1f0d76f-21e1-4a08-afdc-f3c166c05e53', NULL, '204807e1-19ac-4a98-a1f5-c89edca8f69a', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('837c9c9e-b48e-473d-a52f-f4edb2caa741', 'f05133de-797e-4093-922e-0b1fb14df75d', 'c44e5b41-0afb-46e7-a735-0d0d1b85e5b7', 1, 'picked', 4.000, 'A-01-01 · Fridge A - Top Shelf', 'Butter Extra 82%', NULL, 4.000, 'pcs', '6f7ed610-af94-4137-b559-70ce2c066c4e', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('99c9f9ae-259a-4ec2-828b-47c77a459b61', 'f05133de-797e-4093-922e-0b1fb14df75d', 'fa026dd6-28bc-4b7f-99d6-e19700779ec5', 0, 'picked', 6.000, 'A-01-01 · Fridge A - Top Shelf', 'Natural Yoghurt 400g', NULL, 6.000, 'pcs', '0c217898-c9d4-4678-a812-2f8f7b18369c', NULL, '7502d679-f52e-4208-9a0a-6628c5c836fc', NULL);


--
-- Data for Name: wms_pick_session_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('f05133de-797e-4093-922e-0b1fb14df75d', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', 0);
INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('f05133de-797e-4093-922e-0b1fb14df75d', 'e16e2475-b69e-4715-883b-f18f7de2a781', 1);


--
-- Data for Name: wms_pick_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_sessions (id, organization_id, document_id, assigned_to, status, started_at, completed_at, meta_data, last_activity_at) VALUES ('f05133de-797e-4093-922e-0b1fb14df75d', 'b54032f3-d8a3-47a1-bf3f-d3ceaf4d16e9', 'ae284308-57ae-455c-9c4c-5e8b5d0a9b3a', '88e78ef1-115e-465e-a474-c66b601da4b0', 'completed', '2026-11-22 23:55:21.499443+00', '2026-11-22 23:55:21.871419+00', 'null', '2026-11-22 23:55:21.830815+00');


--
-- Name: ai_connections ai_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version_api_keys alembic_version_api_keys_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_api_keys
    ADD CONSTRAINT alembic_version_api_keys_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_approvals alembic_version_approvals_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_approvals
    ADD CONSTRAINT alembic_version_approvals_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_equipment alembic_version_equipment_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_equipment
    ADD CONSTRAINT alembic_version_equipment_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_example_widgets alembic_version_example_widgets_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_example_widgets
    ADD CONSTRAINT alembic_version_example_widgets_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_maker alembic_version_maker_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_maker
    ADD CONSTRAINT alembic_version_maker_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_printing alembic_version_printing_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_printing
    ADD CONSTRAINT alembic_version_printing_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_purchase_orders alembic_version_purchase_orders_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_purchase_orders
    ADD CONSTRAINT alembic_version_purchase_orders_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_recipes alembic_version_recipes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_recipes
    ADD CONSTRAINT alembic_version_recipes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_shopping_lists alembic_version_shopping_lists_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_shopping_lists
    ADD CONSTRAINT alembic_version_shopping_lists_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_stock_takes alembic_version_stock_takes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_stock_takes
    ADD CONSTRAINT alembic_version_stock_takes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_warehouse alembic_version_warehouse_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_warehouse
    ADD CONSTRAINT alembic_version_warehouse_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_webhooks alembic_version_webhooks_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_webhooks
    ADD CONSTRAINT alembic_version_webhooks_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approval_decisions approval_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: approval_workflows approval_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);


--
-- Name: audit_campaigns audit_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_response_items audit_response_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_pkey PRIMARY KEY (id);


--
-- Name: audit_responses audit_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cycle_count_schedules cycle_count_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_pkey PRIMARY KEY (id);


--
-- Name: document_cost_variances document_cost_variances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_pkey PRIMARY KEY (id);


--
-- Name: document_extra_costs document_extra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_pkey PRIMARY KEY (id);


--
-- Name: document_lines document_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_pkey PRIMARY KEY (id);


--
-- Name: document_number_sequences document_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_pkey PRIMARY KEY (organization_id, prefix);


--
-- Name: document_package_lines document_package_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_pkey PRIMARY KEY (id);


--
-- Name: document_packages document_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_pkey PRIMARY KEY (id);


--
-- Name: document_profiles document_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_pkey PRIMARY KEY (id);


--
-- Name: document_relations document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_pkey PRIMARY KEY (id);


--
-- Name: document_shipments document_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: document_type_configs document_type_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_pkey PRIMARY KEY (id);


--
-- Name: document_warehouse_receiving document_warehouse_receiving_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_pkey PRIMARY KEY (id);


--
-- Name: document_work_item_overlays document_work_item_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_jobs email_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_jobs
    ADD CONSTRAINT email_jobs_pkey PRIMARY KEY (id);


--
-- Name: equipment_assignments equipment_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_pkey PRIMARY KEY (id);


--
-- Name: equipment_attachments equipment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_pkey PRIMARY KEY (id);


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: event_deliveries event_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT event_deliveries_pkey PRIMARY KEY (id);


--
-- Name: event_outbox event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox
    ADD CONSTRAINT event_outbox_pkey PRIMARY KEY (id);


--
-- Name: example_widgets example_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_pkey PRIMARY KEY (id);


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_pkey PRIMARY KEY (id);


--
-- Name: inventory_periods inventory_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_pkey PRIMARY KEY (id);


--
-- Name: item_attachments item_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_pkey PRIMARY KEY (id);


--
-- Name: item_history item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_pkey PRIMARY KEY (id);


--
-- Name: item_import_jobs item_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: label_pool label_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_pkey PRIMARY KEY (id);


--
-- Name: location_relocations location_relocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_pkey PRIMARY KEY (id);


--
-- Name: maker_bom_lines maker_bom_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_ingredient_prices maker_ingredient_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT maker_ingredient_prices_pkey PRIMARY KEY (id);


--
-- Name: maker_label_facts maker_label_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT maker_label_facts_pkey PRIMARY KEY (id);


--
-- Name: maker_module_settings maker_module_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: maker_production_attachments maker_production_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_pkey PRIMARY KEY (id);


--
-- Name: maker_production_order_lines maker_production_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_production_orders maker_production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_pkey PRIMARY KEY (id);


--
-- Name: maker_production_portions maker_production_portions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_pkey PRIMARY KEY (id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_recipes maker_recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_pkey PRIMARY KEY (id);


--
-- Name: maker_shelf_lives maker_shelf_lives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT maker_shelf_lives_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_entries meal_plan_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_pkey PRIMARY KEY (id);


--
-- Name: meal_plans meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_pkey PRIMARY KEY (id);


--
-- Name: module_installations module_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_installations
    ADD CONSTRAINT module_installations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: picking_session_items picking_session_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_pkey PRIMARY KEY (id);


--
-- Name: picking_sessions picking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_pkey PRIMARY KEY (id);


--
-- Name: po_partner_pricelist po_partner_pricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_pkey PRIMARY KEY (id);


--
-- Name: po_reorder_rules po_reorder_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_pkey PRIMARY KEY (id);


--
-- Name: po_settings po_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_pkey PRIMARY KEY (id);


--
-- Name: print_agents print_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_pkey PRIMARY KEY (id);


--
-- Name: print_jobs print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_pkey PRIMARY KEY (id);


--
-- Name: product_templates product_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: putaway_capacity putaway_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_pkey PRIMARY KEY (id);


--
-- Name: putaway_home_silenced putaway_home_silenced_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_pkey PRIMARY KEY (id);


--
-- Name: putaway_location_settings putaway_location_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_pkey PRIMARY KEY (id);


--
-- Name: putaway_rule_locations putaway_rule_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_pkey PRIMARY KEY (id);


--
-- Name: putaway_rules putaway_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_pkey PRIMARY KEY (id);


--
-- Name: recipe_collection_members recipe_collection_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_pkey PRIMARY KEY (id);


--
-- Name: recipe_collections recipe_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipe_tag_configs recipe_tag_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shopping_exclusions shopping_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_history shopping_list_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_items shopping_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_pkey PRIMARY KEY (id);


--
-- Name: shopping_lists shopping_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_pkey PRIMARY KEY (id);


--
-- Name: stock_anchors stock_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger_totals stock_ledger_totals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_pkey PRIMARY KEY (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_lots stock_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_pkey PRIMARY KEY (id);


--
-- Name: stock_moves stock_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_closed_locations stock_take_closed_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_counts stock_take_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_take_items stock_take_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);


--
-- Name: stock_takes stock_takes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);


--
-- Name: stock_valuation_layers stock_valuation_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: storage_types storage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tax_rate_assignments tax_rate_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_pkey PRIMARY KEY (id);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: unit_conversions unit_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom_categories uom_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_pkey PRIMARY KEY (id);


--
-- Name: uoms uoms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_pkey PRIMARY KEY (id);


--
-- Name: ai_connections uq_ai_connections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT uq_ai_connections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_bom_lines uq_bom_recipe_child; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT uq_bom_recipe_child UNIQUE (recipe_id, child_template_id);


--
-- Name: document_type_configs uq_doctype_config_org_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT uq_doctype_config_org_type UNIQUE (organization_id, document_type);


--
-- Name: documents uq_document_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT uq_document_org_number UNIQUE (organization_id, number);


--
-- Name: document_package_lines uq_document_package_lines_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT uq_document_package_lines_line UNIQUE (document_package_id, document_line_id);


--
-- Name: document_packages uq_document_packages_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT uq_document_packages_number UNIQUE (document_id, number);


--
-- Name: document_profiles uq_document_profile_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT uq_document_profile_org UNIQUE (organization_id);


--
-- Name: document_shipments uq_document_shipments_document; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT uq_document_shipments_document UNIQUE (document_id);


--
-- Name: document_warehouse_receiving uq_document_warehouse_receiving_org_warehouse; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT uq_document_warehouse_receiving_org_warehouse UNIQUE (organization_id, warehouse_id);


--
-- Name: event_deliveries uq_event_deliveries_event_handler; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT uq_event_deliveries_event_handler UNIQUE (event_id, handler);


--
-- Name: ingredient_nutrition_defaults uq_ingredient_defaults_org_lang_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT uq_ingredient_defaults_org_lang_name UNIQUE (organization_id, lang, name_normalized);


--
-- Name: inventory_periods uq_inventory_period_org_year_month; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT uq_inventory_period_org_year_month UNIQUE (organization_id, year, month);


--
-- Name: label_pool uq_label_pool_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT uq_label_pool_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: stock_lots uq_lot_org_product_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT uq_lot_org_product_name UNIQUE (organization_id, product_template_id, name);


--
-- Name: maker_label_facts uq_maker_label_facts_org_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT uq_maker_label_facts_org_template UNIQUE (organization_id, product_template_id);


--
-- Name: maker_ingredient_prices uq_maker_price_org_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT uq_maker_price_org_template UNIQUE (organization_id, product_template_id);


--
-- Name: maker_shelf_lives uq_maker_shelf_life_org_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT uq_maker_shelf_life_org_template UNIQUE (organization_id, product_template_id);


--
-- Name: meal_plan_entries uq_meal_plan_entries_plan_date_slot_order; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT uq_meal_plan_entries_plan_date_slot_order UNIQUE (meal_plan_id, date, slot, "order");


--
-- Name: partners uq_partner_org_name_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT uq_partner_org_name_type UNIQUE (organization_id, name, type);


--
-- Name: po_reorder_rules uq_po_reorder_rules_org_product_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT uq_po_reorder_rules_org_product_loc UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: po_settings uq_po_settings_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT uq_po_settings_org UNIQUE (organization_id);


--
-- Name: print_agents uq_print_agents_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT uq_print_agents_org_name UNIQUE (organization_id, name);


--
-- Name: purchase_orders uq_purchase_orders_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT uq_purchase_orders_org_number UNIQUE (organization_id, number);


--
-- Name: putaway_capacity uq_putaway_capacity_org_loc_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT uq_putaway_capacity_org_loc_product UNIQUE (organization_id, location_id, product_template_id);


--
-- Name: putaway_home_silenced uq_putaway_home_silenced_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT uq_putaway_home_silenced_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: putaway_location_settings uq_putaway_location_settings_org_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT uq_putaway_location_settings_org_loc UNIQUE (organization_id, location_id);


--
-- Name: putaway_rule_locations uq_putaway_rule_locations_rule_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT uq_putaway_rule_locations_rule_loc UNIQUE (rule_id, location_id);


--
-- Name: recipe_collection_members uq_recipe_collection_members; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT uq_recipe_collection_members UNIQUE (collection_id, recipe_id);


--
-- Name: recipe_collections uq_recipe_collections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT uq_recipe_collections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_recipes uq_recipe_org_template_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT uq_recipe_org_template_name UNIQUE (organization_id, output_template_id, name);


--
-- Name: recipe_tag_configs uq_recipe_tag_configs_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT uq_recipe_tag_configs_org_name UNIQUE (organization_id, name);


--
-- Name: shopping_exclusions uq_shopping_exclusions_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT uq_shopping_exclusions_org_name UNIQUE (organization_id, name_normalized);


--
-- Name: stock_anchors uq_stock_anchor_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT uq_stock_anchor_group UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_take_closed_locations uq_stock_take_closed_locations_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT uq_stock_take_closed_locations_location UNIQUE (stock_take_id, storage_location_id);


--
-- Name: storage_locations uq_storage_locations_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT uq_storage_locations_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_category; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_category UNIQUE (organization_id, category_id);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: unit_conversions uq_unit_conv_org_ingredient_unit_lang; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT uq_unit_conv_org_ingredient_unit_lang UNIQUE (organization_id, ingredient_key, source_unit, lang);


--
-- Name: uom_categories uq_uom_category_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uq_uom_category_org_name UNIQUE (organization_id, name);


--
-- Name: uoms uq_uom_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uq_uom_org_name UNIQUE (organization_id, name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pkey PRIMARY KEY (pick_line_id, lot_id);


--
-- Name: wms_pick_lines wms_pick_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_session_documents wms_pick_session_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_pkey PRIMARY KEY (session_id, document_id);


--
-- Name: wms_pick_sessions wms_pick_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_connections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_connections_organization_id ON public.ai_connections USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_created_at ON public.ai_usage_logs USING btree (created_at);


--
-- Name: ix_ai_usage_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_organization_id ON public.ai_usage_logs USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_user_id ON public.ai_usage_logs USING btree (user_id);


--
-- Name: ix_api_keys_hashed_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_api_keys_hashed_key ON public.api_keys USING btree (hashed_key);


--
-- Name: ix_api_keys_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_organization_id ON public.api_keys USING btree (organization_id);


--
-- Name: ix_approval_decisions_approval_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_decisions_approval_request_id ON public.approval_decisions USING btree (approval_request_id);


--
-- Name: ix_approval_requests_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_organization_id ON public.approval_requests USING btree (organization_id);


--
-- Name: ix_approval_requests_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_target ON public.approval_requests USING btree (target_type, target_id, organization_id);


--
-- Name: ix_approval_workflows_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_workflows_organization_id ON public.approval_workflows USING btree (organization_id);


--
-- Name: ix_audit_campaigns_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_org ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_campaigns_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_organization_id ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_log_org_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_created_at_id ON public.audit_log USING btree (organization_id, created_at DESC, id);


--
-- Name: ix_audit_log_org_type_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_type_created_at ON public.audit_log USING btree (organization_id, target_type, created_at DESC, id);


--
-- Name: ix_audit_log_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_target ON public.audit_log USING btree (target_type, target_id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_audit_response_items_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_assignment_id ON public.audit_response_items USING btree (assignment_id);


--
-- Name: ix_audit_response_items_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_item_id ON public.audit_response_items USING btree (item_id);


--
-- Name: ix_audit_response_items_response_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_response_id ON public.audit_response_items USING btree (response_id);


--
-- Name: ix_audit_responses_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_assignment_id ON public.audit_responses USING btree (assignment_id);


--
-- Name: ix_audit_responses_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_id ON public.audit_responses USING btree (campaign_id);


--
-- Name: ix_audit_responses_campaign_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_status ON public.audit_responses USING btree (campaign_id, status);


--
-- Name: ix_audit_responses_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_organization_id ON public.audit_responses USING btree (organization_id);


--
-- Name: ix_audit_responses_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_responses_token ON public.audit_responses USING btree (token);


--
-- Name: ix_bom_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_org ON public.maker_bom_lines USING btree (organization_id);


--
-- Name: ix_bom_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_parent ON public.maker_bom_lines USING btree (parent_template_id);


--
-- Name: ix_bom_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_recipe ON public.maker_bom_lines USING btree (recipe_id);


--
-- Name: ix_categories_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_code ON public.categories USING btree (code);


--
-- Name: ix_categories_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_context_tag ON public.categories USING btree (context_tag);


--
-- Name: ix_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_is_active ON public.categories USING btree (is_active);


--
-- Name: ix_categories_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_module_name ON public.categories USING btree (module_name);


--
-- Name: ix_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_organization_id ON public.categories USING btree (organization_id);


--
-- Name: ix_cycle_count_schedules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cycle_count_schedules_organization_id ON public.cycle_count_schedules USING btree (organization_id);


--
-- Name: ix_doc_relation_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_source ON public.document_relations USING btree (source_document_id);


--
-- Name: ix_doc_relation_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_target ON public.document_relations USING btree (target_document_id);


--
-- Name: ix_doc_templates_org_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_templates_org_module ON public.document_templates USING btree (organization_id, module);


--
-- Name: ix_document_cost_variances_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_cost_variances_document ON public.document_cost_variances USING btree (document_id);


--
-- Name: ix_document_cost_variances_org_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_cost_variances_org_date ON public.document_cost_variances USING btree (organization_id, occurred_on);


--
-- Name: ix_document_extra_costs_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_document ON public.document_extra_costs USING btree (document_id);


--
-- Name: ix_document_extra_costs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_organization_id ON public.document_extra_costs USING btree (organization_id);


--
-- Name: ix_document_lines_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_brand_trgm ON public.document_lines USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_document_lines_corrects_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_corrects_line_id ON public.document_lines USING btree (corrects_line_id);


--
-- Name: ix_document_lines_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_document_id ON public.document_lines USING btree (document_id);


--
-- Name: ix_document_lines_held; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_held ON public.document_lines USING btree (document_id) WHERE (held_quantity > (0)::numeric);


--
-- Name: ix_document_lines_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_name_trgm ON public.document_lines USING gin (name public.gin_trgm_ops);


--
-- Name: ix_document_lines_puts_away_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_puts_away_line_id ON public.document_lines USING btree (puts_away_line_id);


--
-- Name: ix_document_lines_source_po_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_source_po_line_id ON public.document_lines USING btree (source_po_line_id);


--
-- Name: ix_document_org_partner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_partner ON public.documents USING btree (organization_id, partner_id);


--
-- Name: ix_document_org_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_status_created_at ON public.documents USING btree (organization_id, status, created_at);


--
-- Name: ix_document_org_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_type_status ON public.documents USING btree (organization_id, type, status);


--
-- Name: ix_document_package_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_line_id ON public.document_package_lines USING btree (document_line_id);


--
-- Name: ix_document_package_lines_document_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_package_id ON public.document_package_lines USING btree (document_package_id);


--
-- Name: ix_document_packages_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_document_id ON public.document_packages USING btree (document_id);


--
-- Name: ix_document_packages_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_organization_id ON public.document_packages USING btree (organization_id);


--
-- Name: ix_document_profiles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_profiles_organization_id ON public.document_profiles USING btree (organization_id);


--
-- Name: ix_document_shipments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shipments_organization_id ON public.document_shipments USING btree (organization_id);


--
-- Name: ix_document_templates_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_module ON public.document_templates USING btree (module);


--
-- Name: ix_document_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_organization_id ON public.document_templates USING btree (organization_id);


--
-- Name: ix_document_type_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_type_configs_organization_id ON public.document_type_configs USING btree (organization_id);


--
-- Name: ix_document_warehouse_receiving_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_warehouse_receiving_organization_id ON public.document_warehouse_receiving USING btree (organization_id);


--
-- Name: ix_document_work_item_overlays_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_work_item_overlays_organization_id ON public.document_work_item_overlays USING btree (organization_id);


--
-- Name: ix_documents_backorder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_backorder_id ON public.documents USING btree (backorder_id);


--
-- Name: ix_documents_corrects_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_corrects_document_id ON public.documents USING btree (corrects_document_id);


--
-- Name: ix_documents_external_reference_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_external_reference_trgm ON public.documents USING gin (external_reference public.gin_trgm_ops);


--
-- Name: ix_documents_notes_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_notes_trgm ON public.documents USING gin (notes public.gin_trgm_ops);


--
-- Name: ix_documents_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_number_trgm ON public.documents USING gin (number public.gin_trgm_ops);


--
-- Name: ix_documents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_organization_id ON public.documents USING btree (organization_id);


--
-- Name: ix_documents_partner_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_partner_name_trgm ON public.documents USING gin (((partner_snapshot ->> 'name'::text)) public.gin_trgm_ops);


--
-- Name: ix_email_jobs_next_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_next_attempt_at ON public.email_jobs USING btree (next_attempt_at);


--
-- Name: ix_email_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_organization_id ON public.email_jobs USING btree (organization_id);


--
-- Name: ix_email_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_status ON public.email_jobs USING btree (status);


--
-- Name: ix_eq_assignments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_assignments_org_item ON public.equipment_assignments USING btree (organization_id, item_id);


--
-- Name: ix_eq_attachments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_attachments_org_item ON public.equipment_attachments USING btree (organization_id, item_id);


--
-- Name: ix_eq_maintenance_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_maintenance_org_item ON public.equipment_maintenance_logs USING btree (organization_id, item_id);


--
-- Name: ix_equipment_assignments_assignee_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_assignee_partner_id ON public.equipment_assignments USING btree (assignee_partner_id);


--
-- Name: ix_equipment_assignments_checkout_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_checkout_location_id ON public.equipment_assignments USING btree (checkout_location_id);


--
-- Name: ix_equipment_assignments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_item_id ON public.equipment_assignments USING btree (item_id);


--
-- Name: ix_equipment_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_organization_id ON public.equipment_assignments USING btree (organization_id);


--
-- Name: ix_equipment_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_item_id ON public.equipment_attachments USING btree (item_id);


--
-- Name: ix_equipment_attachments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_organization_id ON public.equipment_attachments USING btree (organization_id);


--
-- Name: ix_equipment_maintenance_logs_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_item_id ON public.equipment_maintenance_logs USING btree (item_id);


--
-- Name: ix_equipment_maintenance_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_organization_id ON public.equipment_maintenance_logs USING btree (organization_id);


--
-- Name: ix_event_deliveries_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_organization_id ON public.event_deliveries USING btree (organization_id);


--
-- Name: ix_event_deliveries_status_next_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_status_next_attempt ON public.event_deliveries USING btree (status, next_attempt_at);


--
-- Name: ix_event_outbox_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_organization_id ON public.event_outbox USING btree (organization_id);


--
-- Name: ix_event_outbox_unpublished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_unpublished ON public.event_outbox USING btree (created_at) WHERE (published_at IS NULL);


--
-- Name: ix_example_widgets_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_example_widgets_organization_id ON public.example_widgets USING btree (organization_id);


--
-- Name: ix_ingredient_defaults_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_defaults_lookup ON public.ingredient_nutrition_defaults USING btree (name_normalized, lang, organization_id);


--
-- Name: ix_ingredient_nutrition_defaults_name_normalized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_name_normalized ON public.ingredient_nutrition_defaults USING btree (name_normalized);


--
-- Name: ix_ingredient_nutrition_defaults_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_organization_id ON public.ingredient_nutrition_defaults USING btree (organization_id);


--
-- Name: ix_item_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_attachments_item_id ON public.item_attachments USING btree (item_id);


--
-- Name: ix_item_history_item_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_item_created ON public.item_history USING btree (item_id, created_at);


--
-- Name: ix_item_history_org_action_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_org_action_created ON public.item_history USING btree (organization_id, action, created_at);


--
-- Name: ix_item_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_organization_id ON public.item_history USING btree (organization_id);


--
-- Name: ix_item_history_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_source_document_id ON public.item_history USING btree (source_document_id);


--
-- Name: ix_item_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_user_id ON public.item_history USING btree (user_id);


--
-- Name: ix_item_import_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_import_jobs_organization_id ON public.item_import_jobs USING btree (organization_id);


--
-- Name: ix_items_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode ON public.items USING btree (barcode);


--
-- Name: ix_items_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode_trgm ON public.items USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_items_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_brand_trgm ON public.items USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_items_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_created_at ON public.items USING btree (created_at);


--
-- Name: ix_items_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_expiry_date ON public.items USING btree (expiry_date);


--
-- Name: ix_items_is_catalog_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_catalog_entry ON public.items USING btree (is_catalog_entry);


--
-- Name: ix_items_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_deleted ON public.items USING btree (is_deleted);


--
-- Name: ix_items_label_code_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_label_code_trgm ON public.items USING gin (label_code public.gin_trgm_ops);


--
-- Name: ix_items_meta_data_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_meta_data_gin ON public.items USING gin (meta_data);


--
-- Name: ix_items_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_module_name ON public.items USING btree (module_name);


--
-- Name: ix_items_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_name_trgm ON public.items USING gin (name public.gin_trgm_ops);


--
-- Name: ix_items_org_archived_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_archived_at ON public.items USING btree (organization_id, is_deleted, COALESCE(deleted_at, created_at) DESC, id);


--
-- Name: ix_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_barcode_active ON public.items USING btree (organization_id, barcode, is_deleted);


--
-- Name: ix_items_org_category_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_category_active ON public.items USING btree (organization_id, category_id, is_deleted);


--
-- Name: ix_items_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_created ON public.items USING btree (organization_id, is_deleted, created_at DESC);


--
-- Name: ix_items_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_name ON public.items USING btree (organization_id, is_deleted, name);


--
-- Name: ix_items_org_not_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_not_deleted ON public.items USING btree (organization_id, is_deleted);


--
-- Name: ix_items_org_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_template_active ON public.items USING btree (organization_id, template_id, is_deleted);


--
-- Name: ix_items_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_organization_id ON public.items USING btree (organization_id);


--
-- Name: ix_items_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_partner_id ON public.items USING btree (partner_id);


--
-- Name: ix_items_quantity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_quantity ON public.items USING btree (quantity);


--
-- Name: ix_items_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number ON public.items USING btree (serial_number);


--
-- Name: ix_items_serial_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number_trgm ON public.items USING gin (serial_number public.gin_trgm_ops);


--
-- Name: ix_items_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_source_document_id ON public.items USING btree (source_document_id);


--
-- Name: ix_items_stock_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_stock_group ON public.items USING btree (organization_id, template_id, storage_location_id, lot_id, owner_id) INCLUDE (quantity, is_deleted);


--
-- Name: ix_items_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_storage_location_id ON public.items USING btree (storage_location_id);


--
-- Name: ix_label_pool_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_context_tag ON public.label_pool USING btree (context_tag);


--
-- Name: ix_label_pool_is_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_is_assigned ON public.label_pool USING btree (is_assigned);


--
-- Name: ix_location_relocations_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_relocations_org_moved_at ON public.location_relocations USING btree (organization_id, moved_at);


--
-- Name: ix_lot_org_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_org_expiry ON public.stock_lots USING btree (organization_id, expiry_date);


--
-- Name: ix_maker_attachment_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_maker_attachment_order ON public.maker_production_attachments USING btree (organization_id, production_order_id);


--
-- Name: ix_maker_price_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_maker_price_org ON public.maker_ingredient_prices USING btree (organization_id);


--
-- Name: ix_meal_plan_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_date ON public.meal_plan_entries USING btree (date);


--
-- Name: ix_meal_plan_entries_meal_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_meal_plan_id ON public.meal_plan_entries USING btree (meal_plan_id);


--
-- Name: ix_meal_plan_entries_plan_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_plan_date ON public.meal_plan_entries USING btree (meal_plan_id, date);


--
-- Name: ix_meal_plan_entries_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_recipe ON public.meal_plan_entries USING btree (recipe_id);


--
-- Name: ix_meal_plans_org_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_end ON public.meal_plans USING btree (organization_id, end_date);


--
-- Name: ix_meal_plans_org_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_start ON public.meal_plans USING btree (organization_id, start_date);


--
-- Name: ix_meal_plans_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_organization_id ON public.meal_plans USING btree (organization_id);


--
-- Name: ix_module_installations_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_module_installations_module_name ON public.module_installations USING btree (module_name);


--
-- Name: ix_notifications_user_read_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_read_created ON public.notifications USING btree (user_id, is_read, created_at);


--
-- Name: ix_organization_invitations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organization_invitations_code ON public.organization_invitations USING btree (code);


--
-- Name: ix_organizations_short_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_short_id ON public.organizations USING btree (short_id);


--
-- Name: ix_partners_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_code ON public.partners USING btree (code);


--
-- Name: ix_partners_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_is_active ON public.partners USING btree (is_active);


--
-- Name: ix_partners_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_name_trgm ON public.partners USING gin (name public.gin_trgm_ops);


--
-- Name: ix_partners_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_organization_id ON public.partners USING btree (organization_id);


--
-- Name: ix_picking_session_items_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_session_items_session_id ON public.picking_session_items USING btree (session_id);


--
-- Name: ix_picking_sessions_meal_plan_entry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_meal_plan_entry_id ON public.picking_sessions USING btree (meal_plan_entry_id);


--
-- Name: ix_picking_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_organization_id ON public.picking_sessions USING btree (organization_id);


--
-- Name: ix_picking_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_user_id ON public.picking_sessions USING btree (user_id);


--
-- Name: ix_po_partner_pricelist_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_organization_id ON public.po_partner_pricelist USING btree (organization_id);


--
-- Name: ix_po_partner_pricelist_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_partner_id ON public.po_partner_pricelist USING btree (partner_id);


--
-- Name: ix_po_partner_pricelist_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_product_template_id ON public.po_partner_pricelist USING btree (product_template_id);


--
-- Name: ix_po_partner_pricelist_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_template_active ON public.po_partner_pricelist USING btree (product_template_id, valid_from, valid_to);


--
-- Name: ix_po_reorder_rules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_organization_id ON public.po_reorder_rules USING btree (organization_id);


--
-- Name: ix_po_reorder_rules_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_product_template_id ON public.po_reorder_rules USING btree (product_template_id);


--
-- Name: ix_po_reorder_rules_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_storage_location_id ON public.po_reorder_rules USING btree (storage_location_id);


--
-- Name: ix_po_settings_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_settings_organization_id ON public.po_settings USING btree (organization_id);


--
-- Name: ix_print_agents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_agents_organization_id ON public.print_agents USING btree (organization_id);


--
-- Name: ix_print_jobs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_agent_id ON public.print_jobs USING btree (agent_id);


--
-- Name: ix_print_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_organization_id ON public.print_jobs USING btree (organization_id);


--
-- Name: ix_print_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_status ON public.print_jobs USING btree (status);


--
-- Name: ix_prod_line_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_line_order ON public.maker_production_order_lines USING btree (production_order_id);


--
-- Name: ix_prod_org_output; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_output ON public.maker_production_orders USING btree (organization_id, output_template_id);


--
-- Name: ix_prod_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_status ON public.maker_production_orders USING btree (organization_id, status);


--
-- Name: ix_prod_portion_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_portion_order ON public.maker_production_portions USING btree (production_order_id);


--
-- Name: ix_product_templates_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode ON public.product_templates USING btree (barcode);


--
-- Name: ix_product_templates_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode_trgm ON public.product_templates USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_product_templates_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_name_trgm ON public.product_templates USING gin (name public.gin_trgm_ops);


--
-- Name: ix_product_templates_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_org_name ON public.product_templates USING btree (organization_id, name);


--
-- Name: ix_product_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_organization_id ON public.product_templates USING btree (organization_id);


--
-- Name: ix_product_templates_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku ON public.product_templates USING btree (sku);


--
-- Name: ix_product_templates_sku_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku_trgm ON public.product_templates USING gin (sku public.gin_trgm_ops);


--
-- Name: ix_purchase_order_lines_purchase_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_purchase_order_id ON public.purchase_order_lines USING btree (purchase_order_id);


--
-- Name: ix_purchase_order_lines_source_reorder_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_source_reorder_rule_id ON public.purchase_order_lines USING btree (source_reorder_rule_id);


--
-- Name: ix_purchase_orders_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_number ON public.purchase_orders USING btree (number);


--
-- Name: ix_purchase_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_organization_id ON public.purchase_orders USING btree (organization_id);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_putaway_capacity_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_capacity_org ON public.putaway_capacity USING btree (organization_id);


--
-- Name: ix_putaway_home_silenced_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_home_silenced_organization_id ON public.putaway_home_silenced USING btree (organization_id);


--
-- Name: ix_putaway_rule_locations_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rule_locations_rule ON public.putaway_rule_locations USING btree (rule_id);


--
-- Name: ix_putaway_rules_org_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_category ON public.putaway_rules USING btree (organization_id, category_id);


--
-- Name: ix_putaway_rules_org_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_priority ON public.putaway_rules USING btree (organization_id, priority);


--
-- Name: ix_putaway_rules_org_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_product ON public.putaway_rules USING btree (organization_id, product_template_id);


--
-- Name: ix_recipe_collection_members_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_collection_id ON public.recipe_collection_members USING btree (collection_id);


--
-- Name: ix_recipe_collection_members_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_recipe_id ON public.recipe_collection_members USING btree (recipe_id);


--
-- Name: ix_recipe_collections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_organization_id ON public.recipe_collections USING btree (organization_id);


--
-- Name: ix_recipe_collections_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_parent_id ON public.recipe_collections USING btree (parent_id);


--
-- Name: ix_recipe_cost_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_org ON public.maker_recipe_cost_lines USING btree (organization_id);


--
-- Name: ix_recipe_cost_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_recipe ON public.maker_recipe_cost_lines USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_ingredient_group_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_ingredient_group_name ON public.recipe_ingredients USING btree (ingredient_group_name);


--
-- Name: ix_recipe_ingredients_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_recipe_id ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_template_id ON public.recipe_ingredients USING btree (template_id);


--
-- Name: ix_recipe_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_org_template ON public.maker_recipes USING btree (organization_id, output_template_id);


--
-- Name: ix_recipe_tag_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_tag_configs_organization_id ON public.recipe_tag_configs USING btree (organization_id);


--
-- Name: ix_recipes_is_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_is_favorite ON public.recipes USING btree (is_favorite);


--
-- Name: ix_recipes_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_organization_id ON public.recipes USING btree (organization_id);


--
-- Name: ix_registration_requests_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);


--
-- Name: ix_registration_requests_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_token ON public.registration_requests USING btree (token);


--
-- Name: ix_reservation_anchor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_anchor ON public.stock_reservations USING btree (anchor_id);


--
-- Name: ix_reservation_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_document ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_reservation_org_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_org_doc ON public.stock_reservations USING btree (organization_id, document_id);


--
-- Name: ix_roles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_organization_id ON public.roles USING btree (organization_id);


--
-- Name: ix_shopping_exclusions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_exclusions_organization_id ON public.shopping_exclusions USING btree (organization_id);


--
-- Name: ix_shopping_list_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_organization_id ON public.shopping_list_history USING btree (organization_id);


--
-- Name: ix_shopping_list_history_original_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_original_list_id ON public.shopping_list_history USING btree (original_list_id);


--
-- Name: ix_shopping_list_items_is_purchased; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_items_is_purchased ON public.shopping_list_items USING btree (is_purchased);


--
-- Name: ix_shopping_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_lists_status ON public.shopping_lists USING btree (status);


--
-- Name: ix_stock_anchors_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_product_template_id ON public.stock_anchors USING btree (product_template_id);


--
-- Name: ix_stock_anchors_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_storage_location_id ON public.stock_anchors USING btree (storage_location_id);


--
-- Name: ix_stock_ledger_totals_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_product_template_id ON public.stock_ledger_totals USING btree (product_template_id);


--
-- Name: ix_stock_ledger_totals_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_storage_location_id ON public.stock_ledger_totals USING btree (storage_location_id);


--
-- Name: ix_stock_lots_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_expiry_date ON public.stock_lots USING btree (expiry_date);


--
-- Name: ix_stock_lots_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_organization_id ON public.stock_lots USING btree (organization_id);


--
-- Name: ix_stock_lots_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_product_template_id ON public.stock_lots USING btree (product_template_id);


--
-- Name: ix_stock_moves_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_completed_at ON public.stock_moves USING btree (completed_at);


--
-- Name: ix_stock_moves_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_at ON public.stock_moves USING btree (created_at);


--
-- Name: ix_stock_moves_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_by ON public.stock_moves USING btree (created_by);


--
-- Name: ix_stock_moves_from_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_from_loc ON public.stock_moves USING btree (from_location_id);


--
-- Name: ix_stock_moves_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_lot_id ON public.stock_moves USING btree (lot_id);


--
-- Name: ix_stock_moves_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_moved_at ON public.stock_moves USING btree (organization_id, COALESCE(completed_at, created_at) DESC, id);


--
-- Name: ix_stock_moves_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_template ON public.stock_moves USING btree (organization_id, product_template_id);


--
-- Name: ix_stock_moves_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_organization_id ON public.stock_moves USING btree (organization_id);


--
-- Name: ix_stock_moves_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_owner_id ON public.stock_moves USING btree (owner_id);


--
-- Name: ix_stock_moves_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_product_template_id ON public.stock_moves USING btree (product_template_id);


--
-- Name: ix_stock_moves_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_reference ON public.stock_moves USING btree (reference_type, reference_id);


--
-- Name: ix_stock_moves_to_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_to_loc ON public.stock_moves USING btree (to_location_id);


--
-- Name: ix_stock_reservations_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_document_id ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_stock_reservations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_organization_id ON public.stock_reservations USING btree (organization_id);


--
-- Name: ix_stock_take_closed_locations_stock_take_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_closed_locations_stock_take_id ON public.stock_take_closed_locations USING btree (stock_take_id);


--
-- Name: ix_stock_take_counts_stock_take_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_counts_stock_take_item_id ON public.stock_take_counts USING btree (stock_take_item_id);


--
-- Name: ix_stock_takes_schedule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_takes_schedule_id ON public.stock_takes USING btree (schedule_id);


--
-- Name: ix_stock_valuation_layers_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_organization_id ON public.stock_valuation_layers USING btree (organization_id);


--
-- Name: ix_stock_valuation_layers_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_product_template_id ON public.stock_valuation_layers USING btree (product_template_id);


--
-- Name: ix_storage_locations_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_context_tag ON public.storage_locations USING btree (context_tag);


--
-- Name: ix_storage_locations_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_org_name ON public.storage_locations USING btree (organization_id, name);


--
-- Name: ix_storage_locations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_organization_id ON public.storage_locations USING btree (organization_id);


--
-- Name: ix_storage_locations_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_parent_id ON public.storage_locations USING btree (parent_id);


--
-- Name: ix_svl_org_direction_dated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_dated_at ON public.stock_valuation_layers USING btree (organization_id, direction, COALESCE(document_date, ((created_at AT TIME ZONE 'UTC'::text))::date), created_at, id);


--
-- Name: ix_svl_org_direction_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_reason ON public.stock_valuation_layers USING btree (organization_id, direction, reason);


--
-- Name: ix_svl_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_template ON public.stock_valuation_layers USING btree (organization_id, product_template_id);


--
-- Name: ix_svl_template_remaining; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_template_remaining ON public.stock_valuation_layers USING btree (organization_id, product_template_id, remaining_qty);


--
-- Name: ix_tax_rate_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_organization_id ON public.tax_rate_assignments USING btree (organization_id);


--
-- Name: ix_tax_rate_assignments_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_tax_rate_id ON public.tax_rate_assignments USING btree (tax_rate_id);


--
-- Name: ix_tax_rates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rates_organization_id ON public.tax_rates USING btree (organization_id);


--
-- Name: ix_unit_conv_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conv_lookup ON public.unit_conversions USING btree (ingredient_key, source_unit, lang, organization_id);


--
-- Name: ix_unit_conversions_ingredient_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_ingredient_key ON public.unit_conversions USING btree (ingredient_key);


--
-- Name: ix_unit_conversions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_organization_id ON public.unit_conversions USING btree (organization_id);


--
-- Name: ix_uom_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uom_categories_organization_id ON public.uom_categories USING btree (organization_id);


--
-- Name: ix_uoms_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uoms_organization_id ON public.uoms USING btree (organization_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_is_superuser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_is_superuser ON public.users USING btree (is_superuser);


--
-- Name: ix_users_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_organization_id ON public.users USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_organization_id ON public.webhook_delivery_logs USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_webhook_endpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_webhook_endpoint_id ON public.webhook_delivery_logs USING btree (webhook_endpoint_id);


--
-- Name: ix_webhook_endpoints_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_endpoints_organization_id ON public.webhook_endpoints USING btree (organization_id);


--
-- Name: ix_wms_pick_line_lots_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_line_lots_lot_id ON public.wms_pick_line_lots USING btree (lot_id);


--
-- Name: ix_wms_pick_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_document_line_id ON public.wms_pick_lines USING btree (document_line_id);


--
-- Name: ix_wms_pick_lines_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_session_id ON public.wms_pick_lines USING btree (session_id);


--
-- Name: ix_wms_pick_session_documents_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_session_documents_document_id ON public.wms_pick_session_documents USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_document_id ON public.wms_pick_sessions USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_organization_id ON public.wms_pick_sessions USING btree (organization_id);


--
-- Name: uq_document_org_post_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_org_post_key ON public.documents USING btree (organization_id, post_key) WHERE (post_key IS NOT NULL);


--
-- Name: uq_document_work_item_overlays_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_work_item_overlays_source ON public.document_work_item_overlays USING btree (organization_id, source_kind, source_id) WHERE (source_id IS NOT NULL);


--
-- Name: uq_eq_assignments_active_per_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_eq_assignments_active_per_item ON public.equipment_assignments USING btree (item_id) WHERE (checked_in_at IS NULL);


--
-- Name: uq_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_barcode_active ON public.items USING btree (organization_id, barcode) WHERE ((barcode IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_items_org_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_serial ON public.items USING btree (organization_id, serial_number) WHERE ((serial_number IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_partner_org_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_partner_org_code ON public.partners USING btree (organization_id, code) WHERE (code IS NOT NULL);


--
-- Name: uq_pending_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pending_request ON public.approval_requests USING btree (organization_id, target_type, target_id) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying])::text[]));


--
-- Name: uq_prod_org_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_prod_org_number ON public.maker_production_orders USING btree (organization_id, number) WHERE (number IS NOT NULL);


--
-- Name: uq_recipe_default_per_template; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_recipe_default_per_template ON public.maker_recipes USING btree (organization_id, output_template_id) WHERE (is_default = true);


--
-- Name: uq_stock_moves_backfill_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_stock_moves_backfill_ref ON public.stock_moves USING btree (reference_type, reference_id) WHERE ((reference_type)::text = 'item_history'::text);


--
-- Name: uq_storage_locations_org_parent_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_storage_locations_org_parent_name ON public.storage_locations USING btree (organization_id, parent_id, name) WHERE (parent_id IS NOT NULL);


--
-- Name: uq_storage_locations_org_root_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_storage_locations_org_root_name ON public.storage_locations USING btree (organization_id, name) WHERE (parent_id IS NULL);


--
-- Name: uq_templates_org_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_barcode ON public.product_templates USING btree (organization_id, barcode) WHERE (barcode IS NOT NULL);


--
-- Name: uq_templates_org_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_sku ON public.product_templates USING btree (organization_id, sku) WHERE (sku IS NOT NULL);


--
-- Name: uq_uom_category_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uom_category_reference ON public.uoms USING btree (category_id) WHERE (is_reference = true);


--
-- Name: uq_workflow_org_target; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_workflow_org_target ON public.approval_workflows USING btree (organization_id, target_type) WHERE (archived_at IS NULL);


--
-- Name: audit_log audit_log_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_log_immutable BEFORE DELETE OR UPDATE ON public.audit_log FOR EACH ROW EXECUTE FUNCTION public.audit_log_immutable();


--
-- Name: items ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER UPDATE OF quantity, lot_id, owner_id, storage_location_id, template_id, is_deleted ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL) AND ((new.is_deleted IS NOT FALSE) OR (new.template_id IS DISTINCT FROM old.template_id) OR (new.storage_location_id IS DISTINCT FROM old.storage_location_id) OR (new.lot_id IS DISTINCT FROM old.lot_id) OR (new.owner_id IS DISTINCT FROM old.owner_id) OR (new.quantity IS NULL) OR (new.quantity = 'NaN'::numeric) OR (new.quantity < old.quantity)))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_reservations ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER INSERT OR UPDATE OF quantity, anchor_id, lot_id, owner_id ON public.stock_reservations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: items ck_stock_holds_within_stock_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock_on_delete AFTER DELETE ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_moves stock_ledger_totals_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_delete AFTER DELETE ON public.stock_moves REFERENCING OLD TABLE AS old_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_insert AFTER INSERT ON public.stock_moves REFERENCING NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_update AFTER UPDATE ON public.stock_moves REFERENCING OLD TABLE AS old_moves NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: ai_connections ai_connections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approval_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approval_request_id_fkey FOREIGN KEY (approval_request_id) REFERENCES public.approval_requests(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.approval_workflows(id) ON DELETE RESTRICT;


--
-- Name: approval_workflows approval_workflows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_campaigns audit_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_campaigns audit_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_response_items audit_response_items_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_response_id_fkey FOREIGN KEY (response_id) REFERENCES public.audit_responses(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.audit_campaigns(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: categories categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_cost_variances document_cost_variances_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_cost_variances document_cost_variances_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_cost_variances document_cost_variances_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_extra_costs document_extra_costs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_corrects_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_corrects_line_id_fkey FOREIGN KEY (corrects_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_executed_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_executed_location_id_fkey FOREIGN KEY (executed_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_puts_away_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_puts_away_line_id_fkey FOREIGN KEY (puts_away_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: document_number_sequences document_number_sequences_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_package_id_fkey FOREIGN KEY (document_package_id) REFERENCES public.document_packages(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_packages document_packages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_default_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_default_template_id_fkey FOREIGN KEY (default_template_id) REFERENCES public.document_templates(id) ON DELETE SET NULL;


--
-- Name: document_profiles document_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_quarantine_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_quarantine_location_id_fkey FOREIGN KEY (quarantine_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_relations document_relations_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_relations document_relations_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_shipped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_shipped_by_fkey FOREIGN KEY (shipped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_type_configs document_type_configs_default_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_source_location_id_fkey FOREIGN KEY (default_source_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_default_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_target_location_id_fkey FOREIGN KEY (default_target_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_receiving_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_receiving_location_id_fkey FOREIGN KEY (receiving_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: document_work_item_overlays document_work_item_overlays_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_backorder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_backorder_id_fkey FOREIGN KEY (backorder_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: documents documents_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_corrects_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_corrects_document_id_fkey FOREIGN KEY (corrects_document_id) REFERENCES public.documents(id) ON DELETE RESTRICT;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: documents documents_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: documents documents_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_assignee_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_assignee_partner_id_fkey FOREIGN KEY (assignee_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_in_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_in_by_fkey FOREIGN KEY (checked_in_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_out_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_out_by_fkey FOREIGN KEY (checked_out_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checkout_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checkout_location_id_fkey FOREIGN KEY (checkout_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_assignments equipment_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_service_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_service_partner_id_fkey FOREIGN KEY (service_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: example_widgets example_widgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests fk_approval_requests_consumed_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_approval_requests_consumed_by_users FOREIGN KEY (consumed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_history fk_item_history_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_stock_anchor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_stock_anchor FOREIGN KEY (organization_id, template_id, storage_location_id) REFERENCES public.stock_anchors(organization_id, product_template_id, storage_location_id);


--
-- Name: label_pool fk_label_pool_item_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_item_id FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: organizations fk_organizations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT fk_organizations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: picking_sessions fk_picking_sessions_meal_plan_entry_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT fk_picking_sessions_meal_plan_entry_id FOREIGN KEY (meal_plan_entry_id) REFERENCES public.meal_plan_entries(id) ON DELETE SET NULL;


--
-- Name: stock_reservations fk_stock_reservations_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT fk_stock_reservations_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_expected_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_expected_location_id FOREIGN KEY (expected_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_storage_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_storage_location_id FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: users fk_users_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wms_pick_lines fk_wms_pick_lines_anchor_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_anchor_id FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines fk_wms_pick_lines_lot_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_lot_id FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_periods inventory_periods_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_reopened_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_reopened_by_fkey FOREIGN KEY (reopened_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_attachments item_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_import_jobs item_import_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_import_jobs item_import_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: items items_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: items items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: items items_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: items items_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: items items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id);


--
-- Name: items items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: label_pool label_pool_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: label_pool label_pool_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: label_pool label_pool_target_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_target_storage_location_id_fkey FOREIGN KEY (target_storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_from_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_from_parent_id_fkey FOREIGN KEY (from_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: location_relocations location_relocations_to_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_to_parent_id_fkey FOREIGN KEY (to_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: maker_bom_lines maker_bom_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_parent_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_parent_template_id_fkey FOREIGN KEY (parent_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_ingredient_prices maker_ingredient_prices_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT maker_ingredient_prices_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_ingredient_prices maker_ingredient_prices_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT maker_ingredient_prices_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_label_facts maker_label_facts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT maker_label_facts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_label_facts maker_label_facts_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT maker_label_facts_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_module_settings maker_module_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_attachments maker_production_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_attachments maker_production_attachments_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_attachments maker_production_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: maker_production_order_lines maker_production_order_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_order_lines maker_production_order_lines_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_source_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_source_storage_location_id_fkey FOREIGN KEY (source_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_orders maker_production_orders_output_layer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_layer_id_fkey FOREIGN KEY (output_layer_id) REFERENCES public.stock_valuation_layers(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_output_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_lot_id_fkey FOREIGN KEY (output_lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_output_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_storage_location_id_fkey FOREIGN KEY (output_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_orders maker_production_orders_produced_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_produced_item_id_fkey FOREIGN KEY (produced_item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id);


--
-- Name: maker_production_portions maker_production_portions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_portions maker_production_portions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_portions maker_production_portions_layer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES public.stock_valuation_layers(id) ON DELETE SET NULL;


--
-- Name: maker_production_portions maker_production_portions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_portions maker_production_portions_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_batch_yield_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_batch_yield_uom_id_fkey FOREIGN KEY (batch_yield_uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_recipes maker_recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_shelf_lives maker_shelf_lives_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT maker_shelf_lives_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_shelf_lives maker_shelf_lives_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT maker_shelf_lives_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_meal_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_meal_plan_id_fkey FOREIGN KEY (meal_plan_id) REFERENCES public.meal_plans(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: meal_plans meal_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: meal_plans meal_plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: organization_invitations organization_invitations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: organization_invitations organization_invitations_used_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_used_by_user_id_fkey FOREIGN KEY (used_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_session_items picking_session_items_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.recipe_ingredients(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.picking_sessions(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: po_partner_pricelist po_partner_pricelist_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_preferred_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_preferred_partner_id_fkey FOREIGN KEY (preferred_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: po_settings po_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_agents print_agents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.print_agents(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_jobs print_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_volume_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_volume_uom_id_fkey FOREIGN KEY (volume_uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_weight_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_weight_uom_id_fkey FOREIGN KEY (weight_uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_order_lines purchase_order_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines purchase_order_lines_source_reorder_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_source_reorder_rule_id_fkey FOREIGN KEY (source_reorder_rule_id) REFERENCES public.po_reorder_rules(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_orders purchase_orders_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: putaway_capacity putaway_capacity_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.putaway_rules(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipe_collections recipe_collections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_price_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_price_uom_id_fkey FOREIGN KEY (price_uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_tag_configs recipe_tag_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipes recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: registration_requests registration_requests_approved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_approved_by_id_fkey FOREIGN KEY (approved_by_id) REFERENCES public.users(id);


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: shopping_exclusions shopping_exclusions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_exclusions shopping_exclusions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_history shopping_list_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_list_history shopping_list_history_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: shopping_list_items shopping_list_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_shopping_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_shopping_list_id_fkey FOREIGN KEY (shopping_list_id) REFERENCES public.shopping_lists(id) ON DELETE CASCADE;


--
-- Name: shopping_list_items shopping_list_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: shopping_lists shopping_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shopping_lists shopping_lists_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_anchor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_anchor_id_fkey FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_counted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_counted_by_fkey FOREIGN KEY (counted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_stock_take_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_stock_take_item_id_fkey FOREIGN KEY (stock_take_item_id) REFERENCES public.stock_take_items(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: stock_take_items stock_take_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_take_items stock_take_items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id);


--
-- Name: stock_take_items stock_take_items_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: stock_takes stock_takes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.cycle_count_schedules(id) ON DELETE SET NULL;


--
-- Name: stock_takes stock_takes_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers stock_valuation_layers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_locations storage_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: storage_locations storage_locations_storage_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_storage_type_id_fkey FOREIGN KEY (storage_type_id) REFERENCES public.storage_types(id);


--
-- Name: storage_types storage_types_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_types storage_types_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tax_rate_assignments tax_rate_assignments_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_tax_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_tax_rate_id_fkey FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rates(id) ON DELETE CASCADE;


--
-- Name: tax_rates tax_rates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: unit_conversions unit_conversions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uom_categories uom_categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uoms uoms_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.uom_categories(id);


--
-- Name: uoms uoms_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_webhook_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_webhook_endpoint_id_fkey FOREIGN KEY (webhook_endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pick_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pick_line_id_fkey FOREIGN KEY (pick_line_id) REFERENCES public.wms_pick_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines wms_pick_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: wms_pick_sessions wms_pick_sessions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


