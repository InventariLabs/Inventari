-- Inventari v0.13.0: the database the release leaves on disk.
-- Cut by scripts/release-db-snapshot.sh from 263fbf98a6ae2f560b641cfeee503f9ca246a322.
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: audit_log_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_log_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_log rows are immutable: % operation not allowed', TG_OP;
    RETURN NULL;
END;
$$;


--
-- Name: stock_holds_within_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_holds_within_stock() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    DECLARE
        g_anchor uuid;
        g_lot uuid;
        g_owner uuid;
        anchor stock_anchors%ROWTYPE;
        held numeric;
        on_hand numeric;
    BEGIN
        IF TG_TABLE_NAME = 'stock_reservations' THEN
            g_anchor := NEW.anchor_id;
            g_lot := NEW.lot_id;
            g_owner := NEW.owner_id;
        ELSE
            SELECT id INTO g_anchor FROM stock_anchors
             WHERE organization_id = OLD.organization_id
               AND product_template_id = OLD.template_id
               AND storage_location_id = OLD.storage_location_id;
            g_lot := OLD.lot_id;
            g_owner := OLD.owner_id;
        END IF;
        -- A group with no anchor has no reservation rows to hold it.
        IF g_anchor IS NULL THEN
            RETURN NULL;
        END IF;
    
        SELECT coalesce(sum(quantity), 0) INTO held
          FROM stock_reservations
         WHERE anchor_id = g_anchor
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner;
        IF held = 0 THEN
            RETURN NULL;
        END IF;
    
        SELECT * INTO anchor FROM stock_anchors WHERE id = g_anchor;
        SELECT coalesce(sum(nullif(quantity, 'NaN'::numeric)), 0) INTO on_hand
          FROM items
         WHERE organization_id = anchor.organization_id
           AND template_id = anchor.product_template_id
           AND storage_location_id = anchor.storage_location_id
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner
           AND is_deleted IS FALSE;
    
        IF held > on_hand THEN
            RAISE EXCEPTION
                'ck_stock_holds_within_stock: % reserved of a grain holding %',
                held, on_hand
            USING ERRCODE = 'check_violation',
                  CONSTRAINT = 'ck_stock_holds_within_stock',
                  DETAIL = format(
                      'product %s, shelf %s, batch %s, owner %s',
                      anchor.product_template_id,
                      anchor.storage_location_id,
                      coalesce(g_lot::text, '-'),
                      coalesce(g_owner::text, '-')
                  );
        END IF;
        RETURN NULL;
    END $$;


--
-- Name: stock_ledger_totals_follow_moves(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_ledger_totals_follow_moves() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    BEGIN
        IF TG_OP IN ('INSERT', 'UPDATE') THEN
            INSERT INTO stock_ledger_totals AS t
                (organization_id, product_template_id, storage_location_id, quantity)
            SELECT organization_id, product_template_id, location_id, sum(qty)
            FROM (
                SELECT organization_id, product_template_id,
                       to_location_id AS location_id, quantity AS qty
                FROM new_moves
                WHERE state = 'done' AND to_location_id IS NOT NULL
                UNION ALL
                SELECT organization_id, product_template_id,
                       from_location_id, -quantity
                FROM new_moves
                WHERE state = 'done' AND from_location_id IS NOT NULL
            ) AS sides
            GROUP BY organization_id, product_template_id, location_id
            ORDER BY organization_id, product_template_id, location_id
            ON CONFLICT (organization_id, product_template_id, storage_location_id)
            DO UPDATE SET quantity = t.quantity + EXCLUDED.quantity;
        END IF;

        IF TG_OP IN ('UPDATE', 'DELETE') THEN
            WITH gone AS (
                SELECT organization_id, product_template_id, location_id,
                       sum(qty) AS qty
                FROM (
                    SELECT organization_id, product_template_id,
                           to_location_id AS location_id, quantity AS qty
                    FROM old_moves
                    WHERE state = 'done' AND to_location_id IS NOT NULL
                    UNION ALL
                    SELECT organization_id, product_template_id,
                           from_location_id, -quantity
                    FROM old_moves
                    WHERE state = 'done' AND from_location_id IS NOT NULL
                ) AS sides
                GROUP BY organization_id, product_template_id, location_id

            ), locked AS (
                SELECT t.organization_id, t.product_template_id,
                       t.storage_location_id, gone.qty
                FROM stock_ledger_totals AS t
                JOIN gone
                  ON t.organization_id = gone.organization_id
                 AND t.product_template_id = gone.product_template_id
                 AND t.storage_location_id = gone.location_id
                ORDER BY t.organization_id, t.product_template_id,
                         t.storage_location_id
                FOR UPDATE OF t
            )
            UPDATE stock_ledger_totals AS t
            SET quantity = t.quantity - locked.qty
            FROM locked
            WHERE t.organization_id = locked.organization_id
              AND t.product_template_id = locked.product_template_id
              AND t.storage_location_id = locked.storage_location_id;
        END IF;

        RETURN NULL;
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_connections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    api_key_enc character varying DEFAULT ''::character varying NOT NULL,
    api_base_url character varying(512) DEFAULT ''::character varying NOT NULL,
    model_name character varying(255) DEFAULT ''::character varying NOT NULL,
    temperature double precision,
    max_tokens integer,
    top_p double precision,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    capability_checks jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage_logs (
    id uuid NOT NULL,
    user_id uuid,
    organization_id uuid NOT NULL,
    model_name character varying(255) NOT NULL,
    provider character varying(100),
    prompt_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    total_tokens integer NOT NULL,
    estimated_cost_usd numeric(16,10),
    cost_is_estimated boolean DEFAULT false NOT NULL,
    action_type character varying(100),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_api_keys (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_approvals (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_equipment (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_example_widgets (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_maker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_maker (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_printing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_printing (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_purchase_orders (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_recipes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_shopping_lists (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_stock_takes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_warehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_warehouse (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_webhooks (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) NOT NULL,
    active_from timestamp with time zone NOT NULL,
    active_until timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    hashed_key character varying(64) NOT NULL,
    key_prefix character varying(15) NOT NULL,
    is_active boolean NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    scope_names jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: approval_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_decisions (
    id uuid NOT NULL,
    approval_request_id uuid NOT NULL,
    stage_order integer NOT NULL,
    approver_id uuid,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    notes text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    current_stage integer DEFAULT 1 NOT NULL,
    total_stages integer NOT NULL,
    created_by uuid NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    consumed_by uuid
);


--
-- Name: approval_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_workflows (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    stages json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    archived_at timestamp with time zone,
    requester_scope jsonb DEFAULT '{"everyone": true}'::jsonb NOT NULL
);


--
-- Name: audit_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_campaigns (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    scope_type character varying(20) NOT NULL,
    scope_filter_id uuid,
    launched_at timestamp with time zone,
    deadline timestamp with time zone NOT NULL,
    reminder_days_before integer NOT NULL,
    last_reminder_sent_at timestamp with time zone,
    status character varying(20) NOT NULL,
    email_subject character varying(255),
    email_body text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    snapshot json,
    reason character varying(500),
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_response_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_response_items (
    id uuid NOT NULL,
    response_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    item_id uuid NOT NULL,
    item_name character varying(255) NOT NULL,
    serial_number character varying(100),
    status character varying(20) NOT NULL,
    dispute_type character varying(30),
    dispute_reason text,
    created_at timestamp with time zone NOT NULL,
    responded_at timestamp with time zone
);


--
-- Name: audit_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_responses (
    id uuid NOT NULL,
    campaign_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    assignment_id uuid,
    assignee_email character varying(255) NOT NULL,
    assignee_name character varying(255) NOT NULL,
    token character varying(86) NOT NULL,
    token_expires_at timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    responded_at timestamp with time zone,
    dispute_reason text,
    dispute_type character varying(30),
    response_ip character varying(45),
    response_user_agent character varying(500),
    email_sent_at timestamp with time zone,
    reminder_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    code character varying(100),
    context_tag character varying(100),
    group_label character varying(50),
    icon character varying(100),
    emoji character varying(32),
    color character varying(16),
    sort_order integer NOT NULL,
    meta_data jsonb,
    default_removal_strategy character varying(10),
    module_name character varying(50),
    is_active boolean NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL
);


--
-- Name: cycle_count_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cycle_count_schedules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    frequency character varying(20) NOT NULL,
    scope character varying(20) NOT NULL,
    scope_filter json,
    sample_size integer,
    tolerance_percent numeric(5,2),
    is_active boolean NOT NULL,
    last_run_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_cycle_count_schedules_frequency CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying])::text[]))),
    CONSTRAINT ck_cycle_count_schedules_scope CHECK (((scope)::text = ANY ((ARRAY['all'::character varying, 'zone'::character varying, 'category'::character varying])::text[])))
);


--
-- Name: document_cost_variances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_cost_variances (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    reason character varying(255) NOT NULL,
    occurred_on date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_cost_variances_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_extra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extra_costs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    allocation_method character varying(10) DEFAULT 'value'::character varying NOT NULL,
    note character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_extra_costs_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_lines (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    item_id uuid,
    product_template_id uuid,
    name character varying(255),
    brand character varying(255),
    barcode character varying(50),
    quantity numeric(12,3) NOT NULL,
    expected_quantity numeric(12,3) NOT NULL,
    done_quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    batch_number character varying(100),
    serial_number character varying(100),
    expiry_date date,
    notes text,
    discrepancy_code character varying(50),
    discrepancy_reason text,
    unit_price numeric(12,2),
    tax_rate numeric(5,2),
    line_value numeric(14,2),
    line_tax numeric(14,2),
    line_gross numeric(14,2),
    currency character varying(3),
    line_number integer NOT NULL,
    source_po_line_id uuid,
    product_snapshot jsonb,
    executed_location_id uuid,
    corrects_line_id uuid,
    target_location_id uuid,
    held_quantity numeric(12,3) DEFAULT 0 NOT NULL,
    source_location_id uuid,
    puts_away_line_id uuid,
    meta_data jsonb,
    expected_is_count boolean DEFAULT false NOT NULL
);


--
-- Name: document_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_number_sequences (
    organization_id uuid NOT NULL,
    prefix character varying(120) NOT NULL,
    next_value integer DEFAULT 1 NOT NULL
);


--
-- Name: document_package_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_package_lines (
    id uuid NOT NULL,
    document_package_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_document_package_lines_quantity CHECK ((quantity > (0)::numeric))
);


--
-- Name: document_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_packages (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    number integer NOT NULL,
    weight_kg numeric(10,3),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_packages_weight CHECK ((weight_kg > (0)::numeric))
);


--
-- Name: document_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    value_tracking_enabled boolean NOT NULL,
    tax_handling character varying(20) NOT NULL,
    default_tax_rate numeric(5,2),
    require_partner_tax_id boolean,
    numbering_format character varying(100) NOT NULL,
    type_labels json,
    default_unit character varying(20) NOT NULL,
    visible_line_fields json,
    print_template character varying(50) NOT NULL,
    default_currency character varying(3),
    default_template_id uuid,
    approval_threshold numeric(14,2),
    approval_required_for_types json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    number_padding smallint NOT NULL,
    require_unit_price boolean DEFAULT false NOT NULL,
    confirm_shelf_by_scan boolean DEFAULT false NOT NULL,
    tracking_url_templates json,
    quarantine_location_id uuid,
    pick_order_strategy character varying(50)
);


--
-- Name: document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_relations (
    id uuid NOT NULL,
    source_document_id uuid NOT NULL,
    target_document_id uuid NOT NULL,
    relation_type character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_shipments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    carrier character varying(100) NOT NULL,
    tracking_number character varying(100),
    shipped_at timestamp with time zone NOT NULL,
    shipped_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    module character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(50) NOT NULL,
    body_html text NOT NULL,
    version integer NOT NULL,
    source_builtin character varying(255),
    source_checksum character varying(64),
    is_default boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: document_type_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_type_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_type character varying(15) NOT NULL,
    default_source_location_id uuid,
    default_target_location_id uuid,
    sequence_format character varying(50) NOT NULL,
    require_partner boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_warehouse_receiving; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_warehouse_receiving (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    two_step boolean DEFAULT false NOT NULL,
    receiving_location_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    free_placement boolean DEFAULT false NOT NULL
);


--
-- Name: document_work_item_overlays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_work_item_overlays (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    source_kind character varying(48) NOT NULL,
    source_id uuid,
    assignee_id uuid,
    title character varying(200),
    due_date date,
    done_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    type character varying(15) NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    source_location_id uuid,
    target_location_id uuid,
    scheduled_date date,
    notes text,
    external_reference character varying(100),
    partner_snapshot jsonb,
    corrects_document_id uuid,
    backorder_id uuid,
    total_net numeric(14,2),
    total_tax numeric(14,2),
    total_gross numeric(14,2),
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    completed_at timestamp with time zone,
    reason_code character varying(50),
    is_opening boolean DEFAULT false NOT NULL,
    stock_already_applied boolean DEFAULT false NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    complete_on_approval boolean DEFAULT false NOT NULL,
    post_key character varying(64),
    held_by character varying(64),
    meta_data jsonb,
    print_snapshot jsonb
);


--
-- Name: email_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_jobs (
    id uuid NOT NULL,
    organization_id uuid,
    to_email character varying(320) NOT NULL,
    subject character varying(500) NOT NULL,
    html_content text NOT NULL,
    attachment_bytes bytea,
    attachment_filename character varying(255),
    smtp_config_enc text,
    failure_notice_enc text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone
);


--
-- Name: equipment_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    assignee_partner_id uuid,
    checkout_location_id uuid,
    assigned_to_name character varying(255) NOT NULL,
    assigned_to_email character varying(255),
    checked_out_at timestamp with time zone NOT NULL,
    expected_return_at timestamp with time zone,
    checked_in_at timestamp with time zone,
    checked_out_by uuid NOT NULL,
    checked_in_by uuid,
    checkout_notes text,
    checkin_notes text,
    checkin_condition character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_type character varying(30) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_maintenance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_maintenance_logs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    maintenance_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    cost numeric(10,2),
    currency character varying(3),
    performed_at date NOT NULL,
    performed_by character varying(255),
    service_partner_id uuid,
    next_maintenance_at date,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_deliveries (
    id uuid NOT NULL,
    event_id character varying(64) NOT NULL,
    event character varying(100) NOT NULL,
    handler character varying(255) NOT NULL,
    organization_id uuid,
    payload jsonb NOT NULL,
    status character varying(16) NOT NULL,
    attempts integer NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_outbox (
    id uuid NOT NULL,
    organization_id uuid,
    event character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    emitter_module character varying(64),
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    published_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.example_widgets (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(30) DEFAULT 'blue'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ingredient_nutrition_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_nutrition_defaults (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    calories_kcal numeric(8,2) NOT NULL,
    protein_g numeric(8,2),
    fat_g numeric(8,2),
    carbs_g numeric(8,2),
    fiber_g numeric(8,2),
    sugar_g numeric(8,2),
    salt_g numeric(8,2),
    source character varying(50) NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_periods (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    reopened_at timestamp with time zone,
    reopened_by uuid,
    notes text
);


--
-- Name: item_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_attachments (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_history (
    id uuid NOT NULL,
    organization_id uuid,
    item_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    changes json,
    source_document_id uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_import_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    total integer NOT NULL,
    processed integer NOT NULL,
    result json,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    category_id uuid,
    module_name character varying(50),
    name character varying(255) NOT NULL,
    brand character varying(255),
    description character varying(500),
    uom_id uuid,
    template_id uuid,
    quantity numeric(12,3) NOT NULL,
    barcode character varying(50),
    serial_number character varying(100),
    added_date date NOT NULL,
    expiry_date date,
    shelf_location character varying(255),
    image_url character varying(500),
    meta_data jsonb,
    purchase_price numeric(10,2),
    currency character varying(3),
    is_deleted boolean NOT NULL,
    is_catalog_entry boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    label_code character varying(20),
    partner_id uuid,
    lot_id uuid,
    owner_id uuid,
    source_document_id uuid,
    CONSTRAINT ck_items_quantity_nonneg CHECK ((quantity >= (0)::numeric))
);


--
-- Name: label_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_pool (
    id uuid NOT NULL,
    short_code character varying(100) NOT NULL,
    is_assigned boolean NOT NULL,
    assigned_at timestamp with time zone,
    item_id uuid,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    label_type character varying(50) NOT NULL,
    description character varying(255),
    target_storage_location_id uuid,
    context_tag character varying(50),
    created_at timestamp with time zone NOT NULL,
    printed_at timestamp with time zone,
    scan_count integer NOT NULL,
    last_scanned_at timestamp with time zone
);


--
-- Name: location_relocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_relocations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid,
    location_name character varying(255) NOT NULL,
    from_parent_id uuid,
    to_parent_id uuid,
    from_path text,
    to_path text,
    moved_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: maker_bom_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_bom_lines (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_template_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    unit character varying(8) NOT NULL,
    yield_loss_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id uuid NOT NULL,
    qty_per_batch numeric(12,4) NOT NULL,
    uom_id uuid,
    make_fresh boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_bom_no_self CHECK ((parent_template_id <> child_template_id)),
    CONSTRAINT ck_bom_qty CHECK ((qty_per_batch > (0)::numeric)),
    CONSTRAINT ck_bom_yield_range CHECK (((yield_loss_pct >= (0)::numeric) AND (yield_loss_pct <= (100)::numeric)))
);


--
-- Name: maker_ingredient_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_ingredient_prices (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: maker_label_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_label_facts (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    label_name character varying(255),
    allergens jsonb,
    may_contain jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: maker_module_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_module_settings (
    organization_id uuid NOT NULL,
    reference_direction character varying(10) DEFAULT 'MARGIN'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    allow_overproduction boolean DEFAULT true NOT NULL,
    availability_check_scope character varying(15) DEFAULT 'GLOBAL'::character varying NOT NULL,
    create_on_shortage_strategy character varying(10) DEFAULT 'WARN'::character varying NOT NULL,
    labor_hourly_rate numeric(12,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: maker_production_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: maker_production_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_order_lines (
    id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    consumed_qty numeric(12,4) NOT NULL,
    unit character varying(8) NOT NULL,
    source_storage_location_id uuid,
    unit_cost_snapshot numeric(12,4),
    cost_source character varying(16),
    shortfall_qty numeric(12,4),
    estimated_qty numeric(12,4),
    estimated_unit_cost_snapshot numeric(12,4)
);


--
-- Name: maker_production_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    planned_qty numeric(12,3) NOT NULL,
    output_storage_location_id uuid NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    total_cost numeric(12,2),
    production_date date,
    notes character varying(500),
    created_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    cancel_reason character varying(500),
    produced_item_id uuid,
    recipe_id uuid,
    actual_qty numeric(12,3),
    overproduced boolean DEFAULT false NOT NULL,
    scrap_qty numeric(12,3),
    unit_cost_snapshot numeric(12,4),
    reference_price_snapshot numeric(12,2),
    result_per_unit numeric(12,2),
    result_per_batch numeric(12,2),
    number character varying(32),
    short_at_create boolean DEFAULT false NOT NULL,
    output_lot_name character varying(100),
    estimated_total_cost numeric(12,2),
    output_lot_id uuid,
    started_on date,
    started_at timestamp with time zone,
    material_cost numeric(12,2),
    unshelved_cost numeric(12,2),
    steps jsonb,
    planned_for date,
    output_layer_id uuid
);


--
-- Name: maker_production_portions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_portions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    qty numeric(12,3) NOT NULL,
    made_on date NOT NULL,
    lot_name character varying(100),
    item_id uuid,
    unit_cost numeric(12,4),
    layer_id uuid,
    created_by uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: maker_recipe_cost_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipe_cost_lines (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    label character varying(120) NOT NULL,
    amount numeric(12,2) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: maker_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    batch_yield_qty numeric(12,4) DEFAULT '1'::numeric NOT NULL,
    batch_yield_uom_id uuid,
    process_steps jsonb,
    reference_price numeric(12,2),
    is_default boolean DEFAULT false NOT NULL,
    source_recipe_id uuid,
    source_snapshot_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maker_shelf_lives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_shelf_lives (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    shelf_life_days integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_maker_shelf_life_positive CHECK ((shelf_life_days > 0))
);


--
-- Name: meal_plan_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_entries (
    id uuid NOT NULL,
    meal_plan_id uuid NOT NULL,
    date date NOT NULL,
    slot character varying(20) NOT NULL,
    recipe_id uuid NOT NULL,
    servings integer,
    notes text,
    "order" integer NOT NULL,
    CONSTRAINT ck_meal_plan_entries_slot CHECK (((slot)::text = ANY ((ARRAY['LUNCH'::character varying, 'BREAKFAST'::character varying, 'DINNER'::character varying, 'SNACK'::character varying])::text[])))
);


--
-- Name: meal_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plans (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255),
    start_date date NOT NULL,
    end_date date NOT NULL,
    enabled_slots jsonb NOT NULL,
    default_servings integer,
    shopping_list_id uuid,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    listed_meals jsonb
);


--
-- Name: module_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_installations (
    id uuid NOT NULL,
    module_name character varying(100) NOT NULL,
    installed_version character varying(50) NOT NULL,
    installed_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(1000) NOT NULL,
    type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    link character varying(255),
    meta_data jsonb
);


--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_invitations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    code character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    is_used boolean NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    role_id uuid,
    invited_email character varying(255),
    used_by_user_id uuid,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid,
    enabled_modules json NOT NULL,
    allowed_modules json,
    settings json NOT NULL,
    short_id character varying(20),
    active_profile_id character varying(50),
    onboarding_completed boolean DEFAULT false,
    focus_module character varying(50),
    pre_focus_enabled_modules json,
    pre_onboarding_manual_modules json,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'UTC'::character varying NOT NULL,
    tax_id character varying(50),
    country character varying(2),
    print_page_size character varying(10),
    address json,
    logo_url character varying(500)
);


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    type character varying(30) NOT NULL,
    tax_id character varying(50),
    is_consumer boolean DEFAULT false NOT NULL,
    email character varying(255),
    phone character varying(50),
    website character varying(500),
    contact_person character varying(255),
    address jsonb,
    notes text,
    is_active boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: picking_session_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_session_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    ingredient_id uuid,
    item_id uuid,
    quantity_consumed numeric(10,3),
    picked_items jsonb,
    consumed_valuation_rate numeric(12,2),
    status character varying(20) NOT NULL,
    ingredient_name character varying(255),
    required_quantity numeric(10,3),
    required_uom_symbol character varying(10)
);


--
-- Name: picking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    user_id uuid NOT NULL,
    servings integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    rating integer,
    scale numeric(10,3),
    meal_plan_entry_id uuid
);


--
-- Name: po_partner_pricelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_partner_pricelist (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    uom_id uuid,
    min_quantity numeric(12,3),
    valid_from date NOT NULL,
    valid_to date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_partner_pricelist_min_qty_positive CHECK (((min_quantity IS NULL) OR (min_quantity > (0)::numeric))),
    CONSTRAINT ck_po_partner_pricelist_unit_price_positive CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT ck_po_partner_pricelist_valid_range CHECK (((valid_to IS NULL) OR (valid_to >= valid_from)))
);


--
-- Name: po_reorder_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_reorder_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    min_quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    safety_stock numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    preferred_partner_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_reorder_rules_max_ge_min CHECK ((max_quantity >= min_quantity)),
    CONSTRAINT ck_po_reorder_rules_min_nonneg CHECK ((min_quantity >= (0)::numeric)),
    CONSTRAINT ck_po_reorder_rules_safety_nonneg CHECK ((safety_stock >= (0)::numeric))
);


--
-- Name: po_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    approval_threshold numeric(14,2),
    approval_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: print_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_agents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    printer_type character varying(50) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_version character varying(50),
    protocol_version integer
);


--
-- Name: print_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    labels jsonb NOT NULL,
    created_by uuid,
    attempts integer NOT NULL,
    lease_until timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    width_mm double precision DEFAULT 50.0 NOT NULL,
    height_mm double precision DEFAULT 24.0 NOT NULL,
    scale double precision,
    read_permissions jsonb NOT NULL
);


--
-- Name: product_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_templates (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    brand character varying(255),
    barcode character varying(50),
    sku character varying(50),
    uom_id uuid,
    weight_value numeric(14,6),
    weight_uom_id uuid,
    volume_value numeric(14,6),
    volume_uom_id uuid,
    image_url character varying(500),
    description character varying(500),
    min_quantity double precision,
    removal_strategy character varying(10),
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_lines (
    id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_template_id uuid,
    name character varying(255) NOT NULL,
    quantity_ordered numeric(12,3) NOT NULL,
    quantity_received numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_price numeric(12,2),
    uom_id uuid,
    tax_rate numeric(5,2),
    line_number integer NOT NULL,
    notes text,
    source_reorder_rule_id uuid
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    scheduled_date date,
    notes text,
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_capacity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_capacity (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_home_silenced; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_home_silenced (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_location_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_location_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    single_product boolean DEFAULT false NOT NULL
);


--
-- Name: putaway_rule_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rule_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    location_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: putaway_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    context_tag character varying(100),
    storage_type_code character varying(50),
    priority integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_putaway_rules_at_least_one_match CHECK (((product_template_id IS NOT NULL) OR (category_id IS NOT NULL) OR (context_tag IS NOT NULL) OR (storage_type_code IS NOT NULL)))
);


--
-- Name: recipe_collection_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collection_members (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(64),
    parent_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    template_id uuid,
    name character varying(255) NOT NULL,
    display_text character varying(500),
    ingredient_group_name character varying(100),
    quantity numeric(10,3) NOT NULL,
    uom_id uuid,
    original_quantity numeric(10,3),
    original_unit_text character varying(50),
    is_optional boolean NOT NULL,
    picking_skip boolean,
    sort_order integer NOT NULL,
    calories_kcal_per_100g numeric(8,2),
    price numeric(10,2),
    price_uom_id uuid,
    price_currency character varying(3),
    allergens jsonb NOT NULL,
    is_spice boolean NOT NULL
);


--
-- Name: recipe_tag_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_tag_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    instructions text,
    servings integer NOT NULL,
    prep_time_minutes integer,
    image_url text,
    source_url text,
    tags jsonb,
    is_favorite boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_requests (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    token character varying(255),
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    accepted_at timestamp with time zone,
    rejected_at timestamp with time zone,
    is_rejected boolean DEFAULT false NOT NULL,
    approved_by_id uuid
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shopping_exclusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_exclusions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    template_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_history (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    original_list_id uuid NOT NULL,
    original_list_name character varying(255) NOT NULL,
    item_name character varying(255) NOT NULL,
    quantity numeric(12,3) DEFAULT 1 NOT NULL,
    estimated_price numeric(10,2),
    purchased_at timestamp with time zone,
    purchased_by uuid,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_items (
    id uuid NOT NULL,
    shopping_list_id uuid NOT NULL,
    item_id uuid,
    category_id uuid,
    name character varying(255) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    notes text,
    estimated_price numeric(10,2),
    is_purchased boolean NOT NULL,
    purchased_at timestamp with time zone,
    purchased_by uuid,
    source character varying(50) NOT NULL,
    priority integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_id uuid,
    note_data jsonb
);


--
-- Name: shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_lists (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    completed_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_anchors (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_ledger_totals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_ledger_totals (
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    quantity numeric(18,3) NOT NULL
);


--
-- Name: stock_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_lots (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    is_serial boolean NOT NULL,
    expiry_date date,
    production_date date,
    use_by_date date,
    removal_strategy character varying(10) NOT NULL,
    status character varying(20) NOT NULL,
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: stock_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_moves (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    from_location_id uuid,
    to_location_id uuid,
    quantity numeric(12,3) NOT NULL,
    lot_id uuid,
    owner_id uuid,
    expiry_date date,
    state character varying(20) DEFAULT 'done'::character varying NOT NULL,
    reference_type character varying(20),
    reference_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_stock_moves_at_least_one_location CHECK (((from_location_id IS NOT NULL) OR (to_location_id IS NOT NULL))),
    CONSTRAINT ck_stock_moves_qty_positive CHECK ((quantity > (0)::numeric))
);


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    document_line_id uuid,
    anchor_id uuid NOT NULL,
    lot_id uuid,
    owner_id uuid,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_quants_from_records; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.stock_quants_from_records AS
 SELECT (md5((((((((((organization_id)::text || '/'::text) || (product_template_id)::text) || '/'::text) || COALESCE((storage_location_id)::text, '-'::text)) || '/'::text) || COALESCE((lot_id)::text, '-'::text)) || '/'::text) || COALESCE((owner_id)::text, '-'::text))))::uuid AS id,
    organization_id,
    product_template_id,
    storage_location_id,
    lot_id,
    owner_id,
    (COALESCE(sum(quantity), (0)::numeric))::numeric(12,3) AS quantity,
    (COALESCE(sum(reserved_quantity), (0)::numeric))::numeric(12,3) AS reserved_quantity,
    'FIFO'::character varying(10) AS removal_strategy,
    min(created_at) AS created_at,
    max(updated_at) AS updated_at
   FROM ( SELECT i.organization_id,
            i.template_id AS product_template_id,
            i.storage_location_id,
            i.lot_id,
            i.owner_id,
            NULLIF(i.quantity, 'NaN'::numeric) AS quantity,
            NULL::numeric AS reserved_quantity,
            i.created_at,
            i.updated_at
           FROM public.items i
          WHERE ((i.is_deleted IS FALSE) AND (i.template_id IS NOT NULL))
        UNION ALL
         SELECT a.organization_id,
            a.product_template_id,
            a.storage_location_id,
            r.lot_id,
            r.owner_id,
            NULL::numeric AS "numeric",
            r.quantity,
            r.created_at,
            r.created_at
           FROM (public.stock_reservations r
             JOIN public.stock_anchors a ON ((a.id = r.anchor_id)))) sides
  GROUP BY organization_id, product_template_id, storage_location_id, lot_id, owner_id;


--
-- Name: stock_take_closed_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_closed_locations (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    storage_location_id uuid,
    path text NOT NULL,
    empty boolean DEFAULT false NOT NULL,
    closed_by uuid,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_counts (
    id uuid NOT NULL,
    stock_take_item_id uuid NOT NULL,
    sequence integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    counted_by uuid,
    counted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_items (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    item_id uuid,
    item_name character varying(255) NOT NULL,
    item_brand character varying(255),
    uom_id uuid,
    assignee_id uuid,
    lot_id uuid,
    system_quantity numeric(12,3),
    counted_quantity numeric(10,3),
    location_in_storage character varying(255),
    notes text,
    discrepancy_reason character varying(255),
    is_discrepancy integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discrepancy_reason_code character varying(50),
    recount_requested boolean DEFAULT false NOT NULL,
    storage_location_id uuid,
    expected_location_id uuid
);


--
-- Name: stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_takes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    blind_mode boolean NOT NULL,
    require_full_count boolean NOT NULL,
    tolerance_percent numeric(5,2),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule_id uuid,
    adjustment_document_id uuid,
    CONSTRAINT ck_stock_takes_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: stock_valuation_layers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_valuation_layers (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    document_line_id uuid,
    quantity numeric(12,3) NOT NULL,
    remaining_qty numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    total_value numeric(14,2) NOT NULL,
    document_date date,
    currency character varying(3),
    direction character varying(10) NOT NULL,
    cost_basis character varying(10) NOT NULL,
    reason character varying(30),
    item_id uuid,
    created_at timestamp with time zone NOT NULL,
    revalued_at timestamp with time zone,
    unit_cost_before numeric(12,4),
    cost_basis_before character varying(10),
    internal boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_svl_remaining_not_negative CHECK ((remaining_qty >= (0)::numeric))
);


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_id uuid,
    storage_type_id uuid,
    context_schema json DEFAULT '[]'::json NOT NULL,
    behavior_mode character varying(50) DEFAULT 'STOCK'::character varying NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    location_details character varying(255),
    short_code character varying(100),
    sequence integer,
    usage character varying(50) DEFAULT 'internal'::character varying NOT NULL,
    context_tag character varying(50),
    settings json,
    warehouse_config jsonb,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL
);


--
-- Name: storage_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_types (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    type_code character varying(50) NOT NULL,
    behavior_mode character varying(50) NOT NULL,
    context_schema json DEFAULT '[]'::json NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    icon character varying(100),
    is_system boolean NOT NULL,
    created_by uuid,
    default_settings json
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by uuid
);


--
-- Name: tax_rate_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    tax_rate_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    CONSTRAINT ck_tax_rate_assignments_one_target CHECK ((num_nonnulls(product_template_id, category_id) = 1))
);


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    rate numeric(5,2) NOT NULL,
    code character varying(10),
    country character varying(2),
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: unit_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_conversions (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    ingredient_key character varying(100) NOT NULL,
    ingredient_name character varying(200) NOT NULL,
    source_unit character varying(50) NOT NULL,
    metric_quantity numeric(10,3) NOT NULL,
    metric_unit character varying(10) NOT NULL,
    category character varying(50) NOT NULL,
    is_system boolean NOT NULL
);


--
-- Name: uom_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom_categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(50) NOT NULL
);


--
-- Name: uoms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uoms (
    id uuid NOT NULL,
    organization_id uuid,
    category_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL,
    factor numeric(18,9) NOT NULL,
    is_reference boolean NOT NULL,
    is_system boolean NOT NULL,
    rounding numeric(12,6) NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    blocking_reason character varying(500),
    failed_login_count bigint DEFAULT 0,
    locked_until timestamp with time zone,
    organization_id uuid
);


--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_delivery_logs (
    id uuid NOT NULL,
    webhook_endpoint_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload_json jsonb NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    attempt_number integer DEFAULT 1 NOT NULL,
    next_retry_at timestamp with time zone,
    delivery_status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    delivery_id character varying(36),
    abandon_reason character varying(40),
    last_attempt_at timestamp with time zone
);


--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_endpoints (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2048) NOT NULL,
    secret character varying(512),
    http_method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    event_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    retry_backoff_seconds integer DEFAULT 10 NOT NULL,
    timeout_seconds integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp with time zone,
    last_status_code integer,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auto_disabled_at timestamp with time zone
);


--
-- Name: wms_pick_line_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_line_lots (
    pick_line_id uuid NOT NULL,
    lot_id uuid NOT NULL,
    lot_name character varying(100) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_lines (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    pick_order integer NOT NULL,
    status character varying(20) NOT NULL,
    picked_quantity numeric(12,3) NOT NULL,
    bin_location character varying(255),
    product_name character varying(255),
    lot_name character varying(100),
    expected_quantity numeric(12,3) NOT NULL,
    uom_symbol character varying(10),
    anchor_id uuid,
    lot_id uuid,
    location_id uuid,
    expiry_date date
);


--
-- Name: wms_pick_session_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_session_documents (
    session_id uuid NOT NULL,
    document_id uuid NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    assigned_to uuid,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    meta_data jsonb,
    last_activity_at timestamp with time zone
);


--
-- Data for Name: ai_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version (version_num) VALUES ('spoons01');


--
-- Data for Name: alembic_version_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_api_keys (version_num) VALUES ('009_key_prefix_column_narrows');


--
-- Data for Name: alembic_version_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_approvals (version_num) VALUES ('007_workflow_requester_scope');


--
-- Data for Name: alembic_version_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_equipment (version_num) VALUES ('010_response_item_responded_at');


--
-- Data for Name: alembic_version_example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_example_widgets (version_num) VALUES ('001_initial');


--
-- Data for Name: alembic_version_maker; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_maker (version_num) VALUES ('023_output_cost_layer');


--
-- Data for Name: alembic_version_printing; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_printing (version_num) VALUES ('007_job_read_permission');


--
-- Data for Name: alembic_version_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_purchase_orders (version_num) VALUES ('po_tzaware01');


--
-- Data for Name: alembic_version_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_recipes (version_num) VALUES ('014_backfill_imported_allergens');


--
-- Data for Name: alembic_version_shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_shopping_lists (version_num) VALUES ('007_history_quantity_default');


--
-- Data for Name: alembic_version_stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_stock_takes (version_num) VALUES ('014_enums_are_text');


--
-- Data for Name: alembic_version_warehouse; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_warehouse (version_num) VALUES ('doc_cost_variance01');


--
-- Data for Name: alembic_version_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_webhooks (version_num) VALUES ('005_timestamps_carry_their_zone');


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('bacc7bfd-1077-4ef9-b892-ec3143f695e3', '16e33317-f2aa-4202-8321-e1768e6ad113', 1, 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'APPROVED', NULL, '2026-11-20 03:36:21.265517+00', '2026-11-20 03:36:21.265517+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('8deec40b-4e6f-48a3-a595-87a8264789c6', '16e33317-f2aa-4202-8321-e1768e6ad113', 2, NULL, 'PENDING', NULL, NULL, '2026-11-20 00:36:21.265517+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('75cacef9-03a1-4dcb-aa0f-01a4d4369ffd', '3d809500-3d33-434e-9365-0f4f81146478', 1, 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'APPROVED', NULL, '2026-11-13 03:36:21.265517+00', '2026-11-13 03:36:21.265517+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('66c4f58d-44ee-4393-9bf4-67e98eed5009', '3d809500-3d33-434e-9365-0f4f81146478', 2, '29df2390-1a60-43fd-ba97-7824689adfc1', 'APPROVED', NULL, '2026-11-13 06:36:21.265517+00', '2026-11-13 06:36:21.265517+00');


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('16e33317-f2aa-4202-8321-e1768e6ad113', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '54bce892-c35d-46ee-9a89-8c7ea8f79d30', 'purchase_order', '0d2220a2-bf3f-4f7a-90c2-435ac297f937', 'IN_PROGRESS', 2, 2, 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-11-20 00:36:21.265517+00', NULL, NULL);
INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('3d809500-3d33-434e-9365-0f4f81146478', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '54bce892-c35d-46ee-9a89-8c7ea8f79d30', 'purchase_order', '499e19cd-12f2-4df7-99d4-bf4de57aa032', 'APPROVED', 2, 2, 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-11-13 00:36:21.265517+00', NULL, NULL);


--
-- Data for Name: approval_workflows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_workflows (id, organization_id, target_type, name, stages, is_active, created_at, updated_at, archived_at, requester_scope) VALUES ('54bce892-c35d-46ee-9a89-8c7ea8f79d30', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'purchase_order', 'Purchase orders over 10,000', '[{"order": 1, "role": "manager", "label": "Team lead", "approver_user_ids": []}, {"order": 2, "role": "admin", "label": "Finance", "approver_user_ids": []}]', true, '2026-11-22 23:36:21.875984+00', NULL, NULL, '{"everyone": true}');


--
-- Data for Name: audit_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_campaigns (id, organization_id, name, description, scope_type, scope_filter_id, launched_at, deadline, reminder_days_before, last_reminder_sent_at, status, email_subject, email_body, created_by, created_at, updated_at) VALUES ('903b7e0c-c056-40e7-8833-64656517aba8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Autumn equipment check', 'Confirm you still hold the equipment issued to you.', 'ALL', NULL, '2026-11-18 23:36:22.310366+00', '2026-12-09 23:59:00+00', 3, NULL, 'ACTIVE', NULL, NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-18 22:36:22.310366+00', '2026-11-22 23:36:22.311518+00');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('be1c7d60-6ef7-4bda-b5eb-eaf3e05811a7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'module', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '{"name": "equipment", "subject": "profile:equipment_wms", "before": {"maintenance_warning_days": 7, "warranty_warning_days": 30}, "after": {"maintenance_warning_days": 14, "warranty_warning_days": 60}}', NULL, 'null', '2026-11-22 23:36:18.625581+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('1b5b434a-7b9d-47d2-8979-b8cb13ea2994', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', 'be63bb32-f836-4a97-904e-2362e64fc3bc', '{"name": "UHT Milk 3.2%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "48.000", "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "storage_location_name": "Fridge A - Top Shelf", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "category_name": "Dairy", "category_code": "dairy", "module_name": null}', NULL, 'null', '2026-11-22 23:36:20.196419+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5f0f1a60-17c5-479a-9aee-2dc0d095f481', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', 'f1b01e73-4b2d-4f5b-a8b2-047403048011', '{"name": "Natural Yoghurt 400g", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "24.000", "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "storage_location_name": "Fridge A - Top Shelf", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:36:20.196427+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('db7598f3-a817-4572-9756-1f3c49d45d91', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '{"name": "Butter Extra 82%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "36.000", "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "storage_location_name": "Fridge A - Top Shelf", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "category_name": "Dairy", "category_code": "dairy", "module_name": null}', NULL, 'null', '2026-11-22 23:36:20.196428+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9c56df69-779c-44aa-aeb2-30ea3b57c83d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '{"name": "Gouda Cheese", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "60.000", "storage_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736", "storage_location_name": "Fridge A - Door", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:36:20.245847+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f4d916df-c593-4dc4-ba69-378be11af663', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', '2daeb525-a954-4004-acd1-dd1d1eca96a3', '{"name": "Sour Cream 18%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "20.000", "storage_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736", "storage_location_name": "Fridge A - Door", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "category_name": "Dairy", "category_code": "dairy", "module_name": null}', NULL, 'null', '2026-11-22 23:36:20.245848+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('1f03f34c-9c61-4aa1-a1bb-32490bd9c624', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', 'aed74404-e412-47b8-b24f-41f54508d717', '{"name": "Dell Latitude 5540", "brand": "Dell", "barcode": null, "sku": null, "quantity": "5.000", "storage_location_id": "f6692961-91cb-41c9-a7e0-bf7b39b1cb1b", "storage_location_name": "Server Rack A", "category_id": "4c2096c1-1ed7-4745-9d6c-dbeee4337c47", "category_name": "Laptop", "category_code": "LAPTOP", "module_name": "equipment"}', NULL, 'null', '2026-11-22 23:36:20.271349+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('bc34d59d-93e3-47e5-bcda-d0c971c77f35', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', '9702ad84-eaae-4361-bc5f-97d245f5334a', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": "3.000", "storage_location_id": "f6692961-91cb-41c9-a7e0-bf7b39b1cb1b", "storage_location_name": "Server Rack A", "category_id": "4c2096c1-1ed7-4745-9d6c-dbeee4337c47", "category_name": "Laptop", "category_code": "LAPTOP", "module_name": "equipment"}', NULL, 'null', '2026-11-22 23:36:20.271351+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('84e56ffa-9735-4755-8e84-319d6efd6e14', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', 'be63bb32-f836-4a97-904e-2362e64fc3bc', '{"name": "UHT Milk 3.2%", "before": {"quantity": "48.000"}, "after": {"quantity": "36.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "fb6b2610-e5da-4418-ae07-eeff4c6a586a"}', '2026-11-22 23:36:20.347388+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('b1e9e565-957b-4d8f-bc19-d60561a33ed0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '{"name": "Butter Extra 82%", "before": {"quantity": "36.000"}, "after": {"quantity": "28.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "fb6b2610-e5da-4418-ae07-eeff4c6a586a"}', '2026-11-22 23:36:20.34739+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('b3c6955b-db72-4a65-b44c-d791c3ef2bca', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "wms_session_id": "0bab75a7-1ebd-49d2-8921-31e64c882e55", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:36:20.628595+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('72a8c22e-f51a-46cf-b71e-8d1b361913b4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aa365cc5-5414-40a4-9ada-86f186c992e3', '{"number": "OUT/2026/004", "wms_session_id": "0bab75a7-1ebd-49d2-8921-31e64c882e55", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:36:20.62985+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e9f55e24-3b10-487b-9113-320bcd91e178', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "wms_session_id": "0bab75a7-1ebd-49d2-8921-31e64c882e55", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:36:20.738436+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('10254e21-f2fb-4145-90c8-1915b591b0bb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aa365cc5-5414-40a4-9ada-86f186c992e3', '{"number": "OUT/2026/004", "wms_session_id": "0bab75a7-1ebd-49d2-8921-31e64c882e55", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-22 23:36:20.738855+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e52d98c6-4871-4b45-9b14-00bbc89e5ca3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "weight_value": null}', NULL, 'null', '2026-11-22 23:36:20.757782+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('224a1537-acd8-4700-8324-68d9a1701822', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "name": "Natural Yoghurt 400g", "quantity": "6", "old_quantity": "0"}', NULL, 'null', '2026-11-22 23:36:20.981253+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('15c385f7-7df4-4fac-a255-db3ccc500abf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "weight_value": null}', NULL, 'null', '2026-11-22 23:36:20.994415+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('be8ea9c0-ad13-4cfa-a0a9-34774f529b0e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "name": "Butter Extra 82%", "quantity": "4", "old_quantity": "0"}', NULL, 'null', '2026-11-22 23:36:21.008512+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('571529e6-a3f6-4f9e-83c6-612f760c9899', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', 'f1b01e73-4b2d-4f5b-a8b2-047403048011', '{"name": "Natural Yoghurt 400g", "before": {"quantity": "24.000"}, "after": {"quantity": "18.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "aaa28144-9b19-429b-9c06-de601c1b317b"}', '2026-11-22 23:36:21.157083+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('6ee11ca2-55de-4295-a3e1-ac3392d3b9a4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '{"name": "Butter Extra 82%", "before": {"quantity": "28.000"}, "after": {"quantity": "24.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "aaa28144-9b19-429b-9c06-de601c1b317b"}', '2026-11-22 23:36:21.157085+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('1ac90c6d-e36a-4473-9e88-4380081c2837', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', '{"number": "OUT/2026/003", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-22 23:36:21.157085+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e62736de-9da7-485d-88e9-a15a1fc30033', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '{"name": "Gouda Cheese", "before": {"quantity": "60.000"}, "after": {"quantity": "50.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "aa365cc5-5414-40a4-9ada-86f186c992e3"}', '2026-11-22 23:36:21.238453+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('97b3ea92-2b23-455e-a3af-2ef4a18617fa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', '2daeb525-a954-4004-acd1-dd1d1eca96a3', '{"name": "Sour Cream 18%", "before": {"quantity": "20.000"}, "after": {"quantity": "15.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "aa365cc5-5414-40a4-9ada-86f186c992e3"}', '2026-11-22 23:36:21.238455+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('3098cf5e-88cd-4102-be81-84ba4596042d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'document', 'aa365cc5-5414-40a4-9ada-86f186c992e3', '{"number": "OUT/2026/004", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-22 23:36:21.238455+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('33118999-398b-44c9-9b50-e3e59c8192df', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', '896db80b-0a08-45a1-91fb-4131104794e5', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": "3.000", "storage_location_id": "f6692961-91cb-41c9-a7e0-bf7b39b1cb1b", "storage_location_name": "Server Rack A", "category_id": "4c2096c1-1ed7-4745-9d6c-dbeee4337c47", "category_name": "Laptop", "category_code": "LAPTOP", "module_name": "equipment"}', NULL, 'null', '2026-11-22 23:36:21.491175+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('da205330-8459-4e75-b9b3-de1770550872', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'maker_production_order', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '{"name": "PR/2026/0001", "status": "DRAFT", "output": "Plum Butter", "planned_qty": "12.000"}', NULL, 'null', '2026-11-22 23:36:21.670423+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('3e0fa2aa-8819-4003-8a3e-22fde7149bc7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', 'e2c46401-5df2-417a-abb4-be3a832b6e89', '{"name": "Damson Plums", "before": {"quantity": "40.000"}, "after": {"quantity": "13.600"}}', 'production_run', '{"production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94", "production_order_number": "PR/2026/0001"}', '2026-11-22 23:36:21.723168+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5b472faa-5133-4921-962a-d68bfa853e7e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', 'c4a17a40-5316-4b45-81c4-66fc0ab3f63e', '{"name": "White Sugar", "before": {"quantity": "25.000"}, "after": {"quantity": "21.220"}}', 'production_run', '{"production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94", "production_order_number": "PR/2026/0001"}', '2026-11-22 23:36:21.748375+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('8e36d253-8414-4fec-b03a-3cd202aa8917', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGE', 'item', '2fb18879-a1da-4481-b850-1ce35d12cfbf', '{"name": "Cassia Cinnamon", "before": {"quantity": "0.500"}, "after": {"quantity": "0.440"}}', 'production_run', '{"production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94", "production_order_number": "PR/2026/0001"}', '2026-11-22 23:36:21.766485+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f7660a24-a02d-49ca-8243-e27d0b8bf155', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATE', 'item', '9b453772-d40a-4c8c-8e44-f10839058cf5', '{"name": "Plum Butter", "brand": null, "barcode": null, "sku": "PLB-001", "quantity": "11.400", "storage_location_id": "211e5889-8bcb-43e8-98ef-685b7582bef3", "storage_location_name": "Shelf A - Bottom", "category_id": null, "category_name": null, "category_code": null, "module_name": null}', NULL, 'null', '2026-11-22 23:36:21.794751+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4e00bc2c-fffa-45fd-bc2f-6af2291380f4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'UPDATE', 'maker_production_order', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '{"name": "PR/2026/0001", "old_status": "DRAFT", "new_status": "COMPLETED", "output": "Plum Butter", "quantity": "11.400", "total_cost": "95.36"}', NULL, 'null', '2026-11-22 23:36:21.802485+00');


--
-- Data for Name: audit_response_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('15f2da58-d2d2-4a1d-80da-7767d82d425b', '7b954ba0-a562-445e-8ba5-29d5ddd75343', 'd5d6dd16-b2f1-40b6-b85e-fdd2fc805476', 'ba38ccac-2151-4fdc-b7b1-1e789ae583f6', 'iPhone 15 Pro', 'SN-100034', 'CONFIRMED', NULL, NULL, '2026-11-22 23:36:22.314099+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('4fda1938-ac90-4b09-a337-4e724c176d33', 'b7bc8ca7-3edc-49fe-9142-42c62cae668f', '52811b9a-4878-4428-a402-db199476b6ff', '9c18923a-6caf-43d9-a1be-0342a59d5196', 'ThinkPad T14s Gen 4', 'SN-100005', 'DISPUTED', 'DAMAGED', 'The hinge on the lid is cracked and the screen flickers.', '2026-11-22 23:36:22.314101+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('f501420c-96a1-4ebc-8921-9aecf7157204', 'dcdd1623-18aa-40e1-b435-6dd8fa9f0d72', 'bc96d5d5-6d1a-454c-83c6-857a2b38ef46', 'ca1868ce-156a-43f1-91da-c2ed95d26841', 'ThinkPad T14s Gen 4', 'SN-100006', 'PENDING', NULL, NULL, '2026-11-22 23:36:22.314101+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('98c6c4b2-f968-4c49-ae6f-40b0529a8f85', '4af86485-5f63-4941-a0cd-e46ea79d9637', '63a51297-1386-4e2b-95e4-bbf79d4fafe1', '20d2d485-2f5b-4fdb-b999-8c2df86bb2bb', 'ThinkPad T14s Gen 4', 'SN-100007', 'PENDING', NULL, NULL, '2026-11-22 23:36:22.314102+00', NULL);


--
-- Data for Name: audit_responses; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('7b954ba0-a562-445e-8ba5-29d5ddd75343', '903b7e0c-c056-40e7-8833-64656517aba8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'admin@example.com', 'Demo Administrator', '6fth49YEmEDrPKU8H7mDRAdhdk2SjDwNjVMu0TPMXC8RBsZhtpJ0B74C8gQ-yHowbAk-pQJ8TpHjQVDdc7NfGg', '2026-12-09 23:59:00+00', 'CONFIRMED', '2026-11-19 23:36:22.310366+00', NULL, NULL, NULL, NULL, '2026-11-18 23:36:22.310366+00', NULL, '2026-11-22 23:36:22.312486+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('b7bc8ca7-3edc-49fe-9142-42c62cae668f', '903b7e0c-c056-40e7-8833-64656517aba8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'priya.raman@example.com', 'Priya Raman', 'yVzne45QFGaoHHpL8jhHyDk75O_tVJbFMWAk8-J3WHkwuGk5WTpIkTv-cBqVU4HGoWaayESpWfk3Uhi7-cporA', '2026-12-09 23:59:00+00', 'DISPUTED', '2026-11-20 00:36:22.310366+00', 'The hinge on the lid is cracked and the screen flickers.', 'DAMAGED', NULL, NULL, '2026-11-18 23:36:22.310366+00', NULL, '2026-11-22 23:36:22.312488+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('dcdd1623-18aa-40e1-b435-6dd8fa9f0d72', '903b7e0c-c056-40e7-8833-64656517aba8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'marcus.webb@example.com', 'Marcus Webb', 'Ak1-TZ-0Qqs2uJk3bRqQ_XzypxxKMUyK_f1jL7nVgpavZ1jvfLUGYvf6f3Y3awnsXw0kt0NOUhYHNfJv9NsLwA', '2026-12-09 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-11-18 23:36:22.310366+00', NULL, '2026-11-22 23:36:22.312488+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('4af86485-5f63-4941-a0cd-e46ea79d9637', '903b7e0c-c056-40e7-8833-64656517aba8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'ava.brennan@example.com', 'Ava Brennan', 'VUxR83Q40OgQo9XM05-ZqOOSCgY8ZGpGtlgL8JLxFGl-PPiMmZXeAOUlLj7_gRFyEAzogUpidJDFRy15cj-Gjg', '2026-12-09 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-11-18 23:36:22.310366+00', NULL, '2026-11-22 23:36:22.312489+00');


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('4c2096c1-1ed7-4745-9d6c-dbeee4337c47', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Laptop', 'LAPTOP', 'equipment', NULL, 'laptop', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "os", "type": "text", "label": "Operating System", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('081774cc-67fb-4828-bd38-fee5db5e3dbd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Desktop Computer', 'DESKTOP', 'equipment', NULL, 'monitor', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('e488fd36-fae0-432e-a1db-07c705993252', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Monitor / Display', 'MONITOR', 'equipment', NULL, 'monitor-smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "size_inches", "type": "number", "label": "Screen Size (inches)", "visible": true, "required": false, "is_system": true}, {"key": "resolution", "type": "text", "label": "Resolution", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 7, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Phone / Tablet', 'PHONE', 'equipment', NULL, 'smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "imei", "type": "text", "label": "IMEI", "visible": true, "required": false, "is_system": true}, {"key": "phone_number", "type": "text", "label": "Phone Number", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 3, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('364aed20-5148-4f63-b7b7-6fba8c707fa1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fish', 'fish', 'cold_storage', 'FREEZER', 'Fish', NULL, NULL, 4, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('4ca1a048-bf47-4788-a4e2-012fcf0438e7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Seafood', 'seafood', 'cold_storage', 'FREEZER', 'Shell', NULL, NULL, 5, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('69a9317c-d464-454f-b021-8d8c163ceba5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen meals', 'frozen_meals', 'cold_storage', 'FREEZER', 'Soup', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('47d0168a-6684-4ae8-b1ac-8ccc7f2d9011', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen vegetables', 'frozen_vegetables', 'cold_storage', 'FREEZER', 'LeafyGreen', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('293adab3-cb18-493b-a188-4799a2342aa2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Network Device', 'NETWORK_DEVICE', 'equipment', NULL, 'wifi', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "mac_address", "type": "text", "label": "MAC Address", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 8, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('64716e9d-6a92-4a9d-80b0-5cbcb821582f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Peripheral', 'PERIPHERAL', 'equipment', NULL, 'mouse', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 4, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('0bd2d983-8838-4137-90d6-18f9690612a8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Server', 'SERVER', 'equipment', NULL, 'server', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "rack_position", "type": "text", "label": "Rack Position", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "cpu", "type": "text", "label": "CPU", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 10, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b560495f-e1ba-41da-ba94-58fc37b6ee1b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Other Equipment', 'OTHER_EQUIPMENT', 'equipment', NULL, 'package', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d6065e41-c5dd-45fa-af1c-583d4104219b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Pork', 'pork', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ab079a38-5529-45c0-a770-447e19bef903', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Beef', 'beef', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('10531d7e-5698-48f2-9736-aa564c29ae47', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Poultry', 'poultry', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 3, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('f7a5c284-3cfd-40e1-aae1-89d486e84334', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen fruits', 'frozen_fruits', 'cold_storage', 'FREEZER', 'Apple', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b49bf2e2-a7ff-4886-aa6d-cbd02d511738', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Ice cream and desserts', 'ice_cream', 'cold_storage', 'FREEZER', 'IceCream', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b45f6081-8501-47ca-b01a-4bebdf6283c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen pizza', 'frozen_pizza', 'cold_storage', 'FREEZER', 'Pizza', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('82a6fd2f-98c4-4647-9290-0612400951fb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dairy', 'dairy', 'cold_storage', 'FRIDGE', 'Milk', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('4d18ddc6-5051-482e-bc56-a6c0fafa1225', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cheese', 'cheese', 'cold_storage', 'FRIDGE', 'Cheese', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ab59039b-a87f-4434-8ac2-630d8f5f7c60', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Deli', 'deli', 'cold_storage', 'FRIDGE', 'Beef', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('601797f1-b499-483a-b6eb-1b59f4872884', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Eggs', 'eggs', 'cold_storage', 'FRIDGE', 'Egg', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a5e843db-1701-4f66-9bb3-c63f484a01bf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fresh vegetables', 'fresh_vegetables', 'cold_storage', 'FRIDGE', 'LeafyGreen', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('6d00bb46-b704-4bb9-9b21-684a7f2a7776', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fresh fruits', 'fresh_fruits', 'cold_storage', 'FRIDGE', 'Apple', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('cab4139b-9813-429f-ab37-4f50d3d05913', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Drinks', 'drinks', 'cold_storage', 'FRIDGE', 'GlassWater', NULL, NULL, 7, NULL, NULL, NULL, true, '[{"key": "abv", "is_system": true, "label": "Alcohol content (ABV %)", "type": "number", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('98031881-b194-443b-958e-09ee94d4565f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Sauces and dips', 'sauces', 'cold_storage', 'FRIDGE', 'Pint', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8ccc1a7c-2ef5-49df-84da-014a62e9c862', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fresh meat', 'fresh_meat', 'cold_storage', 'FRIDGE', 'Drumstick', NULL, NULL, 9, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a4419df3-d4c9-4332-a219-bd6e924e71c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fresh meals', 'fresh_meals', 'cold_storage', 'FRIDGE', 'CookingPot', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a3f8624a-d9ca-4790-a543-b38b34417af5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dry products', 'dry_products', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 1, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('5bd878de-c119-48a8-b0e1-4586bad69195', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Pasta', 'pasta', 'dry_goods', 'PANTRY', 'Utensils', NULL, NULL, 2, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a97391ec-ba34-4907-88f5-d03a5aa6ba75', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Rice and grains', 'rice_grains', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d00b31ee-9624-4783-bff5-5c2bec7b171e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Canned goods', 'canned_goods', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b7acaa85-4afc-4790-a70c-93180a16e4ca', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Spices and herbs', 'spices_herbs', 'dry_goods', 'PANTRY', 'Leaf', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b8e3e596-8b7f-4375-b48c-0987683fb759', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Oils and vinegars', 'oils_vinegars', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('feac2ad5-d3d5-47c1-81b8-925ab0fcc204', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Flours and sugars', 'flours_sugars', 'dry_goods', 'PANTRY', 'Box', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('97dc7519-79ec-4cf1-b76b-c315607db925', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Snacks', 'snacks', 'dry_goods', 'PANTRY', 'Cookie', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ddfaf076-51d7-4fff-a2d5-d7d3c8eea18d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Sweets', 'sweets', 'dry_goods', 'PANTRY', 'Candy', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('451d2056-6da3-44a5-9aa8-5a9e937fae83', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Beverages (non-refrigerated)', 'beverages', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('1b336e37-67db-4641-b316-b48448cce33e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tea and coffee', 'tea_coffee', 'dry_goods', 'PANTRY', 'Coffee', NULL, NULL, 11, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('99e2f510-d62e-4534-8108-d0300b54e3d5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cans and jars', 'cans_jars', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 12, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d98e474c-3a20-40bb-b034-9b943c65832d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Other', 'other', NULL, NULL, 'Archive', NULL, NULL, 100, NULL, NULL, NULL, true, '[]');


--
-- Data for Name: cycle_count_schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_cost_variances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_extra_costs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('bba25478-1bfd-4b8a-8899-52e2626b85eb', '44bc6105-c926-4e12-b6d6-cbb84e5e0c10', '2b4cd597-e3f3-49df-b2d1-cb0f01656380', '45cccb60-d659-4421-a067-32c271cbf33f', 'Soy Sauce', 'Harvest Row', '2000000000725', 5.000, 5.000, 0.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 11.50, NULL, 57.50, NULL, 57.50, 'USD', 1, NULL, '{"name": "Soy Sauce", "seed": "SEED-DOC", "brand": "Harvest Row"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('a6b5c6d3-0434-4c60-af1a-ab43ccacdddb', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', 'be63bb32-f836-4a97-904e-2362e64fc3bc', '656e5398-3fa1-4738-9447-f448081d8e8c', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 48.000, 48.000, 48.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 216.00, NULL, 216.00, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('aaf359ad-0eb3-4700-9d65-45df0552749c', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', 'f1b01e73-4b2d-4f5b-a8b2-047403048011', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 24.000, 24.000, 24.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, NULL, 124.80, NULL, 124.80, 'USD', 2, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('0cf6fce3-6066-4ba0-b431-7572284fd3a3', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 36.000, 36.000, 36.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 320.40, NULL, 320.40, 'USD', 3, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('6934d50c-55e1-4ab9-840c-411775be2a8d', 'a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'Gouda Cheese', 'Meadowlane', '2000000000046', 60.000, 60.000, 60.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 750.00, NULL, 750.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('a0e9e025-9035-44b6-9bbf-9736b25dd99e', 'a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', '2daeb525-a954-4004-acd1-dd1d1eca96a3', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 20.000, 20.000, 20.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 82.00, NULL, 82.00, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('9bdd58de-cf93-4391-a0b2-e777a521dc4b', '7550cc0c-a8ed-4b64-a7db-21d697c2e761', 'aed74404-e412-47b8-b24f-41f54508d717', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 'Dell Latitude 5540', 'Dell', '2000000010014', 5.000, 5.000, 5.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 4200.00, NULL, 21000.00, NULL, 21000.00, 'USD', 1, NULL, '{"name": "Dell Latitude 5540", "seed": "SEED-DOC", "brand": "Dell"}', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('1bd6df43-f9dd-401d-a2da-a65d7ae5183c', '7550cc0c-a8ed-4b64-a7db-21d697c2e761', '9702ad84-eaae-4361-bc5f-97d245f5334a', '0f92a508-261c-403d-bc4f-49b1635180cb', 'ThinkPad T14s Gen 4', 'Lenovo', '2000000010021', 3.000, 3.000, 3.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, NULL, 17400.00, NULL, 17400.00, 'USD', 2, NULL, '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC", "brand": "Lenovo"}', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('a4b5dbcb-4a47-4e8b-97b0-efb3448a26d5', 'fb6b2610-e5da-4418-ae07-eeff4c6a586a', 'be63bb32-f836-4a97-904e-2362e64fc3bc', '656e5398-3fa1-4738-9447-f448081d8e8c', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 12.000, 12.000, 12.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 54.00, NULL, 54.00, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('6c457dd0-837d-471a-bc72-8f56f347d693', 'fb6b2610-e5da-4418-ae07-eeff4c6a586a', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 8.000, 8.000, 8.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 71.20, NULL, 71.20, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('48380f98-79bc-4edd-b7c9-514b30879e76', '0b5b91d1-0670-4240-8c0c-386ac71ab210', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 0.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 125.00, NULL, 125.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('6022265c-5103-4003-be37-3593a50868d4', 'aaa28144-9b19-429b-9c06-de601c1b317b', 'f1b01e73-4b2d-4f5b-a8b2-047403048011', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 6.000, 6.000, 6.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, NULL, 31.20, NULL, 31.20, 'USD', 1, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('dd38a5d5-f174-4d93-a96e-8328248d49f2', 'aaa28144-9b19-429b-9c06-de601c1b317b', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 4.000, 4.000, 4.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 35.60, NULL, 35.60, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('fb05ecc9-fa61-4197-a054-5d596153758e', '736fda6f-bded-4a88-a8a1-57d1bf09f776', '896db80b-0a08-45a1-91fb-4131104794e5', '0f92a508-261c-403d-bc4f-49b1635180cb', 'ThinkPad T14s Gen 4', NULL, NULL, 3.000, 3.000, 3.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, NULL, 17400.00, NULL, 17400.00, 'USD', 1, 'f2130701-aea5-43fc-b164-725a3192a20d', '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC"}', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('58ca2a67-2bae-421a-9d96-9d6ec98d62b0', '997d1da7-392e-435a-a1b8-2509f111bb7a', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'Gouda Cheese', 'Meadowlane', '2000000000046', 8.000, 8.000, 0.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 100.00, NULL, 100.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('42e732f6-d2b1-4ed5-a55e-2a10b3f41fa2', '997d1da7-392e-435a-a1b8-2509f111bb7a', '2daeb525-a954-4004-acd1-dd1d1eca96a3', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 4.000, 4.000, 0.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 16.40, NULL, 16.40, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('4983a982-46a0-4320-906e-2acef04d0b8e', 'aa365cc5-5414-40a4-9ada-86f186c992e3', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 10.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 125.00, NULL, 125.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('1c85a826-d604-43df-a123-9e428ca1422e', 'aa365cc5-5414-40a4-9ada-86f186c992e3', '2daeb525-a954-4004-acd1-dd1d1eca96a3', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 5.000, 5.000, 5.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 20.50, NULL, 20.50, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);


--
-- Data for Name: document_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_number_sequences (organization_id, prefix, next_value) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'PR/2026/', 2);


--
-- Data for Name: document_package_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('2cbebebf-1b9b-4d48-8663-d214c83cca7f', '6e695a4c-92bc-414c-bda0-7cbf28d95203', '6022265c-5103-4003-be37-3593a50868d4', 6.000, '2026-11-22 23:36:20.471872+00');
INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('3b92959a-48b7-44cd-9966-c1c438d69d88', '5a911203-f2e4-42e4-bae0-0adc144ec9ff', 'dd38a5d5-f174-4d93-a96e-8328248d49f2', 4.000, '2026-11-22 23:36:20.471872+00');


--
-- Data for Name: document_packages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('6e695a4c-92bc-414c-bda0-7cbf28d95203', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'aaa28144-9b19-429b-9c06-de601c1b317b', 1, NULL, '2026-11-22 23:36:20.471872+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('5a911203-f2e4-42e4-bae0-0adc144ec9ff', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'aaa28144-9b19-429b-9c06-de601c1b317b', 2, NULL, '2026-11-22 23:36:20.471872+00', '29df2390-1a60-43fd-ba97-7824689adfc1');


--
-- Data for Name: document_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_profiles (id, organization_id, name, value_tracking_enabled, tax_handling, default_tax_rate, require_partner_tax_id, numbering_format, type_labels, default_unit, visible_line_fields, print_template, default_currency, default_template_id, approval_threshold, approval_required_for_types, created_at, updated_at, number_padding, require_unit_price, confirm_shelf_by_scan, tracking_url_templates, quarantine_location_id, pick_order_strategy) VALUES ('38bfe38d-67ef-4e9a-ae98-b37b4301e579', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Full Value', true, 'SIMPLE_RATE', NULL, NULL, '{TYPE}/{YEAR}/{SEQ:03d}', 'null', 'pcs', '[]', 'auto', NULL, NULL, NULL, NULL, '2026-11-22 23:36:18.631816+00', '2026-11-22 23:36:18.648191+00', 3, false, false, NULL, '7808334a-dad9-446d-9ef1-8672d68b5132', NULL);


--
-- Data for Name: document_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_shipments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_shipments (id, organization_id, document_id, carrier, tracking_number, shipped_at, shipped_by, notes, created_at) VALUES ('3f9c7f26-369e-4979-b17d-8e048db33c44', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'aaa28144-9b19-429b-9c06-de601c1b317b', 'InPost', '620012345678901234567890', '2026-11-22 23:36:21.064266+00', '29df2390-1a60-43fd-ba97-7824689adfc1', NULL, '2026-11-22 23:36:21.024085+00');


--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_type_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_warehouse_receiving; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_work_item_overlays; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('0b5b91d1-0670-4240-8c0c-386ac71ab210', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'OUT', 'OUT/2026/002', 'CONFIRMED', 'bb1537cc-0997-4227-bbb1-ccae26c55c31', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, '2026-11-20', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 125.00, 0.00, 125.00, 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', NULL, '2026-11-20 11:20:00+00', '2026-11-22 23:36:22.27289+00', '2026-11-20 12:30:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('44bc6105-c926-4e12-b6d6-cbb84e5e0c10', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'INT', 'INT/2026/001', 'DRAFT', NULL, '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '2026-11-21', NULL, NULL, 'null', NULL, NULL, 57.50, 0.00, 57.50, 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', NULL, NULL, '2026-11-21 08:10:00+00', '2026-11-22 23:36:22.273282+00', NULL, NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('736fda6f-bded-4a88-a8a1-57d1bf09f776', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'IN', 'IN/2026/001', 'COMPLETED', '5680c980-7e65-47cb-b882-d6548a9158fb', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-05', NULL, 'PO/2026/003', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 17400.00, 0.00, 17400.00, 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-05 10:50:00+00', '2026-11-22 23:36:22.273849+00', '2026-11-05 12:00:00+00', '2026-11-05 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('7550cc0c-a8ed-4b64-a7db-21d697c2e761', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'IN', 'IN/2026/004', 'COMPLETED', '5680c980-7e65-47cb-b882-d6548a9158fb', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-20', NULL, 'Delivery note 7313', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 38400.00, 0.00, 38400.00, 'USD', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-20 12:05:00+00', '2026-11-22 23:36:22.273851+00', '2026-11-20 13:15:00+00', '2026-11-20 14:45:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('997d1da7-392e-435a-a1b8-2509f111bb7a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'OUT', 'OUT/2026/005', 'CONFIRMED', '6ad48e50-d312-4dfb-a711-9748d63cca08', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, '2026-11-21', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 116.40, 0.00, 116.40, 'USD', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', NULL, '2026-11-21 12:05:00+00', '2026-11-22 23:36:22.274343+00', '2026-11-21 13:15:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'IN', 'IN/2026/003', 'COMPLETED', 'e23a5390-31be-468c-b94e-d037be34dbc8', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '2026-11-15', NULL, 'Delivery note 7312', '{"code": "MCC-005", "name": "Bulkline Cash & Carry"}', NULL, NULL, 832.00, 0.00, 832.00, 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-15 09:35:00+00', '2026-11-22 23:36:22.274618+00', '2026-11-15 10:45:00+00', '2026-11-15 12:15:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('aa365cc5-5414-40a4-9ada-86f186c992e3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'OUT', 'OUT/2026/004', 'COMPLETED', 'bb1537cc-0997-4227-bbb1-ccae26c55c31', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, '2026-11-21', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 145.50, 0.00, 145.50, 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-21 11:20:00+00', '2026-11-22 23:36:22.27462+00', '2026-11-21 12:30:00+00', '2026-11-21 14:00:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('aaa28144-9b19-429b-9c06-de601c1b317b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'OUT', 'OUT/2026/003', 'COMPLETED', '6ad48e50-d312-4dfb-a711-9748d63cca08', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, '2026-11-21', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 66.80, 0.00, 66.80, 'USD', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-21 10:50:00+00', '2026-11-22 23:36:22.27462+00', '2026-11-21 12:00:00+00', '2026-11-21 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'IN', 'IN/2026/002', 'COMPLETED', '2df551b1-835b-4456-a890-cd7930a9e97c', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '2026-11-13', NULL, 'Delivery note 7311', '{"code": "FFD-004", "name": "Freshfield Wholesale"}', NULL, NULL, 661.20, 0.00, 661.20, 'USD', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-13 09:35:00+00', '2026-11-22 23:36:22.274621+00', '2026-11-13 10:45:00+00', '2026-11-13 12:15:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('fb6b2610-e5da-4418-ae07-eeff4c6a586a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'OUT', 'OUT/2026/001', 'COMPLETED', '6ad48e50-d312-4dfb-a711-9748d63cca08', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, '2026-11-18', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 125.20, 0.00, 125.20, 'USD', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-18 08:10:00+00', '2026-11-22 23:36:22.274621+00', '2026-11-18 09:20:00+00', '2026-11-18 10:50:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);


--
-- Data for Name: email_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('63a51297-1386-4e2b-95e4-bbf79d4fafe1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '20d2d485-2f5b-4fdb-b999-8c2df86bb2bb', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 'Ava Brennan', 'ava.brennan@example.com', '2026-11-08 23:36:21.588364+00', '2027-05-21 23:36:21.588368+00', NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-22 23:36:21.590706+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('bc96d5d5-6d1a-454c-83c6-857a2b38ef46', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ca1868ce-156a-43f1-91da-c2ed95d26841', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 'Marcus Webb', 'marcus.webb@example.com', '2026-10-30 23:36:21.588447+00', '2027-05-21 23:36:21.588449+00', NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-22 23:36:21.590708+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('52811b9a-4878-4428-a402-db199476b6ff', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9c18923a-6caf-43d9-a1be-0342a59d5196', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 'Priya Raman', 'priya.raman@example.com', '2026-10-21 23:36:21.588474+00', '2027-05-21 23:36:21.588475+00', NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-22 23:36:21.590709+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('d5d6dd16-b2f1-40b6-b85e-fdd2fc805476', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ba38ccac-2151-4fdc-b7b1-1e789ae583f6', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 'Demo Administrator', 'admin@example.com', '2026-10-13 23:36:22.289078+00', NULL, NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', NULL, 'Work phone, with case and charger.', NULL, NULL, '2026-11-22 23:36:22.295367+00');


--
-- Data for Name: equipment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_maintenance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('9266d2e9-ade9-4190-b575-4806c5f042c9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '3ad907b2-900d-4c8f-a1a5-d9a425e1750c', 'REPAIR', 'Replace failed PSU', 'Redundant power supply 2 reported a fault; unit sent to the vendor.', NULL, 'USD', '2026-11-19', 'Northgate IT Distribution', NULL, NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.872813+00', '2026-11-22 23:36:21.872815+00');
INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('94388dbd-ef60-4537-812b-f47e710d0783', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e2baf4e3-573f-443d-898c-fd37aa7f5bfa', 'INSPECTION', 'Battery self-test and runtime check', 'Runtime at full load 11 min, within spec. Batteries due next year.', 120.00, 'USD', '2026-10-13', 'Northgate IT Distribution', NULL, '2027-10-13', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.872816+00', '2026-11-22 23:36:21.872817+00');


--
-- Data for Name: event_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: event_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('0479c546-1127-4569-a782-e0dc09abea25', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "be63bb32-f836-4a97-904e-2362e64fc3bc", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "48.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.170701+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.170704+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "656e5398-3fa1-4738-9447-f448081d8e8c", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.202742+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('1ba745e1-2f2e-4759-862b-9d1367d584f5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "f1b01e73-4b2d-4f5b-a8b2-047403048011", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.183573+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.183576+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "cc8ee259-f9ed-483f-8c35-4a06dcee91d2", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.203173+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('2926f140-bf9b-4844-bb18-2f74319305bf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.192235+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.192236+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "064b9631-706c-49d0-84a4-8651d76ca29b", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.203219+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('6203f46f-6140-449b-87ae-a58f5690bb59', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "60.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.237436+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.237437+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.247036+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('571e1b78-63e0-4b94-bfb0-f607728efc93', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "2daeb525-a954-4004-acd1-dd1d1eca96a3", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "20.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.244085+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.244086+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "d9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.247066+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('3379a506-1e74-4a0e-9791-b9b20d6f451d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "aed74404-e412-47b8-b24f-41f54508d717", "name": "Dell Latitude 5540", "brand": "Dell", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "5.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.265711+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.265712+00:00", "category_id": "4c2096c1-1ed7-4745-9d6c-dbeee4337c47", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "b2cb6849-0f1c-4a60-90a6-be0cc53c08ae", "serial_number": null, "purchase_price": "4200.00", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "f6692961-91cb-41c9-a7e0-bf7b39b1cb1b"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.272652+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('8a86d820-c55f-4b71-ac37-55f006379114', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "9702ad84-eaae-4361-bc5f-97d245f5334a", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:20.269955+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.269956+00:00", "category_id": "4c2096c1-1ed7-4745-9d6c-dbeee4337c47", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "0f92a508-261c-403d-bc4f-49b1635180cb", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "f6692961-91cb-41c9-a7e0-bf7b39b1cb1b"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.272688+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('e41741c7-7da2-44f1-b537-ca8d3ddedd2e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "be63bb32-f836-4a97-904e-2362e64fc3bc", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.215166+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "656e5398-3fa1-4738-9447-f448081d8e8c", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "changes": {"quantity": 36.0}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.34805+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('7d4db2b6-a44e-4189-99e9-c37e9cda1a00', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "28.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.215166+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "064b9631-706c-49d0-84a4-8651d76ca29b", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "changes": {"quantity": 28.0}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:20.34818+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('761ef65b-3123-4ecf-96c3-0029ad99332b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "f1b01e73-4b2d-4f5b-a8b2-047403048011", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "18.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.215166+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "cc8ee259-f9ed-483f-8c35-4a06dcee91d2", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "changes": {"quantity": 18.0}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.158787+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('41cee916-cd59-469a-a8b0-2bcd5172cf65', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-13", "created_at": "2026-11-13 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.342683+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "064b9631-706c-49d0-84a4-8651d76ca29b", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93"}, "changes": {"quantity": 24.0}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.159+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('6dfc9c18-6617-470f-947b-c5375abf9287', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'document.completed', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "cc8ee259-f9ed-483f-8c35-4a06dcee91d2", "product_code": null, "done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null, "source_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "target_location_id": null, "source_location_code": "SEED-UDNY", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "064b9631-706c-49d0-84a4-8651d76ca29b", "product_code": null, "done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null, "source_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "target_location_id": null, "source_location_code": "SEED-UDNY", "target_location_code": null}], "document_id": "aaa28144-9b19-429b-9c06-de601c1b317b", "document_type": "OUT", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.159021+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('9fb34a08-1820-477a-88eb-de38eaa55186', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'document.shipped', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "cc8ee259-f9ed-483f-8c35-4a06dcee91d2", "product_code": null, "done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null, "source_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "target_location_id": null, "source_location_code": "SEED-UDNY", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "064b9631-706c-49d0-84a4-8651d76ca29b", "product_code": null, "done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null, "source_location_id": "dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93", "target_location_id": null, "source_location_code": "SEED-UDNY", "target_location_code": null}], "carrier": "InPost", "shipped_at": "2026-11-22T23:36:21.064266+00:00", "document_id": "aaa28144-9b19-429b-9c06-de601c1b317b", "tracking_url": "https://inpost.pl/sledzenie-przesylek?number=620012345678901234567890", "document_type": "OUT", "package_count": 2, "document_number": "OUT/2026/003", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "tracking_number": "620012345678901234567890"}', NULL, '2026-11-22 23:36:21.159048+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('f8744859-c5aa-45d1-b5a8-25ebf4a0e5d0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "50.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-15", "created_at": "2026-11-15 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.249895+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736"}, "changes": {"quantity": 50.0}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.239286+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('f5880eff-667f-492b-9bbf-ffbcd0533333', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "2daeb525-a954-4004-acd1-dd1d1eca96a3", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "15.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-15", "created_at": "2026-11-15 12:15:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:20.249895+00:00", "category_id": "82a6fd2f-98c4-4647-9290-0612400951fb", "description": null, "expiry_date": null, "module_name": null, "template_id": "d9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736"}, "changes": {"quantity": 15.0}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.239322+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('87661055-3893-47ce-9229-56e2f86f7495', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'document.completed', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983", "product_code": null, "done_quantity": 10.0, "expected_quantity": 10.0, "source_po_line_id": null, "source_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736", "target_location_id": null, "source_location_code": "SEED-5KDK", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "d9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9", "product_code": null, "done_quantity": 5.0, "expected_quantity": 5.0, "source_po_line_id": null, "source_location_id": "c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736", "target_location_id": null, "source_location_code": "SEED-5KDK", "target_location_code": null}], "document_id": "aa365cc5-5414-40a4-9ada-86f186c992e3", "document_type": "OUT", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.239362+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('eba1abc0-f996-4eb5-9895-f443afa442af', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "896db80b-0a08-45a1-91fb-4131104794e5", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "8352703e-3fa0-450f-9d3a-031f662471ce", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:21.487207+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:21.487208+00:00", "category_id": "4c2096c1-1ed7-4745-9d6c-dbeee4337c47", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "0f92a508-261c-403d-bc4f-49b1635180cb", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "f6692961-91cb-41c9-a7e0-bf7b39b1cb1b"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.494032+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('e32649af-5ba5-419b-b75d-3425e57281d4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "e2c46401-5df2-417a-abb4-be3a832b6e89", "name": "Damson Plums", "brand": "Green Acre", "lot_id": null, "uom_id": "61cebc75-7127-4699-85e2-7617ae9db641", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "13.600", "image_key": null, "meta_data": null, "added_date": "2026-11-19", "created_at": "2026-11-22 23:36:19.297614+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:21.719498+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "63ade948-60ba-412d-b4b7-1e08c2140c55", "serial_number": null, "purchase_price": "3.40", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c"}, "changes": {"quantity": 13.6}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.724463+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('b1232861-dfe1-4d1d-bc76-83b934fbe638', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "c4a17a40-5316-4b45-81c4-66fc0ab3f63e", "name": "White Sugar", "brand": "Harvest Row", "lot_id": null, "uom_id": "61cebc75-7127-4699-85e2-7617ae9db641", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "21.220", "image_key": null, "meta_data": null, "added_date": "2026-11-02", "created_at": "2026-11-22 23:36:19.297617+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:21.747214+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "5daaf10b-f21e-42cf-8250-9a58f4513d87", "serial_number": null, "purchase_price": "1.10", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "211e5889-8bcb-43e8-98ef-685b7582bef3"}, "changes": {"quantity": 21.22}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.749031+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('dd84e08b-4e33-4f29-8512-fe13f65384e2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.updated', '{"item": {"id": "2fb18879-a1da-4481-b850-1ce35d12cfbf", "name": "Cassia Cinnamon", "brand": "Saltmill", "lot_id": null, "uom_id": "61cebc75-7127-4699-85e2-7617ae9db641", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "0.440", "image_key": null, "meta_data": null, "added_date": "2026-10-19", "created_at": "2026-11-22 23:36:19.297618+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:21.765213+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "7122be79-8284-4962-88fb-8b6b4fee6560", "serial_number": null, "purchase_price": "24.00", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "211e5889-8bcb-43e8-98ef-685b7582bef3"}, "changes": {"quantity": 0.44}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.767197+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('11757c5a-d515-48ef-b907-22c6f9d1ecac', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'item.created', '{"item": {"id": "9b453772-d40a-4c8c-8e44-f10839058cf5", "name": "Plum Butter", "brand": null, "lot_id": "428858fb-8cdd-4c0e-920a-46b2c0372c9a", "uom_id": "61cebc75-7127-4699-85e2-7617ae9db641", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "11.400", "image_key": null, "meta_data": {}, "added_date": "2026-11-22", "created_at": "2026-11-22 23:36:21.792211+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-22 23:36:21.792212+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "a3446456-f5c3-4936-b45d-828b010a472e", "serial_number": null, "purchase_price": "8.36", "shelf_location": null, "deletion_reason": null, "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "211e5889-8bcb-43e8-98ef-685b7582bef3"}, "user_id": "29df2390-1a60-43fd-ba97-7824689adfc1", "organization_id": "7e14c7c3-6333-4270-93ad-2bc976a705d7"}', NULL, '2026-11-22 23:36:21.795976+00', NULL, 0);


--
-- Data for Name: example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ingredient_nutrition_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_periods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('fe674f00-0c9c-4261-9937-7195a551f57b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e2c46401-5df2-417a-abb4-be3a832b6e89', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGED', '{"old": "40.000", "new": "13.600", "reason": "production_run", "production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-22 23:36:21.721445+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('03f31d2b-b845-4665-9bda-19320f934ddb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c4a17a40-5316-4b45-81c4-66fc0ab3f63e', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGED', '{"old": "25.000", "new": "21.220", "reason": "production_run", "production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-22 23:36:21.747866+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('cdd5624c-b9bd-456c-9123-f47e6f9c7eea', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2fb18879-a1da-4481-b850-1ce35d12cfbf', '29df2390-1a60-43fd-ba97-7824689adfc1', 'QUANTITY_CHANGED', '{"old": "0.500", "new": "0.440", "reason": "production_run", "production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-22 23:36:21.765923+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('2204ea71-c012-4592-a3f3-eaad9137aea7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9b453772-d40a-4c8c-8e44-f10839058cf5', '29df2390-1a60-43fd-ba97-7824689adfc1', 'CREATED', '{"created": true, "reason": "production_run", "production_order_id": "10c3cc2d-91a2-4dd3-8364-b8a9498dee94"}', NULL, '2026-11-22 23:36:21.795241+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('471a3018-c922-4d4b-aee3-91d3ebb4284a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '896db80b-0a08-45a1-91fb-4131104794e5', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/004", "from_template": "0f92a508-261c-403d-bc4f-49b1635180cb"}', '736fda6f-bded-4a88-a8a1-57d1bf09f776', '2026-11-22 23:36:21.492396+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('83665ffc-9a45-4035-acd5-d29938db1ed7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'be63bb32-f836-4a97-904e-2362e64fc3bc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "656e5398-3fa1-4738-9447-f448081d8e8c"}', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', '2026-11-22 23:36:20.199033+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1b24c3e3-8bfc-4931-93a4-1044c438dccc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f1b01e73-4b2d-4f5b-a8b2-047403048011', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "cc8ee259-f9ed-483f-8c35-4a06dcee91d2"}', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', '2026-11-22 23:36:20.199037+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('9512f2ff-f424-4d47-913d-9589bd38378a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "064b9631-706c-49d0-84a4-8651d76ca29b"}', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', '2026-11-22 23:36:20.199038+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d7b0fb04-0e91-4d4a-8cc2-6714f3da2747', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983"}', 'a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', '2026-11-22 23:36:20.246304+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d17b5753-99ab-4b4d-9641-8d162cdf5fa1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2daeb525-a954-4004-acd1-dd1d1eca96a3', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "d9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9"}', 'a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', '2026-11-22 23:36:20.246306+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('2b53e6df-4db2-467d-9594-e4ffb06b22d6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'be63bb32-f836-4a97-904e-2362e64fc3bc', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'QUANTITY_CHANGED', '{"old": "48.000", "new": "36.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', 'fb6b2610-e5da-4418-ae07-eeff4c6a586a', '2026-11-22 23:36:20.346681+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('73db3f7b-bccb-4f95-9308-9e0f9dc09eee', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'QUANTITY_CHANGED', '{"old": "36.000", "new": "28.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', 'fb6b2610-e5da-4418-ae07-eeff4c6a586a', '2026-11-22 23:36:20.346683+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('64932667-dabd-4310-9f28-9efed6dded04', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'aed74404-e412-47b8-b24f-41f54508d717', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "b2cb6849-0f1c-4a60-90a6-be0cc53c08ae"}', '7550cc0c-a8ed-4b64-a7db-21d697c2e761', '2026-11-22 23:36:20.271863+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('0ed9575f-8425-4abc-aae3-224edff782b6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9702ad84-eaae-4361-bc5f-97d245f5334a', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "0f92a508-261c-403d-bc4f-49b1635180cb"}', '7550cc0c-a8ed-4b64-a7db-21d697c2e761', '2026-11-22 23:36:20.271864+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1127988a-0b41-4ca7-99d9-b364f19b6f21', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f1b01e73-4b2d-4f5b-a8b2-047403048011', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'QUANTITY_CHANGED', '{"old": "24.000", "new": "18.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'aaa28144-9b19-429b-9c06-de601c1b317b', '2026-11-22 23:36:21.155495+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('35e37173-1f3d-4cf6-bee7-eb58a7c22a98', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'QUANTITY_CHANGED', '{"old": "28.000", "new": "24.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'aaa28144-9b19-429b-9c06-de601c1b317b', '2026-11-22 23:36:21.155498+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('6c6a0d9c-3432-4e66-a71d-a7bbdfff714f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'QUANTITY_CHANGED', '{"old": "60.000", "new": "50.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', 'aa365cc5-5414-40a4-9ada-86f186c992e3', '2026-11-22 23:36:21.237701+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1d4406b0-a295-433d-a0bf-d96eda035e76', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2daeb525-a954-4004-acd1-dd1d1eca96a3', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'QUANTITY_CHANGED', '{"old": "20.000", "new": "15.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', 'aa365cc5-5414-40a4-9ada-86f186c992e3', '2026-11-22 23:36:21.237703+00');


--
-- Data for Name: item_import_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d8fb73c3-b015-4009-bc62-24a62f056e22', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7559c4d7-ce55-4d0a-bbc5-887c559e336d', '1b336e37-67db-4641-b316-b48448cce33e', NULL, 'Coffee Beans', 'Orchard & Oak', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '223c46ae-fe53-4540-a3f4-ab350c9a4fac', 3.000, NULL, NULL, '2026-11-15', '2027-06-01', NULL, NULL, NULL, 4.54, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190943+00', '2026-11-22 23:36:19.190945+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bea2c179-6db0-4291-806c-bc35114d13f3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7a9e185d-1e23-4368-85cd-b555da7b10ea', '601797f1-b499-483a-b6eb-1b59f4872884', NULL, 'Eggs Medium 10pk', 'Fellbrook Farms', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 3.000, NULL, NULL, '2026-11-20', '2027-02-27', NULL, NULL, NULL, 5.40, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190946+00', '2026-11-22 23:36:19.190946+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('190c51fc-564e-4267-bd7b-35d61962641d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7a9e185d-1e23-4368-85cd-b555da7b10ea', 'd6065e41-c5dd-45fa-af1c-583d4104219b', NULL, 'Smoked Bacon', 'Fellbrook Farms', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '972d00df-0e6c-4f20-a77f-ebb4515d1e61', 8.700, NULL, NULL, '2026-11-19', '2026-11-28', NULL, NULL, NULL, 4.43, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190947+00', '2026-11-22 23:36:19.190947+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ece4ff71-bfb4-4115-851e-f04248892ec6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a2cc3792-a342-48e5-bcac-39af703f7b18', 'cab4139b-9813-429f-ab37-4f50d3d05913', NULL, 'Orange Juice NFC', 'Orchard & Oak', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'fd3f7025-38be-4c94-9805-708ad6525e50', 8.000, NULL, NULL, '2026-10-13', NULL, NULL, NULL, NULL, 4.75, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190948+00', '2026-11-22 23:36:19.190948+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('de6175f2-8756-41e7-929c-556fe2d386af', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 'a5e843db-1701-4f66-9bb3-c63f484a01bf', NULL, 'Cucumber', 'Green Acre', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7b1c4b4c-8fb3-4451-bc39-77be69e7915e', 4.000, NULL, NULL, '2026-11-17', '2026-11-29', NULL, NULL, NULL, 5.31, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190948+00', '2026-11-22 23:36:19.190949+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6bbc672b-9ca7-41a0-a783-10563e2e77c9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '211e5889-8bcb-43e8-98ef-685b7582bef3', 'a3f8624a-d9ca-4790-a543-b38b34417af5', NULL, 'Baking Powder', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9fbcd4fb-3632-4189-a80a-26d869595602', 6.000, NULL, NULL, '2026-09-21', '2027-07-05', NULL, NULL, NULL, 5.39, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190949+00', '2026-11-22 23:36:19.19095+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d3f0be28-e352-4d10-8636-20381bddbed8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 'feac2ad5-d3d5-47c1-81b8-925ab0fcc204', NULL, 'White Sugar 1kg', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', 8.000, NULL, NULL, '2026-11-13', '2027-08-12', NULL, NULL, NULL, 4.87, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.19095+00', '2026-11-22 23:36:19.19095+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bb11d545-60d7-4a71-a928-f1d79f999111', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 'ab59039b-a87f-4434-8ac2-630d8f5f7c60', NULL, 'Smoked Sausage', 'Fellbrook Farms', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'bb6529e1-926f-41cd-9b74-c94a03b55f56', 9.000, NULL, NULL, '2026-11-20', '2026-11-23', NULL, NULL, NULL, 5.28, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190951+00', '2026-11-22 23:36:19.190951+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e2da4caf-508b-4090-af9e-283011741965', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd67495d7-2c6d-48b0-b476-132f66241a6d', '47d0168a-6684-4ae8-b1ac-8ccc7f2d9011', NULL, 'Frozen Mixed Vegetables', 'Northwind Frozen', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 'e9791bc9-10f8-49cd-8348-9dda0122063e', 8.000, NULL, NULL, '2026-10-22', NULL, NULL, NULL, NULL, 4.91, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190951+00', '2026-11-22 23:36:19.190952+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3166b19b-c03e-458c-9a99-8d25970cb09f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1b2c39b0-cc65-4b34-a95f-fd944492712f', '98031881-b194-443b-958e-09ee94d4565f', NULL, 'Tomato Ketchup', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0c08476d-f8db-4d18-ac72-a46784985a7d', 6.000, NULL, NULL, '2026-11-18', '2026-11-22', NULL, NULL, NULL, 5.15, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190952+00', '2026-11-22 23:36:19.190952+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ea626c2e-a38e-4682-acea-591ab92e8830', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7559c4d7-ce55-4d0a-bbc5-887c559e336d', 'b7acaa85-4afc-4790-a70c-93180a16e4ca', NULL, 'Ground Ginger', 'Saltmill', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '1a77aa58-6966-427d-8d61-7dd1b4979dd3', 6.000, NULL, NULL, '2026-09-30', NULL, NULL, NULL, NULL, 4.91, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190953+00', '2026-11-22 23:36:19.190953+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('102ea193-adec-420f-9127-008aa46be2f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7c37dfca-c298-4205-87e3-c530c5e88990', 'b7acaa85-4afc-4790-a70c-93180a16e4ca', NULL, 'Dried Oregano', 'Saltmill', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'dbf12d9e-0cfc-4c10-9844-2c06f6c6697f', 2.000, NULL, NULL, '2026-09-19', '2027-07-18', NULL, NULL, NULL, 4.71, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190953+00', '2026-11-22 23:36:19.190954+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('792f9dfc-6e47-499a-87cc-35b05f48751e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '601797f1-b499-483a-b6eb-1b59f4872884', NULL, 'Eggs Medium 10pk', 'Fellbrook Farms', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 7.000, NULL, NULL, '2026-11-17', '2026-11-20', NULL, NULL, NULL, 5.48, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190954+00', '2026-11-22 23:36:19.190954+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1fbb6f2b-49f0-4330-a2ab-895d57ddd9dd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd67495d7-2c6d-48b0-b476-132f66241a6d', '47d0168a-6684-4ae8-b1ac-8ccc7f2d9011', NULL, 'Frozen Chips', 'Northwind Frozen', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', 1.000, NULL, NULL, '2026-10-31', '2027-12-10', NULL, NULL, NULL, 5.21, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190955+00', '2026-11-22 23:36:19.190955+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('563f0a62-91b4-4d86-a892-3039cb0e16c5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ab326239-0c31-4f35-8522-9c914c8be9c3', '97dc7519-79ec-4cf1-b76b-c315607db925', NULL, 'Almonds', 'Green Acre', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', '027755f4-0294-42a1-a43c-d5830beaa781', 4.000, NULL, NULL, '2026-10-20', '2027-06-04', NULL, NULL, NULL, 5.61, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190955+00', '2026-11-22 23:36:19.190956+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0db6b645-8f7c-4c1a-a56b-1c880d8ce6c7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1b2c39b0-cc65-4b34-a95f-fd944492712f', 'd6065e41-c5dd-45fa-af1c-583d4104219b', NULL, 'Minced Pork', 'Fellbrook Farms', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '150c1f18-1619-4b71-9c0c-d4adfacf209a', 6.500, NULL, NULL, '2026-11-18', '2027-11-14', NULL, NULL, NULL, 4.27, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190956+00', '2026-11-22 23:36:19.190956+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('eec97a89-1f44-42f6-8979-ae71db73da10', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7c37dfca-c298-4205-87e3-c530c5e88990', '99e2f510-d62e-4534-8108-d0300b54e3d5', NULL, 'Peeled Tomatoes 400g', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ab1b9846-c8e7-45c6-b695-e655763069ab', 4.000, NULL, NULL, '2026-09-28', '2027-09-25', NULL, NULL, NULL, 5.18, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190957+00', '2026-11-22 23:36:19.190957+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5b69085c-5ded-49f7-9885-0dffd7bc1775', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 'a3f8624a-d9ca-4790-a543-b38b34417af5', NULL, 'Instant Tomato Soup', 'Harvest Row', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', '6b61f4b6-f554-4610-931d-26a0886d231a', 1.000, NULL, NULL, '2026-09-17', NULL, NULL, NULL, NULL, 4.88, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190958+00', '2026-11-22 23:36:19.190958+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2ecd3e2d-1e3a-436e-b4ee-990a46691f4c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7c37dfca-c298-4205-87e3-c530c5e88990', 'a3f8624a-d9ca-4790-a543-b38b34417af5', NULL, 'Fruit Muesli', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '95d6a10f-937b-4b74-a0d4-a012126d9f52', 8.000, NULL, NULL, '2026-11-09', '2027-01-20', NULL, NULL, NULL, 5.06, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190958+00', '2026-11-22 23:36:19.190958+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5c192ec6-c0c4-4c8f-8741-1086eff18172', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc348dec-fee9-4f38-8959-8a0c1f02f466', 'a97391ec-ba34-4907-88f5-d03a5aa6ba75', NULL, 'Buckwheat Groats', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ff1d121d-4fb2-458c-b16d-08824802ade1', 6.000, NULL, NULL, '2026-10-29', '2027-05-04', NULL, NULL, NULL, 4.28, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190959+00', '2026-11-22 23:36:19.190959+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('68dcee58-627d-465f-b316-5f4773b151a8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', 'a5e843db-1701-4f66-9bb3-c63f484a01bf', NULL, 'Carrots 1kg', 'Green Acre', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '8742e916-2785-4512-ab27-fed4ded3c473', 8.600, NULL, NULL, '2026-11-19', '2026-11-27', NULL, NULL, NULL, 5.74, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.19096+00', '2026-11-22 23:36:19.19096+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f6b37e96-2a10-4bd5-a4d4-427e1d3345aa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '96bede93-9802-49a9-952b-075e2301156b', '69a9317c-d464-454f-b021-8d8c163ceba5', NULL, 'Fish Fingers', 'Bluewater', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 'd94e5659-0dfc-4e0b-bf49-0340f296bdf5', 3.000, NULL, NULL, '2026-10-07', '2027-04-02', NULL, NULL, NULL, 4.46, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.19096+00', '2026-11-22 23:36:19.19096+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('24a72a3f-54f8-42ab-88d2-522ddcab4f23', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7a9e185d-1e23-4368-85cd-b555da7b10ea', '98031881-b194-443b-958e-09ee94d4565f', NULL, 'Classic Hummus', 'Green Acre', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'a738adfd-0757-4836-a4b9-70ef1261378f', 3.000, NULL, NULL, '2026-11-17', NULL, NULL, NULL, NULL, 5.13, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190961+00', '2026-11-22 23:36:19.190961+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a846641d-de55-4cc7-8e0e-c1a5b478f3ed', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '211e5889-8bcb-43e8-98ef-685b7582bef3', 'b7acaa85-4afc-4790-a70c-93180a16e4ca', NULL, 'Iodised Salt', 'Saltmill', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'b9014711-5ce7-4aac-8f11-e4748fff949a', 5.000, NULL, NULL, '2026-09-15', NULL, NULL, NULL, NULL, 4.54, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190961+00', '2026-11-22 23:36:19.190962+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6482dc7b-dfe7-4dd3-a1ce-f1b795c5d5fc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'Butter Extra 82%', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '064b9631-706c-49d0-84a4-8651d76ca29b', 4.000, NULL, NULL, '2026-11-21', '2026-11-24', NULL, NULL, NULL, 5.56, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190962+00', '2026-11-22 23:36:19.190962+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('286c29bc-b6ba-4cca-a2c8-c2e3affd8a5a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 'b8e3e596-8b7f-4375-b48c-0987683fb759', NULL, 'Extra Virgin Olive Oil', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', 4.000, NULL, NULL, '2026-10-27', '2027-01-13', NULL, NULL, NULL, 5.45, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190963+00', '2026-11-22 23:36:19.190963+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7b438470-a58f-4023-a6c8-3938366f5aa3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '96bede93-9802-49a9-952b-075e2301156b', 'b49bf2e2-a7ff-4886-aa6d-cbd02d511738', NULL, 'Vanilla Ice Cream', 'Northwind Frozen', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '52559aed-459d-4b60-bdfb-9e8a712c46a7', 6.000, NULL, NULL, '2026-10-16', '2027-12-04', NULL, NULL, NULL, 5.58, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190963+00', '2026-11-22 23:36:19.190963+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('66148578-ba24-4740-8a15-16360820f864', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'Lean Quark', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'fbc113bb-6608-448b-a260-ed9dd4b124d6', 6.000, NULL, NULL, '2026-11-18', '2027-04-05', NULL, NULL, NULL, 4.73, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190964+00', '2026-11-22 23:36:19.190964+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6ebc1945-8360-4fd0-a9a8-947b72196e06', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7c37dfca-c298-4205-87e3-c530c5e88990', 'a97391ec-ba34-4907-88f5-d03a5aa6ba75', NULL, 'Jasmine Rice 1kg', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '595520ae-5062-47f9-9e47-27082e7bc22f', 7.000, NULL, NULL, '2026-09-24', '2027-06-09', NULL, NULL, NULL, 4.33, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190964+00', '2026-11-22 23:36:19.190965+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8a2930ee-6d6b-4cd1-9a69-f263f7d8c5ea', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '96bede93-9802-49a9-952b-075e2301156b', '47d0168a-6684-4ae8-b1ac-8ccc7f2d9011', NULL, 'Frozen Chips', 'Northwind Frozen', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', 7.000, NULL, NULL, '2026-09-13', '2027-10-08', NULL, NULL, NULL, 4.48, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190965+00', '2026-11-22 23:36:19.190965+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('19b31fde-260b-4693-a53e-9316a0519cd1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a2cc3792-a342-48e5-bcac-39af703f7b18', 'cab4139b-9813-429f-ab37-4f50d3d05913', NULL, 'Orange Juice NFC', 'Orchard & Oak', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'fd3f7025-38be-4c94-9805-708ad6525e50', 3.000, NULL, NULL, '2026-11-05', NULL, NULL, NULL, NULL, 5.04, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190966+00', '2026-11-22 23:36:19.190966+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c1c6a81c-c257-4764-8fa7-dcfae764192d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ab326239-0c31-4f35-8522-9c914c8be9c3', 'a3f8624a-d9ca-4790-a543-b38b34417af5', NULL, 'Rolled Oats', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', 7.000, NULL, NULL, '2026-10-25', '2026-12-30', NULL, NULL, NULL, 5.01, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190966+00', '2026-11-22 23:36:19.190966+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2b4cd597-e3f3-49df-b2d1-cb0f01656380', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 'b8e3e596-8b7f-4375-b48c-0987683fb759', NULL, 'Soy Sauce', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '45cccb60-d659-4421-a067-32c271cbf33f', 9.000, NULL, NULL, '2026-10-14', NULL, NULL, NULL, NULL, 4.53, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190967+00', '2026-11-22 23:36:19.190967+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d5930c45-5bdf-4e88-bf66-5066b17c9c68', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'Sour Cream 18%', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 2.000, NULL, NULL, '2026-11-18', '2026-11-21', NULL, NULL, NULL, 4.62, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190967+00', '2026-11-22 23:36:19.190968+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d07c436e-5e3f-4ab4-8d74-093c60827258', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7c37dfca-c298-4205-87e3-c530c5e88990', 'b8e3e596-8b7f-4375-b48c-0987683fb759', NULL, 'Sunflower Oil', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '72d583c2-ff3d-4f7f-ae15-5333b3840dd0', 4.000, NULL, NULL, '2026-09-22', '2027-09-13', NULL, NULL, NULL, 4.71, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190968+00', '2026-11-22 23:36:19.190968+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dcde5eed-3d7a-4888-bb7e-fa52727b44fb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc348dec-fee9-4f38-8959-8a0c1f02f466', 'a3f8624a-d9ca-4790-a543-b38b34417af5', NULL, 'Chicken Stock', 'Harvest Row', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0052c85e-7ae7-42ac-8a15-9a144ea74f59', 4.000, NULL, NULL, '2026-11-14', '2027-04-12', NULL, NULL, NULL, 5.17, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190968+00', '2026-11-22 23:36:19.190969+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4322b97c-2c3d-4660-816a-454ef08d2b2a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '96bede93-9802-49a9-952b-075e2301156b', '69a9317c-d464-454f-b021-8d8c163ceba5', NULL, 'Potato and Cheese Dumplings', 'Northwind Frozen', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', '319dc161-97d4-4a04-9b3d-cc64d9d704dd', 1.000, NULL, NULL, '2026-11-03', '2028-03-14', NULL, NULL, NULL, 5.37, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190969+00', '2026-11-22 23:36:19.190969+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7f615c96-b060-45a0-950c-4296609c6da8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'UHT Milk 3.2%', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '656e5398-3fa1-4738-9447-f448081d8e8c', 8.000, NULL, NULL, '2026-11-20', '2026-11-25', NULL, NULL, NULL, 5.28, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.19097+00', '2026-11-22 23:36:19.19097+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1d751a2d-9cb7-40cd-8dc2-f6ceffb85a02', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', 'a5e843db-1701-4f66-9bb3-c63f484a01bf', NULL, 'Cherry Tomatoes', 'Green Acre', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '6d36f2b9-47c7-4589-905f-b904d79bb551', 5.100, NULL, NULL, '2026-11-19', '2026-11-22', NULL, NULL, NULL, 5.59, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.19097+00', '2026-11-22 23:36:19.19097+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ab788a52-bc7f-4c72-96e8-35a7f773f70f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '10531d7e-5698-48f2-9736-aa564c29ae47', NULL, 'Chicken Breast Fillet', 'Fellbrook Farms', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 'adb37118-6006-4d99-8159-7f92dfcd47da', 6.900, NULL, NULL, '2026-11-18', '2026-11-26', NULL, NULL, NULL, 5.23, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.190971+00', '2026-11-22 23:36:19.190971+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d0ef78b2-af29-4986-befb-6351a07b37f4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 1.000, NULL, 'SN-100000', '2026-10-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-10-08", "warranty_until": "2029-10-07", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-08 09:00:00+00', '2026-11-22 23:36:19.261287+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fa523563-d630-4bd0-a349-2e92cd782335', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 1.000, NULL, 'SN-100002', '2026-03-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-28", "warranty_until": "2029-03-27", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-28 09:00:00+00', '2026-11-22 23:36:19.261291+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f7d18700-e595-4e25-a49c-e2f61cbddc7c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 1.000, NULL, 'SN-100003', '2025-12-21', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-21", "warranty_until": "2028-12-20", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-21 09:00:00+00', '2026-11-22 23:36:19.261292+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e53deba0-c735-492d-83d1-17fc96cddd06', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0f92a508-261c-403d-bc4f-49b1635180cb', 1.000, NULL, 'SN-100004', '2025-09-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-15", "warranty_until": "2028-09-14", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-15 09:00:00+00', '2026-11-22 23:36:19.261292+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4a9b8e1a-282e-4925-828f-3a112f378675', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '755ea5f1-9325-4c48-acc5-91fe380b59f1', 1.000, NULL, 'SN-100008', '2024-08-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-23", "warranty_until": "2027-08-23", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-23 09:00:00+00', '2026-11-22 23:36:19.261294+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('991acbdc-364e-44e2-a493-a92927745ce9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', 1.000, NULL, 'SN-100009', '2024-05-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-18", "warranty_until": "2027-05-18", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-18 09:00:00+00', '2026-11-22 23:36:19.261294+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('86a27834-c1e0-4c6a-a058-5232b6c74377', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', 1.000, NULL, 'SN-100010', '2024-02-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-11", "warranty_until": "2027-02-10", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-11 09:00:00+00', '2026-11-22 23:36:19.261294+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f00dfad4-8c93-445d-b6fd-824a85d758db', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9629cb34-f877-4616-bb58-c4b2e274aab0', 1.000, NULL, 'SN-100011', '2023-11-06', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-06", "warranty_until": "2026-11-05", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-06 09:00:00+00', '2026-11-22 23:36:19.261295+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a76ed544-f628-405d-bf60-cef88ddf40f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9629cb34-f877-4616-bb58-c4b2e274aab0', 1.000, NULL, 'SN-100012', '2026-08-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-05", "warranty_until": "2029-08-04", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-05 09:00:00+00', '2026-11-22 23:36:19.261295+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('37283bb7-2e86-4ddb-ab6c-bffc0321f59b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9629cb34-f877-4616-bb58-c4b2e274aab0', 1.000, NULL, 'SN-100013', '2026-04-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-30", "warranty_until": "2029-04-29", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-30 09:00:00+00', '2026-11-22 23:36:19.261295+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('200bfdce-8216-4fba-8059-1c6b629f7f31', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9629cb34-f877-4616-bb58-c4b2e274aab0', 1.000, NULL, 'SN-100014', '2026-01-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-23", "warranty_until": "2029-01-22", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-23 09:00:00+00', '2026-11-22 23:36:19.261296+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3b95fa2f-965c-4eac-a3fd-8b0adf3c567d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', 1.000, NULL, 'SN-100016', '2025-07-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-13", "warranty_until": "2028-07-12", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-13 09:00:00+00', '2026-11-22 23:36:19.261297+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d7876098-9fde-4eee-914b-d96f8bdd1dd0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', 1.000, NULL, 'SN-100017', '2025-04-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-07", "warranty_until": "2028-04-06", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-07 09:00:00+00', '2026-11-22 23:36:19.261297+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7aea95cb-44c2-4464-836a-a702c567ead0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 1.000, NULL, 'SN-100018', '2024-12-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-31", "warranty_until": "2027-12-31", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-31 09:00:00+00', '2026-11-22 23:36:19.261297+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('05309808-84b6-41bd-af7a-add0a4f5f78c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 1.000, NULL, 'SN-100019', '2024-09-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-25", "warranty_until": "2027-09-25", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-25 09:00:00+00', '2026-11-22 23:36:19.261298+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b17bb4ee-d7de-462a-b1ee-a43ecef00e3c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 1.000, NULL, 'SN-100020', '2024-06-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-20", "warranty_until": "2027-06-20", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-20 09:00:00+00', '2026-11-22 23:36:19.261298+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8fbe90bd-e456-4306-b470-8f1857c34d27', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 1.000, NULL, 'SN-100021', '2024-03-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-15", "warranty_until": "2027-03-15", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-15 09:00:00+00', '2026-11-22 23:36:19.261299+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('32543762-ef9b-42b6-a7e1-5ed3b1d52cb1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95c56c34-8315-438d-b2c2-100085ecf05d', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 1.000, NULL, 'SN-100022', '2023-12-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-09", "warranty_until": "2026-12-08", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-09 09:00:00+00', '2026-11-22 23:36:19.261299+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('14dc5966-6f84-498e-858c-c735b43e8fc7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '081774cc-67fb-4828-bd38-fee5db5e3dbd', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '9629cb34-f877-4616-bb58-c4b2e274aab0', 1.000, NULL, 'SN-100015', '2025-10-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-18", "warranty_until": "2028-10-17", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-18 09:00:00+00', '2026-11-22 23:36:22.326045+00', 'STM-33EK', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ad29c485-561f-4eee-b493-983c11aca6f2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 1.000, NULL, 'SN-100001', '2026-07-03', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-03", "warranty_until": "2029-07-02", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-03 09:00:00+00', '2026-11-22 23:36:22.326048+00', 'STM-CCG8', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a5d5311e-1f75-4563-a6cd-a3303dd91bcb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '14cfd548-8a19-406f-be8f-d1d4b012ee08', 1.000, NULL, 'SN-100023', '2026-09-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-07", "warranty_until": "2029-09-06", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-07 09:00:00+00', '2026-11-22 23:36:19.261299+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('eb8bb386-b3ab-4c28-a894-07f570795ae6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '14cfd548-8a19-406f-be8f-d1d4b012ee08', 1.000, NULL, 'SN-100024', '2026-06-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-02", "warranty_until": "2029-06-01", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-02 09:00:00+00', '2026-11-22 23:36:19.2613+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1b7a00db-d64b-4ba6-bee8-88826bd057bf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'LG 27UK850-W', 'LG', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '60a2899b-6903-44e0-a9a8-63b299378728', 1.000, NULL, 'SN-100025', '2026-02-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-25", "warranty_until": "2029-02-24", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-25 09:00:00+00', '2026-11-22 23:36:19.2613+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('503df92b-bc7d-44ec-b503-1a6a70a328e3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'LG 27UK850-W', 'LG', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '60a2899b-6903-44e0-a9a8-63b299378728', 1.000, NULL, 'SN-100026', '2025-11-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-20", "warranty_until": "2028-11-19", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-20 09:00:00+00', '2026-11-22 23:36:19.261301+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('324478f4-a2c0-4a16-b942-9bb64fdb2aeb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'LG 27UK850-W', 'LG', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '60a2899b-6903-44e0-a9a8-63b299378728', 1.000, NULL, 'SN-100027', '2025-08-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-15", "warranty_until": "2028-08-14", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-15 09:00:00+00', '2026-11-22 23:36:19.261301+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('04e09bd7-1930-470c-8e59-42fdc778dd79', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '608eba71-431c-44b2-965e-4abc27a6ab8a', 1.000, NULL, 'SN-100028', '2025-05-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-10", "warranty_until": "2028-05-09", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-10 09:00:00+00', '2026-11-22 23:36:19.261301+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fc3ac3bd-940a-4516-81b1-688e8a5ff68e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 'e488fd36-fae0-432e-a1db-07c705993252', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '608eba71-431c-44b2-965e-4abc27a6ab8a', 1.000, NULL, 'SN-100029', '2025-02-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-02", "warranty_until": "2028-02-02", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-02 09:00:00+00', '2026-11-22 23:36:19.261302+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a7608b17-cfef-4a49-ac74-e7ad660645a4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2e90cfb5-e0da-41db-857a-cec9986f9225', 1.000, NULL, 'SN-100030', '2024-10-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-28", "warranty_until": "2027-10-28", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-28 09:00:00+00', '2026-11-22 23:36:19.261302+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0bd26c7a-03b0-4fae-b0ca-120cd4a9d427', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2e90cfb5-e0da-41db-857a-cec9986f9225', 1.000, NULL, 'SN-100031', '2024-07-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-23", "warranty_until": "2027-07-23", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-23 09:00:00+00', '2026-11-22 23:36:19.261302+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f812827a-692f-4306-ae0b-2ef7ea7dcbba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2e90cfb5-e0da-41db-857a-cec9986f9225', 1.000, NULL, 'SN-100032', '2024-04-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-17", "warranty_until": "2027-04-17", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-17 09:00:00+00', '2026-11-22 23:36:19.261303+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('20d31129-5635-4d1e-a235-69f723c3abe9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2e90cfb5-e0da-41db-857a-cec9986f9225', 1.000, NULL, 'SN-100033', '2024-01-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-11", "warranty_until": "2027-01-10", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-11 09:00:00+00', '2026-11-22 23:36:19.261303+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f4606069-39ec-4084-ac9d-a83283363d9a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '22852bd0-d709-4bc5-b15d-cedb5ab70059', 1.000, NULL, 'SN-100035', '2026-07-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-05", "warranty_until": "2029-07-04", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-05 09:00:00+00', '2026-11-22 23:36:19.261304+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('02b3afbb-8de3-4f8e-a200-240a79e92dc0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '22852bd0-d709-4bc5-b15d-cedb5ab70059', 1.000, NULL, 'SN-100036', '2026-03-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-30", "warranty_until": "2029-03-29", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-30 09:00:00+00', '2026-11-22 23:36:19.261304+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8b71e9dc-8cd0-4183-a116-9c19c46cab50', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '22852bd0-d709-4bc5-b15d-cedb5ab70059', 1.000, NULL, 'SN-100037', '2025-12-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-23", "warranty_until": "2028-12-22", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-23 09:00:00+00', '2026-11-22 23:36:19.261304+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2e882229-44b7-4d98-b1e5-a117c8d570b8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '22852bd0-d709-4bc5-b15d-cedb5ab70059', 1.000, NULL, 'SN-100038', '2025-09-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-17", "warranty_until": "2028-09-16", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-17 09:00:00+00', '2026-11-22 23:36:19.261305+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3b5a5fb1-02e2-4451-96c3-20574113f40c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '22852bd0-d709-4bc5-b15d-cedb5ab70059', 1.000, NULL, 'SN-100039', '2025-06-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-12", "warranty_until": "2028-06-11", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-12 09:00:00+00', '2026-11-22 23:36:19.261305+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d8f2ea80-a15f-4e14-b62c-7dc8406f42ad', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95c56c34-8315-438d-b2c2-100085ecf05d', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPad Air M2', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '507ace22-1183-4c8d-9c04-fa8cd6e19021', 1.000, NULL, 'SN-100040', '2025-03-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-07", "warranty_until": "2028-03-06", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-07 09:00:00+00', '2026-11-22 23:36:19.261306+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7ae279d7-b988-49a3-b3b4-c5721aadfdfc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPad Air M2', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '507ace22-1183-4c8d-9c04-fa8cd6e19021', 1.000, NULL, 'SN-100041', '2024-11-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-30", "warranty_until": "2027-11-30", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-30 09:00:00+00', '2026-11-22 23:36:19.261306+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3dfdea05-63b1-45fe-8865-9fbd11c00b91', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', 1.000, NULL, 'SN-100042', '2024-08-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-25", "warranty_until": "2027-08-25", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-25 09:00:00+00', '2026-11-22 23:36:19.261306+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a877e0c6-d6a5-4993-a39d-239e009e8b02', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', 1.000, NULL, 'SN-100043', '2024-05-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-20", "warranty_until": "2027-05-20", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-20 09:00:00+00', '2026-11-22 23:36:19.261307+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('180acd4a-9080-44f7-919a-c5b8e11b2235', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', 1.000, NULL, 'SN-100044', '2024-02-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-13", "warranty_until": "2027-02-12", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-13 09:00:00+00', '2026-11-22 23:36:19.261307+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b1990095-7f96-41ec-b357-aa4099c905ff', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', 1.000, NULL, 'SN-100046', '2026-08-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-07", "warranty_until": "2029-08-06", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-07 09:00:00+00', '2026-11-22 23:36:19.261308+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('83b93317-0fb5-48cc-9785-141bed9e4ade', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', 1.000, NULL, 'SN-100047', '2026-05-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-02", "warranty_until": "2029-05-01", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-02 09:00:00+00', '2026-11-22 23:36:19.261308+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9fcfd97e-9033-49f7-8337-96fd992fed6c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', 1.000, NULL, 'SN-100048', '2026-01-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-25", "warranty_until": "2029-01-24", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-25 09:00:00+00', '2026-11-22 23:36:19.261308+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5cf11707-4a3c-4dc3-af33-56506e767e5e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', 1.000, NULL, 'SN-100049', '2025-10-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-20", "warranty_until": "2028-10-19", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-20 09:00:00+00', '2026-11-22 23:36:19.261309+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d3820d60-028b-4d43-ba93-83be24c63573', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95c56c34-8315-438d-b2c2-100085ecf05d', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', 1.000, NULL, 'SN-100050', '2025-07-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-15", "warranty_until": "2028-07-14", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-15 09:00:00+00', '2026-11-22 23:36:19.261309+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('33bbe77b-9f04-4f92-8498-e141d0355175', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', 1.000, NULL, 'SN-100051', '2025-04-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-09", "warranty_until": "2028-04-08", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-09 09:00:00+00', '2026-11-22 23:36:19.261309+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ff6ed9dd-46b5-4886-9ab0-1802f068985a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', 1.000, NULL, 'SN-100052', '2025-01-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-02", "warranty_until": "2028-01-02", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-02 09:00:00+00', '2026-11-22 23:36:19.26131+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('afedc5dc-0f9a-4176-9ed8-151ebd7c1a8f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', 1.000, NULL, 'SN-100053', '2024-09-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-27", "warranty_until": "2027-09-27", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-27 09:00:00+00', '2026-11-22 23:36:19.26131+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4f6a2db0-1898-4158-86b7-d25e9af507ab', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', 1.000, NULL, 'SN-100054', '2024-06-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-22", "warranty_until": "2027-06-22", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-22 09:00:00+00', '2026-11-22 23:36:19.26131+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c505fa5e-00bd-4487-bb17-729dec0ace55', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', 1.000, NULL, 'SN-100055', '2024-03-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-17", "warranty_until": "2027-03-17", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-17 09:00:00+00', '2026-11-22 23:36:19.261311+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('794ed6bb-f35c-403e-85af-5b4571a5d1b6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', 1.000, NULL, 'SN-100056', '2023-12-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-11", "warranty_until": "2026-12-10", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-11 09:00:00+00', '2026-11-22 23:36:19.261311+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d3d077f0-1cd2-44fb-893a-63a0037ca452', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 1.000, NULL, 'SN-100058', '2026-06-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-04", "warranty_until": "2029-06-03", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-04 09:00:00+00', '2026-11-22 23:36:19.261312+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('784a8c2f-f753-4234-8493-61d1e8da7119', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 1.000, NULL, 'SN-100059', '2026-02-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-27", "warranty_until": "2029-02-26", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-27 09:00:00+00', '2026-11-22 23:36:19.261312+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('cc25149e-d18b-4524-9692-313f95d2f251', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 1.000, NULL, 'SN-100060', '2025-11-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-22", "warranty_until": "2028-11-21", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-22 09:00:00+00', '2026-11-22 23:36:19.261313+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5424c9be-1ec8-4803-9fcd-f306df6bd321', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 1.000, NULL, 'SN-100061', '2025-08-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-17", "warranty_until": "2028-08-16", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-17 09:00:00+00', '2026-11-22 23:36:19.261313+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8818a6e0-a58f-4833-b4f4-2b6f08027a6c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 1.000, NULL, 'SN-100062', '2025-05-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-12", "warranty_until": "2028-05-11", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-12 09:00:00+00', '2026-11-22 23:36:19.261313+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c4d23b7d-38e2-4afa-b0b9-a25d29cf3ec5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '89627cb0-3e43-4dad-a1c3-a6d69c378206', 1.000, NULL, 'SN-100063', '2025-02-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-04", "warranty_until": "2028-02-04", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-04 09:00:00+00', '2026-11-22 23:36:19.261314+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fa9a105c-acb5-4ece-9729-2c4b843049b8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '89627cb0-3e43-4dad-a1c3-a6d69c378206', 1.000, NULL, 'SN-100064', '2024-10-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-30", "warranty_until": "2027-10-30", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-30 09:00:00+00', '2026-11-22 23:36:19.261314+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1a2d478c-e147-4f82-a44d-be78168ce2c5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '89627cb0-3e43-4dad-a1c3-a6d69c378206', 1.000, NULL, 'SN-100065', '2024-07-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-25", "warranty_until": "2027-07-25", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-25 09:00:00+00', '2026-11-22 23:36:19.261314+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a5cb1ff0-a879-4b60-a87a-e0168bd14ad6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '89627cb0-3e43-4dad-a1c3-a6d69c378206', 1.000, NULL, 'SN-100066', '2024-04-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-19", "warranty_until": "2027-04-19", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-19 09:00:00+00', '2026-11-22 23:36:19.261315+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('14857ba9-2ee1-4bfc-bc29-213037d82cbb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', 1.000, NULL, 'SN-100067', '2024-01-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-13", "warranty_until": "2027-01-12", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-13 09:00:00+00', '2026-11-22 23:36:19.261315+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c8ce5c15-05e2-4785-b3f0-0742eb86269b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', 1.000, NULL, 'SN-100068', '2023-10-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-08", "warranty_until": "2026-10-07", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-08 09:00:00+00', '2026-11-22 23:36:19.261316+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d194a3ac-f55e-41ca-8944-4ac79943a171', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b736c79-ab15-4f7e-882e-160ba782738d', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', 1.000, NULL, 'SN-100069', '2026-07-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-07", "warranty_until": "2029-07-06", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-07 09:00:00+00', '2026-11-22 23:36:19.261316+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6083110c-8dfd-48fd-97f1-7a4ae837e418', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95c56c34-8315-438d-b2c2-100085ecf05d', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', 1.000, NULL, 'SN-100070', '2026-04-01', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-01", "warranty_until": "2029-03-31", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-01 09:00:00+00', '2026-11-22 23:36:19.261316+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9a88f324-f78b-494b-987b-514b99e9d4e1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '64716e9d-6a92-4a9d-80b0-5cbcb821582f', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '799a7982-e7be-4e9f-8982-4062ab51f1ad', 1.000, NULL, 'SN-100071', '2025-12-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-25", "warranty_until": "2028-12-24", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-25 09:00:00+00', '2026-11-22 23:36:19.261317+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('61a498aa-5b41-4588-8a18-0f6cd313e28b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '44670f62-74cc-4587-8695-adbb5df6e0b6', 1.000, NULL, 'SN-100073', '2025-06-14', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-14", "warranty_until": "2028-06-13", "equipment_status": "AVAILABLE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-14 09:00:00+00', '2026-11-22 23:36:19.261317+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a6f6d8c7-1a4c-4fb3-ae23-a2577403c4b5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '44670f62-74cc-4587-8695-adbb5df6e0b6', 1.000, NULL, 'SN-100074', '2025-03-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-09", "warranty_until": "2028-03-08", "equipment_status": "AVAILABLE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-09 09:00:00+00', '2026-11-22 23:36:19.261318+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5284cea9-d50a-41eb-8eee-c0d78b8529ba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '44670f62-74cc-4587-8695-adbb5df6e0b6', 1.000, NULL, 'SN-100075', '2024-12-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-02", "warranty_until": "2027-12-02", "equipment_status": "AVAILABLE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-02 09:00:00+00', '2026-11-22 23:36:19.261318+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8b2f9025-058f-4c18-8488-dac04d73c55c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', 1.000, NULL, 'SN-100076', '2024-08-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-27", "warranty_until": "2027-08-27", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-27 09:00:00+00', '2026-11-22 23:36:19.261318+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a212def6-0aef-4af7-bd98-cf89ef54a26d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', 1.000, NULL, 'SN-100077', '2024-05-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-22", "warranty_until": "2027-05-22", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-22 09:00:00+00', '2026-11-22 23:36:19.261319+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5279e39e-4169-46fa-8e16-121fccfbcb83', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '8655532e-cb74-4e07-83a7-5eed2c6c9325', 1.000, NULL, 'SN-100078', '2024-02-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-15", "warranty_until": "2027-02-14", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-15 09:00:00+00', '2026-11-22 23:36:19.261319+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('739459f0-5c48-495a-9cc2-8069b7d9bc49', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '8655532e-cb74-4e07-83a7-5eed2c6c9325', 1.000, NULL, 'SN-100079', '2023-11-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-10", "warranty_until": "2026-11-09", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-10 09:00:00+00', '2026-11-22 23:36:19.261319+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b5f4fdd8-4c2b-4ff9-8374-2ce8ffc36396', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '8655532e-cb74-4e07-83a7-5eed2c6c9325', 1.000, NULL, 'SN-100080', '2026-08-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-09", "warranty_until": "2029-08-08", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-09 09:00:00+00', '2026-11-22 23:36:19.26132+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0b552ee9-2127-4811-9ddd-c36e5532178f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 'b560495f-e1ba-41da-ba94-58fc37b6ee1b', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', 1.000, NULL, 'SN-100082', '2026-01-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-27", "warranty_until": "2029-01-26", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-27 09:00:00+00', '2026-11-22 23:36:19.261321+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3c188f4b-4f9b-45be-b9fc-d90680a1d317', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', 'b560495f-e1ba-41da-ba94-58fc37b6ee1b', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', 1.000, NULL, 'SN-100083', '2025-10-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-22", "warranty_until": "2028-10-21", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-22 09:00:00+00', '2026-11-22 23:36:19.261321+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a3f39f03-1f3b-4020-b376-577ecd694307', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95c56c34-8315-438d-b2c2-100085ecf05d', 'b560495f-e1ba-41da-ba94-58fc37b6ee1b', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', 1.000, NULL, 'SN-100084', '2025-07-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-17", "warranty_until": "2028-07-16", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-17 09:00:00+00', '2026-11-22 23:36:19.261321+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('28a648a4-31ae-43d7-95c6-14e98522d458', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', 'b560495f-e1ba-41da-ba94-58fc37b6ee1b', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', 1.000, NULL, 'SN-100085', '2025-04-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-11", "warranty_until": "2028-04-10", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-11 09:00:00+00', '2026-11-22 23:36:19.261322+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('97e63afc-68cb-48dd-b680-941d67e86298', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', 'b560495f-e1ba-41da-ba94-58fc37b6ee1b', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', 1.000, NULL, 'SN-100086', '2025-01-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-04", "warranty_until": "2028-01-04", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-04 09:00:00+00', '2026-11-22 23:36:19.261322+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f1b01e73-4b2d-4f5b-a8b2-047403048011', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, NULL, 'Natural Yoghurt 400g', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 18.000, NULL, NULL, '2026-11-13', NULL, NULL, NULL, '{}', 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-11-13 12:15:00+00', '2026-11-22 23:36:21.121064+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('20d2d485-2f5b-4fdb-b999-8c2df86bb2bb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0f92a508-261c-403d-bc4f-49b1635180cb', 1.000, NULL, 'SN-100007', '2024-11-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-28", "warranty_until": "2027-11-28", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-28 09:00:00+00', '2026-11-22 23:36:21.58904+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9c18923a-6caf-43d9-a1be-0342a59d5196', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0f92a508-261c-403d-bc4f-49b1635180cb', 1.000, NULL, 'SN-100005', '2025-06-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-10", "warranty_until": "2028-06-09", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-10 09:00:00+00', '2026-11-22 23:36:21.589042+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ca1868ce-156a-43f1-91da-c2ed95d26841', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95c56c34-8315-438d-b2c2-100085ecf05d', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0f92a508-261c-403d-bc4f-49b1635180cb', 1.000, NULL, 'SN-100006', '2025-03-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-05", "warranty_until": "2028-03-04", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-05 09:00:00+00', '2026-11-22 23:36:21.589042+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e2c46401-5df2-417a-abb4-be3a832b6e89', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', NULL, NULL, 'Damson Plums', 'Green Acre', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '63ade948-60ba-412d-b4b7-1e08c2140c55', 13.600, NULL, NULL, '2026-11-19', NULL, NULL, NULL, NULL, 3.40, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.297614+00', '2026-11-22 23:36:21.719498+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c4a17a40-5316-4b45-81c4-66fc0ab3f63e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '211e5889-8bcb-43e8-98ef-685b7582bef3', NULL, NULL, 'White Sugar', 'Harvest Row', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '5daaf10b-f21e-42cf-8250-9a58f4513d87', 21.220, NULL, NULL, '2026-11-02', NULL, NULL, NULL, NULL, 1.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.297617+00', '2026-11-22 23:36:21.747214+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ba38ccac-2151-4fdc-b7b1-1e789ae583f6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '3f9e5b9f-1b56-4d7e-b5d1-9c5ed9934391', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '2e90cfb5-e0da-41db-857a-cec9986f9225', 1.000, NULL, 'SN-100034', '2023-10-06', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-06", "warranty_until": "2026-10-05", "equipment_status": "DEPLOYED"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-06 09:00:00+00', '2026-11-22 23:36:22.294162+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9702ad84-eaae-4361-bc5f-97d245f5334a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0f92a508-261c-403d-bc4f-49b1635180cb', 3.000, NULL, NULL, '2026-11-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-20", "warranty_until": "2029-11-19", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-20 14:45:00+00', '2026-11-22 23:36:20.286304+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('aed74404-e412-47b8-b24f-41f54508d717', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 5.000, NULL, NULL, '2026-11-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-20", "warranty_until": "2029-11-19", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-20 14:45:00+00', '2026-11-22 23:36:20.286307+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('be63bb32-f836-4a97-904e-2362e64fc3bc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'UHT Milk 3.2%', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '656e5398-3fa1-4738-9447-f448081d8e8c', 36.000, NULL, NULL, '2026-11-13', NULL, NULL, NULL, '{}', 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-13 12:15:00+00', '2026-11-22 23:36:20.322727+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2e0b9d31-d5d4-497b-82ff-bc0dab1c25e7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'Butter Extra 82%', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '064b9631-706c-49d0-84a4-8651d76ca29b', 24.000, NULL, NULL, '2026-11-13', NULL, NULL, NULL, '{}', 8.90, 'USD', false, false, NULL, NULL, NULL, '2026-11-13 12:15:00+00', '2026-11-22 23:36:21.138908+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dce5edcc-e09c-4a23-81b5-a4dbc7cdeb98', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, NULL, 'Gouda Cheese', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 50.000, NULL, NULL, '2026-11-15', NULL, NULL, NULL, '{}', 12.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-15 12:15:00+00', '2026-11-22 23:36:21.218661+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2daeb525-a954-4004-acd1-dd1d1eca96a3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, 'Sour Cream 18%', 'Meadowlane', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 15.000, NULL, NULL, '2026-11-15', NULL, NULL, NULL, '{}', 4.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-15 12:15:00+00', '2026-11-22 23:36:21.232268+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('896db80b-0a08-45a1-91fb-4131104794e5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '4c2096c1-1ed7-4745-9d6c-dbeee4337c47', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '0f92a508-261c-403d-bc4f-49b1635180cb', 3.000, NULL, NULL, '2026-11-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-05", "warranty_until": "2029-11-04", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-05 13:30:00+00', '2026-11-22 23:36:21.510309+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2fb18879-a1da-4481-b850-1ce35d12cfbf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '211e5889-8bcb-43e8-98ef-685b7582bef3', NULL, NULL, 'Cassia Cinnamon', 'Saltmill', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', '7122be79-8284-4962-88fb-8b6b4fee6560', 0.440, NULL, NULL, '2026-10-19', NULL, NULL, NULL, NULL, 24.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:19.297618+00', '2026-11-22 23:36:21.765213+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9b453772-d40a-4c8c-8e44-f10839058cf5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '211e5889-8bcb-43e8-98ef-685b7582bef3', NULL, NULL, 'Plum Butter', NULL, NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 'a3446456-f5c3-4936-b45d-828b010a472e', 11.400, NULL, NULL, '2026-11-22', NULL, NULL, NULL, '{}', 8.36, 'USD', false, false, NULL, NULL, NULL, '2026-11-22 23:36:21.792211+00', '2026-11-22 23:36:21.792212+00', NULL, NULL, '428858fb-8cdd-4c0e-920a-46b2c0372c9a', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('152fdd45-eae6-4f1c-96dd-e0f9f04f737c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608e2d51-d0d0-4a64-80be-dad9c224283a', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', 1.000, NULL, 'SN-100045', '2023-11-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-08", "warranty_until": "2026-11-07", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-08 09:00:00+00', '2026-11-22 23:36:22.326047+00', 'STM-QPTG', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3ad907b2-900d-4c8f-a1a5-d9a425e1750c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '0bd2d983-8838-4137-90d6-18f9690612a8', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '44670f62-74cc-4587-8695-adbb5df6e0b6', 1.000, NULL, 'SN-100072', '2025-09-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-19", "warranty_until": "2028-09-18", "equipment_status": "MAINTENANCE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-19 09:00:00+00', '2026-11-22 23:36:22.326047+00', 'STM-WZ0B', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4d8fdd38-4e83-45a4-8836-68af9d31490a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '24937559-02f7-4737-9908-083c06714c5c', '293adab3-cb18-493b-a188-4799a2342aa2', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', 1.000, NULL, 'SN-100057', '2026-09-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-09", "warranty_until": "2029-09-08", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-09 09:00:00+00', '2026-11-22 23:36:22.326047+00', 'STM-YD0P', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e2baf4e3-573f-443d-898c-fd37aa7f5bfa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8b6f6b4a-9882-4863-a243-f5a107568dee', 'b560495f-e1ba-41da-ba94-58fc37b6ee1b', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', '68482959-681d-40b9-8bcf-d052b31def99', 1.000, NULL, 'SN-100081', '2026-05-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-04", "warranty_until": "2029-05-03", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-04 09:00:00+00', '2026-11-22 23:36:22.326048+00', 'STM-FCLZ', NULL, NULL, NULL, NULL);


--
-- Data for Name: label_pool; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('2fa676cc-f3c3-4b40-83ee-5ca6809f8439', 'STM-FCLZ', true, '2026-11-11 23:36:22.325084+00', 'e2baf4e3-573f-443d-898c-fd37aa7f5bfa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('820303d4-2b84-4604-a731-3f1cd4e73220', 'STM-QPTG', true, '2026-11-11 23:36:22.325084+00', '152fdd45-eae6-4f1c-96dd-e0f9f04f737c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('847c3f57-448a-45ca-8420-2f2d1410c006', 'STM-YD0P', true, '2026-11-11 23:36:22.325084+00', '4d8fdd38-4e83-45a4-8836-68af9d31490a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('c24e3dd5-d92f-4316-b6f3-15781c84d779', 'STM-CCG8', true, '2026-11-11 23:36:22.325084+00', 'ad29c485-561f-4eee-b493-983c11aca6f2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('104a4485-4282-4682-ae22-d70643c5ce4a', 'STM-33EK', true, '2026-11-11 23:36:22.325084+00', '14dc5966-6f84-498e-858c-c735b43e8fc7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('59947c99-6301-4256-9f33-d8fcda9376bd', 'STM-WZ0B', true, '2026-11-11 23:36:22.325084+00', '3ad907b2-900d-4c8f-a1a5-d9a425e1750c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('52d5d3fb-5817-4bf4-b384-4b253249115e', 'STM-MHNB', false, NULL, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('5eb301ae-6b1c-4c02-8e93-5980a4186e7c', 'STM-U2G8', false, NULL, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('039b3dd4-c885-4b4c-b71e-879de9cb62bd', 'STM-22CD', false, NULL, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('8a63a60d-2e6a-4ac3-8f0d-dd99f18225a1', 'STM-AIXQ', false, NULL, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('af3b6d06-738e-495a-b56c-8c86f608de1f', 'STM-RD4T', false, NULL, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('3a4bf90a-0a80-4773-b470-fbdb6d7cf585', 'STM-NX52', false, NULL, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7', '29df2390-1a60-43fd-ba97-7824689adfc1', 'GENERIC', NULL, NULL, NULL, '2026-11-10 23:36:22.325084+00', '2026-11-10 23:36:22.325084+00', 0, NULL);


--
-- Data for Name: location_relocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_bom_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id, make_fresh) VALUES ('79535a19-2513-4906-8079-11b57ca42102', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', '63ade948-60ba-412d-b4b7-1e08c2140c55', 'kg', 10.00, 'stone fruit', '2026-11-22 23:36:19.106749+00', '2026-11-22 23:36:19.106752+00', 'bb155fdb-78c8-45e0-b7f2-196483b85f23', 2.0000, '61cebc75-7127-4699-85e2-7617ae9db641', false);
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id, make_fresh) VALUES ('f844dca6-e161-4081-9e8c-00339844ce62', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', '5daaf10b-f21e-42cf-8250-9a58f4513d87', 'kg', 5.00, 'sweetener', '2026-11-22 23:36:19.106755+00', '2026-11-22 23:36:19.106755+00', 'bb155fdb-78c8-45e0-b7f2-196483b85f23', 0.3000, '61cebc75-7127-4699-85e2-7617ae9db641', false);
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id, make_fresh) VALUES ('c04392c6-1f11-41cc-9f46-97a87f9128ae', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', '7122be79-8284-4962-88fb-8b6b4fee6560', 'kg', 0.00, 'spice', '2026-11-22 23:36:19.106756+00', '2026-11-22 23:36:19.106757+00', 'bb155fdb-78c8-45e0-b7f2-196483b85f23', 0.0050, '61cebc75-7127-4699-85e2-7617ae9db641', false);


--
-- Data for Name: maker_ingredient_prices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_label_facts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_module_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_module_settings (organization_id, reference_direction, created_at, updated_at, allow_overproduction, availability_check_scope, create_on_shortage_strategy, labor_hourly_rate) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'MARGIN', '2026-11-22 23:36:21.629644+00', '2026-11-22 23:36:21.629646+00', true, 'GLOBAL', 'WARN', 0.00);


--
-- Data for Name: maker_production_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_production_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty, estimated_qty, estimated_unit_cost_snapshot) VALUES ('487c323c-bfd3-44c4-91fd-5e78962ab6a8', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '63ade948-60ba-412d-b4b7-1e08c2140c55', 26.4000, 'kg', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 3.4000, 'fifo', NULL, 25.0800, 3.4000);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty, estimated_qty, estimated_unit_cost_snapshot) VALUES ('b088c9c2-48c8-4e1b-a990-6e6a17ab1463', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '5daaf10b-f21e-42cf-8250-9a58f4513d87', 3.7800, 'kg', '211e5889-8bcb-43e8-98ef-685b7582bef3', 1.1000, 'fifo', NULL, 3.5910, 1.1000);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty, estimated_qty, estimated_unit_cost_snapshot) VALUES ('874c9acd-28d4-491c-96cd-8b3755adc231', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '7122be79-8284-4962-88fb-8b6b4fee6560', 0.0600, 'kg', '211e5889-8bcb-43e8-98ef-685b7582bef3', 24.0000, 'fifo', NULL, 0.0570, 24.0000);


--
-- Data for Name: maker_production_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_orders (id, organization_id, output_template_id, planned_qty, output_storage_location_id, status, total_cost, production_date, notes, created_by, completed_by, created_at, completed_at, cancel_reason, produced_item_id, recipe_id, actual_qty, overproduced, scrap_qty, unit_cost_snapshot, reference_price_snapshot, result_per_unit, result_per_batch, number, short_at_create, output_lot_name, estimated_total_cost, output_lot_id, started_on, started_at, material_cost, unshelved_cost, steps, planned_for, output_layer_id) VALUES ('10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', 12.000, '211e5889-8bcb-43e8-98ef-685b7582bef3', 'COMPLETED', 95.36, '2026-11-22', 'Autumn batch, first of the season.', '29df2390-1a60-43fd-ba97-7824689adfc1', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.668377+00', '2026-11-22 23:36:21.802172+00', NULL, '9b453772-d40a-4c8c-8e44-f10839058cf5', 'bb155fdb-78c8-45e0-b7f2-196483b85f23', 11.400, false, 0.600, 8.3647, 18.00, 9.64, 9.64, 'PR/2026/0001', false, '20261122-1', 90.59, '428858fb-8cdd-4c0e-920a-46b2c0372c9a', NULL, NULL, NULL, NULL, NULL, NULL, '4cbe68b3-9a26-4b5b-809b-6e163784a55c');


--
-- Data for Name: maker_production_portions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipe_cost_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_recipes (id, organization_id, output_template_id, name, batch_yield_qty, batch_yield_uom_id, process_steps, reference_price, is_default, source_recipe_id, source_snapshot_at, created_at, updated_at) VALUES ('bb155fdb-78c8-45e0-b7f2-196483b85f23', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', 'Plum Butter', 1.0000, NULL, NULL, 18.00, true, NULL, NULL, '2026-11-22 23:36:19.094088+00', '2026-11-22 23:36:19.09409+00');


--
-- Data for Name: maker_shelf_lives; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: meal_plan_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('a597e414-e079-4df7-84d8-168d888f273e', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-16', 'BREAKFAST', '736f57cf-de96-4bfa-a572-2ac75cff9925', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('976eccb3-3af0-43e8-997a-a50d97b41209', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-16', 'DINNER', '9a2de8ce-44a8-4e33-b54f-785cb610c5f8', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('fa68452f-e958-456b-b7b2-32b7704499ba', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-17', 'DINNER', '0b6620d6-43b9-47ad-8691-252b4d19ecf5', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('0d69cb8c-123c-4f2f-a5cc-0c5fc70daf6f', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-18', 'BREAKFAST', '736f57cf-de96-4bfa-a572-2ac75cff9925', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('5a545012-a90e-45d5-aa27-e0d86317aed3', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-18', 'DINNER', '1e236768-1c83-4f26-be5b-01f870c745f4', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('6d6fa779-3720-4b48-9014-eb1989b8e9dc', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-19', 'DINNER', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('d9cbfab3-0c9a-40e6-b0ff-e001da6b3a17', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-20', 'DINNER', '59f9665c-135e-47a7-a4b9-c53d54f91181', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('668d14be-b4fe-4097-a46c-41ab3d585ee8', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-21', 'BREAKFAST', '47f1b501-370e-49ed-8042-8a63192d37e6', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('126502e0-9cae-481f-ab48-28d32cfd5cdb', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-21', 'DINNER', '04ed959b-e92a-438c-818d-05c859cb17aa', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('46158144-13dd-4658-93a8-59f9f410f5fc', '4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '2026-11-22', 'BREAKFAST', '8f09c05f-ae10-42f6-a355-abd186e75841', NULL, NULL, 0);


--
-- Data for Name: meal_plans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plans (id, organization_id, name, start_date, end_date, enabled_slots, default_servings, shopping_list_id, notes, created_by, created_at, updated_at, listed_meals) VALUES ('4f7ce9ff-05ed-4bb2-9e52-d2ccdf9ec64e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'This week', '2026-11-16', '2026-11-22', '["BREAKFAST", "DINNER"]', NULL, '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.852219+00', '2026-11-22 23:36:21.85222+00', NULL);


--
-- Data for Name: module_installations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.organizations (id, name, created_at, created_by, enabled_modules, allowed_modules, settings, short_id, active_profile_id, onboarding_completed, focus_module, pre_focus_enabled_modules, pre_onboarding_manual_modules, currency, timezone, tax_id, country, print_page_size, address, logo_url) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Larkspur Trading Co.', '2026-11-22 23:36:18.522582+00', '29df2390-1a60-43fd-ba97-7824689adfc1', '["equipment", "locations", "maker", "purchase_orders", "api_keys", "stats", "stock_takes", "recipes", "announcements", "categories", "shopping_lists", "printing", "approvals", "warehouse", "items", "nutrition", "mcp_server", "partners", "core"]', NULL, '{"module:equipment": {"warranty_warning_days": 60, "maintenance_warning_days": 14, "__schema_version": 1}, "module:stats": {"enable_analytics": true, "show_inventory_value": true, "__schema_version": 1}, "show_module_data": true, "module:approvals": {"allow_admin_self_approve": true}, "demo_last_reset_at": "2026-11-22T23:36:22.500097+00:00"}', NULL, 'equipment_wms', true, NULL, NULL, NULL, 'USD', 'UTC', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('5680c980-7e65-47cb-b882-d6548a9158fb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Eurodata Systems', 'SUP-001', 'SUPPLIER', NULL, false, 'orders@eurodata.example.com', '+44 20 7946 0101', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111096+00', '2026-11-22 23:36:19.111098+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('43905c73-9a09-442d-969d-1cb165a1e3da', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Northgate IT Distribution', 'ITD-002', 'SUPPLIER', NULL, false, 'sales@northgate-it.example.com', '+44 20 7946 0102', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111099+00', '2026-11-22 23:36:19.1111+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('f9df9fcf-78ab-4f9e-8118-2c9c47773ee8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'TechSupply Europe', 'TSE-003', 'SUPPLIER', NULL, false, 'orders@techsupply.example.net', '+44 20 7946 0103', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.1111+00', '2026-11-22 23:36:19.1111+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('2df551b1-835b-4456-a890-cd7930a9e97c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Freshfield Wholesale', 'FFD-004', 'SUPPLIER', NULL, false, 'orders@freshfield.example.com', '+44 20 7946 0104', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111101+00', '2026-11-22 23:36:19.111101+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('e23a5390-31be-468c-b94e-d037be34dbc8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Bulkline Cash & Carry', 'MCC-005', 'SUPPLIER', NULL, false, 'b2b@bulkline.example.com', '+44 20 7946 0105', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111102+00', '2026-11-22 23:36:19.111102+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('75a0913c-9187-4e85-b999-94b777a477b9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cornerstore Deliveries', 'ZAB-006', 'SUPPLIER', NULL, false, 'deliveries@cornerstore.example.com', '+44 20 7946 0106', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111102+00', '2026-11-22 23:36:19.111103+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('15e35aae-2e9a-432a-b234-0dafc8364ebc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cisco Systems', 'CSC-007', 'MANUFACTURER', NULL, false, 'enterprise@cisco.example.com', '+44 20 7946 0107', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111103+00', '2026-11-22 23:36:19.111103+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('2e5b6412-2fa9-4175-9860-e94cf8a481fd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dell Technologies', 'DLL-008', 'MANUFACTURER', NULL, false, 'enterprise@dell.example.com', '+44 20 7946 0108', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111104+00', '2026-11-22 23:36:19.111104+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('e7449af8-e28b-4820-a377-46ae939ea91a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Hewlett Packard Enterprise', 'HPE-009', 'MANUFACTURER', NULL, false, 'sales@hpe.example.com', '+44 20 7946 0109', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111104+00', '2026-11-22 23:36:19.111105+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('2d2660a4-c3d5-42d6-8998-010b4e18dea9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Apple', 'APL-010', 'MANUFACTURER', NULL, false, 'business@apple.example.com', '+44 20 7946 0110', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111105+00', '2026-11-22 23:36:19.111105+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('6ad48e50-d312-4dfb-a711-9748d63cca08', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Harper Catering', 'CUS-011', 'CUSTOMER', NULL, false, 'orders@harpercatering.example.com', '+44 20 7946 0111', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111106+00', '2026-11-22 23:36:19.111106+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('bb1537cc-0997-4227-bbb1-ccae26c55c31', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Officeworks Services', 'CUS-012', 'CUSTOMER', NULL, false, 'office@officeworks.example.net', '+44 20 7946 0112', NULL, NULL, NULL, NULL, true, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:19.111106+00', '2026-11-22 23:36:19.111107+00');


--
-- Data for Name: picking_session_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: picking_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: po_partner_pricelist; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('d9fbc89d-26d8-4e96-90ab-3b1919edec93', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2df551b1-835b-4456-a890-cd7930a9e97c', '63ade948-60ba-412d-b4b7-1e08c2140c55', 3.2000, 'USD', '61cebc75-7127-4699-85e2-7617ae9db641', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:36:22.350633+00', '2026-11-22 23:36:22.350635+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('3c01884c-6325-417a-bcad-aaedba44360a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e23a5390-31be-468c-b94e-d037be34dbc8', '5daaf10b-f21e-42cf-8250-9a58f4513d87', 1.0500, 'USD', '61cebc75-7127-4699-85e2-7617ae9db641', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:36:22.350635+00', '2026-11-22 23:36:22.350636+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('ff4c10b7-03bc-45bc-9d95-45ea55f4a038', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e23a5390-31be-468c-b94e-d037be34dbc8', '7122be79-8284-4962-88fb-8b6b4fee6560', 22.5000, 'USD', '61cebc75-7127-4699-85e2-7617ae9db641', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:36:22.350636+00', '2026-11-22 23:36:22.350636+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('ae49e1a1-fa02-40c4-bc87-dbd2e3193d6f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5680c980-7e65-47cb-b882-d6548a9158fb', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 4100.0000, 'USD', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:36:22.350637+00', '2026-11-22 23:36:22.350637+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('31bd20e7-8ff7-40ca-8cfc-2e556cf9c5e8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '43905c73-9a09-442d-969d-1cb165a1e3da', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 4180.0000, 'USD', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:36:22.350637+00', '2026-11-22 23:36:22.350637+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('b9faa89e-3cb7-429b-9290-8c02f414f404', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '43905c73-9a09-442d-969d-1cb165a1e3da', '0f92a508-261c-403d-bc4f-49b1635180cb', 5650.0000, 'USD', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, '2026-09-23', NULL, NULL, '2026-11-22 23:36:22.350638+00', '2026-11-22 23:36:22.350638+00');


--
-- Data for Name: po_reorder_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('b4b3fb5a-2179-449c-9a35-4691c0995ba8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 20.000, 40.000, 10.000, '2df551b1-835b-4456-a890-cd7930a9e97c', NULL, '2026-11-22 23:36:22.344817+00', '2026-11-22 23:36:22.344819+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('d93fa4e2-392f-4e6b-95e5-f26bbf9fe883', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', '211e5889-8bcb-43e8-98ef-685b7582bef3', 5.000, 25.000, 2.000, 'e23a5390-31be-468c-b94e-d037be34dbc8', NULL, '2026-11-22 23:36:22.344819+00', '2026-11-22 23:36:22.34482+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('b0fc8b28-6ad1-4e85-81ee-bf32f80d0285', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', '211e5889-8bcb-43e8-98ef-685b7582bef3', 0.100, 0.500, 0.100, 'e23a5390-31be-468c-b94e-d037be34dbc8', NULL, '2026-11-22 23:36:22.34482+00', '2026-11-22 23:36:22.34482+00');


--
-- Data for Name: po_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_settings (id, organization_id, approval_threshold, approval_required, created_at, updated_at) VALUES ('4badbaed-fe1e-4d47-9b83-f32a6c8f48b5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 10000.00, false, '2026-11-22 23:36:22.283262+00', '2026-11-22 23:36:22.283264+00');


--
-- Data for Name: print_agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: print_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('656e5398-3fa1-4738-9447-f448081d8e8c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.2, "carbs_g": 4.8, "protein_g": 3.2, "calories_kcal": 62}}', '2026-11-22 23:36:19.072926+00', '2026-11-22 23:36:19.072929+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cc8ee259-f9ed-483f-8c35-4a06dcee91d2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 7.5, "protein_g": 4.0, "calories_kcal": 67}}', '2026-11-22 23:36:19.072931+00', '2026-11-22 23:36:19.072931+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('064b9631-706c-49d0-84a4-8651d76ca29b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Butter Extra 82%', 'Meadowlane', '2000000000039', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 200.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 82.0, "carbs_g": 0.8, "protein_g": 0.5, "calories_kcal": 748}}', '2026-11-22 23:36:19.072932+00', '2026-11-22 23:36:19.072932+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Gouda Cheese', 'Meadowlane', '2000000000046', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 300.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 1.3, "protein_g": 24.0, "calories_kcal": 356}}', '2026-11-22 23:36:19.072932+00', '2026-11-22 23:36:19.072933+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Sour Cream 18%', 'Meadowlane', '2000000000053', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 300.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 18.0, "carbs_g": 3.4, "protein_g": 2.5, "calories_kcal": 182}}', '2026-11-22 23:36:19.072933+00', '2026-11-22 23:36:19.072934+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8511a165-fee7-4d2b-9674-5906c1e815df', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cottage Cheese', 'Meadowlane', '2000000000060', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 200.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 5.0, "protein_g": 9.0, "calories_kcal": 125}}', '2026-11-22 23:36:19.072934+00', '2026-11-22 23:36:19.072935+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fbc113bb-6608-448b-a260-ed9dd4b124d6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Lean Quark', 'Meadowlane', '2000000000077', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 250.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 3.5, "protein_g": 18.0, "calories_kcal": 85}}', '2026-11-22 23:36:19.072935+00', '2026-11-22 23:36:19.072935+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1ad1598a-376c-4ed4-8ece-d6b1e3dad820', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Eggs Medium 10pk', 'Fellbrook Farms', '2000000000084', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 600.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 1.1, "protein_g": 13.0, "calories_kcal": 155}}', '2026-11-22 23:36:19.072935+00', '2026-11-22 23:36:19.072936+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('dc835893-e55f-4bc8-8127-05e1dee1f7b2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Chicken Ham', 'Fellbrook Farms', '2000000000091', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 4.5, "carbs_g": 1.0, "protein_g": 16.0, "calories_kcal": 110}}', '2026-11-22 23:36:19.072936+00', '2026-11-22 23:36:19.072936+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9f9e6242-3bb6-4252-850b-8aeffc12087d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Pork Frankfurters', 'Fellbrook Farms', '2000000000107', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 22.0, "carbs_g": 2.0, "protein_g": 12.0, "calories_kcal": 253}}', '2026-11-22 23:36:19.072937+00', '2026-11-22 23:36:19.072937+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('bb6529e1-926f-41cd-9b74-c94a03b55f56', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Smoked Sausage', 'Fellbrook Farms', '2000000000114', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 3.0, "protein_g": 12.0, "calories_kcal": 301}}', '2026-11-22 23:36:19.072937+00', '2026-11-22 23:36:19.072937+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('972d00df-0e6c-4f20-a77f-ebb4515d1e61', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Smoked Bacon', 'Fellbrook Farms', '2000000000121', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 38.0, "carbs_g": 1.0, "protein_g": 12.0, "calories_kcal": 393}}', '2026-11-22 23:36:19.072938+00', '2026-11-22 23:36:19.072938+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('adb37118-6006-4d99-8159-7f92dfcd47da', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Chicken Breast Fillet', 'Fellbrook Farms', '2000000000138', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 600.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.2, "carbs_g": 0.0, "protein_g": 23.0, "calories_kcal": 110}}', '2026-11-22 23:36:19.072939+00', '2026-11-22 23:36:19.072939+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b5aae030-c765-4344-bb3c-590b79753472', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Smoked Salmon', 'Bluewater', '2000000000145', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 150.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 13.0, "carbs_g": 0.0, "protein_g": 20.0, "calories_kcal": 196}}', '2026-11-22 23:36:19.072939+00', '2026-11-22 23:36:19.072939+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cab4fed8-bf0a-4edb-919e-ad8b9fb4a7de', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Mayonnaise', 'Harvest Row', '2000000000152', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 300.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 79.0, "carbs_g": 1.0, "protein_g": 1.0, "calories_kcal": 714}}', '2026-11-22 23:36:19.07294+00', '2026-11-22 23:36:19.07294+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0c08476d-f8db-4d18-ac72-a46784985a7d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tomato Ketchup', 'Harvest Row', '2000000000169', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 26.0, "protein_g": 1.0, "calories_kcal": 112}}', '2026-11-22 23:36:19.07294+00', '2026-11-22 23:36:19.072941+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fd3f7025-38be-4c94-9805-708ad6525e50', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Orange Juice NFC', 'Orchard & Oak', '2000000000176', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.7, "calories_kcal": 45}}', '2026-11-22 23:36:19.072941+00', '2026-11-22 23:36:19.072941+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9e63b114-d3ef-4a45-aca3-a6188cbc140f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Chocolate Milk Drink', 'Meadowlane', '2000000000183', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 14.0, "protein_g": 3.2, "calories_kcal": 84}}', '2026-11-22 23:36:19.072942+00', '2026-11-22 23:36:19.072942+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a738adfd-0757-4836-a4b9-70ef1261378f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Classic Hummus', 'Green Acre', '2000000000190', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 200.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 14.0, "carbs_g": 14.0, "protein_g": 7.0, "calories_kcal": 215}}', '2026-11-22 23:36:19.072942+00', '2026-11-22 23:36:19.072943+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e0b85e67-3fb1-4b12-96ec-c0c5e22cf127', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Red Pesto', 'Harvest Row', '2000000000206', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 190.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 25.0, "carbs_g": 5.0, "protein_g": 3.0, "calories_kcal": 267}}', '2026-11-22 23:36:19.072943+00', '2026-11-22 23:36:19.072943+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8742e916-2785-4512-ab27-fed4ded3c473', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Carrots 1kg', 'Green Acre', '4651922764332', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.9, "calories_kcal": 41}}', '2026-11-22 23:36:19.072944+00', '2026-11-22 23:36:19.072944+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('666ea27b-05f1-4c1d-a5c2-934ef6a5bc3a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Broccoli', 'Green Acre', '7671591271129', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 7.0, "protein_g": 2.8, "calories_kcal": 34}}', '2026-11-22 23:36:19.072944+00', '2026-11-22 23:36:19.072945+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6d36f2b9-47c7-4589-905f-b904d79bb551', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cherry Tomatoes', 'Green Acre', '1461382306422', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 3.9, "protein_g": 0.9, "calories_kcal": 18}}', '2026-11-22 23:36:19.072945+00', '2026-11-22 23:36:19.072945+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7b1c4b4c-8fb3-4451-bc39-77be69e7915e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cucumber', 'Green Acre', '3824875293377', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 300.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 3.6, "protein_g": 0.7, "calories_kcal": 16}}', '2026-11-22 23:36:19.072946+00', '2026-11-22 23:36:19.072946+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('aa94072c-ac9a-48eb-8ddf-b2a0c11058bf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fuji Apples', 'Green Acre', '0774915747311', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 14.0, "protein_g": 0.3, "calories_kcal": 52}}', '2026-11-22 23:36:19.072946+00', '2026-11-22 23:36:19.072947+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c1cc3788-f9c0-4496-9e75-cc96e64e832c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Green Grapes', 'Green Acre', '2178682164889', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 18.0, "protein_g": 0.7, "calories_kcal": 69}}', '2026-11-22 23:36:19.072947+00', '2026-11-22 23:36:19.072947+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0b20e3d3-4b5e-4b47-820c-2513e24ae9cd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Strawberries', 'Green Acre', '9922816702736', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 7.7, "protein_g": 0.7, "calories_kcal": 32}}', '2026-11-22 23:36:19.072948+00', '2026-11-22 23:36:19.072948+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a2cb8657-0e93-43db-a962-6c5670f4b141', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Bananas', 'Green Acre', '6348208271001', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 23.0, "protein_g": 1.1, "calories_kcal": 89}}', '2026-11-22 23:36:19.072948+00', '2026-11-22 23:36:19.072949+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('52559aed-459d-4b60-bdfb-9e8a712c46a7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Vanilla Ice Cream', 'Northwind Frozen', '2000000000299', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 24.0, "protein_g": 3.5, "calories_kcal": 207}}', '2026-11-22 23:36:19.072949+00', '2026-11-22 23:36:19.072949+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d918c10c-4479-4c3f-9e5f-849aa2088b56', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen Pepperoni Pizza', 'Northwind Frozen', '2000000000305', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 350.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 12.0, "carbs_g": 28.0, "protein_g": 11.0, "calories_kcal": 266}}', '2026-11-22 23:36:19.07295+00', '2026-11-22 23:36:19.07295+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('319dc161-97d4-4a04-9b3d-cc64d9d704dd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Potato and Cheese Dumplings', 'Northwind Frozen', '2000000000312', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 600.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 28.0, "protein_g": 5.0, "calories_kcal": 196}}', '2026-11-22 23:36:19.07295+00', '2026-11-22 23:36:19.07295+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d94e5659-0dfc-4e0b-bf49-0340f296bdf5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fish Fingers', 'Bluewater', '2000000000329', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 10.0, "carbs_g": 22.0, "protein_g": 10.0, "calories_kcal": 215}}', '2026-11-22 23:36:19.072951+00', '2026-11-22 23:36:19.072951+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('da365ea3-8bea-4038-8a2f-09bb0f4a6119', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen Green Peas', 'Northwind Frozen', '2000000000343', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 450.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 14.0, "protein_g": 5.0, "calories_kcal": 81}}', '2026-11-22 23:36:19.072952+00', '2026-11-22 23:36:19.072952+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f0dfd71d-13fb-469d-b712-a1fa1100b99b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen Chips', 'Northwind Frozen', '2000000000350', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 750.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 5.0, "carbs_g": 24.0, "protein_g": 2.5, "calories_kcal": 152}}', '2026-11-22 23:36:19.072953+00', '2026-11-22 23:36:19.072953+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('85b30619-ebeb-459f-a6c3-c123cce38ab2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen Blueberries', 'Northwind Frozen', '2000000000367', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 14.0, "protein_g": 0.7, "calories_kcal": 57}}', '2026-11-22 23:36:19.072953+00', '2026-11-22 23:36:19.072953+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('15b7c606-d26e-4e43-9de3-084e7de9824f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen Sour Cherries', 'Northwind Frozen', '2000000000374', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 12.0, "protein_g": 1.0, "calories_kcal": 50}}', '2026-11-22 23:36:19.072954+00', '2026-11-22 23:36:19.072954+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('150c1f18-1619-4b71-9c0c-d4adfacf209a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Minced Pork', 'Fellbrook Farms', '2000000000381', NULL, '61cebc75-7127-4699-85e2-7617ae9db641', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 19.0, "carbs_g": 0.0, "protein_g": 15.0, "calories_kcal": 242}}', '2026-11-22 23:36:19.072954+00', '2026-11-22 23:36:19.072955+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('11da52ea-9837-4656-b7e9-b2ef2010e08c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Spaghetti 500g', 'Harvest Row', '2000000000398', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-22 23:36:19.072955+00', '2026-11-22 23:36:19.072955+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('460a449f-4c24-43e3-921d-c9b18b3bda75', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Penne Pasta', 'Harvest Row', '2000000000404', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-22 23:36:19.072956+00', '2026-11-22 23:36:19.072956+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b3b21331-b2d7-4601-ba68-c2cc968c267e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fusilli Pasta', 'Harvest Row', '2000000000411', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-22 23:36:19.072956+00', '2026-11-22 23:36:19.072956+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('595520ae-5062-47f9-9e47-27082e7bc22f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Jasmine Rice 1kg', 'Harvest Row', '2000000000428', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 78.0, "protein_g": 7.0, "calories_kcal": 348}}', '2026-11-22 23:36:19.072957+00', '2026-11-22 23:36:19.072957+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ff1d121d-4fb2-458c-b16d-08824802ade1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Buckwheat Groats', 'Harvest Row', '2000000000435', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.0, "carbs_g": 62.0, "protein_g": 12.0, "calories_kcal": 343}}', '2026-11-22 23:36:19.072957+00', '2026-11-22 23:36:19.072958+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Rolled Oats', 'Harvest Row', '2000000000442', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 68.0, "protein_g": 13.0, "calories_kcal": 379}}', '2026-11-22 23:36:19.072958+00', '2026-11-22 23:36:19.072958+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('95d6a10f-937b-4b74-a0d4-a012126d9f52', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fruit Muesli', 'Harvest Row', '2000000000459', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 67.0, "protein_g": 9.0, "calories_kcal": 398}}', '2026-11-22 23:36:19.072959+00', '2026-11-22 23:36:19.072959+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('bb7fd41c-28b1-40a6-bf02-842e11c0f198', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Corn Flakes', 'Harvest Row', '2000000000466', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 375.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 84.0, "protein_g": 6.0, "calories_kcal": 361}}', '2026-11-22 23:36:19.072959+00', '2026-11-22 23:36:19.072959+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('08da4f37-6c57-44fd-b5b5-194ff528ed05', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Wheat Flour Type 550', 'Harvest Row', '2000000000473', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 72.0, "protein_g": 10.0, "calories_kcal": 341}}', '2026-11-22 23:36:19.07296+00', '2026-11-22 23:36:19.07296+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'White Sugar 1kg', 'Harvest Row', '2000000000480', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 100.0, "protein_g": 0.0, "calories_kcal": 387}}', '2026-11-22 23:36:19.07296+00', '2026-11-22 23:36:19.072961+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b9014711-5ce7-4aac-8f11-e4748fff949a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Iodised Salt', 'Saltmill', '2000000000497', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072961+00', '2026-11-22 23:36:19.072961+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8cb0f5a5-32c3-4af6-a76a-b320f013cdb0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Ground Black Pepper', 'Saltmill', '2000000000503', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 40.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072962+00', '2026-11-22 23:36:19.072962+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('dbf12d9e-0cfc-4c10-9844-2c06f6c6697f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dried Oregano', 'Saltmill', '2000000000510', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 15.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072962+00', '2026-11-22 23:36:19.072962+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('97a89b73-a69a-4ff9-ab77-3817802541ba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dried Basil', 'Saltmill', '2000000000527', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 10.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072963+00', '2026-11-22 23:36:19.072963+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1c324057-7e3a-4675-946b-28a3b9a3ddcb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Granulated Garlic', 'Saltmill', '2000000000534', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 25.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072964+00', '2026-11-22 23:36:19.072964+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Extra Virgin Olive Oil', 'Harvest Row', '2000000000541', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 750.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-22 23:36:19.072964+00', '2026-11-22 23:36:19.072964+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('72d583c2-ff3d-4f7f-ae15-5333b3840dd0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Sunflower Oil', 'Harvest Row', '2000000000558', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-22 23:36:19.072965+00', '2026-11-22 23:36:19.072965+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3f035a28-b936-439d-8255-6907612165c0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tomato Passata', 'Harvest Row', '2000000000565', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 700.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 5.5, "protein_g": 1.5, "calories_kcal": 32}}', '2026-11-22 23:36:19.072966+00', '2026-11-22 23:36:19.072966+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ab1b9846-c8e7-45c6-b695-e655763069ab', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Peeled Tomatoes 400g', 'Harvest Row', '2000000000572', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 4.0, "protein_g": 1.2, "calories_kcal": 26}}', '2026-11-22 23:36:19.072966+00', '2026-11-22 23:36:19.072966+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('03eac769-95d8-4c00-b062-a34ad47c6e49', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Canned Chickpeas', 'Harvest Row', '2000000000589', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.6, "carbs_g": 27.0, "protein_g": 9.0, "calories_kcal": 164}}', '2026-11-22 23:36:19.072967+00', '2026-11-22 23:36:19.072967+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('42e6f32b-c103-46f6-bdd6-be34da557ae6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Canned White Beans', 'Harvest Row', '2000000000596', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 400.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 25.0, "protein_g": 9.0, "calories_kcal": 139}}', '2026-11-22 23:36:19.072967+00', '2026-11-22 23:36:19.072968+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('62ebb3c9-a0e7-4f16-8565-b3edfa33ab5e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Canned Sweetcorn', 'Harvest Row', '2000000000602', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 340.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 19.0, "protein_g": 3.0, "calories_kcal": 96}}', '2026-11-22 23:36:19.072968+00', '2026-11-22 23:36:19.072968+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4bc01401-9706-4db0-970f-2f2fae6d685e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tuna in Oil', 'Bluewater', '2000000000619', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 160.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 0.0, "protein_g": 26.0, "calories_kcal": 198}}', '2026-11-22 23:36:19.072968+00', '2026-11-22 23:36:19.072969+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0052c85e-7ae7-42ac-8a15-9a144ea74f59', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Chicken Stock', 'Harvest Row', '2000000000626', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 120.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072969+00', '2026-11-22 23:36:19.072969+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('089c0383-3599-40ad-880b-5d5ef9c56572', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Earl Grey Tea', 'Orchard & Oak', '2000000000633', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 50.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.07297+00', '2026-11-22 23:36:19.07297+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cd04be7b-2ad3-412b-942c-1800cb2941ae', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Ground Coffee', 'Orchard & Oak', '2000000000640', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 250.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.07297+00', '2026-11-22 23:36:19.07297+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8aa82946-87c7-40c9-9d5a-1c2bbb06dbf6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Strawberry Jam', 'Orchard & Oak', '2000000000664', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 350.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 65.0, "protein_g": 0.5, "calories_kcal": 264}}', '2026-11-22 23:36:19.072971+00', '2026-11-22 23:36:19.072972+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4a48ed38-45e4-450a-b7cf-44a5ce7374a0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Peanut Butter', 'Orchard & Oak', '2000000000671', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 250.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 20.0, "protein_g": 25.0, "calories_kcal": 588}}', '2026-11-22 23:36:19.072972+00', '2026-11-22 23:36:19.072972+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('57d033bf-a1fd-4a02-8c90-652a565c7aaa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dark Chocolate 85%', 'Orchard & Oak', '2000000000688', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 100.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 44.0, "carbs_g": 39.0, "protein_g": 8.0, "calories_kcal": 598}}', '2026-11-22 23:36:19.072973+00', '2026-11-22 23:36:19.072973+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('93abab03-5353-45da-b59c-51fb2db9d423', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Salted Potato Crisps', 'Orchard & Oak', '2000000000695', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 165.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 35.0, "carbs_g": 53.0, "protein_g": 4.0, "calories_kcal": 536}}', '2026-11-22 23:36:19.072974+00', '2026-11-22 23:36:19.072974+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4edeb6ed-a152-4947-bba8-ab27f0ef5c7d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Rice Cakes', 'Harvest Row', '2000000000701', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 120.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.0, "carbs_g": 82.0, "protein_g": 7.0, "calories_kcal": 387}}', '2026-11-22 23:36:19.072974+00', '2026-11-22 23:36:19.072974+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c9661c72-74dc-4818-bd90-7f4694727cb1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Butter Biscuits', 'Orchard & Oak', '2000000000718', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 200.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 17.0, "carbs_g": 71.0, "protein_g": 6.0, "calories_kcal": 454}}', '2026-11-22 23:36:19.072975+00', '2026-11-22 23:36:19.072975+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('45cccb60-d659-4421-a067-32c271cbf33f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Soy Sauce', 'Harvest Row', '2000000000725', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 250.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 5.0, "protein_g": 8.0, "calories_kcal": 53}}', '2026-11-22 23:36:19.072975+00', '2026-11-22 23:36:19.072976+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9fc47c96-109d-449d-8b5b-b144c4594fba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tomato Paste', 'Harvest Row', '2000000000732', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 170.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 9.0, "protein_g": 3.0, "calories_kcal": 55}}', '2026-11-22 23:36:19.072976+00', '2026-11-22 23:36:19.072976+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cff8a70d-e1c9-4a00-aa21-91c157860368', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Potato Starch', 'Harvest Row', '2000000000749', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 500.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 85.0, "protein_g": 0.5, "calories_kcal": 341}}', '2026-11-22 23:36:19.072976+00', '2026-11-22 23:36:19.072977+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9fbcd4fb-3632-4189-a80a-26d869595602', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Baking Powder', 'Harvest Row', '2000000000756', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 50.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072977+00', '2026-11-22 23:36:19.072977+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1801966a-2db0-4352-9a07-48c7cb32fda3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dry Yeast', 'Harvest Row', '2000000000763', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 14.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072978+00', '2026-11-22 23:36:19.072978+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('138ee962-e9f1-4d59-86f1-50817126d765', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Vanilla Sugar', 'Harvest Row', '2000000000770', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 32.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072978+00', '2026-11-22 23:36:19.072978+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b680f25d-bd6b-4bb6-8eb6-fa5ad1a29511', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Ground Cinnamon', 'Saltmill', '2000000000787', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 20.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072979+00', '2026-11-22 23:36:19.072979+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7cbb5eaa-cc3f-495c-80c3-24959ac78c68', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Sweet Paprika', 'Saltmill', '2000000000794', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 30.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072979+00', '2026-11-22 23:36:19.07298+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('99b1fa02-26f7-45c3-8111-699c68130650', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Curry Powder', 'Saltmill', '2000000000800', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 25.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.07298+00', '2026-11-22 23:36:19.07298+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5cd24d64-30d6-4936-b13d-268845618032', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Wildflower Honey', 'Orchard & Oak', '2000000000824', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 82.0, "protein_g": 0.3, "calories_kcal": 304}}', '2026-11-22 23:36:19.072981+00', '2026-11-22 23:36:19.072981+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7a1102e9-8820-448a-a5c5-dd657ad519c8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Walnuts', 'Green Acre', '2000000000831', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 200.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 65.0, "carbs_g": 14.0, "protein_g": 15.0, "calories_kcal": 654}}', '2026-11-22 23:36:19.072982+00', '2026-11-22 23:36:19.072982+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('027755f4-0294-42a1-a43c-d5830beaa781', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Almonds', 'Green Acre', '2000000000848', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 200.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 22.0, "protein_g": 21.0, "calories_kcal": 579}}', '2026-11-22 23:36:19.072982+00', '2026-11-22 23:36:19.072982+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6b61f4b6-f554-4610-931d-26a0886d231a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Instant Tomato Soup', 'Harvest Row', '2000000000855', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 85.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-22 23:36:19.072983+00', '2026-11-22 23:36:19.072983+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c43184ae-d31f-4a77-924f-82299a34974f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cocoa Powder', 'Orchard & Oak', '2000000000862', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 100.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 15.0, "carbs_g": 36.0, "protein_g": 24.0, "calories_kcal": 348}}', '2026-11-22 23:36:19.072983+00', '2026-11-22 23:36:19.072984+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dell Latitude 5540', 'Dell', '2000000010014', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-1345U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-22 23:36:19.083628+00', '2026-11-22 23:36:19.083631+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0f92a508-261c-403d-bc4f-49b1635180cb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ThinkPad T14s Gen 4', 'Lenovo', '2000000010021', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "AMD Ryzen 7 PRO", "ram": "32GB", "storage": "1TB SSD"}}', '2026-11-22 23:36:19.083632+00', '2026-11-22 23:36:19.083632+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('755ea5f1-9325-4c48-acc5-91fe380b59f1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'MacBook Pro 14 M3', 'Apple', '2000000010038', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Apple M3 Pro", "ram": "18GB", "storage": "512GB SSD"}}', '2026-11-22 23:36:19.083632+00', '2026-11-22 23:36:19.083633+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9a22de9a-3c3a-4454-a156-5dd21d659a6e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'HP EliteBook 840 G10', 'HP', '2000000010045', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-1365U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-22 23:36:19.083633+00', '2026-11-22 23:36:19.083633+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9629cb34-f877-4616-bb58-c4b2e274aab0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dell OptiPlex 7010', 'Dell', '2000000010052', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-13500", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-22 23:36:19.083634+00', '2026-11-22 23:36:19.083634+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ad69dfca-feca-493b-ac3a-2cb57cdcddec', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'HP ProDesk 400 G9', 'HP', '2000000010069', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-12500", "ram": "8GB", "storage": "256GB SSD"}}', '2026-11-22 23:36:19.083634+00', '2026-11-22 23:36:19.083635+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Lenovo ThinkCentre M90q', 'Lenovo', '2000000010076', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-13700", "ram": "16GB", "storage": "1TB SSD"}}', '2026-11-22 23:36:19.083635+00', '2026-11-22 23:36:19.083635+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('14cfd548-8a19-406f-be8f-d1d4b012ee08', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dell UltraSharp U2723QE', 'Dell', '2000000010083', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-22 23:36:19.083636+00', '2026-11-22 23:36:19.083636+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('60a2899b-6903-44e0-a9a8-63b299378728', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'LG 27UK850-W', 'LG', '2000000010090', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-22 23:36:19.083637+00', '2026-11-22 23:36:19.083637+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('608eba71-431c-44b2-965e-4abc27a6ab8a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Samsung Odyssey G5', 'Samsung', '2000000010106', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "32\"", "panel": "VA", "resolution": "2560x1440"}}', '2026-11-22 23:36:19.083637+00', '2026-11-22 23:36:19.083637+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2e90cfb5-e0da-41db-857a-cec9986f9225', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'iPhone 15 Pro', 'Apple', '2000000010113', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Natural Titanium", "storage": "256GB"}}', '2026-11-22 23:36:19.083638+00', '2026-11-22 23:36:19.083638+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('22852bd0-d709-4bc5-b15d-cedb5ab70059', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Samsung Galaxy S24', 'Samsung', '2000000010120', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Phantom Black", "storage": "128GB"}}', '2026-11-22 23:36:19.083638+00', '2026-11-22 23:36:19.083639+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('507ace22-1183-4c8d-9c04-fa8cd6e19021', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'iPad Air M2', 'Apple', '2000000010137', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Space Gray", "storage": "128GB"}}', '2026-11-22 23:36:19.083639+00', '2026-11-22 23:36:19.083639+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cisco Catalyst 9200L', 'Cisco', '2000000010144', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE", "management": "DNA Center"}}', '2026-11-22 23:36:19.08364+00', '2026-11-22 23:36:19.08364+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a0e69b2f-02a1-4a01-b2af-199c95cc152f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', '2000000010151', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "48x 1GbE + 4x 10GbE"}}', '2026-11-22 23:36:19.08364+00', '2026-11-22 23:36:19.08364+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ec404269-dc14-4df1-a3e5-f3f1d1ccd619', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'TP-Link TL-SG3428', 'TP-Link', '2000000010168', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE + 4x SFP"}}', '2026-11-22 23:36:19.083641+00', '2026-11-22 23:36:19.083641+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ed6ded13-e200-4e54-8da1-9e715cf9e681', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cisco Meraki MR46', 'Cisco', '2000000010175', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"speed": "AX5400", "standard": "Wi-Fi 6"}}', '2026-11-22 23:36:19.083641+00', '2026-11-22 23:36:19.083642+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5be9a80e-66e6-4ea3-990d-ea61b247c23c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Logitech MX Keys S', 'Logitech', '2000000010182', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Mechanical", "layout": "US"}}', '2026-11-22 23:36:19.083642+00', '2026-11-22 23:36:19.083642+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('89627cb0-3e43-4dad-a1c3-a6d69c378206', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Logitech MX Master 3S', 'Logitech', '2000000010199', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"dpi": 8000, "buttons": 7}}', '2026-11-22 23:36:19.083642+00', '2026-11-22 23:36:19.083643+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2d6fa235-d67a-4abe-89c9-f84f68e3c175', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Logitech C920 HD Pro', 'Logitech', '2000000010205', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"fps": 30, "resolution": "1080p"}}', '2026-11-22 23:36:19.083643+00', '2026-11-22 23:36:19.083643+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('799a7982-e7be-4e9f-8982-4062ab51f1ad', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Jabra Evolve2 65', 'Jabra', '2000000010212', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Headset", "connection": "Bluetooth"}}', '2026-11-22 23:36:19.083644+00', '2026-11-22 23:36:19.083644+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('44670f62-74cc-4587-8695-adbb5df6e0b6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Dell PowerEdge R750', 'Dell', '2000000010229', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4314", "ram": "64GB", "storage": "2x 480GB SSD"}}', '2026-11-22 23:36:19.083644+00', '2026-11-22 23:36:19.083645+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cfa1af94-c19f-461e-ac45-bf2db317d2cf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'HPE ProLiant DL380 Gen10', 'HPE', '2000000010236', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Gold 5318Y", "ram": "128GB", "storage": "4x 960GB SSD"}}', '2026-11-22 23:36:19.083645+00', '2026-11-22 23:36:19.083645+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8655532e-cb74-4e07-83a7-5eed2c6c9325', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Supermicro SYS-1029U', 'Supermicro', '2000000010243', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4214", "ram": "96GB", "storage": "2x 1TB SSD"}}', '2026-11-22 23:36:19.083646+00', '2026-11-22 23:36:19.083646+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('68482959-681d-40b9-8bcf-d052b31def99', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'APC Smart-UPS 3000VA', 'APC', '2000000010250', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"runtime": "~15min at full load", "capacity": "3000VA/2700W"}}', '2026-11-22 23:36:19.083646+00', '2026-11-22 23:36:19.083646+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Rack 42U Open Frame', 'Rittal', '2000000010267', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "42U", "width": "19 inch"}}', '2026-11-22 23:36:19.083647+00', '2026-11-22 23:36:19.083647+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a3446456-f5c3-4936-b45d-828b010a472e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Plum Butter', 'Hollow Lane Orchard', '2000000009018', 'PLB-001', '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:36:19.091039+00', '2026-11-22 23:36:19.091042+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('63ade948-60ba-412d-b4b7-1e08c2140c55', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Damson Plums', 'Green Acre', '2000000009025', 'PLM-001', '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:36:19.091043+00', '2026-11-22 23:36:19.091043+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5daaf10b-f21e-42cf-8250-9a58f4513d87', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'White Sugar', 'Harvest Row', '2000000009032', 'SUG-001', '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:36:19.091044+00', '2026-11-22 23:36:19.091044+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7122be79-8284-4962-88fb-8b6b4fee6560', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Cassia Cinnamon', 'Saltmill', '2000000009049', 'CIN-001', '61cebc75-7127-4699-85e2-7617ae9db641', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-22 23:36:19.091044+00', '2026-11-22 23:36:19.091045+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1a77aa58-6966-427d-8d61-7dd1b4979dd3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Ground Ginger', 'Saltmill', '2000000000817', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 20.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 6, NULL, 'null', '2026-11-22 23:36:19.072981+00', '2026-11-22 23:36:19.187876+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('223c46ae-fe53-4540-a3f4-ab350c9a4fac', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Coffee Beans', 'Orchard & Oak', '2000000000657', NULL, '8352703e-3fa0-450f-9d3a-031f662471ce', 1000.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 3, NULL, 'null', '2026-11-22 23:36:19.072971+00', '2026-11-22 23:36:19.18788+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e9791bc9-10f8-49cd-8348-9dda0122063e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Frozen Mixed Vegetables', 'Northwind Frozen', '2000000000336', NULL, '10215777-64f1-4376-ac45-1cc7b9b2128b', 750.000000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, NULL, NULL, 8, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 5.0, "protein_g": 2.0, "calories_kcal": 35}}', '2026-11-22 23:36:19.072951+00', '2026-11-22 23:36:19.187881+00');


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('6c125561-e3c3-4eec-89fe-0b490d78a444', '0d2220a2-bf3f-4f7a-90c2-435ac297f937', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 'Dell Latitude 5540', 4.000, 0.000, 4200.00, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('08c6c09f-5b87-4915-92f6-1b35d42760f2', '499e19cd-12f2-4df7-99d4-bf4de57aa032', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 'Dell Latitude 5540', 6.000, 0.000, 4200.00, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('27cad19a-abc7-42a0-b419-9872def5b5e7', '499e19cd-12f2-4df7-99d4-bf4de57aa032', '0f92a508-261c-403d-bc4f-49b1635180cb', 'ThinkPad T14s Gen 4', 2.000, 0.000, 5800.00, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, 2, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('f2130701-aea5-43fc-b164-725a3192a20d', 'b255df3f-d889-4f70-86d6-f22dc32a537e', '0f92a508-261c-403d-bc4f-49b1635180cb', 'ThinkPad T14s Gen 4', 5.000, 3.000, 5800.00, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, 1, NULL, NULL);


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('b255df3f-d889-4f70-86d6-f22dc32a537e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'PO/2026/003', 'CONFIRMED', '5680c980-7e65-47cb-b882-d6548a9158fb', '2026-11-09', 'Partly delivered; the rest is on back order with the supplier.', 'USD', '29df2390-1a60-43fd-ba97-7824689adfc1', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-02 23:36:21.265517+00', NULL, NULL, '2026-11-02 23:36:21.265517+00', '2026-11-22 23:36:21.910182+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('0d2220a2-bf3f-4f7a-90c2-435ac297f937', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'PO/2026/001', 'PENDING_APPROVAL', '43905c73-9a09-442d-969d-1cb165a1e3da', '2026-11-26', 'Laptops for the two November starters and two for the loan pool.', 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', NULL, NULL, NULL, NULL, '2026-11-19 23:36:21.265517+00', '2026-11-22 23:36:22.285385+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('499e19cd-12f2-4df7-99d4-bf4de57aa032', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'PO/2026/002', 'CONFIRMED', '43905c73-9a09-442d-969d-1cb165a1e3da', '2026-11-19', 'Quarterly refresh of the support desk.', 'USD', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-13 07:36:21.265517+00', NULL, NULL, '2026-11-12 23:36:21.265517+00', '2026-11-22 23:36:22.285753+00');


--
-- Data for Name: putaway_capacity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_home_silenced; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_location_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_rule_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('5ef96a3e-ba0b-47e7-b0c8-3862e16f8619', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dce1c07a-33c3-45e3-839b-bd1d1c142da7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('c68708dc-cc09-462b-961c-4da335a59aa1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dce1c07a-33c3-45e3-839b-bd1d1c142da7', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('f862b21a-9261-4101-9cd3-8d59880ae0db', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2f70d047-1697-4346-8f32-a833c7a87fab', '96bede93-9802-49a9-952b-075e2301156b', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('85e76668-a501-4b68-a9c2-2a1701f4f840', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2f70d047-1697-4346-8f32-a833c7a87fab', '896495c0-ac5b-4f88-9d3c-263344cc6d3a', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('e1804188-7bab-4ec2-8d49-e317661969fe', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e465f70c-c30c-4cba-a09c-ad7c1b51108d', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('df95b612-47f8-41fd-86e9-88a008830bea', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e465f70c-c30c-4cba-a09c-ad7c1b51108d', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 1);


--
-- Data for Name: putaway_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('dce1c07a-33c3-45e3-839b-bd1d1c142da7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, '82a6fd2f-98c4-4647-9290-0612400951fb', NULL, NULL, 50, true, '2026-11-22 23:36:21.875984+00', '2026-11-22 23:36:21.875984+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('2f70d047-1697-4346-8f32-a833c7a87fab', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, '69a9317c-d464-454f-b021-8d8c163ceba5', NULL, NULL, 50, true, '2026-11-22 23:36:21.875984+00', '2026-11-22 23:36:21.875984+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('e465f70c-c30c-4cba-a09c-ad7c1b51108d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', NULL, NULL, NULL, 10, true, '2026-11-22 23:36:21.875984+00', '2026-11-22 23:36:21.875984+00');


--
-- Data for Name: recipe_collection_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('4bead584-c79b-4f4b-a57e-9cca1153232a', '9a2de8ce-44a8-4e33-b54f-785cb610c5f8', '03eac769-95d8-4c00-b062-a34ad47c6e49', 'Canned Chickpeas', NULL, NULL, 2.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6c5c4073-8efa-4bb1-9bd8-42bbdc990ea4', '9a2de8ce-44a8-4e33-b54f-785cb610c5f8', '3f035a28-b936-439d-8255-6907612165c0', 'Tomato Passata', NULL, NULL, 500.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('57f4f603-fa05-4d5c-af50-ba283357b047', '9a2de8ce-44a8-4e33-b54f-785cb610c5f8', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('37b033fa-3ba0-46e4-9a85-5f5f384cb591', '9a2de8ce-44a8-4e33-b54f-785cb610c5f8', '7cbb5eaa-cc3f-495c-80c3-24959ac78c68', 'Sweet Paprika', NULL, NULL, 3.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bd892d6b-b29a-4562-9a65-bcfe73ea8021', '0b6620d6-43b9-47ad-8691-252b4d19ecf5', '11da52ea-9837-4656-b7e9-b2ef2010e08c', 'Spaghetti 500g', NULL, NULL, 200.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0048f8db-2e21-4ee5-8974-3d34ec8a9d95', '0b6620d6-43b9-47ad-8691-252b4d19ecf5', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', 'Extra Virgin Olive Oil', NULL, NULL, 40.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1f3d89fc-c5b6-49d5-a61a-41d7e186cfbe', '0b6620d6-43b9-47ad-8691-252b4d19ecf5', '1c324057-7e3a-4675-946b-28a3b9a3ddcb', 'Granulated Garlic', NULL, NULL, 3.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bfe46325-fd6b-41a8-aed0-1cebfb435721', '0b6620d6-43b9-47ad-8691-252b4d19ecf5', 'b9014711-5ce7-4aac-8f11-e4748fff949a', 'Iodised Salt', NULL, NULL, 10.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('e1c8deec-f9b8-4a57-b76d-87ece2360e54', '1e236768-1c83-4f26-be5b-01f870c745f4', 'adb37118-6006-4d99-8159-7f92dfcd47da', 'Chicken Breast Fillet', NULL, NULL, 600.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c2fd1dec-5605-4f8b-80e0-ddc71f695c4d', '1e236768-1c83-4f26-be5b-01f870c745f4', '595520ae-5062-47f9-9e47-27082e7bc22f', 'Jasmine Rice 1kg', NULL, NULL, 300.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0a628f07-6fbf-4eec-bb6d-e8f2b4bd9e63', '1e236768-1c83-4f26-be5b-01f870c745f4', '99b1fa02-26f7-45c3-8111-699c68130650', 'Curry Powder', NULL, NULL, 10.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6580cef5-e88c-47ee-98d8-1d87edb859f1', '1e236768-1c83-4f26-be5b-01f870c745f4', 'ab1b9846-c8e7-45c6-b695-e655763069ab', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d8ead012-f12a-48f2-bd67-92bef1d54f8c', '1e236768-1c83-4f26-be5b-01f870c745f4', NULL, 'Coconut Milk', NULL, NULL, 400.000, '91076c0d-7a37-4f23-9590-300a47f93015', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('9713d062-f3c7-44fb-8c99-8f53de24fec6', '59f9665c-135e-47a7-a4b9-c53d54f91181', '460a449f-4c24-43e3-921d-c9b18b3bda75', 'Penne Pasta', NULL, NULL, 200.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('2e3ec8cd-2a3b-4dbf-9b6e-2cb351baf034', '59f9665c-135e-47a7-a4b9-c53d54f91181', 'e0b85e67-3fb1-4b12-96ec-c0c5e22cf127', 'Red Pesto', NULL, NULL, 90.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d6428c3f-6dd3-4974-b33d-caf33f80ef4f', '59f9665c-135e-47a7-a4b9-c53d54f91181', '6d36f2b9-47c7-4589-905f-b904d79bb551', 'Cherry Tomatoes', NULL, NULL, 250.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0bb33578-0ec0-4cdc-a234-82ed620f55d0', '59f9665c-135e-47a7-a4b9-c53d54f91181', NULL, 'Parmesan', NULL, NULL, 40.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ffd1bf4f-3d1b-415f-a43d-dfadf8553caf', '736f57cf-de96-4bfa-a572-2ac75cff9925', '8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', 'Rolled Oats', NULL, NULL, 100.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('30f32163-35d4-4a87-88b9-f6ede7824190', '736f57cf-de96-4bfa-a572-2ac75cff9925', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'Natural Yoghurt 400g', NULL, NULL, 300.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('8687cb11-3c15-49f1-9aad-51f34d3808ff', '736f57cf-de96-4bfa-a572-2ac75cff9925', '85b30619-ebeb-459f-a6c3-c123cce38ab2', 'Frozen Blueberries', NULL, NULL, 120.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('aaba9e73-79c3-401f-8907-99c13fe1e134', '736f57cf-de96-4bfa-a572-2ac75cff9925', '5cd24d64-30d6-4936-b13d-268845618032', 'Wildflower Honey', NULL, NULL, 20.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('5358f983-6423-42b7-ab5d-e33768e3f763', '8f09c05f-ae10-42f6-a355-abd186e75841', 'a2cb8657-0e93-43db-a962-6c5670f4b141', 'Bananas', NULL, NULL, 500.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('e1191938-88ff-46e1-9e97-e8e20b416b4e', '8f09c05f-ae10-42f6-a355-abd186e75841', '08da4f37-6c57-44fd-b5b5-194ff528ed05', 'Wheat Flour Type 550', NULL, NULL, 250.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ec8148ed-e31a-40e9-bde2-f75be5ed1eb1', '8f09c05f-ae10-42f6-a355-abd186e75841', '8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', 'White Sugar 1kg', NULL, NULL, 150.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0ed0b5e0-2b83-4b54-8368-338f31f4f38a', '8f09c05f-ae10-42f6-a355-abd186e75841', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 'Eggs Medium 10pk', NULL, NULL, 1.000, '10215777-64f1-4376-ac45-1cc7b9b2128b', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3a683534-3ae0-453a-88b2-108bc338f707', '8f09c05f-ae10-42f6-a355-abd186e75841', '064b9631-706c-49d0-84a4-8651d76ca29b', 'Butter Extra 82%', NULL, NULL, 100.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d81a0974-c6eb-49bd-a373-93d48e82335d', '8f09c05f-ae10-42f6-a355-abd186e75841', '9fbcd4fb-3632-4189-a80a-26d869595602', 'Baking Powder', NULL, NULL, 8.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('aac2a408-1a69-471d-8a78-5d736d26749d', '8f09c05f-ae10-42f6-a355-abd186e75841', '7a1102e9-8820-448a-a5c5-dd657ad519c8', 'Walnuts', NULL, NULL, 100.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 6, NULL, NULL, NULL, NULL, '["nuts"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a570b9aa-7790-4292-8944-5d5836ecb892', '04ed959b-e92a-438c-818d-05c859cb17aa', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 'Eggs Medium 10pk', NULL, NULL, 1.000, '10215777-64f1-4376-ac45-1cc7b9b2128b', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bfa79326-9191-4b36-9c98-8ce5710b230f', '04ed959b-e92a-438c-818d-05c859cb17aa', 'ab1b9846-c8e7-45c6-b695-e655763069ab', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a4ef1a73-8d64-406c-8bd6-309787c41263', '04ed959b-e92a-438c-818d-05c859cb17aa', '7cbb5eaa-cc3f-495c-80c3-24959ac78c68', 'Sweet Paprika', NULL, NULL, 3.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('745c5994-1c18-4afc-9990-ea2e9ad2428e', '04ed959b-e92a-438c-818d-05c859cb17aa', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3812e9ca-fb18-4dbb-9e4a-b83d80bef0da', '04ed959b-e92a-438c-818d-05c859cb17aa', NULL, 'Onion', NULL, NULL, 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('fd19749d-62a1-4bf2-8dea-a94f76f3b30e', '47f1b501-370e-49ed-8042-8a63192d37e6', '08da4f37-6c57-44fd-b5b5-194ff528ed05', 'Wheat Flour Type 550', NULL, NULL, 250.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('004300ec-1dc9-4cb4-b7a0-835e613e7895', '47f1b501-370e-49ed-8042-8a63192d37e6', '656e5398-3fa1-4738-9447-f448081d8e8c', 'UHT Milk 3.2%', NULL, NULL, 500.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c7c87cf5-992a-4608-b9cf-3b580b37024d', '47f1b501-370e-49ed-8042-8a63192d37e6', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 'Eggs Medium 10pk', NULL, NULL, 1.000, '10215777-64f1-4376-ac45-1cc7b9b2128b', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3f0d7f56-22ce-42db-9653-35c210a9fa59', '47f1b501-370e-49ed-8042-8a63192d37e6', '0b20e3d3-4b5e-4b47-820c-2513e24ae9cd', 'Strawberries', NULL, NULL, 300.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('10f4e758-5343-4a8c-adb4-2994e92823b2', '47f1b501-370e-49ed-8042-8a63192d37e6', '72d583c2-ff3d-4f7f-ae15-5333b3840dd0', 'Sunflower Oil', NULL, NULL, 25.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('de25972c-6c9c-4d15-ade0-979912d6ce59', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', 'b3b21331-b2d7-4601-ba68-c2cc968c267e', 'Fusilli Pasta', NULL, NULL, 300.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0a543a09-e3f5-4ecd-ad00-cf657fe354a3', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', '4bc01401-9706-4db0-970f-2f2fae6d685e', 'Tuna in Oil', NULL, NULL, 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["fish"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('04a37510-9f05-4b6b-8d13-b40307a33673', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', '62ebb3c9-a0e7-4f16-8565-b3edfa33ab5e', 'Canned Sweetcorn', NULL, NULL, 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('61a8abb8-81c8-4b65-a374-419d18531986', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', 'cab4fed8-bf0a-4edb-919e-ad8b9fb4a7de', 'Mayonnaise', NULL, NULL, 75.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('4ed073db-a939-4bda-a7c2-f6f144e1d928', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', '7b1c4b4c-8fb3-4451-bc39-77be69e7915e', 'Cucumber', NULL, NULL, 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('435b7cd8-82e5-42fa-a08d-6eb9441a3031', '5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', NULL, 'Fresh Basil', NULL, NULL, 10.000, '0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);


--
-- Data for Name: recipe_tag_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('04ed959b-e92a-438c-818d-05c859cb17aa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Shakshuka', 'Eggs poached in a spiced tomato sauce, straight from the pan.', '1. Soften the sliced onion in the oil with the paprika.
2. Add the tomatoes and simmer until thick.
3. Make four wells, crack in the eggs, cover and cook until set.', 2, 25, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/04ed959b-e92a-438c-818d-05c859cb17aa/cover.f495462017a6.jpg', NULL, '["breakfast", "vegetarian"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.84012+00', '2026-11-22 23:36:22.483962+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('0b6620d6-43b9-47ad-8691-252b4d19ecf5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Spaghetti with Garlic and Oil', 'The five-ingredient supper worth knowing by heart.', '1. Cook the spaghetti in well-salted water.
2. Warm the oil gently with the garlic; do not let it brown.
3. Toss the drained pasta in the oil with a splash of cooking water.', 2, 20, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/0b6620d6-43b9-47ad-8691-252b4d19ecf5/cover.02cc9ab66567.jpg', NULL, '["quick", "pasta"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.831436+00', '2026-11-22 23:36:22.483966+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('1e236768-1c83-4f26-be5b-01f870c745f4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Chicken Curry with Jasmine Rice', 'A weeknight curry from the freezer and the spice drawer.', '1. Brown the diced chicken, then stir in the curry powder.
2. Add the tomatoes and coconut milk; simmer for twenty minutes.
3. Serve over the rice.', 4, 40, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/1e236768-1c83-4f26-be5b-01f870c745f4/cover.7dc6671c2bc9.jpg', NULL, '["dinner"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.833766+00', '2026-11-22 23:36:22.483967+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('47f1b501-370e-49ed-8042-8a63192d37e6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Pancakes with Strawberries', 'Saturday breakfast, twelve thin pancakes.', '1. Whisk the flour, milk and eggs into a thin batter; rest it ten minutes.
2. Fry in a lightly oiled pan, a ladle at a time.
3. Serve with sliced strawberries.', 4, 30, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/47f1b501-370e-49ed-8042-8a63192d37e6/cover.3882e8b3d23f.jpg', NULL, '["breakfast"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.841501+00', '2026-11-22 23:36:22.483967+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('59f9665c-135e-47a7-a4b9-c53d54f91181', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Penne with Red Pesto', 'Fifteen minutes, one pan, no chopping board.', '1. Cook the penne.
2. Halve the tomatoes and warm them in the pesto.
3. Toss with the pasta and finish with grated parmesan.', 2, 15, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/59f9665c-135e-47a7-a4b9-c53d54f91181/cover.a2c6108f9a7c.jpg', NULL, '["quick", "pasta", "vegetarian"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.835873+00', '2026-11-22 23:36:22.483967+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('5ba3c69d-563a-4a9d-8a3c-db00d6b922ab', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tuna Pasta Salad', 'A lunchbox that keeps until Wednesday.', '1. Cook the fusilli and cool it under running water.
2. Mix with the tuna, sweetcorn, diced cucumber and mayonnaise.
3. Tear the basil over the top before serving.', 3, 20, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/5ba3c69d-563a-4a9d-8a3c-db00d6b922ab/cover.f2cb55c523ee.jpg', NULL, '["quick", "pasta"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.842671+00', '2026-11-22 23:36:22.483968+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('736f57cf-de96-4bfa-a572-2ac75cff9925', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Overnight Oats with Blueberries', 'Made the evening before, eaten on the way out.', '1. Stir the oats into the yoghurt with a spoon of honey.
2. Fold in the blueberries straight from the freezer.
3. Cover and leave in the fridge overnight.', 2, 10, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/736f57cf-de96-4bfa-a572-2ac75cff9925/cover.dfc3aa2068eb.jpg', NULL, '["breakfast", "vegetarian"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.837759+00', '2026-11-22 23:36:22.483968+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('8f09c05f-ae10-42f6-a355-abd186e75841', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Banana Bread', 'What the bananas going brown on the counter are for.', '1. Mash the bananas and beat in the melted butter, sugar and eggs.
2. Fold in the flour, baking powder and chopped walnuts.
3. Bake in a lined loaf tin at 175 C for about an hour.', 8, 70, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/8f09c05f-ae10-42f6-a355-abd186e75841/cover.3af478a733d8.jpg', NULL, '["baking"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.838926+00', '2026-11-22 23:36:22.483968+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('9a2de8ce-44a8-4e33-b54f-785cb610c5f8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tomato and Chickpea Stew', 'One pot, thirty minutes, everything from the pantry shelf.', '1. Warm the oil and toast the paprika for thirty seconds.
2. Add the passata and the drained chickpeas.
3. Simmer for twenty minutes, season and serve with bread.', 4, 30, '7e14c7c3-6333-4270-93ad-2bc976a705d7/recipes/9a2de8ce-44a8-4e33-b54f-785cb610c5f8/cover.a73330974669.jpg', NULL, '["quick", "vegetarian"]', false, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.830455+00', '2026-11-22 23:36:22.483969+00');


--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_exclusions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('b6fe6959-0bfb-47fc-9d9f-4603fa4c45aa', '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, NULL, 'Coconut Milk', 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', 'For the curry on Wednesday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:36:21.853037+00', '2026-11-22 23:36:21.853039+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('8e55dde6-bd93-4d23-b860-d78bacf1706d', '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, NULL, 'Parmesan', 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', 'For the penne on Friday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:36:21.85304+00', '2026-11-22 23:36:21.85304+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('855e927f-56f7-4fa3-a425-12b4ec3f40c3', '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, NULL, 'Onion', 3.000, '8352703e-3fa0-450f-9d3a-031f662471ce', 'Shakshuka on Saturday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:36:21.853041+00', '2026-11-22 23:36:21.853041+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('f72b748c-2fcd-461a-a392-ad9eec36dd14', '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, NULL, 'Fresh Basil', 1.000, '8352703e-3fa0-450f-9d3a-031f662471ce', 'Tuna pasta salad', NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:36:21.853042+00', '2026-11-22 23:36:21.853042+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('362a8e67-1d60-4406-95a4-3516d65f67a4', '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, NULL, 'UHT Milk 3.2%', 2.000, '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:36:21.853042+00', '2026-11-22 23:36:21.853043+00', '656e5398-3fa1-4738-9447-f448081d8e8c', NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('ba997ca8-efd4-433d-9e4b-41793d159d5d', '3d203cfa-3d0d-423f-97ff-f0889009cd39', NULL, NULL, 'Bananas', 1.000, '61cebc75-7127-4699-85e2-7617ae9db641', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-22 23:36:21.853043+00', '2026-11-22 23:36:21.853043+00', 'a2cb8657-0e93-43db-a962-6c5670f4b141', NULL);


--
-- Data for Name: shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_lists (id, organization_id, name, status, completed_at, archived_at, created_by, created_at, updated_at) VALUES ('3d203cfa-3d0d-423f-97ff-f0889009cd39', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Weekly shop', 'active', NULL, NULL, '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.850727+00', '2026-11-22 23:36:21.850728+00');


--
-- Data for Name: stock_anchors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('df1f2cb5-052f-4a5e-874b-195aab6e1cbb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '223c46ae-fe53-4540-a3f4-ab350c9a4fac', '7559c4d7-ce55-4d0a-bbc5-887c559e336d', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('956fd3d3-119b-4a2c-8028-6115c000a148', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', '7a9e185d-1e23-4368-85cd-b555da7b10ea', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('47d53251-d393-44f5-98e8-61557a2d3f65', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '972d00df-0e6c-4f20-a77f-ebb4515d1e61', '7a9e185d-1e23-4368-85cd-b555da7b10ea', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('058a8697-81b3-4e7d-93c9-9bdca48453a2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fd3f7025-38be-4c94-9805-708ad6525e50', 'a2cc3792-a342-48e5-bcac-39af703f7b18', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8dd502bc-3a11-4f14-b037-1558818a477c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7b1c4b4c-8fb3-4451-bc39-77be69e7915e', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4ea56079-4e42-421f-9782-b2096b087860', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9fbcd4fb-3632-4189-a80a-26d869595602', '211e5889-8bcb-43e8-98ef-685b7582bef3', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0cb73d77-a324-46c7-9602-12a4754b8f2a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('64d297ed-2d4e-4f3c-b4dd-024d171b0503', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'bb6529e1-926f-41cd-9b74-c94a03b55f56', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a61af8e5-e6e1-4e92-b403-d1ae74b9785e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e9791bc9-10f8-49cd-8348-9dda0122063e', 'd67495d7-2c6d-48b0-b476-132f66241a6d', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('afca218f-a531-41e0-bddb-02189b1135a3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0c08476d-f8db-4d18-ac72-a46784985a7d', '1b2c39b0-cc65-4b34-a95f-fd944492712f', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fd3a9de9-6cbf-4712-91ee-037a401e6421', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1a77aa58-6966-427d-8d61-7dd1b4979dd3', '7559c4d7-ce55-4d0a-bbc5-887c559e336d', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('31f98e59-76c6-4c79-8a09-329ba88e3e93', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dbf12d9e-0cfc-4c10-9844-2c06f6c6697f', '7c37dfca-c298-4205-87e3-c530c5e88990', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3e4091a2-1ca3-420c-9873-e8f5c5f6a654', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('336d2b66-6e3c-42a2-8056-cff1b78dfd9e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', 'd67495d7-2c6d-48b0-b476-132f66241a6d', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2c25dc3a-9ee1-422a-9b6f-4e64489c2556', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '027755f4-0294-42a1-a43c-d5830beaa781', 'ab326239-0c31-4f35-8522-9c914c8be9c3', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cb5bd675-6724-491c-a0c9-c279615ca9dc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '150c1f18-1619-4b71-9c0c-d4adfacf209a', '1b2c39b0-cc65-4b34-a95f-fd944492712f', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7f461eab-998f-4080-9ebc-1b0c876f3fd6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ab1b9846-c8e7-45c6-b695-e655763069ab', '7c37dfca-c298-4205-87e3-c530c5e88990', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('94a90ca4-981a-4b8a-be98-86f645ee5fcf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b61f4b6-f554-4610-931d-26a0886d231a', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c607d763-2a5e-4ff9-bf4b-6460f82749f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95d6a10f-937b-4b74-a0d4-a012126d9f52', '7c37dfca-c298-4205-87e3-c530c5e88990', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4b1c68ed-3eb1-48b5-8327-9408c28ac1de', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ff1d121d-4fb2-458c-b16d-08824802ade1', 'dc348dec-fee9-4f38-8959-8a0c1f02f466', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e918cb3b-0f55-426c-9951-17e6bd994fa4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8742e916-2785-4512-ab27-fed4ded3c473', '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f209813a-e71a-4574-a8b8-9deca3c96e62', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd94e5659-0dfc-4e0b-bf49-0340f296bdf5', '96bede93-9802-49a9-952b-075e2301156b', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ebd9f8e5-a8c6-421c-a3e6-d5ec2c7b07f6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a738adfd-0757-4836-a4b9-70ef1261378f', '7a9e185d-1e23-4368-85cd-b555da7b10ea', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f82f0a0e-66ce-47ea-9c3a-5e47db86b537', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b9014711-5ce7-4aac-8f11-e4748fff949a', '211e5889-8bcb-43e8-98ef-685b7582bef3', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('dbe644e1-23a4-40dc-a3bb-2ed209b206f6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('57b321e9-7df6-4a10-bf62-b09378f3d10a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a0daba86-1558-4796-aee7-62cae1c7bcaa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '52559aed-459d-4b60-bdfb-9e8a712c46a7', '96bede93-9802-49a9-952b-075e2301156b', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('35003f2a-a211-417b-8486-413ab8499673', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fbc113bb-6608-448b-a260-ed9dd4b124d6', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4a48301f-14dc-44f1-8144-5ea3d4285a4f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '595520ae-5062-47f9-9e47-27082e7bc22f', '7c37dfca-c298-4205-87e3-c530c5e88990', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('22fe6277-0381-4a70-99e8-67276a5ce737', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', '96bede93-9802-49a9-952b-075e2301156b', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('56123f0d-f56c-4bd8-b9be-af3488574b3b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', 'ab326239-0c31-4f35-8522-9c914c8be9c3', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a5878ee0-e5f5-41c9-8a68-604c6a133318', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45cccb60-d659-4421-a067-32c271cbf33f', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b4c0dd0a-3a0f-49c6-b9f7-b5038f22fe6f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0ca8c933-f46f-4837-bd5e-2f767dfb3ee1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '72d583c2-ff3d-4f7f-ae15-5333b3840dd0', '7c37dfca-c298-4205-87e3-c530c5e88990', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3687e438-2b06-49c2-983c-d227710b1825', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0052c85e-7ae7-42ac-8a15-9a144ea74f59', 'dc348dec-fee9-4f38-8959-8a0c1f02f466', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('93445a04-6a5c-482d-a860-651e0780c14a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '319dc161-97d4-4a04-9b3d-cc64d9d704dd', '96bede93-9802-49a9-952b-075e2301156b', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('62063cbb-17a7-404b-9efd-2044cd96c9c8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a46b401f-2984-4e21-8c48-ac35bb6c1b89', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6d36f2b9-47c7-4589-905f-b904d79bb551', '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e7c30392-0176-4d97-b503-a0b0dd19dc36', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'adb37118-6006-4d99-8159-7f92dfcd47da', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '2026-11-22 23:36:19.116576+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8e65eaca-f0f9-4c57-ba07-b9dfc0172887', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('22106cb7-e4e3-4218-be94-34b3a5502af4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('151531ab-4732-4b60-8a79-ec1f5cc7068c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4ad92830-ad4c-4ef0-b56a-7455b4626136', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('90bec4ae-a936-4f5f-982d-42c494ba7aeb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('62aac095-c2a9-4a7b-a3b2-baf47b30689d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '95c56c34-8315-438d-b2c2-100085ecf05d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('92751c15-28fd-48bc-9423-8238abfb7baa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '755ea5f1-9325-4c48-acc5-91fe380b59f1', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('950b7695-e989-4a74-b49b-47ea0e143b6a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6b13fd04-effb-417c-93a5-0bed49641c03', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cd00b6cf-ff8e-4825-a5c5-7b1959212d85', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3569af13-7ef8-4088-bb80-8465b687c297', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('858337ad-94ee-451f-bebf-f5cf09b4afec', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8b76d788-e8aa-4349-916e-501efcc88f1e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('751be8d6-4524-4bdc-95fa-0395dd3e8992', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0e575d8e-3083-47fe-94ac-4670332a1a92', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('48593755-2393-4eeb-8a03-776b917993df', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('92ca0482-469c-48f6-aab8-ec2ff57dce4c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5dc21113-b049-4ec0-bae4-c35c9ce297bf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '95c56c34-8315-438d-b2c2-100085ecf05d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('61b48323-249f-4298-aa31-d0129b549099', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('23fddcf1-c434-42e0-abea-801d582a51c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cc25639f-6b9b-4721-99df-9c3da50d3b97', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7e0fe435-ea61-4adf-a50d-232a0e89492d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('65760e92-ffae-457c-a90f-a035313b4441', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608eba71-431c-44b2-965e-4abc27a6ab8a', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2093037f-40c1-43de-aa3a-6cfb0ac83e91', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('486dcfa2-9e0e-48c5-8385-8e4bb1e0d9bd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b08109fb-a20a-4309-bdc8-5261c65dbe73', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d2d3f9e5-0a7e-4d1b-8b12-5acf70a933ed', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9ebe9853-1387-4133-a01e-17025fe0d990', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7b392e3f-02e9-4250-bbbc-1a5086dddfa5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f8009fb6-b8cd-4c91-a2b7-331184a4492e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0dd66394-83c4-420e-99e8-26c8f09c98d6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('34f481b9-f309-4a37-94d7-d9b5c01acf99', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('32e2e8ed-83cf-4055-85eb-ae41efe38f2c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', '95c56c34-8315-438d-b2c2-100085ecf05d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('082daa07-d2be-48e2-9074-a9ef08d4fa71', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('24861b0e-aed0-4c31-bb14-4b1e18cfec49', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a4d9510e-4940-4fa3-aacd-db82dd30bf44', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6ae31e0a-ae52-447f-adaf-cdc943fbb11c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('99dbef53-b4ce-4959-84af-55088f156e3e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2dd23045-1fea-4710-a509-e82a0cb0643d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('43b5e2a6-3507-4999-a447-344e1a2aacad', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('69e71d14-a898-49e8-9d94-e2ca2d047f4f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1b7291c3-4cfb-4368-8866-6466881d1e48', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3f59eacf-9dfb-4b0d-a8ef-19e3d1f7aa19', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '95c56c34-8315-438d-b2c2-100085ecf05d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('844cb6a5-65e4-4efb-9345-76a94b72fdf8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ebfc6008-d86b-4cc9-9af2-9dfaf30007cb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9d0ec701-ceaa-4000-9f2a-6ebd3d0a3436', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c9ea913b-a230-4b53-9d41-516157833e67', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('395184bd-affb-4ed1-89aa-2723fe5fe951', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c6025aeb-d1fd-4d6d-a9d2-c4fbf7f1e2d9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1e779cc2-71cd-4ac6-a546-e5271ee194b8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d9570bc4-5f68-425d-ab19-e2c7ae0ba2c4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5982bc23-9edf-4925-8697-566d6360c4b2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('063484d3-82f6-4e9c-a592-61e2dc86d59a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', '1ed0662e-7961-450a-a0f8-54ac1250f82a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cf750615-1d52-4ae4-ae3a-5ef702f907a6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b8d7c0d8-f03e-4280-a6a5-55efe96635f5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('67f086c2-156f-4ae5-b0c1-ccc5d7e8a8a2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0538462b-58e7-4115-818d-1bd96505f72d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9159c639-770f-4915-a2b1-2b6902299fe9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c9e9d237-e156-45cb-bca3-f6b10a307c55', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', '6b736c79-ab15-4f7e-882e-160ba782738d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('be30f2d7-cd50-4575-b403-0bf338e33198', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', '95c56c34-8315-438d-b2c2-100085ecf05d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('27d03521-54aa-4c9a-8204-7cd9a5734851', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '799a7982-e7be-4e9f-8982-4062ab51f1ad', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3f81dfca-23dc-41c3-a692-6865ac1af892', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2073f1c2-c666-40cc-8ccc-5b472f41a010', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8df8e18a-9499-4c7a-97c3-3ab846ff91c3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3ca43384-58f7-45c8-a7ef-705d8d709c02', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('472a291e-e36d-4450-b958-704cc109b4b7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ffe7316e-856c-4bca-a3eb-cf82f20b7d76', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0ea6e56d-113d-4dfb-a9c8-928c8d4479a5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('23329af8-90de-4ef3-8e4d-3f8a4c1d0e03', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('00da2300-d1c8-429b-8f5b-ec083e100391', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '68482959-681d-40b9-8bcf-d052b31def99', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('829bcadb-6992-4f77-90e1-45c8bfdb08ac', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '010c3392-34d5-4fc7-be38-c536e1e95ca1', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fa8bd9f5-85ce-4649-bde6-76af57f82ac5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '24937559-02f7-4737-9908-083c06714c5c', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bebab02e-f7f3-41b0-a98c-939f26ec2d6c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '95c56c34-8315-438d-b2c2-100085ecf05d', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('07bf360f-bc84-4097-8fcc-87fcac357ffb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '608e2d51-d0d0-4a64-80be-dad9c224283a', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('92ff4b4c-fd00-439d-add5-c0427a53565b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '8b6f6b4a-9882-4863-a243-f5a107568dee', '2026-11-22 23:36:19.202168+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('edd49a28-c1fe-45eb-8ddd-0b89ec78c04c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '2026-11-22 23:36:19.279692+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ac1c9332-3e11-4504-bb8b-6bf80d672549', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', '211e5889-8bcb-43e8-98ef-685b7582bef3', '2026-11-22 23:36:19.279692+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('352330eb-44f5-4c26-8dd9-148ec3e3e19c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', '211e5889-8bcb-43e8-98ef-685b7582bef3', '2026-11-22 23:36:19.279692+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('82ec997c-6945-4522-93a0-1f1c2fed8269', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '2026-11-22 23:36:19.969054+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('dfabd9de-7da0-45e6-9ae2-a670237e9f15', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '2026-11-22 23:36:19.969054+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5ac79edd-280f-4fb0-a2db-b5ed60b83506', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '2026-11-22 23:36:19.969054+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6af67158-bb2e-4dfc-aecb-3174cc0a01ae', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '2026-11-22 23:36:19.969054+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7f3fbf06-170b-4f74-bf3d-926c20a88693', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', '211e5889-8bcb-43e8-98ef-685b7582bef3', '2026-11-22 23:36:21.607208+00');


--
-- Data for Name: stock_ledger_totals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', '608e2d51-d0d0-4a64-80be-dad9c224283a', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '755ea5f1-9325-4c48-acc5-91fe380b59f1', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '608eba71-431c-44b2-965e-4abc27a6ab8a', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '1ed0662e-7961-450a-a0f8-54ac1250f82a', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '799a7982-e7be-4e9f-8982-4062ab51f1ad', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', '608e2d51-d0d0-4a64-80be-dad9c224283a', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '68482959-681d-40b9-8bcf-d052b31def99', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', '1ed0662e-7961-450a-a0f8-54ac1250f82a', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', '608e2d51-d0d0-4a64-80be-dad9c224283a', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', '608e2d51-d0d0-4a64-80be-dad9c224283a', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', '24937559-02f7-4737-9908-083c06714c5c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '223c46ae-fe53-4540-a3f4-ab350c9a4fac', '7559c4d7-ce55-4d0a-bbc5-887c559e336d', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', '7a9e185d-1e23-4368-85cd-b555da7b10ea', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '972d00df-0e6c-4f20-a77f-ebb4515d1e61', '7a9e185d-1e23-4368-85cd-b555da7b10ea', 8.700);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7b1c4b4c-8fb3-4451-bc39-77be69e7915e', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9fbcd4fb-3632-4189-a80a-26d869595602', '211e5889-8bcb-43e8-98ef-685b7582bef3', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'bb6529e1-926f-41cd-9b74-c94a03b55f56', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e9791bc9-10f8-49cd-8348-9dda0122063e', 'd67495d7-2c6d-48b0-b476-132f66241a6d', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '0c08476d-f8db-4d18-ac72-a46784985a7d', '1b2c39b0-cc65-4b34-a95f-fd944492712f', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dbf12d9e-0cfc-4c10-9844-2c06f6c6697f', '7c37dfca-c298-4205-87e3-c530c5e88990', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1a77aa58-6966-427d-8d61-7dd1b4979dd3', '7559c4d7-ce55-4d0a-bbc5-887c559e336d', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', 'd67495d7-2c6d-48b0-b476-132f66241a6d', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '027755f4-0294-42a1-a43c-d5830beaa781', 'ab326239-0c31-4f35-8522-9c914c8be9c3', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '150c1f18-1619-4b71-9c0c-d4adfacf209a', '1b2c39b0-cc65-4b34-a95f-fd944492712f', 6.500);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ab1b9846-c8e7-45c6-b695-e655763069ab', '7c37dfca-c298-4205-87e3-c530c5e88990', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '95d6a10f-937b-4b74-a0d4-a012126d9f52', '7c37dfca-c298-4205-87e3-c530c5e88990', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b61f4b6-f554-4610-931d-26a0886d231a', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ff1d121d-4fb2-458c-b16d-08824802ade1', 'dc348dec-fee9-4f38-8959-8a0c1f02f466', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '8742e916-2785-4512-ab27-fed4ded3c473', '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', 8.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd94e5659-0dfc-4e0b-bf49-0340f296bdf5', '96bede93-9802-49a9-952b-075e2301156b', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 13.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a738adfd-0757-4836-a4b9-70ef1261378f', '7a9e185d-1e23-4368-85cd-b555da7b10ea', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', '211e5889-8bcb-43e8-98ef-685b7582bef3', 21.220);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b9014711-5ce7-4aac-8f11-e4748fff949a', '211e5889-8bcb-43e8-98ef-685b7582bef3', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '52559aed-459d-4b60-bdfb-9e8a712c46a7', '96bede93-9802-49a9-952b-075e2301156b', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fbc113bb-6608-448b-a260-ed9dd4b124d6', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '595520ae-5062-47f9-9e47-27082e7bc22f', '7c37dfca-c298-4205-87e3-c530c5e88990', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 44.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', '96bede93-9802-49a9-952b-075e2301156b', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fd3f7025-38be-4c94-9805-708ad6525e50', 'a2cc3792-a342-48e5-bcac-39af703f7b18', 11.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 17.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', 'ab326239-0c31-4f35-8522-9c914c8be9c3', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '45cccb60-d659-4421-a067-32c271cbf33f', '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '72d583c2-ff3d-4f7f-ae15-5333b3840dd0', '7c37dfca-c298-4205-87e3-c530c5e88990', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '0052c85e-7ae7-42ac-8a15-9a144ea74f59', 'dc348dec-fee9-4f38-8959-8a0c1f02f466', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '319dc161-97d4-4a04-9b3d-cc64d9d704dd', '96bede93-9802-49a9-952b-075e2301156b', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '6d36f2b9-47c7-4589-905f-b904d79bb551', '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', 5.100);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'adb37118-6006-4d99-8159-7f92dfcd47da', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 6.900);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', '211e5889-8bcb-43e8-98ef-685b7582bef3', 0.440);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', '211e5889-8bcb-43e8-98ef-685b7582bef3', 11.400);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 24.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 18.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('7e14c7c3-6333-4270-93ad-2bc976a705d7', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 50.000);


--
-- Data for Name: stock_lots; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_lots (id, organization_id, product_template_id, name, is_serial, expiry_date, production_date, use_by_date, removal_strategy, status, meta_data, created_at) VALUES ('428858fb-8cdd-4c0e-920a-46b2c0372c9a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', '20261122-1', false, NULL, '2026-11-22', NULL, 'FIFO', 'active', NULL, '2026-11-22 23:36:21.786249+00');


--
-- Data for Name: stock_moves; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('286fbad3-d596-4c00-9bee-c59029fb9897', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ba38ccac-2151-4fdc-b7b1-1e789ae583f6', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-10-06 07:00:00+00', '2026-11-22 23:36:19.322103+00', '2023-10-06 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7cc664b7-7e69-45a0-8eb2-92e41ca2ba4d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c8ce5c15-05e2-4785-b3f0-0742eb86269b', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-10-08 08:07:00+00', '2026-11-22 23:36:19.332446+00', '2023-10-08 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ece5df99-543f-44fb-969d-e5aa45d6f763', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f00dfad4-8c93-445d-b6fd-824a85d758db', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-11-06 09:14:00+00', '2026-11-22 23:36:19.338208+00', '2023-11-06 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('502c6a21-57c9-4367-896b-73d86d361444', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '152fdd45-eae6-4f1c-96dd-e0f9f04f737c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-11-08 10:21:00+00', '2026-11-22 23:36:19.342467+00', '2023-11-08 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('97895b15-110e-4ab1-883b-43593e8d7ddc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '739459f0-5c48-495a-9cc2-8069b7d9bc49', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-11-10 11:28:00+00', '2026-11-22 23:36:19.348216+00', '2023-11-10 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a7efd4bd-b8ba-4bf0-a1f6-4c6ea3244eae', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '32543762-ef9b-42b6-a7e1-5ed3b1d52cb1', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-12-09 12:35:00+00', '2026-11-22 23:36:19.352295+00', '2023-12-09 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fcf3a805-98cd-4d2a-b783-b791b98b2a49', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '794ed6bb-f35c-403e-85af-5b4571a5d1b6', '29df2390-1a60-43fd-ba97-7824689adfc1', '2023-12-11 13:42:00+00', '2026-11-22 23:36:19.356199+00', '2023-12-11 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f2595361-be52-4a41-86cd-831f786d71ba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '20d31129-5635-4d1e-a235-69f723c3abe9', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-01-11 14:49:00+00', '2026-11-22 23:36:19.360066+00', '2024-01-11 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('34ba58c3-5576-4f8c-a30b-84f68ce680cc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '14857ba9-2ee1-4bfc-bc29-213037d82cbb', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-01-13 15:56:00+00', '2026-11-22 23:36:19.36292+00', '2024-01-13 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b9832a0c-dea8-41f9-a932-7cc9973b2bf8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '86a27834-c1e0-4c6a-a058-5232b6c74377', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-02-11 16:03:00+00', '2026-11-22 23:36:19.366484+00', '2024-02-11 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('60938a8e-271f-4d0b-b0fc-f3bddc48e932', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '180acd4a-9080-44f7-919a-c5b8e11b2235', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-02-13 07:10:00+00', '2026-11-22 23:36:19.370461+00', '2024-02-13 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bfd34a25-2be0-4f3d-abd3-538cad7fc913', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5279e39e-4169-46fa-8e16-121fccfbcb83', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-02-15 08:17:00+00', '2026-11-22 23:36:19.374558+00', '2024-02-15 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('00149d99-d63b-43c4-9677-74a158924495', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8fbe90bd-e456-4306-b470-8f1857c34d27', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-03-15 09:24:00+00', '2026-11-22 23:36:19.37845+00', '2024-03-15 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3c53a9ef-5660-4ad2-a851-94a7f088fad7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c505fa5e-00bd-4487-bb17-729dec0ace55', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-03-17 10:31:00+00', '2026-11-22 23:36:19.382152+00', '2024-03-17 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0c5ae46c-7c54-4f06-b9b2-a0c1a6e21936', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f812827a-692f-4306-ae0b-2ef7ea7dcbba', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-04-17 11:38:00+00', '2026-11-22 23:36:19.386352+00', '2024-04-17 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('46fa3bb8-5bb7-4e91-bdd9-728e18aa2e68', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a5cb1ff0-a879-4b60-a87a-e0168bd14ad6', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-04-19 12:45:00+00', '2026-11-22 23:36:19.390078+00', '2024-04-19 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bff99a23-36fb-4b8d-8b5c-4979631f11b5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '991acbdc-364e-44e2-a493-a92927745ce9', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-05-18 13:52:00+00', '2026-11-22 23:36:19.393276+00', '2024-05-18 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a276c60a-401b-41bd-8e70-72cffffee50f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a877e0c6-d6a5-4993-a39d-239e009e8b02', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-05-20 14:59:00+00', '2026-11-22 23:36:19.397302+00', '2024-05-20 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4dd85307-b323-4f06-91d1-152d4e988fb8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a212def6-0aef-4af7-bd98-cf89ef54a26d', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-05-22 15:06:00+00', '2026-11-22 23:36:19.401059+00', '2024-05-22 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8fa7d90f-ab7e-4cc2-be8c-5c404b2c7e00', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b17bb4ee-d7de-462a-b1ee-a43ecef00e3c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-06-20 16:13:00+00', '2026-11-22 23:36:19.40464+00', '2024-06-20 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b5ece841-d1ca-4df0-9489-6b9400dc9e0c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4f6a2db0-1898-4158-86b7-d25e9af507ab', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-06-22 07:20:00+00', '2026-11-22 23:36:19.409463+00', '2024-06-22 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9426e19d-02b3-45de-8144-307922bb7c39', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0bd26c7a-03b0-4fae-b0ca-120cd4a9d427', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-07-23 08:27:00+00', '2026-11-22 23:36:19.41393+00', '2024-07-23 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('59c20a75-8e1e-4482-bc5a-29a8c662ef67', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1a2d478c-e147-4f82-a44d-be78168ce2c5', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-07-25 09:34:00+00', '2026-11-22 23:36:19.418167+00', '2024-07-25 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5d769368-d366-4c4c-82c2-3b3289fa043c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '755ea5f1-9325-4c48-acc5-91fe380b59f1', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4a9b8e1a-282e-4925-828f-3a112f378675', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-08-23 10:41:00+00', '2026-11-22 23:36:19.422126+00', '2024-08-23 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fbe5d22e-e73c-4c03-813e-1a10affd97b9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3dfdea05-63b1-45fe-8865-9fbd11c00b91', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-08-25 11:48:00+00', '2026-11-22 23:36:19.425789+00', '2024-08-25 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7878b0e6-17d3-4f9d-bf24-55927ed7fe38', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8b2f9025-058f-4c18-8488-dac04d73c55c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-08-27 12:55:00+00', '2026-11-22 23:36:19.430006+00', '2024-08-27 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c60353ed-52be-482b-a742-3450e2f1023a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '05309808-84b6-41bd-af7a-add0a4f5f78c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-09-25 13:02:00+00', '2026-11-22 23:36:19.433396+00', '2024-09-25 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e50c529b-8929-4b9b-9ed9-d4ab5d0f7ed2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'afedc5dc-0f9a-4176-9ed8-151ebd7c1a8f', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-09-27 14:09:00+00', '2026-11-22 23:36:19.437518+00', '2024-09-27 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('431792dc-7f24-41cd-98c9-52abbda49fc5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a7608b17-cfef-4a49-ac74-e7ad660645a4', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-10-28 15:16:00+00', '2026-11-22 23:36:19.441826+00', '2024-10-28 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('25418f07-dc47-4f8f-9aa8-edd6a9fbb007', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fa9a105c-acb5-4ece-9729-2c4b843049b8', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-10-30 16:23:00+00', '2026-11-22 23:36:19.445417+00', '2024-10-30 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('57c2b51b-a1f2-4b00-a16d-52811cbea623', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '20d2d485-2f5b-4fdb-b999-8c2df86bb2bb', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-11-28 07:30:00+00', '2026-11-22 23:36:19.449842+00', '2024-11-28 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f39413e4-73bb-4a95-8d4d-e8a8fec159e3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7ae279d7-b988-49a3-b3b4-c5721aadfdfc', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-11-30 08:37:00+00', '2026-11-22 23:36:19.454001+00', '2024-11-30 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('71e5f948-5a25-48fd-a231-906493414e0b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5284cea9-d50a-41eb-8eee-c0d78b8529ba', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-12-02 09:44:00+00', '2026-11-22 23:36:19.458852+00', '2024-12-02 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('eea1d64a-1e34-4ab9-8a6c-83f9fa67649d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7aea95cb-44c2-4464-836a-a702c567ead0', '29df2390-1a60-43fd-ba97-7824689adfc1', '2024-12-31 10:51:00+00', '2026-11-22 23:36:19.463308+00', '2024-12-31 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ec3b6f8f-89e9-480b-b661-6f88c42ce4c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ff6ed9dd-46b5-4886-9ab0-1802f068985a', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-01-02 11:58:00+00', '2026-11-22 23:36:19.467289+00', '2025-01-02 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2475f1d4-f013-4e68-a0fe-94d8dc0e91a8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '97e63afc-68cb-48dd-b680-941d67e86298', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-01-04 12:05:00+00', '2026-11-22 23:36:19.471091+00', '2025-01-04 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c1475399-8002-4941-a7c1-5cdf4707b891', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608eba71-431c-44b2-965e-4abc27a6ab8a', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fc3ac3bd-940a-4516-81b1-688e8a5ff68e', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-02-02 13:12:00+00', '2026-11-22 23:36:19.475256+00', '2025-02-02 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('58fc04d7-af27-4324-9f79-309575414032', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c4d23b7d-38e2-4afa-b0b9-a25d29cf3ec5', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-02-04 14:19:00+00', '2026-11-22 23:36:19.480019+00', '2025-02-04 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7f6c8211-94b5-46d6-b9b7-7ee8f51c2bce', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ca1868ce-156a-43f1-91da-c2ed95d26841', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-03-05 15:26:00+00', '2026-11-22 23:36:19.484258+00', '2025-03-05 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c51144eb-4ad3-460d-8444-1dff59273942', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd8f2ea80-a15f-4e14-b62c-7dc8406f42ad', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-03-07 16:33:00+00', '2026-11-22 23:36:19.488468+00', '2025-03-07 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e968d660-225a-4c2d-9a8c-7b2e1e56bd76', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a6f6d8c7-1a4c-4fb3-ae23-a2577403c4b5', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-03-09 07:40:00+00', '2026-11-22 23:36:19.492895+00', '2025-03-09 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f5f57e85-a15c-433e-b668-b877f0d754c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd7876098-9fde-4eee-914b-d96f8bdd1dd0', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-04-07 08:47:00+00', '2026-11-22 23:36:19.498381+00', '2025-04-07 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7cded1a7-9990-48ae-bfbb-d451bb8891f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '33bbe77b-9f04-4f92-8498-e141d0355175', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-04-09 09:54:00+00', '2026-11-22 23:36:19.502617+00', '2025-04-09 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('641e2a44-57d0-44ed-a6ee-50efc2f185f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '28a648a4-31ae-43d7-95c6-14e98522d458', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-04-11 10:01:00+00', '2026-11-22 23:36:19.507908+00', '2025-04-11 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9dfc9290-0659-4c7c-886d-e7d3f946fda7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608eba71-431c-44b2-965e-4abc27a6ab8a', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '04e09bd7-1930-470c-8e59-42fdc778dd79', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-05-10 11:08:00+00', '2026-11-22 23:36:19.511921+00', '2025-05-10 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dc42efed-600a-4813-8048-0908da8118b4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8818a6e0-a58f-4833-b4f4-2b6f08027a6c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-05-12 12:15:00+00', '2026-11-22 23:36:19.51627+00', '2025-05-12 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('56635971-8145-4dad-86be-0da6bb2c9cef', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9c18923a-6caf-43d9-a1be-0342a59d5196', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-06-10 13:22:00+00', '2026-11-22 23:36:19.519989+00', '2025-06-10 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a3234813-9310-48cd-a4e6-8bedceee1723', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3b5a5fb1-02e2-4451-96c3-20574113f40c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-06-12 14:29:00+00', '2026-11-22 23:36:19.524022+00', '2025-06-12 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b9beca76-465c-489e-b04b-73dbe2723889', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '61a498aa-5b41-4588-8a18-0f6cd313e28b', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-06-14 15:36:00+00', '2026-11-22 23:36:19.528196+00', '2025-06-14 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('79c7de2c-ae6c-41e4-9f71-89713ab7d952', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3b95fa2f-965c-4eac-a3fd-8b0adf3c567d', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-07-13 16:43:00+00', '2026-11-22 23:36:19.532855+00', '2025-07-13 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('76dd9453-2b04-4013-ae43-99384094a488', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd3820d60-028b-4d43-ba93-83be24c63573', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-07-15 07:50:00+00', '2026-11-22 23:36:19.537583+00', '2025-07-15 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c445d786-d1b1-4a79-82af-6a1631d0b892', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a3f39f03-1f3b-4020-b376-577ecd694307', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-07-17 08:57:00+00', '2026-11-22 23:36:19.54237+00', '2025-07-17 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('222a6fe9-b38e-4691-8a4e-01d0611ac9e1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '324478f4-a2c0-4a16-b942-9bb64fdb2aeb', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-08-15 09:04:00+00', '2026-11-22 23:36:19.546672+00', '2025-08-15 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bdf3d148-d4a4-45cc-8082-6123f3c50df8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5424c9be-1ec8-4803-9fcd-f306df6bd321', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-08-17 10:11:00+00', '2026-11-22 23:36:19.550944+00', '2025-08-17 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fbfbbb2f-d646-4fa4-bc33-40a7a86995ca', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e53deba0-c735-492d-83d1-17fc96cddd06', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-09-15 11:18:00+00', '2026-11-22 23:36:19.554203+00', '2025-09-15 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0fd9f82f-6ac7-4044-8825-bbfcc4f6690d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2e882229-44b7-4d98-b1e5-a117c8d570b8', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-09-17 12:25:00+00', '2026-11-22 23:36:19.558829+00', '2025-09-17 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('63767ae3-0627-4a24-aff1-da42c64562bd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3ad907b2-900d-4c8f-a1a5-d9a425e1750c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-09-19 13:32:00+00', '2026-11-22 23:36:19.562167+00', '2025-09-19 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9ddbdfd2-a8a1-4f6f-b83f-4d91e8ffb0f2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '14dc5966-6f84-498e-858c-c735b43e8fc7', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-10-18 14:39:00+00', '2026-11-22 23:36:19.566147+00', '2025-10-18 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1e1b5c62-3e32-4aa1-8639-11bc13ec7056', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5cf11707-4a3c-4dc3-af33-56506e767e5e', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-10-20 15:46:00+00', '2026-11-22 23:36:19.570647+00', '2025-10-20 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3f73ac7d-eaef-4c46-9c57-624f2ac613a2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3c188f4b-4f9b-45be-b9fc-d90680a1d317', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-10-22 16:53:00+00', '2026-11-22 23:36:19.575382+00', '2025-10-22 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8de4390f-b1fe-42d0-b64d-04f79e64c0cc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '503df92b-bc7d-44ec-b503-1a6a70a328e3', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-11-20 07:00:00+00', '2026-11-22 23:36:19.579339+00', '2025-11-20 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d90a7c01-4cfb-44ac-9ede-e0f0ae3227f7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'cc25149e-d18b-4524-9692-313f95d2f251', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-11-22 08:07:00+00', '2026-11-22 23:36:19.58345+00', '2025-11-22 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8a628f06-cefd-4a6c-9086-f3ce9f9d086e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f7d18700-e595-4e25-a49c-e2f61cbddc7c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-12-21 09:14:00+00', '2026-11-22 23:36:19.587775+00', '2025-12-21 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3ccd30c5-9d9c-4bf4-bef4-1d80f0d48e73', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8b71e9dc-8cd0-4183-a116-9c19c46cab50', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-12-23 10:21:00+00', '2026-11-22 23:36:19.592514+00', '2025-12-23 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('19e5ab31-3c2b-4815-9a6d-ef10ea1ac32e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '799a7982-e7be-4e9f-8982-4062ab51f1ad', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9a88f324-f78b-494b-987b-514b99e9d4e1', '29df2390-1a60-43fd-ba97-7824689adfc1', '2025-12-25 11:28:00+00', '2026-11-22 23:36:19.596711+00', '2025-12-25 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ad161dfb-19bd-44db-91d3-95f1a7b2007a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '200bfdce-8216-4fba-8059-1c6b629f7f31', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-01-23 12:35:00+00', '2026-11-22 23:36:19.600591+00', '2026-01-23 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b493b511-7f66-4d7b-8536-5885655703f6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9fcfd97e-9033-49f7-8337-96fd992fed6c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-01-25 13:42:00+00', '2026-11-22 23:36:19.605437+00', '2026-01-25 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('32bab834-b54b-41d7-b198-4c9613ebd3c6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0b552ee9-2127-4811-9ddd-c36e5532178f', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-01-27 14:49:00+00', '2026-11-22 23:36:19.609232+00', '2026-01-27 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3e0351b8-4091-4830-9ccf-95a42fca606a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1b7a00db-d64b-4ba6-bee8-88826bd057bf', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-02-25 15:56:00+00', '2026-11-22 23:36:19.611937+00', '2026-02-25 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('208312ff-4e36-42ca-912f-66ca21d7467b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '784a8c2f-f753-4234-8493-61d1e8da7119', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-02-27 16:03:00+00', '2026-11-22 23:36:19.614562+00', '2026-02-27 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('924a32ac-56a4-4838-b350-92a167de56a2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fa523563-d630-4bd0-a349-2e92cd782335', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-03-28 07:10:00+00', '2026-11-22 23:36:19.617795+00', '2026-03-28 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0aa0ca24-99b1-4227-ad5f-bfee2abbaeb5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '02b3afbb-8de3-4f8e-a200-240a79e92dc0', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-03-30 08:17:00+00', '2026-11-22 23:36:19.620996+00', '2026-03-30 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e215bff7-b954-44d5-ab0d-42d2f4d8fc5b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, '95c56c34-8315-438d-b2c2-100085ecf05d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6083110c-8dfd-48fd-97f1-7a4ae837e418', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-04-01 09:24:00+00', '2026-11-22 23:36:19.624183+00', '2026-04-01 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('71ad5ab5-588b-4142-8c89-0da9c4b493f1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '37283bb7-2e86-4ddb-ab6c-bffc0321f59b', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-04-30 10:31:00+00', '2026-11-22 23:36:19.627529+00', '2026-04-30 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d27150f6-90a3-4dbc-a2e7-970dc84a162b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '83b93317-0fb5-48cc-9785-141bed9e4ade', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-05-02 11:38:00+00', '2026-11-22 23:36:19.630757+00', '2026-05-02 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('78027d38-0aca-4628-888a-9c5657b63a43', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '68482959-681d-40b9-8bcf-d052b31def99', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e2baf4e3-573f-443d-898c-fd37aa7f5bfa', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-05-04 12:45:00+00', '2026-11-22 23:36:19.633978+00', '2026-05-04 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('955c4345-aeae-45c1-bac3-9e3633cb5adf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', NULL, '010c3392-34d5-4fc7-be38-c536e1e95ca1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'eb8bb386-b3ab-4c28-a894-07f570795ae6', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-06-02 13:52:00+00', '2026-11-22 23:36:19.637209+00', '2026-06-02 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('34ddfaf3-3543-4f68-9573-d3f8c4b61f8c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 'af9d51aa-9aee-47f4-9b59-6134c2411cc6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd3d077f0-1cd2-44fb-893a-63a0037ca452', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-06-04 14:59:00+00', '2026-11-22 23:36:19.641473+00', '2026-06-04 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('429803bd-e871-4a9f-89b4-e17954bceae2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, '1ed0662e-7961-450a-a0f8-54ac1250f82a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ad29c485-561f-4eee-b493-983c11aca6f2', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-07-03 15:06:00+00', '2026-11-22 23:36:19.645882+00', '2026-07-03 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5a4637db-a4c5-45a5-ada5-e98e122fd35c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f4606069-39ec-4084-ac9d-a83283363d9a', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-07-05 16:13:00+00', '2026-11-22 23:36:19.649814+00', '2026-07-05 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('27294a5d-5970-450f-8b85-b5a72dc2c108', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, '6b736c79-ab15-4f7e-882e-160ba782738d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd194a3ac-f55e-41ca-8944-4ac79943a171', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-07-07 07:20:00+00', '2026-11-22 23:36:19.654624+00', '2026-07-07 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c702ce1b-201f-4d9c-9d97-6c48fac45316', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, '608e2d51-d0d0-4a64-80be-dad9c224283a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a76ed544-f628-405d-bf60-cef88ddf40f9', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-08-05 08:27:00+00', '2026-11-22 23:36:19.65786+00', '2026-08-05 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('91a45155-229e-4967-b7f6-18b964634c35', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, '555c4fbf-b2d4-4c9e-90b6-35eb39735284', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b1990095-7f96-41ec-b357-aa4099c905ff', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-08-07 09:34:00+00', '2026-11-22 23:36:19.661579+00', '2026-08-07 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5862f6f6-0586-4521-aa65-1b006fd86a3f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', NULL, '756a80c8-21e1-4f4f-9f75-0cbd79fd3960', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b5f4fdd8-4c2b-4ff9-8374-2ce8ffc36396', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-08-09 10:41:00+00', '2026-11-22 23:36:19.66558+00', '2026-08-09 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('70ea1ec9-f84f-49ea-9f1e-2eedf0fe1c59', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', NULL, '8b6f6b4a-9882-4863-a243-f5a107568dee', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a5d5311e-1f75-4563-a6cd-a3303dd91bcb', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-07 11:48:00+00', '2026-11-22 23:36:19.669511+00', '2026-09-07 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fafb03b9-3140-47ed-9acf-54becd30c7a0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, '24937559-02f7-4737-9908-083c06714c5c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4d8fdd38-4e83-45a4-8836-68af9d31490a', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-09 12:55:00+00', '2026-11-22 23:36:19.6731+00', '2026-09-09 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ef5e0acf-d1eb-439e-80c6-2f454388cc0c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd0ef78b2-af29-4986-befb-6351a07b37f4', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-08 13:02:00+00', '2026-11-22 23:36:19.676973+00', '2026-10-08 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7dc4874c-dce7-4d88-b493-84d171b260a1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '223c46ae-fe53-4540-a3f4-ab350c9a4fac', NULL, '7559c4d7-ce55-4d0a-bbc5-887c559e336d', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd8fb73c3-b015-4009-bc62-24a62f056e22', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-15 14:09:00+00', '2026-11-22 23:36:19.68114+00', '2026-11-15 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a0173f91-5480-47ea-8a3b-9483d167b98d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', NULL, '7a9e185d-1e23-4368-85cd-b555da7b10ea', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bea2c179-6db0-4291-806c-bc35114d13f3', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-20 15:16:00+00', '2026-11-22 23:36:19.686668+00', '2026-11-20 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a7aea3fa-e6f0-43c8-b485-1fc1b7ffbcfa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '972d00df-0e6c-4f20-a77f-ebb4515d1e61', NULL, '7a9e185d-1e23-4368-85cd-b555da7b10ea', 8.700, NULL, NULL, NULL, 'done', 'opening_balance', '190c51fc-564e-4267-bd7b-35d61962641d', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-19 16:23:00+00', '2026-11-22 23:36:19.691321+00', '2026-11-19 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1af39c8c-fe6a-4219-ad3c-8c4467f6b26b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7b1c4b4c-8fb3-4451-bc39-77be69e7915e', NULL, '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', 'de6175f2-8756-41e7-929c-556fe2d386af', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-17 07:30:00+00', '2026-11-22 23:36:19.69611+00', '2026-11-17 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('66878a70-4cae-4b15-9c05-9ea5144a72e3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fd3f7025-38be-4c94-9805-708ad6525e50', NULL, 'a2cc3792-a342-48e5-bcac-39af703f7b18', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ece4ff71-bfb4-4115-851e-f04248892ec6', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-13 08:37:00+00', '2026-11-22 23:36:19.701677+00', '2026-10-13 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1e38065b-c26b-4020-b3f5-d7fa177b3d63', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9fbcd4fb-3632-4189-a80a-26d869595602', NULL, '211e5889-8bcb-43e8-98ef-685b7582bef3', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '6bbc672b-9ca7-41a0-a783-10563e2e77c9', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-21 09:44:00+00', '2026-11-22 23:36:19.705876+00', '2026-09-21 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c5bf1f78-a4eb-46ae-b392-70f7f444fa8e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', NULL, '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd3f0be28-e352-4d10-8636-20381bddbed8', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-13 10:51:00+00', '2026-11-22 23:36:19.710271+00', '2026-11-13 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b45935e3-ba85-40c8-95be-46354db42eff', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'bb6529e1-926f-41cd-9b74-c94a03b55f56', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bb11d545-60d7-4a71-a928-f1d79f999111', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-20 11:58:00+00', '2026-11-22 23:36:19.71444+00', '2026-11-20 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ad8f1b6f-2878-4501-baaa-ad32d52322ba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e9791bc9-10f8-49cd-8348-9dda0122063e', NULL, 'd67495d7-2c6d-48b0-b476-132f66241a6d', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e2da4caf-508b-4090-af9e-283011741965', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-22 12:05:00+00', '2026-11-22 23:36:19.7185+00', '2026-10-22 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c7353084-52c7-4cdf-b2de-d592ec460544', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0c08476d-f8db-4d18-ac72-a46784985a7d', NULL, '1b2c39b0-cc65-4b34-a95f-fd944492712f', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '3166b19b-c03e-458c-9a99-8d25970cb09f', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-18 13:12:00+00', '2026-11-22 23:36:19.722522+00', '2026-11-18 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9aa9b46d-71c6-42ee-b32b-ffbb0e289461', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dbf12d9e-0cfc-4c10-9844-2c06f6c6697f', NULL, '7c37dfca-c298-4205-87e3-c530c5e88990', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', '102ea193-adec-420f-9127-008aa46be2f9', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-19 14:19:00+00', '2026-11-22 23:36:19.726569+00', '2026-09-19 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('05f30c7c-d275-4a36-82f5-17acbc86d422', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1a77aa58-6966-427d-8d61-7dd1b4979dd3', NULL, '7559c4d7-ce55-4d0a-bbc5-887c559e336d', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ea626c2e-a38e-4682-acea-591ab92e8830', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-30 15:26:00+00', '2026-11-22 23:36:19.730824+00', '2026-09-30 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('de81f9e7-4c21-4dfc-9203-402342e1fd8e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '792f9dfc-6e47-499a-87cc-35b05f48751e', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-17 16:33:00+00', '2026-11-22 23:36:19.734799+00', '2026-11-17 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d5895b57-46d7-4010-8da0-51da0dfc4e4e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', NULL, 'd67495d7-2c6d-48b0-b476-132f66241a6d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1fbb6f2b-49f0-4330-a2ab-895d57ddd9dd', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-31 07:40:00+00', '2026-11-22 23:36:19.738766+00', '2026-10-31 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('83eccd95-cad4-4c16-a8cf-02400afdcbcf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '027755f4-0294-42a1-a43c-d5830beaa781', NULL, 'ab326239-0c31-4f35-8522-9c914c8be9c3', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '563f0a62-91b4-4d86-a892-3039cb0e16c5', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-20 08:47:00+00', '2026-11-22 23:36:19.742728+00', '2026-10-20 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('18676658-a893-4405-bff9-d0aef6829a84', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '150c1f18-1619-4b71-9c0c-d4adfacf209a', NULL, '1b2c39b0-cc65-4b34-a95f-fd944492712f', 6.500, NULL, NULL, NULL, 'done', 'opening_balance', '0db6b645-8f7c-4c1a-a56b-1c880d8ce6c7', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-18 09:54:00+00', '2026-11-22 23:36:19.746711+00', '2026-11-18 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8c0969d3-e9a7-43ac-bee0-730775da41ac', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ab1b9846-c8e7-45c6-b695-e655763069ab', NULL, '7c37dfca-c298-4205-87e3-c530c5e88990', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', 'eec97a89-1f44-42f6-8979-ae71db73da10', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-28 10:01:00+00', '2026-11-22 23:36:19.750673+00', '2026-09-28 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5a6baeed-e122-46e5-8b61-54c8473c34af', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95d6a10f-937b-4b74-a0d4-a012126d9f52', NULL, '7c37dfca-c298-4205-87e3-c530c5e88990', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '2ecd3e2d-1e3a-436e-b4ee-990a46691f4c', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-09 11:08:00+00', '2026-11-22 23:36:19.754659+00', '2026-11-09 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9469e40e-c91b-43d8-bb85-e841920252d9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b61f4b6-f554-4610-931d-26a0886d231a', NULL, '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5b69085c-5ded-49f7-9885-0dffd7bc1775', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-17 12:15:00+00', '2026-11-22 23:36:19.758619+00', '2026-09-17 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('efcfcfd3-15c9-4449-bb01-e116aef48a9a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ff1d121d-4fb2-458c-b16d-08824802ade1', NULL, 'dc348dec-fee9-4f38-8959-8a0c1f02f466', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '5c192ec6-c0c4-4c8f-8741-1086eff18172', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-29 13:22:00+00', '2026-11-22 23:36:19.762629+00', '2026-10-29 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9f7394d5-4c50-410f-8f17-da11f26d6bfa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8742e916-2785-4512-ab27-fed4ded3c473', NULL, '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', 8.600, NULL, NULL, NULL, 'done', 'opening_balance', '68dcee58-627d-465f-b316-5f4773b151a8', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-19 14:29:00+00', '2026-11-22 23:36:19.767776+00', '2026-11-19 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('31f2935c-43ab-4439-bbd4-e33f1ffef6aa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd94e5659-0dfc-4e0b-bf49-0340f296bdf5', NULL, '96bede93-9802-49a9-952b-075e2301156b', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f6b37e96-2a10-4bd5-a4d4-427e1d3345aa', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-07 15:36:00+00', '2026-11-22 23:36:19.772062+00', '2026-10-07 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e9d685d7-0252-418d-8e12-e172265eae68', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a738adfd-0757-4836-a4b9-70ef1261378f', NULL, '7a9e185d-1e23-4368-85cd-b555da7b10ea', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '24a72a3f-54f8-42ab-88d2-522ddcab4f23', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-17 16:43:00+00', '2026-11-22 23:36:19.776211+00', '2026-11-17 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('da240615-1204-45ee-bf6c-caac6e038fd9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b9014711-5ce7-4aac-8f11-e4748fff949a', NULL, '211e5889-8bcb-43e8-98ef-685b7582bef3', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a846641d-de55-4cc7-8e0e-c1a5b478f3ed', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-15 07:50:00+00', '2026-11-22 23:36:19.780172+00', '2026-09-15 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3339a9af-24e9-40a9-bdf4-beb5be343702', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', NULL, '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '6482dc7b-dfe7-4dd3-a1ce-f1b795c5d5fc', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-21 08:57:00+00', '2026-11-22 23:36:19.784128+00', '2026-11-21 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6b76be8a-c4f0-411c-9d2c-3139fffd0b22', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', NULL, '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '286c29bc-b6ba-4cca-a2c8-c2e3affd8a5a', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-27 09:04:00+00', '2026-11-22 23:36:19.788359+00', '2026-10-27 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6c3b7453-4017-4dc9-8255-786b405fced1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '52559aed-459d-4b60-bdfb-9e8a712c46a7', NULL, '96bede93-9802-49a9-952b-075e2301156b', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '7b438470-a58f-4023-a6c8-3938366f5aa3', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-16 10:11:00+00', '2026-11-22 23:36:19.792514+00', '2026-10-16 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ea224c31-fa96-4cb8-9d04-71353a27557d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fbc113bb-6608-448b-a260-ed9dd4b124d6', NULL, '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '66148578-ba24-4740-8a15-16360820f864', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-18 11:18:00+00', '2026-11-22 23:36:19.796842+00', '2026-11-18 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2c40e2a0-6f26-44f2-b1b0-4160c15d0aca', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '595520ae-5062-47f9-9e47-27082e7bc22f', NULL, '7c37dfca-c298-4205-87e3-c530c5e88990', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '6ebc1945-8360-4fd0-a9a8-947b72196e06', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-24 12:25:00+00', '2026-11-22 23:36:19.801333+00', '2026-09-24 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3906127d-b089-4746-9750-17700f08df20', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', NULL, '96bede93-9802-49a9-952b-075e2301156b', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '8a2930ee-6d6b-4cd1-9a69-f263f7d8c5ea', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-13 13:32:00+00', '2026-11-22 23:36:19.806328+00', '2026-09-13 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('688074a3-8bf4-4c24-b96a-f0643a3e8960', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fd3f7025-38be-4c94-9805-708ad6525e50', NULL, 'a2cc3792-a342-48e5-bcac-39af703f7b18', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '19b31fde-260b-4693-a53e-9316a0519cd1', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-05 14:39:00+00', '2026-11-22 23:36:19.810553+00', '2026-11-05 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('35cc978b-b080-45d2-85d6-5ce914663424', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', NULL, 'ab326239-0c31-4f35-8522-9c914c8be9c3', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c1c6a81c-c257-4764-8fa7-dcfae764192d', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-25 15:46:00+00', '2026-11-22 23:36:19.815234+00', '2026-10-25 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5b4db60d-bca9-4761-b4f5-45bd459a68b3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45cccb60-d659-4421-a067-32c271cbf33f', NULL, '62d3f0fd-fc28-46d8-8f11-7054e44c2046', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '2b4cd597-e3f3-49df-b2d1-cb0f01656380', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-14 16:53:00+00', '2026-11-22 23:36:19.819329+00', '2026-10-14 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2518f8f7-1ab5-44c0-b54d-2e24e20849d7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd5930c45-5bdf-4e88-bf66-5066b17c9c68', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-18 07:00:00+00', '2026-11-22 23:36:19.823217+00', '2026-11-18 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('66e29bd3-f2bf-4fad-a04b-077b019c8582', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '72d583c2-ff3d-4f7f-ae15-5333b3840dd0', NULL, '7c37dfca-c298-4205-87e3-c530c5e88990', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd07c436e-5e3f-4ab4-8d74-093c60827258', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-09-22 08:07:00+00', '2026-11-22 23:36:19.82718+00', '2026-09-22 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b4ce20d5-34cb-4fad-9e76-6cdd54132991', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0052c85e-7ae7-42ac-8a15-9a144ea74f59', NULL, 'dc348dec-fee9-4f38-8959-8a0c1f02f466', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', 'dcde5eed-3d7a-4888-bb7e-fa52727b44fb', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-14 09:14:00+00', '2026-11-22 23:36:19.831134+00', '2026-11-14 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f92f4992-400d-439c-a6c5-7c5b87f61f2b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '319dc161-97d4-4a04-9b3d-cc64d9d704dd', NULL, '96bede93-9802-49a9-952b-075e2301156b', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4322b97c-2c3d-4660-816a-454ef08d2b2a', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-03 10:21:00+00', '2026-11-22 23:36:19.834915+00', '2026-11-03 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('768241c9-979c-47cb-ad17-27fc5e1cbcf4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6d36f2b9-47c7-4589-905f-b904d79bb551', NULL, '0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', 5.100, NULL, NULL, NULL, 'done', 'opening_balance', '1d751a2d-9cb7-40cd-8dc2-f6ceffb85a02', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-19 11:28:00+00', '2026-11-22 23:36:19.838859+00', '2026-11-19 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('467b92db-5766-4099-8210-221ea0988262', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '7f615c96-b060-45a0-950c-4296609c6da8', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-20 12:35:00+00', '2026-11-22 23:36:19.842743+00', '2026-11-20 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1cabaf1d-3dd5-4fff-9bdd-e135d79d47b1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'adb37118-6006-4d99-8159-7f92dfcd47da', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 6.900, NULL, NULL, NULL, 'done', 'opening_balance', 'ab788a52-bc7f-4c72-96e8-35a7f773f70f', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-18 13:42:00+00', '2026-11-22 23:36:19.84654+00', '2026-11-18 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bd0b70e2-c40d-4d79-a796-9d32f06c06d2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', NULL, '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', 40.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e2c46401-5df2-417a-abb4-be3a832b6e89', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-19 14:49:00+00', '2026-11-22 23:36:19.850539+00', '2026-11-19 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f10b5d06-b95a-4b58-b349-1987db6126c1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', NULL, '211e5889-8bcb-43e8-98ef-685b7582bef3', 25.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c4a17a40-5316-4b45-81c4-66fc0ab3f63e', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-02 15:56:00+00', '2026-11-22 23:36:19.854454+00', '2026-11-02 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('675d9269-fe41-4438-86db-fd06ed291549', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', NULL, '211e5889-8bcb-43e8-98ef-685b7582bef3', 0.500, NULL, NULL, NULL, 'done', 'opening_balance', '2fb18879-a1da-4481-b850-1ce35d12cfbf', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-10-19 16:03:00+00', '2026-11-22 23:36:19.858244+00', '2026-10-19 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8517382a-02fe-4b05-9bfa-79c8939d38ba', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', NULL, 26.400, NULL, NULL, NULL, 'done', 'maker_production', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.72617+00', '2026-11-22 23:36:21.726171+00', '2026-11-22 23:36:21.72575+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b813a8dd-9b4a-4aab-8dc4-e81e491465a6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', '211e5889-8bcb-43e8-98ef-685b7582bef3', NULL, 3.780, NULL, NULL, NULL, 'done', 'maker_production', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.74977+00', '2026-11-22 23:36:21.749771+00', '2026-11-22 23:36:21.749645+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0363efb5-7949-4bb2-9fc9-bd02fc83a5f0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', '211e5889-8bcb-43e8-98ef-685b7582bef3', NULL, 0.060, NULL, NULL, NULL, 'done', 'maker_production', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.768+00', '2026-11-22 23:36:21.768001+00', '2026-11-22 23:36:21.767874+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8fced8e0-8797-4318-8dad-7bb94d8fd2bb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', NULL, '211e5889-8bcb-43e8-98ef-685b7582bef3', 11.400, '428858fb-8cdd-4c0e-920a-46b2c0372c9a', NULL, NULL, 'done', 'maker_production', '10c3cc2d-91a2-4dd3-8364-b8a9498dee94', '29df2390-1a60-43fd-ba97-7824689adfc1', '2026-11-22 23:36:21.79724+00', '2026-11-22 23:36:21.797241+00', '2026-11-22 23:36:21.796844+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('51a0d0e1-144f-48cc-a93f-700232b665cd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 3.000, NULL, NULL, NULL, 'done', 'document', '736fda6f-bded-4a88-a8a1-57d1bf09f776', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-05 13:30:00+00', '2026-11-22 23:36:22.257793+00', '2026-11-05 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9a011ec2-8fe4-4faf-bec5-78506b853c8f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 48.000, NULL, NULL, NULL, 'done', 'document', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-13 12:15:00+00', '2026-11-22 23:36:22.261972+00', '2026-11-13 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d8e7ded7-4d76-4eff-9a4e-f986af805623', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 24.000, NULL, NULL, NULL, 'done', 'document', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-13 12:15:00+00', '2026-11-22 23:36:22.261972+00', '2026-11-13 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9201c696-5647-4516-946a-e8c2a8295851', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', 36.000, NULL, NULL, NULL, 'done', 'document', 'cfa5d558-eed0-4ed9-90d9-cf79f5b115a9', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-13 12:15:00+00', '2026-11-22 23:36:22.261972+00', '2026-11-13 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b9268510-0f1e-4984-bd8c-4ae51fbc2bc2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 60.000, NULL, NULL, NULL, 'done', 'document', 'a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-15 12:15:00+00', '2026-11-22 23:36:22.263538+00', '2026-11-15 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('64c0b6ae-50b8-423d-b98f-e4d500883e4a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', 20.000, NULL, NULL, NULL, 'done', 'document', 'a5b4b7d9-8ca0-49be-b7a7-c78b0805ff9b', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-15 12:15:00+00', '2026-11-22 23:36:22.263538+00', '2026-11-15 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9951efae-d9f3-46ff-8ffd-5d5733613e5f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, 12.000, NULL, NULL, NULL, 'done', 'document', 'fb6b2610-e5da-4418-ae07-eeff4c6a586a', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-18 10:50:00+00', '2026-11-22 23:36:22.264795+00', '2026-11-18 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('60eba6f5-71b8-4f79-8cb4-4832d50dd6f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, 8.000, NULL, NULL, NULL, 'done', 'document', 'fb6b2610-e5da-4418-ae07-eeff4c6a586a', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-18 10:50:00+00', '2026-11-22 23:36:22.264795+00', '2026-11-18 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d9751927-8798-4902-b4d5-7c869941cca1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 5.000, NULL, NULL, NULL, 'done', 'document', '7550cc0c-a8ed-4b64-a7db-21d697c2e761', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-20 14:45:00+00', '2026-11-22 23:36:22.266607+00', '2026-11-20 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('85ab02ee-1e3c-45bc-a127-19fa4b68144c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, 'f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', 3.000, NULL, NULL, NULL, 'done', 'document', '7550cc0c-a8ed-4b64-a7db-21d697c2e761', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-20 14:45:00+00', '2026-11-22 23:36:22.266607+00', '2026-11-20 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7fa32e9b-2abb-433c-a5b4-0203562713aa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, 6.000, NULL, NULL, NULL, 'done', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-21 13:30:00+00', '2026-11-22 23:36:22.268448+00', '2026-11-21 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('848115ea-cee6-4fd9-861e-4003c6603f83', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL, 4.000, NULL, NULL, NULL, 'done', 'document', 'aaa28144-9b19-429b-9c06-de601c1b317b', 'f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', '2026-11-21 13:30:00+00', '2026-11-22 23:36:22.268448+00', '2026-11-21 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d0a83e15-607a-419d-8092-c32b1b940a02', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, 10.000, NULL, NULL, NULL, 'done', 'document', 'aa365cc5-5414-40a4-9ada-86f186c992e3', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-21 14:00:00+00', '2026-11-22 23:36:22.270136+00', '2026-11-21 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ea324d39-c371-41d1-a04f-98bb83f7fbf6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL, 5.000, NULL, NULL, NULL, 'done', 'document', 'aa365cc5-5414-40a4-9ada-86f186c992e3', 'c0c8f11c-71c2-4a0b-aa25-045c63464d1e', '2026-11-21 14:00:00+00', '2026-11-22 23:36:22.270136+00', '2026-11-21 14:00:00+00');


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('afda841e-57fe-4849-8bf3-fdc0041d859a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0b5b91d1-0670-4240-8c0c-386ac71ab210', '48380f98-79bc-4edd-b7c9-514b30879e76', '5ac79edd-280f-4fb0-a2db-b5ed60b83506', NULL, NULL, 10.000, '2026-11-22 23:36:20.37719+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('a3d8dcb8-91cc-484a-b4dc-c45eaf0e115d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '997d1da7-392e-435a-a1b8-2509f111bb7a', '58ca2a67-2bae-421a-9d96-9d6ec98d62b0', '5ac79edd-280f-4fb0-a2db-b5ed60b83506', NULL, NULL, 8.000, '2026-11-22 23:36:20.442435+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('1e79202a-cd67-4d9e-8300-34af98ac7b40', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '997d1da7-392e-435a-a1b8-2509f111bb7a', '42e732f6-d2b1-4ed5-a55e-2a10b3f41fa2', 'b4c0dd0a-3a0f-49c6-b9f7-b5038f22fe6f', NULL, NULL, 4.000, '2026-11-22 23:36:20.451399+00');


--
-- Data for Name: stock_take_closed_locations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_counts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('a7553d67-bc5c-4c86-81e5-f5c987cf93aa', '181b6454-966f-4010-9a93-0ee7e7f53796', 'd8fb73c3-b015-4009-bc62-24a62f056e22', 'Coffee Beans', 'Orchard & Oak', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, 3.000, 2.000, NULL, NULL, NULL, 1, '2026-11-22 23:36:21.823887+00', '2026-11-22 23:36:21.823889+00', 'MISCOUNT', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('ac579b06-6825-4eb4-8439-31adea7d6042', '181b6454-966f-4010-9a93-0ee7e7f53796', '6bbc672b-9ca7-41a0-a783-10563e2e77c9', 'Baking Powder', 'Harvest Row', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, 6.000, 6.000, NULL, NULL, NULL, 0, '2026-11-22 23:36:21.82389+00', '2026-11-22 23:36:21.82389+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('8d07ccca-fc1e-4c7c-8f84-593fb96e2b6a', '181b6454-966f-4010-9a93-0ee7e7f53796', 'd3f0be28-e352-4d10-8636-20381bddbed8', 'White Sugar 1kg', 'Harvest Row', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, 8.000, 8.000, NULL, NULL, NULL, 0, '2026-11-22 23:36:21.823891+00', '2026-11-22 23:36:21.823891+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('b0d7ca53-9cbb-4b1a-a4c7-820d190dcf01', '181b6454-966f-4010-9a93-0ee7e7f53796', 'ea626c2e-a38e-4682-acea-591ab92e8830', 'Ground Ginger', 'Saltmill', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, 6.000, 4.000, NULL, NULL, NULL, 1, '2026-11-22 23:36:21.823891+00', '2026-11-22 23:36:21.823892+00', 'DAMAGE', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('8d4c3aef-31ec-49a0-ba5f-74e86af58c9e', '181b6454-966f-4010-9a93-0ee7e7f53796', '102ea193-adec-420f-9127-008aa46be2f9', 'Dried Oregano', 'Saltmill', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, 2.000, 2.000, NULL, NULL, NULL, 0, '2026-11-22 23:36:21.823892+00', '2026-11-22 23:36:21.823892+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('fc2dcf6a-cd18-44ab-9d89-ae4a644f2255', '181b6454-966f-4010-9a93-0ee7e7f53796', '563f0a62-91b4-4d86-a892-3039cb0e16c5', 'Almonds', 'Green Acre', '10215777-64f1-4376-ac45-1cc7b9b2128b', NULL, NULL, 4.000, 5.000, NULL, NULL, NULL, 1, '2026-11-22 23:36:21.823893+00', '2026-11-22 23:36:21.823893+00', 'WRONG_LOCATION', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('498ceb85-c5e0-4222-bb79-11cd634c4282', '181b6454-966f-4010-9a93-0ee7e7f53796', 'eec97a89-1f44-42f6-8979-ae71db73da10', 'Peeled Tomatoes 400g', 'Harvest Row', '8352703e-3fa0-450f-9d3a-031f662471ce', NULL, NULL, 4.000, 4.000, NULL, NULL, NULL, 0, '2026-11-22 23:36:21.823893+00', '2026-11-22 23:36:21.823894+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('e004b486-9ae7-4d54-bb48-c6c5835fcc0f', '181b6454-966f-4010-9a93-0ee7e7f53796', '5b69085c-5ded-49f7-9885-0dffd7bc1775', 'Instant Tomato Soup', 'Harvest Row', '10215777-64f1-4376-ac45-1cc7b9b2128b', NULL, NULL, 1.000, 1.000, NULL, NULL, NULL, 0, '2026-11-22 23:36:21.823894+00', '2026-11-22 23:36:21.823894+00', NULL, false, NULL, NULL);


--
-- Data for Name: stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_takes (id, user_id, organization_id, storage_location_id, name, description, status, started_at, completed_at, notes, blind_mode, require_full_count, tolerance_percent, deleted_at, created_at, updated_at, schedule_id, adjustment_document_id) VALUES ('181b6454-966f-4010-9a93-0ee7e7f53796', '29df2390-1a60-43fd-ba97-7824689adfc1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', 'Dry Goods count', 'Quarterly count of the dry goods shelves.', 'completed', '2026-11-19 21:36:21.821761+00', '2026-11-19 23:36:21.821768+00', NULL, false, true, 2.00, NULL, '2026-11-22 23:36:21.822299+00', '2026-11-22 23:36:21.910824+00', NULL, NULL);


--
-- Data for Name: stock_valuation_layers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('16706e87-9c2b-478a-bbf8-903aefa795e4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2023-10-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.329329+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('606f5644-6968-4f68-9316-c3dc78111d28', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, 1.000, 1.000, 350.0000, 350.00, '2023-10-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.335991+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c7364b12-4049-4a0d-a495-85f95ad18748', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2023-11-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.340528+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('915496d0-98a5-48ca-89d6-ef6ff2ae3a1e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2023-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.345848+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('eabf09e2-291e-4e52-955e-19860e5e20ec', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2023-11-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.350453+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('2820ff98-489e-4741-a985-7d4bc48230d0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2023-12-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.354435+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('18afd258-dc9d-4fcc-8542-a376cac0738e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2023-12-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.358252+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('aedf881d-0420-4b1a-8f19-d94147a4574f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2024-01-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.361984+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('574b623b-a1dd-455d-b643-d4c33bf105fb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, 1.000, 1.000, 350.0000, 350.00, '2024-01-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.364805+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('447c86f7-768f-439f-b484-a1731a95651c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-02-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.368589+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7a809bf2-f784-462d-bed9-9eb13111006d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-02-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.372679+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('169f3ded-a103-44a2-ba4e-d50f97cd254d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2024-02-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.376664+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('41c57f7a-5cdc-45a7-91f3-23a1c259363c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2024-03-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.380417+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('41694563-83d2-4894-a508-2d58592149ef', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-03-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.384518+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a9af431e-0fd8-409f-9f76-98eaa0b4fe44', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2024-04-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.388356+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a53ff387-0b7d-4e76-836e-a09605b8862f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-04-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.392224+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3b507806-efac-4ee3-ae81-f39635776c9b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9a22de9a-3c3a-4454-a156-5dd21d659a6e', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-05-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.395476+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ac3c68b6-ac3c-4ece-8014-d0498d964f50', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-05-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.399316+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ee4ecdae-db2b-4ae2-869a-88fcbbde353d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-05-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.402972+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('00a46790-f894-44ad-b7d3-d9354de61226', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2024-06-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.407058+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('cd4af005-0e83-4152-a7ad-2e4441db8118', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-06-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.411942+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('66bd37a0-266a-4aa5-a7b9-5a1b6f3cd859', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2024-07-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.416321+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('624c0fb6-9d8a-41cf-8f36-811dd4274cd3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-07-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.420282+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bdca3d70-6243-4dce-a729-6795c0b837b1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '755ea5f1-9325-4c48-acc5-91fe380b59f1', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2024-08-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.424076+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('595fb5eb-bbbe-4c8a-88d7-0684fd227d45', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-08-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.428057+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6e1ebcff-6c77-48dd-bc09-edab6cfa096f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cfa1af94-c19f-461e-ac45-bf2db317d2cf', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-08-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.432242+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8251e713-5a8b-47e3-864d-48a5ed00ca31', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2024-09-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.435555+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8d80c7b4-49a0-41a5-a120-222656f36d01', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', NULL, 1.000, 1.000, 950.0000, 950.00, '2024-09-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.439806+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('46800c78-e1a7-4813-ba2a-7296a5a1cb24', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2e90cfb5-e0da-41db-857a-cec9986f9225', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2024-10-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.444194+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7b37d6bc-8bb4-45b8-898f-cb5999ccd69e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-10-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.44795+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dedc5b45-23be-4b4b-9e8f-7f4b6e939e75', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2024-11-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.452109+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9d5b1117-18b4-486b-8ab1-5c6ba8ecaee7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2024-11-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.456475+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e1453051-7cdc-40d2-8605-60b215d34555', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2024-12-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.461312+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b37b0e36-6291-410f-9771-6fc3db401c1a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7acf8b63-3d43-40ab-8a8c-5032ad7dc1fe', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2024-12-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.465498+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9dcadb41-8201-45c6-9f98-e235c474b550', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ec404269-dc14-4df1-a3e5-f3f1d1ccd619', NULL, 1.000, 1.000, 950.0000, 950.00, '2025-01-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.469249+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('187f2c4c-5e30-45dd-abbf-8cb73848b206', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-01-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.473285+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('03dce911-30b3-4802-bfa5-b4234a2b8ebe', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608eba71-431c-44b2-965e-4abc27a6ab8a', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2025-02-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.47784+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('05a83b69-faaa-47c8-a1ca-b2cbb5878888', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '89627cb0-3e43-4dad-a1c3-a6d69c378206', NULL, 1.000, 1.000, 400.0000, 400.00, '2025-02-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.482294+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6e36dc00-9238-4c73-aecc-bf11e668776f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-03-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.486386+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3b83902c-5944-4814-8711-48fb79f81d0f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '507ace22-1183-4c8d-9c04-fa8cd6e19021', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2025-03-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.490562+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9ce328a3-8d7c-4562-8a0b-56d0aca21aa6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2025-03-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.495985+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b9010780-759f-4ce8-948f-c2bc976a9ed3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-04-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.50069+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('262a64fa-47a6-4c77-b205-44655f701bd5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-04-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.504944+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('0e9b29e2-ff87-4c8b-ad3a-4e711af48d7d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-04-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.510473+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('916788c9-ef27-42be-ac87-85824959169b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '608eba71-431c-44b2-965e-4abc27a6ab8a', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2025-05-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.514344+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('2c5cf7c6-194c-46e7-978b-781ecd2a0815', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-05-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.518271+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('de3ac5f1-a689-4626-ade3-5648894726ab', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-06-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.521878+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('5a19fa61-55cb-49ac-8101-83508fe73d86', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-06-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.526062+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a3cb83cf-fbb1-4409-961f-9814fe5efac5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2025-06-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.530856+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3addbfb8-7bb9-40d5-a19b-6ba5bb5637e7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ad69dfca-feca-493b-ac3a-2cb57cdcddec', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-07-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.535366+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('aae7baea-c9f1-4c77-869b-bd579dc764fa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-07-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.539975+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dbb2ee7c-de4e-40cf-a59a-1a282680c691', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-07-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.544712+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d32d92d8-87a4-4709-88ae-109395c726f3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2025-08-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.548897+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7fd645f0-8bcc-49ee-b80b-b78c85ba38df', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-08-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.553095+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('09f2f8fb-051d-4a13-b25d-eb00ce45d8a7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-09-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.556589+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dc9dcd8e-d77d-4871-a04f-3552c674230b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-09-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.56101+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c3213bb8-b95e-4ea0-b8cb-b48cb6b58c7c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '44670f62-74cc-4587-8695-adbb5df6e0b6', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2025-09-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.564268+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('916d6e51-4ddb-4485-8d19-458456514745', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-10-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.568294+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a0679bf7-0772-4fba-9b85-a95f25e0189c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-10-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.573385+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f15a8a35-77b7-48b9-9a19-94cd82c7c7fd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-10-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.577441+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('662d6ce1-8c7b-4249-b446-3b66730ffe5f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2025-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.581624+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('79205c13-4b8a-43cc-be4e-01c1e88bb488', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 1.000, 1.000, 450.0000, 450.00, '2025-11-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.585714+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('22357bc8-01b0-442f-bac5-b1ffe15bf20b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2025-12-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.59027+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d90a7945-4f9e-4278-b6d2-ba2359f873ca', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-12-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.594932+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4816f5b8-393d-409c-8268-89190e06fc84', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '799a7982-e7be-4e9f-8982-4062ab51f1ad', NULL, 1.000, 1.000, 650.0000, 650.00, '2025-12-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.598804+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3e207fb8-6af1-431f-9157-4ecf098f526d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-01-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.602486+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3cc3805f-418b-477a-ae85-bd27fd16c52d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-01-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.60759+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('d8c58785-b424-44d3-bdc2-276b4fde53c3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ec73166-e75a-4ed9-a3c9-d0f77cf7cb53', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-01-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.611056+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('03589c96-d7ba-4f41-808f-655680458d59', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '60a2899b-6903-44e0-a9a8-63b299378728', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2026-02-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.61369+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bb1fd17e-f2be-4456-b759-85d2139a0476', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 1.000, 1.000, 450.0000, 450.00, '2026-02-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.616298+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c90bbfc2-79fc-4d3b-9886-b51a8924b533', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-03-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.619515+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ebe9659e-be32-44c0-b078-fa9f8c80e8bf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2026-03-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.622711+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('49269dc3-38ba-4d4b-845e-5ab7af8225e8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, 1.000, 1.000, 350.0000, 350.00, '2026-04-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.625965+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('837be012-7e8b-49d7-942e-82d1e7a6d4fa', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-04-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.629268+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fbc91c5a-55ae-46f3-aecb-93fdf019c2c7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a0e69b2f-02a1-4a01-b2af-199c95cc152f', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-05-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.632473+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('981c9e3d-560e-45e2-9486-b214d8033431', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '68482959-681d-40b9-8bcf-d052b31def99', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-05-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.635714+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('21a2a5c9-dad4-4fb2-a7ac-8fa60b11f42d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2026-06-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.638971+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3353fb08-bdad-42da-b2af-f533e16c079d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5be9a80e-66e6-4ea3-990d-ea61b247c23c', NULL, 1.000, 1.000, 450.0000, 450.00, '2026-06-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.644366+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a3be3a9b-cdaa-4a55-a940-9a32f7678d59', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-07-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.648472+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('41b534ee-2995-4cd0-ab6b-5d6c202f62e7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '22852bd0-d709-4bc5-b15d-cedb5ab70059', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2026-07-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.652304+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e4ea01c0-8f53-4a2d-9830-2242d3bd21cc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '2d6fa235-d67a-4abe-89c9-f84f68e3c175', NULL, 1.000, 1.000, 350.0000, 350.00, '2026-07-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.656808+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('20443edb-d565-4eef-a377-29340dd8a985', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9629cb34-f877-4616-bb58-c4b2e274aab0', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-08-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.659821+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f1271b97-1cf9-4df9-9122-cbd2912423c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45e0d6c0-a96c-44b3-b5fd-d9642da74ff3', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2026-08-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.66355+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fbdad5b5-ba63-4124-a454-095073fdf065', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8655532e-cb74-4e07-83a7-5eed2c6c9325', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2026-08-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.667789+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8ebe30e6-bd88-41a9-b917-cf1958a237bd', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '14cfd548-8a19-406f-be8f-d1d4b012ee08', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2026-09-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.671409+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('459cf691-1ab9-441c-871a-4582611fb991', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ed6ded13-e200-4e54-8da1-9e715cf9e681', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-09-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.675048+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8d193678-2e26-4694-8199-3ad7a291a556', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-10-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.679279+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('25fd0207-1217-4565-9f59-e3fac0b0fd71', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '223c46ae-fe53-4540-a3f4-ab350c9a4fac', NULL, 3.000, 3.000, 4.5400, 13.62, '2026-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.684539+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('20717e53-fa0a-4f5e-83fd-4a4d4a3141e0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', NULL, 3.000, 3.000, 5.4000, 16.20, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.689437+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('88040020-9b9a-4f6f-aeb2-f74259f47038', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '972d00df-0e6c-4f20-a77f-ebb4515d1e61', NULL, 8.700, 8.700, 4.4300, 38.54, '2026-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.694187+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('9e3c13c0-5e58-4710-aae3-c81d430be6f0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7b1c4b4c-8fb3-4451-bc39-77be69e7915e', NULL, 4.000, 4.000, 5.3100, 21.24, '2026-11-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.69966+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3aef4c42-e990-47d2-919a-aa4a5eb70176', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fd3f7025-38be-4c94-9805-708ad6525e50', NULL, 8.000, 8.000, 4.7500, 38.00, '2026-10-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.704254+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b87bd38d-781f-4516-91a9-419876842417', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9fbcd4fb-3632-4189-a80a-26d869595602', NULL, 6.000, 6.000, 5.3900, 32.34, '2026-09-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.708572+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('89583625-e81d-48af-83f4-63882f9d2dc1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8502c7df-137a-4e1f-a60b-f5e6e2ebfc61', NULL, 8.000, 8.000, 4.8700, 38.96, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.712785+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6ac10230-5502-40d5-b379-96a373fe23e7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'bb6529e1-926f-41cd-9b74-c94a03b55f56', NULL, 9.000, 9.000, 5.2800, 47.52, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.716927+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e4ff4f8a-f35b-4908-b940-f6a7a4b08ef4', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'e9791bc9-10f8-49cd-8348-9dda0122063e', NULL, 8.000, 8.000, 4.9100, 39.28, '2026-10-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.720973+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('52878128-1031-4db3-8150-13cf82babe55', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0c08476d-f8db-4d18-ac72-a46784985a7d', NULL, 6.000, 6.000, 5.1500, 30.90, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.724884+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('22f99660-d428-4eef-8899-b696f1fabe70', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dbf12d9e-0cfc-4c10-9844-2c06f6c6697f', NULL, 2.000, 2.000, 4.7100, 9.42, '2026-09-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.729186+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('f3f64088-9457-40d4-9b26-462b8a6e6122', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1a77aa58-6966-427d-8d61-7dd1b4979dd3', NULL, 6.000, 6.000, 4.9100, 29.46, '2026-09-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.733252+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('c665cf3e-1d9c-495b-97d8-4be9ad19ddd8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '1ad1598a-376c-4ed4-8ece-d6b1e3dad820', NULL, 7.000, 7.000, 5.4800, 38.36, '2026-11-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.737215+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('99f34754-5273-4867-8f1f-c4071a3a8bbc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', NULL, 1.000, 1.000, 5.2100, 5.21, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.741075+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('dfe7237c-1a86-4984-ac4c-de877ad3a72e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '027755f4-0294-42a1-a43c-d5830beaa781', NULL, 4.000, 4.000, 5.6100, 22.44, '2026-10-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.745126+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('8cfae9d6-340b-4e5d-bda5-eb2f0cf15ef2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '150c1f18-1619-4b71-9c0c-d4adfacf209a', NULL, 6.500, 6.500, 4.2700, 27.76, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.749017+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ad4aed6c-6794-48cd-92e3-e8682051fd7c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ab1b9846-c8e7-45c6-b695-e655763069ab', NULL, 4.000, 4.000, 5.1800, 20.72, '2026-09-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.753067+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('21cb3779-f2db-401c-b68b-bb8ff7fb8787', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '95d6a10f-937b-4b74-a0d4-a012126d9f52', NULL, 8.000, 8.000, 5.0600, 40.48, '2026-11-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.757062+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e9038d2d-8161-411e-9c95-633fdae75097', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6b61f4b6-f554-4610-931d-26a0886d231a', NULL, 1.000, 1.000, 4.8800, 4.88, '2026-09-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.760938+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('97d3dc52-7a5e-4a5d-a5a9-7ceb5f6f8223', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ff1d121d-4fb2-458c-b16d-08824802ade1', NULL, 6.000, 6.000, 4.2800, 25.68, '2026-10-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.765836+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('bde99066-311a-4819-bd7b-84020ea2a87f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8742e916-2785-4512-ab27-fed4ded3c473', NULL, 8.600, 8.600, 5.7400, 49.36, '2026-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.770352+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4e58b595-2a2c-4730-ba64-613578edc94c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd94e5659-0dfc-4e0b-bf49-0340f296bdf5', NULL, 3.000, 3.000, 4.4600, 13.38, '2026-10-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.774558+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('26163bf5-d08a-4f6b-91bb-7812770cd7f5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a738adfd-0757-4836-a4b9-70ef1261378f', NULL, 3.000, 3.000, 5.1300, 15.39, '2026-11-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.778553+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('31c465ec-7ea8-4328-9a36-6a880bcbfa7e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b9014711-5ce7-4aac-8f11-e4748fff949a', NULL, 5.000, 5.000, 4.5400, 22.70, '2026-09-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.782539+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4efdac66-870c-4a38-a305-c77d65a3c1b7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', NULL, 4.000, 4.000, 5.5600, 22.24, '2026-11-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.786572+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('75e3769a-fbe4-4ee9-96fb-482dad24c1d2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '9aef3b83-c7f1-4c0c-b3c3-b26274c971d2', NULL, 4.000, 4.000, 5.4500, 21.80, '2026-10-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.790832+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('baa46234-eb26-49ac-822c-4ca54433e15c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '52559aed-459d-4b60-bdfb-9e8a712c46a7', NULL, 6.000, 6.000, 5.5800, 33.48, '2026-10-16', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.794929+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('519c0ecc-f1c0-4153-9025-ba2569f327cb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fbc113bb-6608-448b-a260-ed9dd4b124d6', NULL, 6.000, 6.000, 4.7300, 28.38, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.799288+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7996fed3-cbab-45fd-9e10-95174534f6cb', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '595520ae-5062-47f9-9e47-27082e7bc22f', NULL, 7.000, 7.000, 4.3300, 30.31, '2026-09-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.804334+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fc35211e-21bb-458c-875b-6acbc13906d6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'f0dfd71d-13fb-469d-b712-a1fa1100b99b', NULL, 7.000, 7.000, 4.4800, 31.36, '2026-09-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.809385+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('48f00abd-c157-40da-a888-2c9e662e24c2', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fd3f7025-38be-4c94-9805-708ad6525e50', NULL, 3.000, 3.000, 5.0400, 15.12, '2026-11-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.813501+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('00b44347-3a51-4723-932c-4bfb093e60a8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '8ba86f57-bf94-4b0f-aa8f-05d918e08ba9', NULL, 7.000, 7.000, 5.0100, 35.07, '2026-10-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.817731+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a3820886-70f2-451b-ae99-5d924e455f32', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '45cccb60-d659-4421-a067-32c271cbf33f', NULL, 9.000, 9.000, 4.5300, 40.77, '2026-10-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.821635+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('61e81ddf-15f2-4512-8338-1eba317e91f1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', NULL, 2.000, 2.000, 4.6200, 9.24, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.825562+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('64ad57cb-da77-458f-85a5-a7a81a96b96e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '72d583c2-ff3d-4f7f-ae15-5333b3840dd0', NULL, 4.000, 4.000, 4.7100, 18.84, '2026-09-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.829584+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6e343cf1-21a3-472f-b598-2f65a83ea903', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0052c85e-7ae7-42ac-8a15-9a144ea74f59', NULL, 4.000, 4.000, 5.1700, 20.68, '2026-11-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.8334+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4360838c-b2d5-40b4-b730-d7a979eb536a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '319dc161-97d4-4a04-9b3d-cc64d9d704dd', NULL, 1.000, 1.000, 5.3700, 5.37, '2026-11-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.837254+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('07c8ddfd-0433-4377-bd9e-97b8e8bce089', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '6d36f2b9-47c7-4589-905f-b904d79bb551', NULL, 5.100, 5.100, 5.5900, 28.51, '2026-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.84123+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('95f2d0fe-8adb-46d3-854c-cb914495c276', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', NULL, 8.000, 8.000, 5.2800, 42.24, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.845033+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b3b5a0b8-9d29-4454-b1de-87577b390c92', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'adb37118-6006-4d99-8159-7f92dfcd47da', NULL, 6.900, 6.900, 5.2300, 36.09, '2026-11-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.848916+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('379465a3-2596-41e9-877e-6853ac6cd5b5', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'b2cb6849-0f1c-4a60-90a6-be0cc53c08ae', '9bdd58de-cf93-4391-a0b2-e777a521dc4b', 5.000, 5.000, 4200.0000, 21000.00, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.273617+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('20db69ca-6bd1-42f8-aa2d-dbfd4da6179c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', '1bd6df43-f9dd-401d-a2da-a65d7ae5183c', 3.000, 3.000, 5800.0000, 17400.00, '2026-11-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.273619+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6c941fee-b981-4252-9729-a29a90fea5b0', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', 'a6b5c6d3-0434-4c60-af1a-ab43ccacdddb', 48.000, 36.000, 4.5000, 216.00, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.208459+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('ae921086-248b-453f-a57d-ca149e38173b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '656e5398-3fa1-4738-9447-f448081d8e8c', 'a4b5dbcb-4a47-4e8b-97b0-efb3448a26d5', 12.000, 0.000, 4.5000, 54.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:36:20.348582+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('6e395f3a-04d5-4a28-8ae2-c9fda4aabf9c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', '6c457dd0-837d-471a-bc72-8f56f347d693', 8.000, 0.000, 8.9000, 71.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:36:20.348584+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('26b3ecd3-1de2-4709-a84d-803c5eb9710a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', 'aaf359ad-0eb3-4700-9d65-45df0552749c', 24.000, 18.000, 5.2000, 124.80, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.208462+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e6861283-4581-4341-aa98-f61895ad2855', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', '0cf6fce3-6066-4ba0-b431-7572284fd3a3', 36.000, 24.000, 8.9000, 320.40, '2026-11-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.208462+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('3ecc7424-a042-49b3-97fe-94e7aa22c06e', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'cc8ee259-f9ed-483f-8c35-4a06dcee91d2', '6022265c-5103-4003-be37-3593a50868d4', 6.000, 0.000, 5.2000, 31.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:36:21.159471+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('eeb16ab8-834e-480c-ae17-95c8a4f244a7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '064b9631-706c-49d0-84a4-8651d76ca29b', 'dd38a5d5-f174-4d93-a96e-8328248d49f2', 4.000, 0.000, 8.9000, 35.60, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:36:21.159472+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fae1b494-ed36-42a5-b395-39a59780616d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', '6934d50c-55e1-4ab9-840c-411775be2a8d', 60.000, 50.000, 12.5000, 750.00, '2026-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.247907+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('538d698c-7a87-42fe-9145-bb9da71bcbe8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', 'a0e9e025-9035-44b6-9bbf-9736b25dd99e', 20.000, 15.000, 4.1000, 82.00, '2026-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:20.247909+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('b3c5cc6e-5b7c-41a3-98a6-4be230c8f915', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7f8fb8ed-a9a4-46c0-a8c0-5815c06a4983', '4983a982-46a0-4320-906e-2acef04d0b8e', 10.000, 0.000, 12.5000, 125.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:36:21.239579+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('7028f4ca-c3c6-4699-82a7-6f8d293c4702', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'd9fb1f82-0cfa-4cdb-9bbb-84d95d9e69d9', '1c85a826-d604-43df-a123-9e428ca1422e', 5.000, 0.000, 4.1000, 20.50, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-22 23:36:21.23958+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1889ee24-8178-4d1b-8ca7-2191599f71cf', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0f92a508-261c-403d-bc4f-49b1635180cb', 'fb05ecc9-fa61-4197-a054-5d596153758e', 3.000, 3.000, 5800.0000, 17400.00, '2026-11-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:21.496934+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('e8720e22-d0dd-4fbd-8d26-00110a304495', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', NULL, 40.000, 13.600, 3.4000, 136.00, '2026-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.852936+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('1606b293-7059-47b8-9af8-f42c64f8782b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '63ade948-60ba-412d-b4b7-1e08c2140c55', NULL, 26.400, 0.000, 3.4000, 89.76, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-22 23:36:21.736134+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('32c63214-1e3e-4f3b-b1f0-96b0dee68658', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', NULL, 25.000, 21.220, 1.1000, 27.50, '2026-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.856725+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('326bef50-a905-4311-9702-c91ca22bab47', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5daaf10b-f21e-42cf-8250-9a58f4513d87', NULL, 3.780, 0.000, 1.1000, 4.16, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-22 23:36:21.754149+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('fab65eb0-2b49-4556-9c5c-ec4c00520038', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', NULL, 0.500, 0.440, 24.0000, 12.00, '2026-10-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:19.860792+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('a0880829-ac79-4051-9921-76daddd6e8f9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '7122be79-8284-4962-88fb-8b6b4fee6560', NULL, 0.060, 0.000, 24.0000, 1.44, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-22 23:36:21.77245+00', NULL, NULL, NULL, false);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at, revalued_at, unit_cost_before, cost_basis_before, internal) VALUES ('4cbe68b3-9a26-4b5b-809b-6e163784a55c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'a3446456-f5c3-4936-b45d-828b010a472e', NULL, 11.400, 11.400, 8.3647, 95.36, NULL, 'USD', 'IN', 'stated', NULL, NULL, '2026-11-22 23:36:21.801795+00', NULL, NULL, NULL, true);


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0dd7ddd4-eb86-469c-bc76-ee805d30a167', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, NULL, '[]', 'STOCK', '[]', 'Main Warehouse', 'Receiving and dispatch — shared by every module', NULL, NULL, 1, 'internal', NULL, '{"seed": {"code": "MAIN_WAREHOUSE", "name": "Main Warehouse"}}', NULL, '2026-11-22 23:36:18.612136+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('379db136-ad1f-4966-a755-480744391e2c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'cd439239-5d2c-4862-9d15-5bf0c5dc7034', '[]', 'STOCK', '[]', 'Consumed (Virtual)', NULL, 'System location', NULL, 39, 'customer', NULL, '{"seed": {"code": "CONSUMED_VIRTUAL", "name": "Consumed (Virtual)"}}', NULL, '2026-11-22 23:36:18.638857+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('529e1efd-7f3e-4ab9-9d0e-a6d97aa55803', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, NULL, '[]', 'NONE', '[]', 'IT Storage', 'IT equipment storage and logistics warehouse', NULL, NULL, 40, 'internal', 'equipment', '{"seed": {"code": "IT_STORAGE", "name": "IT Storage"}}', NULL, '2026-11-22 23:36:18.612142+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7808334a-dad9-446d-9ef1-8672d68b5132', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, '5e925474-29b8-4f13-8a83-6c5bda2ab5c6', '[]', 'STOCK', '[]', 'Quarantine', NULL, NULL, NULL, 43, 'internal', NULL, '{"seed": {"code": "QUARANTINE", "name": "Quarantine"}}', NULL, '2026-11-22 23:36:18.64467+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('010c3392-34d5-4fc7-be38-c536e1e95ca1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5d04b3e4-1c78-47dd-beaf-6cd40ca82b95', '0c55d08c-a98b-4d30-a6e3-8e6cf7540425', '[]', 'STOCK', '[]', 'UPS Bay', NULL, NULL, 'C-03', 28, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.045125+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0545b4f5-3032-4bf1-a785-2dbcf8b1bc2a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ca49c6ad-4a98-4ea9-b55e-237a22960943', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Fridge C', NULL, NULL, 'A-03', 7, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.027515+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('a592a0b4-923a-4034-b370-8891a40d43f7', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, NULL, '[]', 'NONE', '[]', 'Server Room', 'Primary server room / data center', NULL, NULL, 44, 'internal', 'equipment', '{"seed": {"code": "SERVER_ROOM", "name": "Server Room"}}', NULL, '2026-11-22 23:36:18.612141+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('e28b6ba5-d64f-4d73-b6c1-ff94571b89cc', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'cd439239-5d2c-4862-9d15-5bf0c5dc7034', '[]', 'STOCK', '[]', 'Production (Virtual)', NULL, 'System location', NULL, 42, 'production', NULL, '{"seed": {"code": "PRODUCTION_VIRTUAL", "name": "Production (Virtual)"}}', NULL, '2026-11-22 23:36:18.641356+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f1a8bdfd-069a-462d-9aaf-5ab1263311f8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, 'cd439239-5d2c-4862-9d15-5bf0c5dc7034', '[]', 'STOCK', '[]', 'Inventory Loss (Virtual)', NULL, 'System location', NULL, 41, 'inventory', NULL, '{"seed": {"code": "LOSS_VIRTUAL", "name": "Inventory Loss (Virtual)"}}', NULL, '2026-11-22 23:36:18.640165+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ca49c6ad-4a98-4ea9-b55e-237a22960943', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Fridge A', NULL, NULL, 'A-01', 3, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.024308+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('1b2c39b0-cc65-4b34-a95f-fd944492712f', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ca49c6ad-4a98-4ea9-b55e-237a22960943', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Fridge B', NULL, NULL, 'A-02', 6, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.026726+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('1ed0662e-7961-450a-a0f8-54ac1250f82a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '736c883c-00c6-41ad-aaac-238b44b067ad', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Workshop Shelf 2', NULL, NULL, 'D-02', 32, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.047943+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('211e5889-8bcb-43e8-98ef-685b7582bef3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Shelf A - Bottom', NULL, NULL, 'F-03', 17, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.036732+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('23002f42-22a6-41cb-b48d-49f1c0e23dde', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fde43874-4cd0-47b3-8c84-77641ba0d077', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Dry Goods', NULL, NULL, 'F', 14, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.034506+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('24937559-02f7-4737-9908-083c06714c5c', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5d04b3e4-1c78-47dd-beaf-6cd40ca82b95', '0c55d08c-a98b-4d30-a6e3-8e6cf7540425', '[]', 'STOCK', '[]', 'Patch Panel', NULL, NULL, 'C-04', 29, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.045834+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('34514748-faac-4ff5-adc7-005028de65a9', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc4786c3-8376-483b-ad46-944cef65da1b', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Workstations', NULL, NULL, 'E', 34, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.049354+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('555c4fbf-b2d4-4c9e-90b6-35eb39735284', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '736c883c-00c6-41ad-aaac-238b44b067ad', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Workshop Shelf 1', NULL, NULL, 'D-01', 31, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.047236+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('5d04b3e4-1c78-47dd-beaf-6cd40ca82b95', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc4786c3-8376-483b-ad46-944cef65da1b', '0c55d08c-a98b-4d30-a6e3-8e6cf7540425', '[]', 'STOCK', '[]', 'Server Room', NULL, NULL, 'C', 25, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.042946+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('608e2d51-d0d0-4a64-80be-dad9c224283a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '34514748-faac-4ff5-adc7-005028de65a9', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Floor 1 - Row B', NULL, NULL, 'E-02', 36, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.050768+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('62d3f0fd-fc28-46d8-8f11-7054e44c2046', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Shelf B - Bottom', NULL, NULL, 'F-06', 20, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.038948+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('6b736c79-ab15-4f7e-882e-160ba782738d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '736c883c-00c6-41ad-aaac-238b44b067ad', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Spare Parts Bin', NULL, NULL, 'D-03', 33, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.048647+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('736c883c-00c6-41ad-aaac-238b44b067ad', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'dc4786c3-8376-483b-ad46-944cef65da1b', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'IT Workshop', NULL, NULL, 'D', 30, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.046536+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7559c4d7-ce55-4d0a-bbc5-887c559e336d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Shelf A - Middle', NULL, NULL, 'F-02', 16, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.036008+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('756a80c8-21e1-4f4f-9f75-0cbd79fd3960', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '34514748-faac-4ff5-adc7-005028de65a9', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Floor 2 - Row A', NULL, NULL, 'E-03', 37, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.051475+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7a9e185d-1e23-4368-85cd-b555da7b10ea', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'ca49c6ad-4a98-4ea9-b55e-237a22960943', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Walk-in Cooler', NULL, NULL, 'A-04', 8, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.028299+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7c37dfca-c298-4205-87e3-c530c5e88990', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Shelf A - Top', NULL, NULL, 'F-01', 15, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.035257+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('896495c0-ac5b-4f88-9d3c-263344cc6d3a', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c7fe03df-7fef-469b-aa7e-a9ff2ee8f3f8', 'df171819-d4ec-45c4-92a4-a82442f9d6e3', '[]', 'FREEZING', '[]', 'Freezer 1', NULL, NULL, 'B-01', 10, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.030783+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('8b6f6b4a-9882-4863-a243-f5a107568dee', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5d04b3e4-1c78-47dd-beaf-6cd40ca82b95', '0c55d08c-a98b-4d30-a6e3-8e6cf7540425', '[]', 'STOCK', '[]', 'Server Rack B', NULL, NULL, 'C-02', 27, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.044403+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('95c56c34-8315-438d-b2c2-100085ecf05d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '34514748-faac-4ff5-adc7-005028de65a9', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Floor 2 - Row B', NULL, NULL, 'E-04', 38, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.052185+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('96bede93-9802-49a9-952b-075e2301156b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c7fe03df-7fef-469b-aa7e-a9ff2ee8f3f8', 'df171819-d4ec-45c4-92a4-a82442f9d6e3', '[]', 'FREEZING', '[]', 'Chest Freezer', NULL, NULL, 'B-03', 12, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.032694+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('a2cc3792-a342-48e5-bcac-39af703f7b18', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fc3f9936-ba37-4fdb-940a-d9341cc86b52', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'STOCK', '[]', 'Beverage Rack 2', NULL, NULL, 'G-02', 23, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.041137+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('aa58c46f-95a2-4436-bf0b-fea72254b649', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fc3f9936-ba37-4fdb-940a-d9341cc86b52', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'STOCK', '[]', 'Beverage Rack 1', NULL, NULL, 'G-01', 22, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.040401+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ab326239-0c31-4f35-8522-9c914c8be9c3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Shelf B - Top', NULL, NULL, 'F-04', 18, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.03746+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('af9d51aa-9aee-47f4-9b59-6134c2411cc6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '34514748-faac-4ff5-adc7-005028de65a9', 'aa87daf6-dc50-4c4c-88cb-757d718511b1', '[]', 'STOCK', '[]', 'Floor 1 - Row A', NULL, NULL, 'E-01', 35, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.050063+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Fridge A - Door', NULL, NULL, 'A-01-02', 5, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.025926+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c7fe03df-7fef-469b-aa7e-a9ff2ee8f3f8', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0dd7ddd4-eb86-469c-bc76-ee805d30a167', 'df171819-d4ec-45c4-92a4-a82442f9d6e3', '[]', 'FREEZING', '[]', 'Freezer Zone', NULL, NULL, 'B', 9, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.029714+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ca49c6ad-4a98-4ea9-b55e-237a22960943', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0dd7ddd4-eb86-469c-bc76-ee805d30a167', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Cold Storage', NULL, NULL, 'A', 2, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.023176+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('d67495d7-2c6d-48b0-b476-132f66241a6d', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'c7fe03df-7fef-469b-aa7e-a9ff2ee8f3f8', 'df171819-d4ec-45c4-92a4-a82442f9d6e3', '[]', 'FREEZING', '[]', 'Freezer 2', NULL, NULL, 'B-02', 11, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.031846+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('dc348dec-fee9-4f38-8959-8a0c1f02f466', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '23002f42-22a6-41cb-b48d-49f1c0e23dde', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'EXPIRY', '[]', 'Shelf B - Middle', NULL, NULL, 'F-05', 19, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.038164+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '0be6ade2-a2c4-4f0d-9d36-6fc0f0f9b17c', '73174578-cf1a-45e2-88d3-c7bc9b722def', '[]', 'EXPIRY', '[]', 'Fridge A - Top Shelf', NULL, NULL, 'A-01-01', 4, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.025114+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f6692961-91cb-41c9-a7e0-bf7b39b1cb1b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', '5d04b3e4-1c78-47dd-beaf-6cd40ca82b95', '0c55d08c-a98b-4d30-a6e3-8e6cf7540425', '[]', 'STOCK', '[]', 'Server Rack A', NULL, NULL, 'C-01', 26, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.043678+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('fc3f9936-ba37-4fdb-940a-d9341cc86b52', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'fde43874-4cd0-47b3-8c84-77641ba0d077', '2a7fb973-068f-4e2b-adcc-11ee43472156', '[]', 'STOCK', '[]', 'Beverages', NULL, NULL, 'G', 21, 'internal', 'food', NULL, NULL, '2026-11-22 23:36:19.039689+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('dc4786c3-8376-483b-ad46-944cef65da1b', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, '5e925474-29b8-4f13-8a83-6c5bda2ab5c6', '[]', 'STOCK', '[]', 'Office Building', NULL, NULL, 'LOC-P07U', 24, 'internal', 'equipment', NULL, NULL, '2026-11-22 23:36:19.042214+00', '29df2390-1a60-43fd-ba97-7824689adfc1');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('fde43874-4cd0-47b3-8c84-77641ba0d077', '7e14c7c3-6333-4270-93ad-2bc976a705d7', NULL, '5e925474-29b8-4f13-8a83-6c5bda2ab5c6', '[]', 'STOCK', '[]', 'Pantry Building', NULL, NULL, 'LOC-V1CZ', 13, 'internal', NULL, NULL, NULL, '2026-11-22 23:36:19.033699+00', '29df2390-1a60-43fd-ba97-7824689adfc1');


--
-- Data for Name: storage_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('93483d96-3c25-4857-b4da-86e872039b69', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Shelf / Cabinet', 'SHELF', 'STOCK', '["quantity", "unit"]', '[]', 'BookOpen', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('5e925474-29b8-4f13-8a83-6c5bda2ab5c6', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Storage Room', 'STORAGE_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Warehouse', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('cd439239-5d2c-4862-9d15-5bf0c5dc7034', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'System', 'SYSTEM', 'NONE', '[]', '[]', 'Settings', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('50366e48-1391-4587-904b-806c160bb298', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Tool Room', 'TOOL_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Wrench', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('e11816b3-6860-4be1-bf0f-0ca056aa7e57', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Maintenance Bay', 'MAINTENANCE_BAY', 'NONE', '["quantity", "unit"]', '[]', 'Hammer', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('0c55d08c-a98b-4d30-a6e3-8e6cf7540425', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Server Room', 'SERVER_ROOM', 'NONE', '["serial_number", "manufacturer", "model", "ip_address", "equipment_status"]', '[]', 'server', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('aa87daf6-dc50-4c4c-88cb-757d718511b1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'IT Storage / Warehouse', 'IT_STORAGE', 'NONE', '["serial_number", "manufacturer", "model", "equipment_status"]', '[]', 'warehouse', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('df171819-d4ec-45c4-92a4-a82442f9d6e3', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Freezer', 'FREEZER', 'FREEZING', '[]', '[]', 'Snowflake', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('73174578-cf1a-45e2-88d3-c7bc9b722def', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Fridge', 'FRIDGE', 'EXPIRY', '[]', '[]', 'Refrigerator', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('2a7fb973-068f-4e2b-adcc-11ee43472156', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Pantry', 'PANTRY', 'EXPIRY', '[]', '[]', 'ShoppingBasket', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('749e404c-d8c1-419d-9303-d9358e9f80e1', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'Medicine Cabinet', 'MEDICINE_CABINET', 'EXPIRY', '[]', '[]', 'Cross', true, NULL, '{"check_expiry": true}');


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_settings (key, value, updated_at, updated_by) VALUES ('default_org_limits', '{"max_members": null, "max_products": null, "ai_scans_monthly": null, "ai_requests_monthly": 20}', '2026-11-22 23:36:22.497076+00', NULL);


--
-- Data for Name: tax_rate_assignments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unit_conversions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: uom_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('4d10ed93-f6a2-4b49-9996-aba13fc06e92', NULL, 'Weight');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('e23e35cf-03d0-4750-9c01-76d61712422c', NULL, 'Volume');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('0fb2d921-d4fa-443d-b1de-58aac83c87e7', NULL, 'Unit');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('b26fcc11-1bf4-4bad-99d8-776b32ba5a90', NULL, 'Length');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('54da75c9-1102-4b85-b303-1d459e60dec3', NULL, 'Pack');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('7b3566a9-978a-486d-a853-13eb3165751b', NULL, 'Can');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('dd81f4a1-bc37-4d46-867e-1fd239daa18b', NULL, 'Bottle');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('f985c4d6-a551-4980-841d-b931aa92043f', NULL, 'Box');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('78852487-3743-4c16-b640-4b49ab7b97fb', NULL, 'Bag');


--
-- Data for Name: uoms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('0df06f1f-f1a8-4767-84a8-c7c5c4dd5bf4', NULL, '4d10ed93-f6a2-4b49-9996-aba13fc06e92', 'Gram', 'g', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('61cebc75-7127-4699-85e2-7617ae9db641', NULL, '4d10ed93-f6a2-4b49-9996-aba13fc06e92', 'Kilogram', 'kg', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('b42fd5a3-eab3-475b-8441-99206e1085a6', NULL, '4d10ed93-f6a2-4b49-9996-aba13fc06e92', 'Milligram', 'mg', 0.001000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('29c1522c-225d-4d62-8f12-641c72e23be9', NULL, '4d10ed93-f6a2-4b49-9996-aba13fc06e92', 'Ounce', 'oz', 28.349500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('5174f825-e914-443f-b5e2-e6328259d815', NULL, '4d10ed93-f6a2-4b49-9996-aba13fc06e92', 'Pound', 'lb', 453.592000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('91076c0d-7a37-4f23-9590-300a47f93015', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Milliliter', 'ml', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('19e5de51-08ed-48a0-9789-eb06c81d1e36', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Liter', 'l', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8352703e-3fa0-450f-9d3a-031f662471ce', NULL, '0fb2d921-d4fa-443d-b1de-58aac83c87e7', 'Piece', 'pcs', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('10215777-64f1-4376-ac45-1cc7b9b2128b', NULL, '54da75c9-1102-4b85-b303-1d459e60dec3', 'Pack', 'pack', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('a71af32c-86c9-43ec-a3b9-3ea09bab09fe', NULL, '7b3566a9-978a-486d-a853-13eb3165751b', 'Can', 'can', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8f1d9930-156b-40eb-97cd-9382934de286', NULL, 'dd81f4a1-bc37-4d46-867e-1fd239daa18b', 'Bottle', 'bottle', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('d010dbf0-9d3c-4b28-a47e-b2aa6d7b6eb3', NULL, 'f985c4d6-a551-4980-841d-b931aa92043f', 'Box', 'box', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('acf27799-1102-40d4-95c6-1ea3edbede20', NULL, '78852487-3743-4c16-b640-4b49ab7b97fb', 'Bag', 'bag', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('ccb90ec3-a00c-4cbe-8e16-6e73274bda02', NULL, 'b26fcc11-1bf4-4bad-99d8-776b32ba5a90', 'Centimeter', 'cm', 1.000000000, true, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('35d65477-d76b-4720-a3f0-3d50f4177990', NULL, 'b26fcc11-1bf4-4bad-99d8-776b32ba5a90', 'Meter', 'm', 100.000000000, false, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('aee4d17e-8d46-476f-8f1f-f86bdeae0012', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Fluid Ounce', 'fl oz', 29.573500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('06e8fd2c-a58f-4af7-b1d8-58e10b9466ff', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Cup (US)', 'cup', 236.588000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('fe1c92a4-aed2-4c42-b7cd-3d3d7447a83e', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Tablespoon', 'tbsp', 14.786800000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('eb321e6e-9c9f-4005-b9d7-75f6f6c92454', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Teaspoon', 'tsp', 4.928920000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('fef55dbf-3913-4bb9-8ab1-f7c5df37c199', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Pint (US)', 'pt', 473.176000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('7fe169b8-bb3d-4bd3-8adc-5f810e0510e2', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Quart (US)', 'qt', 946.353000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f19c56a4-50d3-4ca3-9ae2-0648bf66303c', NULL, 'e23e35cf-03d0-4750-9c01-76d61712422c', 'Gallon (US)', 'gal', 3785.410000000, false, true, 0.001000);


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('29df2390-1a60-43fd-ba97-7824689adfc1', 'admin@example.com', '$2b$12$4879Ol211t3Qktrc.vTX1.isuu05AwkgvYlCeHI1wxJua/k.Nv1By', 'Demo Administrator', '2026-11-22 23:36:18.521051+00', '2026-11-22 23:36:18.528279+00', 'en', 'admin', true, false, false, NULL, NULL, 0, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('c0c8f11c-71c2-4a0b-aa25-045c63464d1e', 'ava.brennan@example.com', '$2b$12$musPdPOclymJqqpgjG9SKeCWYhF8kOTlZ09IT/6LLf28Dp7h8/SX6', 'Ava Brennan', '2026-11-22 23:36:22.238886+00', '2026-11-22 23:36:22.238888+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('f1d9c079-8f7d-467d-9a00-a127d6f7b5dc', 'marcus.webb@example.com', '$2b$12$ayJntcHXGvX8VgOCzv3D6eCi9zJZOK/IPxR0sKIlhiIZ7XSDVIKiW', 'Marcus Webb', '2026-11-22 23:36:22.23889+00', '2026-11-22 23:36:22.238891+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, '7e14c7c3-6333-4270-93ad-2bc976a705d7');


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_line_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('67105cd1-0179-4bde-81d0-6486dc07c689', '0bab75a7-1ebd-49d2-8921-31e64c882e55', '4983a982-46a0-4320-906e-2acef04d0b8e', 2, 'picked', 10.000, 'A-01-02 · Fridge A - Door', 'Gouda Cheese', NULL, 10.000, 'pcs', '5ac79edd-280f-4fb0-a2db-b5ed60b83506', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('a911f0d4-2d09-4187-816e-65bba5154a64', '0bab75a7-1ebd-49d2-8921-31e64c882e55', '1c85a826-d604-43df-a123-9e428ca1422e', 3, 'picked', 5.000, 'A-01-02 · Fridge A - Door', 'Sour Cream 18%', NULL, 5.000, 'pcs', 'b4c0dd0a-3a0f-49c6-b9f7-b5038f22fe6f', NULL, 'c0fcef7e-38b1-4cb2-82bf-3ba9acbc0736', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('e88d7990-e20b-44fe-bfbd-a47468cafa20', '0bab75a7-1ebd-49d2-8921-31e64c882e55', '6022265c-5103-4003-be37-3593a50868d4', 0, 'picked', 6.000, 'A-01-01 · Fridge A - Top Shelf', 'Natural Yoghurt 400g', NULL, 6.000, 'pcs', 'dfabd9de-7da0-45e6-9ae2-a670237e9f15', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('f76dd76b-e758-425f-ab33-89ed5924e4a0', '0bab75a7-1ebd-49d2-8921-31e64c882e55', 'dd38a5d5-f174-4d93-a96e-8328248d49f2', 1, 'picked', 4.000, 'A-01-01 · Fridge A - Top Shelf', 'Butter Extra 82%', NULL, 4.000, 'pcs', '82ec997c-6945-4522-93a0-1f1c2fed8269', NULL, 'dc726c2c-e7df-4a6c-9e7c-5f5c1998bf93', NULL);


--
-- Data for Name: wms_pick_session_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('0bab75a7-1ebd-49d2-8921-31e64c882e55', 'aaa28144-9b19-429b-9c06-de601c1b317b', 0);
INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('0bab75a7-1ebd-49d2-8921-31e64c882e55', 'aa365cc5-5414-40a4-9ada-86f186c992e3', 1);


--
-- Data for Name: wms_pick_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_sessions (id, organization_id, document_id, assigned_to, status, started_at, completed_at, meta_data, last_activity_at) VALUES ('0bab75a7-1ebd-49d2-8921-31e64c882e55', '7e14c7c3-6333-4270-93ad-2bc976a705d7', 'aaa28144-9b19-429b-9c06-de601c1b317b', '29df2390-1a60-43fd-ba97-7824689adfc1', 'completed', '2026-11-22 23:36:20.552639+00', '2026-11-22 23:36:20.736482+00', 'null', '2026-11-22 23:36:20.717515+00');


--
-- Name: ai_connections ai_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version_api_keys alembic_version_api_keys_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_api_keys
    ADD CONSTRAINT alembic_version_api_keys_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_approvals alembic_version_approvals_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_approvals
    ADD CONSTRAINT alembic_version_approvals_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_equipment alembic_version_equipment_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_equipment
    ADD CONSTRAINT alembic_version_equipment_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_example_widgets alembic_version_example_widgets_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_example_widgets
    ADD CONSTRAINT alembic_version_example_widgets_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_maker alembic_version_maker_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_maker
    ADD CONSTRAINT alembic_version_maker_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_printing alembic_version_printing_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_printing
    ADD CONSTRAINT alembic_version_printing_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_purchase_orders alembic_version_purchase_orders_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_purchase_orders
    ADD CONSTRAINT alembic_version_purchase_orders_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_recipes alembic_version_recipes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_recipes
    ADD CONSTRAINT alembic_version_recipes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_shopping_lists alembic_version_shopping_lists_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_shopping_lists
    ADD CONSTRAINT alembic_version_shopping_lists_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_stock_takes alembic_version_stock_takes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_stock_takes
    ADD CONSTRAINT alembic_version_stock_takes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_warehouse alembic_version_warehouse_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_warehouse
    ADD CONSTRAINT alembic_version_warehouse_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_webhooks alembic_version_webhooks_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_webhooks
    ADD CONSTRAINT alembic_version_webhooks_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approval_decisions approval_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: approval_workflows approval_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);


--
-- Name: audit_campaigns audit_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_response_items audit_response_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_pkey PRIMARY KEY (id);


--
-- Name: audit_responses audit_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cycle_count_schedules cycle_count_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_pkey PRIMARY KEY (id);


--
-- Name: document_cost_variances document_cost_variances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_pkey PRIMARY KEY (id);


--
-- Name: document_extra_costs document_extra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_pkey PRIMARY KEY (id);


--
-- Name: document_lines document_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_pkey PRIMARY KEY (id);


--
-- Name: document_number_sequences document_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_pkey PRIMARY KEY (organization_id, prefix);


--
-- Name: document_package_lines document_package_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_pkey PRIMARY KEY (id);


--
-- Name: document_packages document_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_pkey PRIMARY KEY (id);


--
-- Name: document_profiles document_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_pkey PRIMARY KEY (id);


--
-- Name: document_relations document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_pkey PRIMARY KEY (id);


--
-- Name: document_shipments document_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: document_type_configs document_type_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_pkey PRIMARY KEY (id);


--
-- Name: document_warehouse_receiving document_warehouse_receiving_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_pkey PRIMARY KEY (id);


--
-- Name: document_work_item_overlays document_work_item_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_jobs email_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_jobs
    ADD CONSTRAINT email_jobs_pkey PRIMARY KEY (id);


--
-- Name: equipment_assignments equipment_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_pkey PRIMARY KEY (id);


--
-- Name: equipment_attachments equipment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_pkey PRIMARY KEY (id);


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: event_deliveries event_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT event_deliveries_pkey PRIMARY KEY (id);


--
-- Name: event_outbox event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox
    ADD CONSTRAINT event_outbox_pkey PRIMARY KEY (id);


--
-- Name: example_widgets example_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_pkey PRIMARY KEY (id);


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_pkey PRIMARY KEY (id);


--
-- Name: inventory_periods inventory_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_pkey PRIMARY KEY (id);


--
-- Name: item_attachments item_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_pkey PRIMARY KEY (id);


--
-- Name: item_history item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_pkey PRIMARY KEY (id);


--
-- Name: item_import_jobs item_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: label_pool label_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_pkey PRIMARY KEY (id);


--
-- Name: location_relocations location_relocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_pkey PRIMARY KEY (id);


--
-- Name: maker_bom_lines maker_bom_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_ingredient_prices maker_ingredient_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT maker_ingredient_prices_pkey PRIMARY KEY (id);


--
-- Name: maker_label_facts maker_label_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT maker_label_facts_pkey PRIMARY KEY (id);


--
-- Name: maker_module_settings maker_module_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: maker_production_attachments maker_production_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_pkey PRIMARY KEY (id);


--
-- Name: maker_production_order_lines maker_production_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_production_orders maker_production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_pkey PRIMARY KEY (id);


--
-- Name: maker_production_portions maker_production_portions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_pkey PRIMARY KEY (id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_recipes maker_recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_pkey PRIMARY KEY (id);


--
-- Name: maker_shelf_lives maker_shelf_lives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT maker_shelf_lives_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_entries meal_plan_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_pkey PRIMARY KEY (id);


--
-- Name: meal_plans meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_pkey PRIMARY KEY (id);


--
-- Name: module_installations module_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_installations
    ADD CONSTRAINT module_installations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: picking_session_items picking_session_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_pkey PRIMARY KEY (id);


--
-- Name: picking_sessions picking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_pkey PRIMARY KEY (id);


--
-- Name: po_partner_pricelist po_partner_pricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_pkey PRIMARY KEY (id);


--
-- Name: po_reorder_rules po_reorder_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_pkey PRIMARY KEY (id);


--
-- Name: po_settings po_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_pkey PRIMARY KEY (id);


--
-- Name: print_agents print_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_pkey PRIMARY KEY (id);


--
-- Name: print_jobs print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_pkey PRIMARY KEY (id);


--
-- Name: product_templates product_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: putaway_capacity putaway_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_pkey PRIMARY KEY (id);


--
-- Name: putaway_home_silenced putaway_home_silenced_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_pkey PRIMARY KEY (id);


--
-- Name: putaway_location_settings putaway_location_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_pkey PRIMARY KEY (id);


--
-- Name: putaway_rule_locations putaway_rule_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_pkey PRIMARY KEY (id);


--
-- Name: putaway_rules putaway_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_pkey PRIMARY KEY (id);


--
-- Name: recipe_collection_members recipe_collection_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_pkey PRIMARY KEY (id);


--
-- Name: recipe_collections recipe_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipe_tag_configs recipe_tag_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shopping_exclusions shopping_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_history shopping_list_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_items shopping_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_pkey PRIMARY KEY (id);


--
-- Name: shopping_lists shopping_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_pkey PRIMARY KEY (id);


--
-- Name: stock_anchors stock_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger_totals stock_ledger_totals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_pkey PRIMARY KEY (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_lots stock_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_pkey PRIMARY KEY (id);


--
-- Name: stock_moves stock_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_closed_locations stock_take_closed_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_counts stock_take_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_take_items stock_take_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);


--
-- Name: stock_takes stock_takes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);


--
-- Name: stock_valuation_layers stock_valuation_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: storage_types storage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tax_rate_assignments tax_rate_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_pkey PRIMARY KEY (id);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: unit_conversions unit_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom_categories uom_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_pkey PRIMARY KEY (id);


--
-- Name: uoms uoms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_pkey PRIMARY KEY (id);


--
-- Name: ai_connections uq_ai_connections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT uq_ai_connections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_bom_lines uq_bom_recipe_child; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT uq_bom_recipe_child UNIQUE (recipe_id, child_template_id);


--
-- Name: document_type_configs uq_doctype_config_org_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT uq_doctype_config_org_type UNIQUE (organization_id, document_type);


--
-- Name: documents uq_document_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT uq_document_org_number UNIQUE (organization_id, number);


--
-- Name: document_package_lines uq_document_package_lines_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT uq_document_package_lines_line UNIQUE (document_package_id, document_line_id);


--
-- Name: document_packages uq_document_packages_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT uq_document_packages_number UNIQUE (document_id, number);


--
-- Name: document_profiles uq_document_profile_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT uq_document_profile_org UNIQUE (organization_id);


--
-- Name: document_shipments uq_document_shipments_document; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT uq_document_shipments_document UNIQUE (document_id);


--
-- Name: document_warehouse_receiving uq_document_warehouse_receiving_org_warehouse; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT uq_document_warehouse_receiving_org_warehouse UNIQUE (organization_id, warehouse_id);


--
-- Name: event_deliveries uq_event_deliveries_event_handler; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT uq_event_deliveries_event_handler UNIQUE (event_id, handler);


--
-- Name: ingredient_nutrition_defaults uq_ingredient_defaults_org_lang_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT uq_ingredient_defaults_org_lang_name UNIQUE (organization_id, lang, name_normalized);


--
-- Name: inventory_periods uq_inventory_period_org_year_month; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT uq_inventory_period_org_year_month UNIQUE (organization_id, year, month);


--
-- Name: label_pool uq_label_pool_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT uq_label_pool_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: stock_lots uq_lot_org_product_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT uq_lot_org_product_name UNIQUE (organization_id, product_template_id, name);


--
-- Name: maker_label_facts uq_maker_label_facts_org_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT uq_maker_label_facts_org_template UNIQUE (organization_id, product_template_id);


--
-- Name: maker_ingredient_prices uq_maker_price_org_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT uq_maker_price_org_template UNIQUE (organization_id, product_template_id);


--
-- Name: maker_shelf_lives uq_maker_shelf_life_org_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT uq_maker_shelf_life_org_template UNIQUE (organization_id, product_template_id);


--
-- Name: meal_plan_entries uq_meal_plan_entries_plan_date_slot_order; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT uq_meal_plan_entries_plan_date_slot_order UNIQUE (meal_plan_id, date, slot, "order");


--
-- Name: partners uq_partner_org_name_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT uq_partner_org_name_type UNIQUE (organization_id, name, type);


--
-- Name: po_reorder_rules uq_po_reorder_rules_org_product_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT uq_po_reorder_rules_org_product_loc UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: po_settings uq_po_settings_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT uq_po_settings_org UNIQUE (organization_id);


--
-- Name: print_agents uq_print_agents_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT uq_print_agents_org_name UNIQUE (organization_id, name);


--
-- Name: purchase_orders uq_purchase_orders_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT uq_purchase_orders_org_number UNIQUE (organization_id, number);


--
-- Name: putaway_capacity uq_putaway_capacity_org_loc_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT uq_putaway_capacity_org_loc_product UNIQUE (organization_id, location_id, product_template_id);


--
-- Name: putaway_home_silenced uq_putaway_home_silenced_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT uq_putaway_home_silenced_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: putaway_location_settings uq_putaway_location_settings_org_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT uq_putaway_location_settings_org_loc UNIQUE (organization_id, location_id);


--
-- Name: putaway_rule_locations uq_putaway_rule_locations_rule_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT uq_putaway_rule_locations_rule_loc UNIQUE (rule_id, location_id);


--
-- Name: recipe_collection_members uq_recipe_collection_members; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT uq_recipe_collection_members UNIQUE (collection_id, recipe_id);


--
-- Name: recipe_collections uq_recipe_collections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT uq_recipe_collections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_recipes uq_recipe_org_template_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT uq_recipe_org_template_name UNIQUE (organization_id, output_template_id, name);


--
-- Name: recipe_tag_configs uq_recipe_tag_configs_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT uq_recipe_tag_configs_org_name UNIQUE (organization_id, name);


--
-- Name: shopping_exclusions uq_shopping_exclusions_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT uq_shopping_exclusions_org_name UNIQUE (organization_id, name_normalized);


--
-- Name: stock_anchors uq_stock_anchor_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT uq_stock_anchor_group UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_take_closed_locations uq_stock_take_closed_locations_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT uq_stock_take_closed_locations_location UNIQUE (stock_take_id, storage_location_id);


--
-- Name: storage_locations uq_storage_locations_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT uq_storage_locations_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_category; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_category UNIQUE (organization_id, category_id);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: unit_conversions uq_unit_conv_org_ingredient_unit_lang; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT uq_unit_conv_org_ingredient_unit_lang UNIQUE (organization_id, ingredient_key, source_unit, lang);


--
-- Name: uom_categories uq_uom_category_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uq_uom_category_org_name UNIQUE (organization_id, name);


--
-- Name: uoms uq_uom_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uq_uom_org_name UNIQUE (organization_id, name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pkey PRIMARY KEY (pick_line_id, lot_id);


--
-- Name: wms_pick_lines wms_pick_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_session_documents wms_pick_session_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_pkey PRIMARY KEY (session_id, document_id);


--
-- Name: wms_pick_sessions wms_pick_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_connections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_connections_organization_id ON public.ai_connections USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_created_at ON public.ai_usage_logs USING btree (created_at);


--
-- Name: ix_ai_usage_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_organization_id ON public.ai_usage_logs USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_user_id ON public.ai_usage_logs USING btree (user_id);


--
-- Name: ix_api_keys_hashed_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_api_keys_hashed_key ON public.api_keys USING btree (hashed_key);


--
-- Name: ix_api_keys_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_organization_id ON public.api_keys USING btree (organization_id);


--
-- Name: ix_approval_decisions_approval_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_decisions_approval_request_id ON public.approval_decisions USING btree (approval_request_id);


--
-- Name: ix_approval_requests_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_organization_id ON public.approval_requests USING btree (organization_id);


--
-- Name: ix_approval_requests_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_target ON public.approval_requests USING btree (target_type, target_id, organization_id);


--
-- Name: ix_approval_workflows_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_workflows_organization_id ON public.approval_workflows USING btree (organization_id);


--
-- Name: ix_audit_campaigns_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_org ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_campaigns_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_organization_id ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_log_org_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_created_at_id ON public.audit_log USING btree (organization_id, created_at DESC, id);


--
-- Name: ix_audit_log_org_type_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_type_created_at ON public.audit_log USING btree (organization_id, target_type, created_at DESC, id);


--
-- Name: ix_audit_log_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_target ON public.audit_log USING btree (target_type, target_id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_audit_response_items_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_assignment_id ON public.audit_response_items USING btree (assignment_id);


--
-- Name: ix_audit_response_items_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_item_id ON public.audit_response_items USING btree (item_id);


--
-- Name: ix_audit_response_items_response_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_response_id ON public.audit_response_items USING btree (response_id);


--
-- Name: ix_audit_responses_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_assignment_id ON public.audit_responses USING btree (assignment_id);


--
-- Name: ix_audit_responses_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_id ON public.audit_responses USING btree (campaign_id);


--
-- Name: ix_audit_responses_campaign_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_status ON public.audit_responses USING btree (campaign_id, status);


--
-- Name: ix_audit_responses_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_organization_id ON public.audit_responses USING btree (organization_id);


--
-- Name: ix_audit_responses_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_responses_token ON public.audit_responses USING btree (token);


--
-- Name: ix_bom_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_org ON public.maker_bom_lines USING btree (organization_id);


--
-- Name: ix_bom_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_parent ON public.maker_bom_lines USING btree (parent_template_id);


--
-- Name: ix_bom_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_recipe ON public.maker_bom_lines USING btree (recipe_id);


--
-- Name: ix_categories_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_code ON public.categories USING btree (code);


--
-- Name: ix_categories_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_context_tag ON public.categories USING btree (context_tag);


--
-- Name: ix_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_is_active ON public.categories USING btree (is_active);


--
-- Name: ix_categories_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_module_name ON public.categories USING btree (module_name);


--
-- Name: ix_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_organization_id ON public.categories USING btree (organization_id);


--
-- Name: ix_cycle_count_schedules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cycle_count_schedules_organization_id ON public.cycle_count_schedules USING btree (organization_id);


--
-- Name: ix_doc_relation_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_source ON public.document_relations USING btree (source_document_id);


--
-- Name: ix_doc_relation_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_target ON public.document_relations USING btree (target_document_id);


--
-- Name: ix_doc_templates_org_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_templates_org_module ON public.document_templates USING btree (organization_id, module);


--
-- Name: ix_document_cost_variances_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_cost_variances_document ON public.document_cost_variances USING btree (document_id);


--
-- Name: ix_document_cost_variances_org_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_cost_variances_org_date ON public.document_cost_variances USING btree (organization_id, occurred_on);


--
-- Name: ix_document_extra_costs_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_document ON public.document_extra_costs USING btree (document_id);


--
-- Name: ix_document_extra_costs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_organization_id ON public.document_extra_costs USING btree (organization_id);


--
-- Name: ix_document_lines_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_brand_trgm ON public.document_lines USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_document_lines_corrects_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_corrects_line_id ON public.document_lines USING btree (corrects_line_id);


--
-- Name: ix_document_lines_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_document_id ON public.document_lines USING btree (document_id);


--
-- Name: ix_document_lines_held; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_held ON public.document_lines USING btree (document_id) WHERE (held_quantity > (0)::numeric);


--
-- Name: ix_document_lines_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_name_trgm ON public.document_lines USING gin (name public.gin_trgm_ops);


--
-- Name: ix_document_lines_puts_away_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_puts_away_line_id ON public.document_lines USING btree (puts_away_line_id);


--
-- Name: ix_document_lines_source_po_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_source_po_line_id ON public.document_lines USING btree (source_po_line_id);


--
-- Name: ix_document_org_partner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_partner ON public.documents USING btree (organization_id, partner_id);


--
-- Name: ix_document_org_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_status_created_at ON public.documents USING btree (organization_id, status, created_at);


--
-- Name: ix_document_org_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_type_status ON public.documents USING btree (organization_id, type, status);


--
-- Name: ix_document_package_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_line_id ON public.document_package_lines USING btree (document_line_id);


--
-- Name: ix_document_package_lines_document_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_package_id ON public.document_package_lines USING btree (document_package_id);


--
-- Name: ix_document_packages_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_document_id ON public.document_packages USING btree (document_id);


--
-- Name: ix_document_packages_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_organization_id ON public.document_packages USING btree (organization_id);


--
-- Name: ix_document_profiles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_profiles_organization_id ON public.document_profiles USING btree (organization_id);


--
-- Name: ix_document_shipments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shipments_organization_id ON public.document_shipments USING btree (organization_id);


--
-- Name: ix_document_templates_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_module ON public.document_templates USING btree (module);


--
-- Name: ix_document_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_organization_id ON public.document_templates USING btree (organization_id);


--
-- Name: ix_document_type_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_type_configs_organization_id ON public.document_type_configs USING btree (organization_id);


--
-- Name: ix_document_warehouse_receiving_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_warehouse_receiving_organization_id ON public.document_warehouse_receiving USING btree (organization_id);


--
-- Name: ix_document_work_item_overlays_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_work_item_overlays_organization_id ON public.document_work_item_overlays USING btree (organization_id);


--
-- Name: ix_documents_backorder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_backorder_id ON public.documents USING btree (backorder_id);


--
-- Name: ix_documents_corrects_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_corrects_document_id ON public.documents USING btree (corrects_document_id);


--
-- Name: ix_documents_external_reference_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_external_reference_trgm ON public.documents USING gin (external_reference public.gin_trgm_ops);


--
-- Name: ix_documents_notes_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_notes_trgm ON public.documents USING gin (notes public.gin_trgm_ops);


--
-- Name: ix_documents_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_number_trgm ON public.documents USING gin (number public.gin_trgm_ops);


--
-- Name: ix_documents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_organization_id ON public.documents USING btree (organization_id);


--
-- Name: ix_documents_partner_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_partner_name_trgm ON public.documents USING gin (((partner_snapshot ->> 'name'::text)) public.gin_trgm_ops);


--
-- Name: ix_email_jobs_next_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_next_attempt_at ON public.email_jobs USING btree (next_attempt_at);


--
-- Name: ix_email_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_organization_id ON public.email_jobs USING btree (organization_id);


--
-- Name: ix_email_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_status ON public.email_jobs USING btree (status);


--
-- Name: ix_eq_assignments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_assignments_org_item ON public.equipment_assignments USING btree (organization_id, item_id);


--
-- Name: ix_eq_attachments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_attachments_org_item ON public.equipment_attachments USING btree (organization_id, item_id);


--
-- Name: ix_eq_maintenance_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_maintenance_org_item ON public.equipment_maintenance_logs USING btree (organization_id, item_id);


--
-- Name: ix_equipment_assignments_assignee_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_assignee_partner_id ON public.equipment_assignments USING btree (assignee_partner_id);


--
-- Name: ix_equipment_assignments_checkout_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_checkout_location_id ON public.equipment_assignments USING btree (checkout_location_id);


--
-- Name: ix_equipment_assignments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_item_id ON public.equipment_assignments USING btree (item_id);


--
-- Name: ix_equipment_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_organization_id ON public.equipment_assignments USING btree (organization_id);


--
-- Name: ix_equipment_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_item_id ON public.equipment_attachments USING btree (item_id);


--
-- Name: ix_equipment_attachments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_organization_id ON public.equipment_attachments USING btree (organization_id);


--
-- Name: ix_equipment_maintenance_logs_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_item_id ON public.equipment_maintenance_logs USING btree (item_id);


--
-- Name: ix_equipment_maintenance_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_organization_id ON public.equipment_maintenance_logs USING btree (organization_id);


--
-- Name: ix_event_deliveries_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_organization_id ON public.event_deliveries USING btree (organization_id);


--
-- Name: ix_event_deliveries_status_next_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_status_next_attempt ON public.event_deliveries USING btree (status, next_attempt_at);


--
-- Name: ix_event_outbox_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_organization_id ON public.event_outbox USING btree (organization_id);


--
-- Name: ix_event_outbox_unpublished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_unpublished ON public.event_outbox USING btree (created_at) WHERE (published_at IS NULL);


--
-- Name: ix_example_widgets_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_example_widgets_organization_id ON public.example_widgets USING btree (organization_id);


--
-- Name: ix_ingredient_defaults_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_defaults_lookup ON public.ingredient_nutrition_defaults USING btree (name_normalized, lang, organization_id);


--
-- Name: ix_ingredient_nutrition_defaults_name_normalized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_name_normalized ON public.ingredient_nutrition_defaults USING btree (name_normalized);


--
-- Name: ix_ingredient_nutrition_defaults_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_organization_id ON public.ingredient_nutrition_defaults USING btree (organization_id);


--
-- Name: ix_item_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_attachments_item_id ON public.item_attachments USING btree (item_id);


--
-- Name: ix_item_history_item_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_item_created ON public.item_history USING btree (item_id, created_at);


--
-- Name: ix_item_history_org_action_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_org_action_created ON public.item_history USING btree (organization_id, action, created_at);


--
-- Name: ix_item_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_organization_id ON public.item_history USING btree (organization_id);


--
-- Name: ix_item_history_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_source_document_id ON public.item_history USING btree (source_document_id);


--
-- Name: ix_item_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_user_id ON public.item_history USING btree (user_id);


--
-- Name: ix_item_import_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_import_jobs_organization_id ON public.item_import_jobs USING btree (organization_id);


--
-- Name: ix_items_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode ON public.items USING btree (barcode);


--
-- Name: ix_items_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode_trgm ON public.items USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_items_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_brand_trgm ON public.items USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_items_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_created_at ON public.items USING btree (created_at);


--
-- Name: ix_items_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_expiry_date ON public.items USING btree (expiry_date);


--
-- Name: ix_items_is_catalog_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_catalog_entry ON public.items USING btree (is_catalog_entry);


--
-- Name: ix_items_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_deleted ON public.items USING btree (is_deleted);


--
-- Name: ix_items_label_code_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_label_code_trgm ON public.items USING gin (label_code public.gin_trgm_ops);


--
-- Name: ix_items_meta_data_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_meta_data_gin ON public.items USING gin (meta_data);


--
-- Name: ix_items_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_module_name ON public.items USING btree (module_name);


--
-- Name: ix_items_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_name_trgm ON public.items USING gin (name public.gin_trgm_ops);


--
-- Name: ix_items_org_archived_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_archived_at ON public.items USING btree (organization_id, is_deleted, COALESCE(deleted_at, created_at) DESC, id);


--
-- Name: ix_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_barcode_active ON public.items USING btree (organization_id, barcode, is_deleted);


--
-- Name: ix_items_org_category_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_category_active ON public.items USING btree (organization_id, category_id, is_deleted);


--
-- Name: ix_items_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_created ON public.items USING btree (organization_id, is_deleted, created_at DESC);


--
-- Name: ix_items_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_name ON public.items USING btree (organization_id, is_deleted, name);


--
-- Name: ix_items_org_not_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_not_deleted ON public.items USING btree (organization_id, is_deleted);


--
-- Name: ix_items_org_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_template_active ON public.items USING btree (organization_id, template_id, is_deleted);


--
-- Name: ix_items_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_organization_id ON public.items USING btree (organization_id);


--
-- Name: ix_items_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_partner_id ON public.items USING btree (partner_id);


--
-- Name: ix_items_quantity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_quantity ON public.items USING btree (quantity);


--
-- Name: ix_items_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number ON public.items USING btree (serial_number);


--
-- Name: ix_items_serial_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number_trgm ON public.items USING gin (serial_number public.gin_trgm_ops);


--
-- Name: ix_items_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_source_document_id ON public.items USING btree (source_document_id);


--
-- Name: ix_items_stock_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_stock_group ON public.items USING btree (organization_id, template_id, storage_location_id, lot_id, owner_id) INCLUDE (quantity, is_deleted);


--
-- Name: ix_items_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_storage_location_id ON public.items USING btree (storage_location_id);


--
-- Name: ix_label_pool_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_context_tag ON public.label_pool USING btree (context_tag);


--
-- Name: ix_label_pool_is_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_is_assigned ON public.label_pool USING btree (is_assigned);


--
-- Name: ix_location_relocations_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_relocations_org_moved_at ON public.location_relocations USING btree (organization_id, moved_at);


--
-- Name: ix_lot_org_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_org_expiry ON public.stock_lots USING btree (organization_id, expiry_date);


--
-- Name: ix_maker_attachment_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_maker_attachment_order ON public.maker_production_attachments USING btree (organization_id, production_order_id);


--
-- Name: ix_maker_price_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_maker_price_org ON public.maker_ingredient_prices USING btree (organization_id);


--
-- Name: ix_meal_plan_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_date ON public.meal_plan_entries USING btree (date);


--
-- Name: ix_meal_plan_entries_meal_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_meal_plan_id ON public.meal_plan_entries USING btree (meal_plan_id);


--
-- Name: ix_meal_plan_entries_plan_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_plan_date ON public.meal_plan_entries USING btree (meal_plan_id, date);


--
-- Name: ix_meal_plan_entries_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_recipe ON public.meal_plan_entries USING btree (recipe_id);


--
-- Name: ix_meal_plans_org_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_end ON public.meal_plans USING btree (organization_id, end_date);


--
-- Name: ix_meal_plans_org_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_start ON public.meal_plans USING btree (organization_id, start_date);


--
-- Name: ix_meal_plans_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_organization_id ON public.meal_plans USING btree (organization_id);


--
-- Name: ix_module_installations_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_module_installations_module_name ON public.module_installations USING btree (module_name);


--
-- Name: ix_notifications_user_read_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_read_created ON public.notifications USING btree (user_id, is_read, created_at);


--
-- Name: ix_organization_invitations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organization_invitations_code ON public.organization_invitations USING btree (code);


--
-- Name: ix_organizations_short_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_short_id ON public.organizations USING btree (short_id);


--
-- Name: ix_partners_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_code ON public.partners USING btree (code);


--
-- Name: ix_partners_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_is_active ON public.partners USING btree (is_active);


--
-- Name: ix_partners_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_name_trgm ON public.partners USING gin (name public.gin_trgm_ops);


--
-- Name: ix_partners_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_organization_id ON public.partners USING btree (organization_id);


--
-- Name: ix_picking_session_items_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_session_items_session_id ON public.picking_session_items USING btree (session_id);


--
-- Name: ix_picking_sessions_meal_plan_entry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_meal_plan_entry_id ON public.picking_sessions USING btree (meal_plan_entry_id);


--
-- Name: ix_picking_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_organization_id ON public.picking_sessions USING btree (organization_id);


--
-- Name: ix_picking_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_user_id ON public.picking_sessions USING btree (user_id);


--
-- Name: ix_po_partner_pricelist_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_organization_id ON public.po_partner_pricelist USING btree (organization_id);


--
-- Name: ix_po_partner_pricelist_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_partner_id ON public.po_partner_pricelist USING btree (partner_id);


--
-- Name: ix_po_partner_pricelist_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_product_template_id ON public.po_partner_pricelist USING btree (product_template_id);


--
-- Name: ix_po_partner_pricelist_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_template_active ON public.po_partner_pricelist USING btree (product_template_id, valid_from, valid_to);


--
-- Name: ix_po_reorder_rules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_organization_id ON public.po_reorder_rules USING btree (organization_id);


--
-- Name: ix_po_reorder_rules_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_product_template_id ON public.po_reorder_rules USING btree (product_template_id);


--
-- Name: ix_po_reorder_rules_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_storage_location_id ON public.po_reorder_rules USING btree (storage_location_id);


--
-- Name: ix_po_settings_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_settings_organization_id ON public.po_settings USING btree (organization_id);


--
-- Name: ix_print_agents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_agents_organization_id ON public.print_agents USING btree (organization_id);


--
-- Name: ix_print_jobs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_agent_id ON public.print_jobs USING btree (agent_id);


--
-- Name: ix_print_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_organization_id ON public.print_jobs USING btree (organization_id);


--
-- Name: ix_print_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_status ON public.print_jobs USING btree (status);


--
-- Name: ix_prod_line_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_line_order ON public.maker_production_order_lines USING btree (production_order_id);


--
-- Name: ix_prod_org_output; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_output ON public.maker_production_orders USING btree (organization_id, output_template_id);


--
-- Name: ix_prod_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_status ON public.maker_production_orders USING btree (organization_id, status);


--
-- Name: ix_prod_portion_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_portion_order ON public.maker_production_portions USING btree (production_order_id);


--
-- Name: ix_product_templates_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode ON public.product_templates USING btree (barcode);


--
-- Name: ix_product_templates_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode_trgm ON public.product_templates USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_product_templates_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_name_trgm ON public.product_templates USING gin (name public.gin_trgm_ops);


--
-- Name: ix_product_templates_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_org_name ON public.product_templates USING btree (organization_id, name);


--
-- Name: ix_product_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_organization_id ON public.product_templates USING btree (organization_id);


--
-- Name: ix_product_templates_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku ON public.product_templates USING btree (sku);


--
-- Name: ix_product_templates_sku_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku_trgm ON public.product_templates USING gin (sku public.gin_trgm_ops);


--
-- Name: ix_purchase_order_lines_purchase_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_purchase_order_id ON public.purchase_order_lines USING btree (purchase_order_id);


--
-- Name: ix_purchase_order_lines_source_reorder_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_source_reorder_rule_id ON public.purchase_order_lines USING btree (source_reorder_rule_id);


--
-- Name: ix_purchase_orders_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_number ON public.purchase_orders USING btree (number);


--
-- Name: ix_purchase_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_organization_id ON public.purchase_orders USING btree (organization_id);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_putaway_capacity_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_capacity_org ON public.putaway_capacity USING btree (organization_id);


--
-- Name: ix_putaway_home_silenced_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_home_silenced_organization_id ON public.putaway_home_silenced USING btree (organization_id);


--
-- Name: ix_putaway_rule_locations_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rule_locations_rule ON public.putaway_rule_locations USING btree (rule_id);


--
-- Name: ix_putaway_rules_org_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_category ON public.putaway_rules USING btree (organization_id, category_id);


--
-- Name: ix_putaway_rules_org_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_priority ON public.putaway_rules USING btree (organization_id, priority);


--
-- Name: ix_putaway_rules_org_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_product ON public.putaway_rules USING btree (organization_id, product_template_id);


--
-- Name: ix_recipe_collection_members_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_collection_id ON public.recipe_collection_members USING btree (collection_id);


--
-- Name: ix_recipe_collection_members_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_recipe_id ON public.recipe_collection_members USING btree (recipe_id);


--
-- Name: ix_recipe_collections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_organization_id ON public.recipe_collections USING btree (organization_id);


--
-- Name: ix_recipe_collections_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_parent_id ON public.recipe_collections USING btree (parent_id);


--
-- Name: ix_recipe_cost_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_org ON public.maker_recipe_cost_lines USING btree (organization_id);


--
-- Name: ix_recipe_cost_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_recipe ON public.maker_recipe_cost_lines USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_ingredient_group_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_ingredient_group_name ON public.recipe_ingredients USING btree (ingredient_group_name);


--
-- Name: ix_recipe_ingredients_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_recipe_id ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_template_id ON public.recipe_ingredients USING btree (template_id);


--
-- Name: ix_recipe_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_org_template ON public.maker_recipes USING btree (organization_id, output_template_id);


--
-- Name: ix_recipe_tag_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_tag_configs_organization_id ON public.recipe_tag_configs USING btree (organization_id);


--
-- Name: ix_recipes_is_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_is_favorite ON public.recipes USING btree (is_favorite);


--
-- Name: ix_recipes_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_organization_id ON public.recipes USING btree (organization_id);


--
-- Name: ix_registration_requests_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);


--
-- Name: ix_registration_requests_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_token ON public.registration_requests USING btree (token);


--
-- Name: ix_reservation_anchor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_anchor ON public.stock_reservations USING btree (anchor_id);


--
-- Name: ix_reservation_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_document ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_reservation_org_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_org_doc ON public.stock_reservations USING btree (organization_id, document_id);


--
-- Name: ix_roles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_organization_id ON public.roles USING btree (organization_id);


--
-- Name: ix_shopping_exclusions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_exclusions_organization_id ON public.shopping_exclusions USING btree (organization_id);


--
-- Name: ix_shopping_list_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_organization_id ON public.shopping_list_history USING btree (organization_id);


--
-- Name: ix_shopping_list_history_original_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_original_list_id ON public.shopping_list_history USING btree (original_list_id);


--
-- Name: ix_shopping_list_items_is_purchased; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_items_is_purchased ON public.shopping_list_items USING btree (is_purchased);


--
-- Name: ix_shopping_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_lists_status ON public.shopping_lists USING btree (status);


--
-- Name: ix_stock_anchors_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_product_template_id ON public.stock_anchors USING btree (product_template_id);


--
-- Name: ix_stock_anchors_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_storage_location_id ON public.stock_anchors USING btree (storage_location_id);


--
-- Name: ix_stock_ledger_totals_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_product_template_id ON public.stock_ledger_totals USING btree (product_template_id);


--
-- Name: ix_stock_ledger_totals_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_storage_location_id ON public.stock_ledger_totals USING btree (storage_location_id);


--
-- Name: ix_stock_lots_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_expiry_date ON public.stock_lots USING btree (expiry_date);


--
-- Name: ix_stock_lots_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_organization_id ON public.stock_lots USING btree (organization_id);


--
-- Name: ix_stock_lots_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_product_template_id ON public.stock_lots USING btree (product_template_id);


--
-- Name: ix_stock_moves_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_completed_at ON public.stock_moves USING btree (completed_at);


--
-- Name: ix_stock_moves_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_at ON public.stock_moves USING btree (created_at);


--
-- Name: ix_stock_moves_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_by ON public.stock_moves USING btree (created_by);


--
-- Name: ix_stock_moves_from_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_from_loc ON public.stock_moves USING btree (from_location_id);


--
-- Name: ix_stock_moves_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_lot_id ON public.stock_moves USING btree (lot_id);


--
-- Name: ix_stock_moves_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_moved_at ON public.stock_moves USING btree (organization_id, COALESCE(completed_at, created_at) DESC, id);


--
-- Name: ix_stock_moves_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_template ON public.stock_moves USING btree (organization_id, product_template_id);


--
-- Name: ix_stock_moves_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_organization_id ON public.stock_moves USING btree (organization_id);


--
-- Name: ix_stock_moves_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_owner_id ON public.stock_moves USING btree (owner_id);


--
-- Name: ix_stock_moves_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_product_template_id ON public.stock_moves USING btree (product_template_id);


--
-- Name: ix_stock_moves_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_reference ON public.stock_moves USING btree (reference_type, reference_id);


--
-- Name: ix_stock_moves_to_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_to_loc ON public.stock_moves USING btree (to_location_id);


--
-- Name: ix_stock_reservations_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_document_id ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_stock_reservations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_organization_id ON public.stock_reservations USING btree (organization_id);


--
-- Name: ix_stock_take_closed_locations_stock_take_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_closed_locations_stock_take_id ON public.stock_take_closed_locations USING btree (stock_take_id);


--
-- Name: ix_stock_take_counts_stock_take_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_counts_stock_take_item_id ON public.stock_take_counts USING btree (stock_take_item_id);


--
-- Name: ix_stock_takes_schedule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_takes_schedule_id ON public.stock_takes USING btree (schedule_id);


--
-- Name: ix_stock_valuation_layers_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_organization_id ON public.stock_valuation_layers USING btree (organization_id);


--
-- Name: ix_stock_valuation_layers_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_product_template_id ON public.stock_valuation_layers USING btree (product_template_id);


--
-- Name: ix_storage_locations_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_context_tag ON public.storage_locations USING btree (context_tag);


--
-- Name: ix_storage_locations_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_org_name ON public.storage_locations USING btree (organization_id, name);


--
-- Name: ix_storage_locations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_organization_id ON public.storage_locations USING btree (organization_id);


--
-- Name: ix_storage_locations_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_parent_id ON public.storage_locations USING btree (parent_id);


--
-- Name: ix_svl_org_direction_dated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_dated_at ON public.stock_valuation_layers USING btree (organization_id, direction, COALESCE(document_date, ((created_at AT TIME ZONE 'UTC'::text))::date), created_at, id);


--
-- Name: ix_svl_org_direction_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_reason ON public.stock_valuation_layers USING btree (organization_id, direction, reason);


--
-- Name: ix_svl_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_template ON public.stock_valuation_layers USING btree (organization_id, product_template_id);


--
-- Name: ix_svl_template_remaining; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_template_remaining ON public.stock_valuation_layers USING btree (organization_id, product_template_id, remaining_qty);


--
-- Name: ix_tax_rate_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_organization_id ON public.tax_rate_assignments USING btree (organization_id);


--
-- Name: ix_tax_rate_assignments_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_tax_rate_id ON public.tax_rate_assignments USING btree (tax_rate_id);


--
-- Name: ix_tax_rates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rates_organization_id ON public.tax_rates USING btree (organization_id);


--
-- Name: ix_unit_conv_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conv_lookup ON public.unit_conversions USING btree (ingredient_key, source_unit, lang, organization_id);


--
-- Name: ix_unit_conversions_ingredient_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_ingredient_key ON public.unit_conversions USING btree (ingredient_key);


--
-- Name: ix_unit_conversions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_organization_id ON public.unit_conversions USING btree (organization_id);


--
-- Name: ix_uom_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uom_categories_organization_id ON public.uom_categories USING btree (organization_id);


--
-- Name: ix_uoms_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uoms_organization_id ON public.uoms USING btree (organization_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_is_superuser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_is_superuser ON public.users USING btree (is_superuser);


--
-- Name: ix_users_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_organization_id ON public.users USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_organization_id ON public.webhook_delivery_logs USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_webhook_endpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_webhook_endpoint_id ON public.webhook_delivery_logs USING btree (webhook_endpoint_id);


--
-- Name: ix_webhook_endpoints_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_endpoints_organization_id ON public.webhook_endpoints USING btree (organization_id);


--
-- Name: ix_wms_pick_line_lots_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_line_lots_lot_id ON public.wms_pick_line_lots USING btree (lot_id);


--
-- Name: ix_wms_pick_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_document_line_id ON public.wms_pick_lines USING btree (document_line_id);


--
-- Name: ix_wms_pick_lines_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_session_id ON public.wms_pick_lines USING btree (session_id);


--
-- Name: ix_wms_pick_session_documents_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_session_documents_document_id ON public.wms_pick_session_documents USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_document_id ON public.wms_pick_sessions USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_organization_id ON public.wms_pick_sessions USING btree (organization_id);


--
-- Name: uq_document_org_post_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_org_post_key ON public.documents USING btree (organization_id, post_key) WHERE (post_key IS NOT NULL);


--
-- Name: uq_document_work_item_overlays_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_work_item_overlays_source ON public.document_work_item_overlays USING btree (organization_id, source_kind, source_id) WHERE (source_id IS NOT NULL);


--
-- Name: uq_eq_assignments_active_per_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_eq_assignments_active_per_item ON public.equipment_assignments USING btree (item_id) WHERE (checked_in_at IS NULL);


--
-- Name: uq_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_barcode_active ON public.items USING btree (organization_id, barcode) WHERE ((barcode IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_items_org_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_serial ON public.items USING btree (organization_id, serial_number) WHERE ((serial_number IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_partner_org_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_partner_org_code ON public.partners USING btree (organization_id, code) WHERE (code IS NOT NULL);


--
-- Name: uq_pending_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pending_request ON public.approval_requests USING btree (organization_id, target_type, target_id) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying])::text[]));


--
-- Name: uq_prod_org_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_prod_org_number ON public.maker_production_orders USING btree (organization_id, number) WHERE (number IS NOT NULL);


--
-- Name: uq_recipe_default_per_template; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_recipe_default_per_template ON public.maker_recipes USING btree (organization_id, output_template_id) WHERE (is_default = true);


--
-- Name: uq_stock_moves_backfill_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_stock_moves_backfill_ref ON public.stock_moves USING btree (reference_type, reference_id) WHERE ((reference_type)::text = 'item_history'::text);


--
-- Name: uq_storage_locations_org_parent_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_storage_locations_org_parent_name ON public.storage_locations USING btree (organization_id, parent_id, name) WHERE (parent_id IS NOT NULL);


--
-- Name: uq_storage_locations_org_root_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_storage_locations_org_root_name ON public.storage_locations USING btree (organization_id, name) WHERE (parent_id IS NULL);


--
-- Name: uq_templates_org_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_barcode ON public.product_templates USING btree (organization_id, barcode) WHERE (barcode IS NOT NULL);


--
-- Name: uq_templates_org_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_sku ON public.product_templates USING btree (organization_id, sku) WHERE (sku IS NOT NULL);


--
-- Name: uq_uom_category_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uom_category_reference ON public.uoms USING btree (category_id) WHERE (is_reference = true);


--
-- Name: uq_workflow_org_target; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_workflow_org_target ON public.approval_workflows USING btree (organization_id, target_type) WHERE (archived_at IS NULL);


--
-- Name: audit_log audit_log_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_log_immutable BEFORE DELETE OR UPDATE ON public.audit_log FOR EACH ROW EXECUTE FUNCTION public.audit_log_immutable();


--
-- Name: items ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER UPDATE OF quantity, lot_id, owner_id, storage_location_id, template_id, is_deleted ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL) AND ((new.is_deleted IS NOT FALSE) OR (new.template_id IS DISTINCT FROM old.template_id) OR (new.storage_location_id IS DISTINCT FROM old.storage_location_id) OR (new.lot_id IS DISTINCT FROM old.lot_id) OR (new.owner_id IS DISTINCT FROM old.owner_id) OR (new.quantity IS NULL) OR (new.quantity = 'NaN'::numeric) OR (new.quantity < old.quantity)))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_reservations ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER INSERT OR UPDATE OF quantity, anchor_id, lot_id, owner_id ON public.stock_reservations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: items ck_stock_holds_within_stock_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock_on_delete AFTER DELETE ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_moves stock_ledger_totals_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_delete AFTER DELETE ON public.stock_moves REFERENCING OLD TABLE AS old_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_insert AFTER INSERT ON public.stock_moves REFERENCING NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_update AFTER UPDATE ON public.stock_moves REFERENCING OLD TABLE AS old_moves NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: ai_connections ai_connections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approval_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approval_request_id_fkey FOREIGN KEY (approval_request_id) REFERENCES public.approval_requests(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.approval_workflows(id) ON DELETE RESTRICT;


--
-- Name: approval_workflows approval_workflows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_campaigns audit_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_campaigns audit_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_response_items audit_response_items_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_response_id_fkey FOREIGN KEY (response_id) REFERENCES public.audit_responses(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.audit_campaigns(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: categories categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_cost_variances document_cost_variances_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_cost_variances document_cost_variances_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_cost_variances document_cost_variances_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_cost_variances
    ADD CONSTRAINT document_cost_variances_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_extra_costs document_extra_costs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_corrects_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_corrects_line_id_fkey FOREIGN KEY (corrects_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_executed_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_executed_location_id_fkey FOREIGN KEY (executed_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_puts_away_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_puts_away_line_id_fkey FOREIGN KEY (puts_away_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: document_number_sequences document_number_sequences_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_package_id_fkey FOREIGN KEY (document_package_id) REFERENCES public.document_packages(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_packages document_packages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_default_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_default_template_id_fkey FOREIGN KEY (default_template_id) REFERENCES public.document_templates(id) ON DELETE SET NULL;


--
-- Name: document_profiles document_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_quarantine_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_quarantine_location_id_fkey FOREIGN KEY (quarantine_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_relations document_relations_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_relations document_relations_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_shipped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_shipped_by_fkey FOREIGN KEY (shipped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_type_configs document_type_configs_default_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_source_location_id_fkey FOREIGN KEY (default_source_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_default_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_target_location_id_fkey FOREIGN KEY (default_target_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_receiving_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_receiving_location_id_fkey FOREIGN KEY (receiving_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: document_work_item_overlays document_work_item_overlays_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_backorder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_backorder_id_fkey FOREIGN KEY (backorder_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: documents documents_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_corrects_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_corrects_document_id_fkey FOREIGN KEY (corrects_document_id) REFERENCES public.documents(id) ON DELETE RESTRICT;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: documents documents_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: documents documents_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_assignee_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_assignee_partner_id_fkey FOREIGN KEY (assignee_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_in_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_in_by_fkey FOREIGN KEY (checked_in_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_out_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_out_by_fkey FOREIGN KEY (checked_out_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checkout_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checkout_location_id_fkey FOREIGN KEY (checkout_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_assignments equipment_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_service_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_service_partner_id_fkey FOREIGN KEY (service_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: example_widgets example_widgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests fk_approval_requests_consumed_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_approval_requests_consumed_by_users FOREIGN KEY (consumed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_history fk_item_history_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_stock_anchor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_stock_anchor FOREIGN KEY (organization_id, template_id, storage_location_id) REFERENCES public.stock_anchors(organization_id, product_template_id, storage_location_id);


--
-- Name: label_pool fk_label_pool_item_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_item_id FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: organizations fk_organizations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT fk_organizations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: picking_sessions fk_picking_sessions_meal_plan_entry_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT fk_picking_sessions_meal_plan_entry_id FOREIGN KEY (meal_plan_entry_id) REFERENCES public.meal_plan_entries(id) ON DELETE SET NULL;


--
-- Name: stock_reservations fk_stock_reservations_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT fk_stock_reservations_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_expected_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_expected_location_id FOREIGN KEY (expected_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_storage_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_storage_location_id FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: users fk_users_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wms_pick_lines fk_wms_pick_lines_anchor_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_anchor_id FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines fk_wms_pick_lines_lot_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_lot_id FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_periods inventory_periods_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_reopened_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_reopened_by_fkey FOREIGN KEY (reopened_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_attachments item_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_import_jobs item_import_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_import_jobs item_import_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: items items_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: items items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: items items_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: items items_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: items items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id);


--
-- Name: items items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: label_pool label_pool_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: label_pool label_pool_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: label_pool label_pool_target_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_target_storage_location_id_fkey FOREIGN KEY (target_storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_from_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_from_parent_id_fkey FOREIGN KEY (from_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: location_relocations location_relocations_to_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_to_parent_id_fkey FOREIGN KEY (to_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: maker_bom_lines maker_bom_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_parent_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_parent_template_id_fkey FOREIGN KEY (parent_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_ingredient_prices maker_ingredient_prices_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT maker_ingredient_prices_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_ingredient_prices maker_ingredient_prices_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_ingredient_prices
    ADD CONSTRAINT maker_ingredient_prices_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_label_facts maker_label_facts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT maker_label_facts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_label_facts maker_label_facts_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_label_facts
    ADD CONSTRAINT maker_label_facts_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_module_settings maker_module_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_attachments maker_production_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_attachments maker_production_attachments_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_attachments maker_production_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_attachments
    ADD CONSTRAINT maker_production_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: maker_production_order_lines maker_production_order_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_order_lines maker_production_order_lines_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_source_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_source_storage_location_id_fkey FOREIGN KEY (source_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_orders maker_production_orders_output_layer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_layer_id_fkey FOREIGN KEY (output_layer_id) REFERENCES public.stock_valuation_layers(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_output_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_lot_id_fkey FOREIGN KEY (output_lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_output_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_storage_location_id_fkey FOREIGN KEY (output_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_orders maker_production_orders_produced_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_produced_item_id_fkey FOREIGN KEY (produced_item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id);


--
-- Name: maker_production_portions maker_production_portions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_portions maker_production_portions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_portions maker_production_portions_layer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES public.stock_valuation_layers(id) ON DELETE SET NULL;


--
-- Name: maker_production_portions maker_production_portions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_portions maker_production_portions_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_portions
    ADD CONSTRAINT maker_production_portions_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_batch_yield_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_batch_yield_uom_id_fkey FOREIGN KEY (batch_yield_uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_recipes maker_recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_shelf_lives maker_shelf_lives_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT maker_shelf_lives_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_shelf_lives maker_shelf_lives_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_shelf_lives
    ADD CONSTRAINT maker_shelf_lives_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_meal_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_meal_plan_id_fkey FOREIGN KEY (meal_plan_id) REFERENCES public.meal_plans(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: meal_plans meal_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: meal_plans meal_plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: organization_invitations organization_invitations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: organization_invitations organization_invitations_used_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_used_by_user_id_fkey FOREIGN KEY (used_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_session_items picking_session_items_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.recipe_ingredients(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.picking_sessions(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: po_partner_pricelist po_partner_pricelist_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_preferred_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_preferred_partner_id_fkey FOREIGN KEY (preferred_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: po_settings po_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_agents print_agents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.print_agents(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_jobs print_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_volume_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_volume_uom_id_fkey FOREIGN KEY (volume_uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_weight_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_weight_uom_id_fkey FOREIGN KEY (weight_uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_order_lines purchase_order_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines purchase_order_lines_source_reorder_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_source_reorder_rule_id_fkey FOREIGN KEY (source_reorder_rule_id) REFERENCES public.po_reorder_rules(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_orders purchase_orders_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: putaway_capacity putaway_capacity_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.putaway_rules(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipe_collections recipe_collections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_price_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_price_uom_id_fkey FOREIGN KEY (price_uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_tag_configs recipe_tag_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipes recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: registration_requests registration_requests_approved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_approved_by_id_fkey FOREIGN KEY (approved_by_id) REFERENCES public.users(id);


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: shopping_exclusions shopping_exclusions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_exclusions shopping_exclusions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_history shopping_list_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_list_history shopping_list_history_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: shopping_list_items shopping_list_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_shopping_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_shopping_list_id_fkey FOREIGN KEY (shopping_list_id) REFERENCES public.shopping_lists(id) ON DELETE CASCADE;


--
-- Name: shopping_list_items shopping_list_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: shopping_lists shopping_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shopping_lists shopping_lists_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_anchor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_anchor_id_fkey FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_counted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_counted_by_fkey FOREIGN KEY (counted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_stock_take_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_stock_take_item_id_fkey FOREIGN KEY (stock_take_item_id) REFERENCES public.stock_take_items(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: stock_take_items stock_take_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_take_items stock_take_items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id);


--
-- Name: stock_take_items stock_take_items_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: stock_takes stock_takes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.cycle_count_schedules(id) ON DELETE SET NULL;


--
-- Name: stock_takes stock_takes_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers stock_valuation_layers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_locations storage_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: storage_locations storage_locations_storage_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_storage_type_id_fkey FOREIGN KEY (storage_type_id) REFERENCES public.storage_types(id);


--
-- Name: storage_types storage_types_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_types storage_types_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tax_rate_assignments tax_rate_assignments_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_tax_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_tax_rate_id_fkey FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rates(id) ON DELETE CASCADE;


--
-- Name: tax_rates tax_rates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: unit_conversions unit_conversions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uom_categories uom_categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uoms uoms_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.uom_categories(id);


--
-- Name: uoms uoms_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_webhook_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_webhook_endpoint_id_fkey FOREIGN KEY (webhook_endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pick_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pick_line_id_fkey FOREIGN KEY (pick_line_id) REFERENCES public.wms_pick_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines wms_pick_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: wms_pick_sessions wms_pick_sessions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


