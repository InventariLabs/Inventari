-- Inventari v0.11.0: the database the release leaves on disk.
-- Cut by scripts/release-db-snapshot.sh from 246a05d4e70970b050082c1594e4c9e54f42e2ba.
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: audit_log_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_log_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_log rows are immutable: % operation not allowed', TG_OP;
    RETURN NULL;
END;
$$;


--
-- Name: stock_holds_within_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_holds_within_stock() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    DECLARE
        g_anchor uuid;
        g_lot uuid;
        g_owner uuid;
        anchor stock_anchors%ROWTYPE;
        held numeric;
        on_hand numeric;
    BEGIN
        IF TG_TABLE_NAME = 'stock_reservations' THEN
            g_anchor := NEW.anchor_id;
            g_lot := NEW.lot_id;
            g_owner := NEW.owner_id;
        ELSE
            SELECT id INTO g_anchor FROM stock_anchors
             WHERE organization_id = OLD.organization_id
               AND product_template_id = OLD.template_id
               AND storage_location_id = OLD.storage_location_id;
            g_lot := OLD.lot_id;
            g_owner := OLD.owner_id;
        END IF;
        -- A group with no anchor has no reservation rows to hold it.
        IF g_anchor IS NULL THEN
            RETURN NULL;
        END IF;
    
        SELECT coalesce(sum(quantity), 0) INTO held
          FROM stock_reservations
         WHERE anchor_id = g_anchor
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner;
        IF held = 0 THEN
            RETURN NULL;
        END IF;
    
        SELECT * INTO anchor FROM stock_anchors WHERE id = g_anchor;
        SELECT coalesce(sum(nullif(quantity, 'NaN'::numeric)), 0) INTO on_hand
          FROM items
         WHERE organization_id = anchor.organization_id
           AND template_id = anchor.product_template_id
           AND storage_location_id = anchor.storage_location_id
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner
           AND is_deleted IS FALSE;
    
        IF held > on_hand THEN
            RAISE EXCEPTION
                'ck_stock_holds_within_stock: % reserved of a grain holding %',
                held, on_hand
            USING ERRCODE = 'check_violation',
                  CONSTRAINT = 'ck_stock_holds_within_stock',
                  DETAIL = format(
                      'product %s, shelf %s, batch %s, owner %s',
                      anchor.product_template_id,
                      anchor.storage_location_id,
                      coalesce(g_lot::text, '-'),
                      coalesce(g_owner::text, '-')
                  );
        END IF;
        RETURN NULL;
    END $$;


--
-- Name: stock_ledger_totals_follow_moves(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_ledger_totals_follow_moves() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    BEGIN
        IF TG_OP IN ('INSERT', 'UPDATE') THEN
            INSERT INTO stock_ledger_totals AS t
                (organization_id, product_template_id, storage_location_id, quantity)
            SELECT organization_id, product_template_id, location_id, sum(qty)
            FROM (
                SELECT organization_id, product_template_id,
                       to_location_id AS location_id, quantity AS qty
                FROM new_moves
                WHERE state = 'done' AND to_location_id IS NOT NULL
                UNION ALL
                SELECT organization_id, product_template_id,
                       from_location_id, -quantity
                FROM new_moves
                WHERE state = 'done' AND from_location_id IS NOT NULL
            ) AS sides
            GROUP BY organization_id, product_template_id, location_id
            ORDER BY organization_id, product_template_id, location_id
            ON CONFLICT (organization_id, product_template_id, storage_location_id)
            DO UPDATE SET quantity = t.quantity + EXCLUDED.quantity;
        END IF;
        IF TG_OP IN ('UPDATE', 'DELETE') THEN
            UPDATE stock_ledger_totals AS t
            SET quantity = t.quantity - gone.qty
            FROM (
                SELECT organization_id, product_template_id, location_id,
                       sum(qty) AS qty
                FROM (
                    SELECT organization_id, product_template_id,
                           to_location_id AS location_id, quantity AS qty
                    FROM old_moves
                    WHERE state = 'done' AND to_location_id IS NOT NULL
                    UNION ALL
                    SELECT organization_id, product_template_id,
                           from_location_id, -quantity
                    FROM old_moves
                    WHERE state = 'done' AND from_location_id IS NOT NULL
                ) AS sides
                GROUP BY organization_id, product_template_id, location_id
            ) AS gone
            WHERE t.organization_id = gone.organization_id
              AND t.product_template_id = gone.product_template_id
              AND t.storage_location_id = gone.location_id;
        END IF;
        RETURN NULL;
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_connections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    api_key_enc character varying DEFAULT ''::character varying NOT NULL,
    api_base_url character varying(512) DEFAULT ''::character varying NOT NULL,
    model_name character varying(255) DEFAULT ''::character varying NOT NULL,
    temperature double precision,
    max_tokens integer,
    top_p double precision,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    capability_checks jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage_logs (
    id uuid NOT NULL,
    user_id uuid,
    organization_id uuid NOT NULL,
    model_name character varying(255) NOT NULL,
    provider character varying(100),
    prompt_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    total_tokens integer NOT NULL,
    estimated_cost_usd double precision,
    cost_is_estimated boolean DEFAULT false NOT NULL,
    action_type character varying(100),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_api_keys (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_approvals (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_equipment (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_example_widgets (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_maker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_maker (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_printing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_printing (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_purchase_orders (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_recipes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_shopping_lists (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_stock_takes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_warehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_warehouse (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_webhooks (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) NOT NULL,
    active_from timestamp with time zone NOT NULL,
    active_until timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    hashed_key character varying(64) NOT NULL,
    key_prefix character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    scope_names jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: approval_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_decisions (
    id uuid NOT NULL,
    approval_request_id uuid NOT NULL,
    stage_order integer NOT NULL,
    approver_id uuid,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    notes text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    current_stage integer DEFAULT 1 NOT NULL,
    total_stages integer NOT NULL,
    created_by uuid NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    consumed_by uuid
);


--
-- Name: approval_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_workflows (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    stages json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    archived_at timestamp with time zone,
    requester_scope jsonb DEFAULT '{"everyone": true}'::jsonb NOT NULL
);


--
-- Name: audit_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_campaigns (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    scope_type character varying(20) NOT NULL,
    scope_filter_id uuid,
    launched_at timestamp with time zone,
    deadline timestamp with time zone NOT NULL,
    reminder_days_before integer NOT NULL,
    last_reminder_sent_at timestamp with time zone,
    status character varying(20) NOT NULL,
    email_subject character varying(255),
    email_body text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    snapshot json,
    reason character varying(500),
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_response_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_response_items (
    id uuid NOT NULL,
    response_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    item_id uuid NOT NULL,
    item_name character varying(255) NOT NULL,
    serial_number character varying(100),
    status character varying(20) NOT NULL,
    dispute_type character varying(30),
    dispute_reason text,
    created_at timestamp with time zone NOT NULL,
    responded_at timestamp with time zone
);


--
-- Name: audit_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_responses (
    id uuid NOT NULL,
    campaign_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    assignment_id uuid,
    assignee_email character varying(255) NOT NULL,
    assignee_name character varying(255) NOT NULL,
    token character varying(86) NOT NULL,
    token_expires_at timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    responded_at timestamp with time zone,
    dispute_reason text,
    dispute_type character varying(30),
    response_ip character varying(45),
    response_user_agent character varying(500),
    email_sent_at timestamp with time zone,
    reminder_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    code character varying(100),
    context_tag character varying(100),
    group_label character varying(50),
    icon character varying(100),
    emoji character varying(32),
    color character varying(16),
    sort_order integer NOT NULL,
    meta_data jsonb,
    default_removal_strategy character varying(10),
    module_name character varying(50),
    is_active boolean NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL
);


--
-- Name: cycle_count_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cycle_count_schedules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    frequency character varying(20) NOT NULL,
    scope character varying(20) NOT NULL,
    scope_filter json,
    sample_size integer,
    tolerance_percent numeric(5,2),
    is_active boolean NOT NULL,
    last_run_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_cycle_count_schedules_frequency CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying])::text[]))),
    CONSTRAINT ck_cycle_count_schedules_scope CHECK (((scope)::text = ANY ((ARRAY['all'::character varying, 'zone'::character varying, 'category'::character varying])::text[])))
);


--
-- Name: document_extra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extra_costs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    allocation_method character varying(10) DEFAULT 'value'::character varying NOT NULL,
    note character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_extra_costs_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_lines (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    item_id uuid,
    product_template_id uuid,
    name character varying(255),
    brand character varying(255),
    barcode character varying(50),
    quantity numeric(12,3) NOT NULL,
    expected_quantity numeric(12,3) NOT NULL,
    done_quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    batch_number character varying(100),
    serial_number character varying(100),
    expiry_date date,
    notes text,
    discrepancy_code character varying(50),
    discrepancy_reason text,
    unit_price numeric(12,2),
    tax_rate numeric(5,2),
    line_value numeric(14,2),
    line_tax numeric(14,2),
    line_gross numeric(14,2),
    currency character varying(3),
    line_number integer NOT NULL,
    source_po_line_id uuid,
    product_snapshot jsonb,
    executed_location_id uuid,
    corrects_line_id uuid,
    target_location_id uuid,
    held_quantity numeric(12,3) DEFAULT 0 NOT NULL,
    source_location_id uuid,
    puts_away_line_id uuid,
    meta_data jsonb,
    expected_is_count boolean DEFAULT false NOT NULL
);


--
-- Name: document_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_number_sequences (
    organization_id uuid NOT NULL,
    prefix character varying(120) NOT NULL,
    next_value integer DEFAULT 1 NOT NULL
);


--
-- Name: document_package_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_package_lines (
    id uuid NOT NULL,
    document_package_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_document_package_lines_quantity CHECK ((quantity > (0)::numeric))
);


--
-- Name: document_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_packages (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    number integer NOT NULL,
    weight_kg numeric(10,3),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_packages_weight CHECK ((weight_kg > (0)::numeric))
);


--
-- Name: document_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    value_tracking_enabled boolean NOT NULL,
    tax_handling character varying(20) NOT NULL,
    default_tax_rate numeric(5,2),
    require_partner_tax_id boolean,
    numbering_format character varying(100) NOT NULL,
    type_labels json,
    default_unit character varying(20) NOT NULL,
    visible_line_fields json,
    print_template character varying(50) NOT NULL,
    default_currency character varying(3),
    default_template_id uuid,
    approval_threshold numeric(14,2),
    approval_required_for_types json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    number_padding smallint NOT NULL,
    require_unit_price boolean DEFAULT false NOT NULL,
    confirm_shelf_by_scan boolean DEFAULT false NOT NULL,
    tracking_url_templates json,
    quarantine_location_id uuid,
    pick_order_strategy character varying(50)
);


--
-- Name: document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_relations (
    id uuid NOT NULL,
    source_document_id uuid NOT NULL,
    target_document_id uuid NOT NULL,
    relation_type character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_shipments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    carrier character varying(100) NOT NULL,
    tracking_number character varying(100),
    shipped_at timestamp with time zone NOT NULL,
    shipped_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    module character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(50) NOT NULL,
    body_html text NOT NULL,
    version integer NOT NULL,
    source_builtin character varying(255),
    source_checksum character varying(64),
    is_default boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: document_type_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_type_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_type character varying(15) NOT NULL,
    default_source_location_id uuid,
    default_target_location_id uuid,
    sequence_format character varying(50) NOT NULL,
    require_partner boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_warehouse_receiving; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_warehouse_receiving (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    two_step boolean DEFAULT false NOT NULL,
    receiving_location_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    free_placement boolean DEFAULT false NOT NULL
);


--
-- Name: document_work_item_overlays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_work_item_overlays (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    source_kind character varying(48) NOT NULL,
    source_id uuid,
    assignee_id uuid,
    title character varying(200),
    due_date date,
    done_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    type character varying(15) NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    source_location_id uuid,
    target_location_id uuid,
    scheduled_date date,
    notes text,
    external_reference character varying(100),
    partner_snapshot jsonb,
    corrects_document_id uuid,
    backorder_id uuid,
    total_net numeric(14,2),
    total_tax numeric(14,2),
    total_gross numeric(14,2),
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    completed_at timestamp with time zone,
    reason_code character varying(50),
    is_opening boolean DEFAULT false NOT NULL,
    stock_already_applied boolean DEFAULT false NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    complete_on_approval boolean DEFAULT false NOT NULL,
    post_key character varying(64),
    held_by character varying(64),
    meta_data jsonb
);


--
-- Name: email_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_jobs (
    id uuid NOT NULL,
    organization_id uuid,
    to_email character varying(320) NOT NULL,
    subject character varying(500) NOT NULL,
    html_content text NOT NULL,
    attachment_bytes bytea,
    attachment_filename character varying(255),
    smtp_config_enc text,
    failure_notice_enc text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone
);


--
-- Name: equipment_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    assignee_partner_id uuid,
    checkout_location_id uuid,
    assigned_to_name character varying(255) NOT NULL,
    assigned_to_email character varying(255),
    checked_out_at timestamp with time zone NOT NULL,
    expected_return_at timestamp with time zone,
    checked_in_at timestamp with time zone,
    checked_out_by uuid NOT NULL,
    checked_in_by uuid,
    checkout_notes text,
    checkin_notes text,
    checkin_condition character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_type character varying(30) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_maintenance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_maintenance_logs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    maintenance_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    cost numeric(10,2),
    currency character varying(3),
    performed_at date NOT NULL,
    performed_by character varying(255),
    service_partner_id uuid,
    next_maintenance_at date,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_deliveries (
    id uuid NOT NULL,
    event_id character varying(64) NOT NULL,
    event character varying(100) NOT NULL,
    handler character varying(255) NOT NULL,
    organization_id uuid,
    payload jsonb NOT NULL,
    status character varying(16) NOT NULL,
    attempts integer NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_outbox (
    id uuid NOT NULL,
    organization_id uuid,
    event character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    emitter_module character varying(64),
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    published_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.example_widgets (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(30) DEFAULT 'blue'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ingredient_nutrition_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_nutrition_defaults (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    calories_kcal numeric(8,2) NOT NULL,
    protein_g numeric(8,2),
    fat_g numeric(8,2),
    carbs_g numeric(8,2),
    fiber_g numeric(8,2),
    sugar_g numeric(8,2),
    salt_g numeric(8,2),
    source character varying(50) NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_periods (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    reopened_at timestamp with time zone,
    reopened_by uuid,
    notes text
);


--
-- Name: item_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_attachments (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_history (
    id uuid NOT NULL,
    organization_id uuid,
    item_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    changes json,
    source_document_id uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_import_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    total integer NOT NULL,
    processed integer NOT NULL,
    result json,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    category_id uuid,
    module_name character varying(50),
    name character varying(255) NOT NULL,
    brand character varying(255),
    description character varying(500),
    uom_id uuid,
    template_id uuid,
    quantity numeric(12,3) NOT NULL,
    barcode character varying(50),
    serial_number character varying(100),
    added_date date NOT NULL,
    expiry_date date,
    shelf_location character varying(255),
    image_url character varying(500),
    meta_data jsonb,
    purchase_price numeric(10,2),
    currency character varying(3),
    is_deleted boolean NOT NULL,
    is_catalog_entry boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    label_code character varying(20),
    partner_id uuid,
    lot_id uuid,
    owner_id uuid,
    source_document_id uuid,
    CONSTRAINT ck_items_quantity_nonneg CHECK ((quantity >= (0)::numeric))
);


--
-- Name: label_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_pool (
    id uuid NOT NULL,
    short_code character varying(100) NOT NULL,
    is_assigned boolean NOT NULL,
    assigned_at timestamp with time zone,
    item_id uuid,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    label_type character varying(50) NOT NULL,
    description character varying(255),
    target_storage_location_id uuid,
    context_tag character varying(50),
    created_at timestamp with time zone NOT NULL,
    printed_at timestamp with time zone,
    scan_count integer NOT NULL,
    last_scanned_at timestamp with time zone
);


--
-- Name: location_relocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_relocations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid,
    location_name character varying(255) NOT NULL,
    from_parent_id uuid,
    to_parent_id uuid,
    from_path text,
    to_path text,
    moved_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: maker_bom_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_bom_lines (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_template_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    unit character varying(8) NOT NULL,
    yield_loss_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id uuid NOT NULL,
    qty_per_batch numeric(12,4) NOT NULL,
    uom_id uuid,
    CONSTRAINT ck_bom_no_self CHECK ((parent_template_id <> child_template_id)),
    CONSTRAINT ck_bom_qty CHECK ((qty_per_batch > (0)::numeric)),
    CONSTRAINT ck_bom_yield_range CHECK (((yield_loss_pct >= (0)::numeric) AND (yield_loss_pct <= (100)::numeric)))
);


--
-- Name: maker_module_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_module_settings (
    organization_id uuid NOT NULL,
    reference_direction character varying(10) DEFAULT 'MARGIN'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    allow_overproduction boolean DEFAULT true NOT NULL,
    availability_check_scope character varying(15) DEFAULT 'GLOBAL'::character varying NOT NULL,
    create_on_shortage_strategy character varying(10) DEFAULT 'WARN'::character varying NOT NULL
);


--
-- Name: maker_production_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_order_lines (
    id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    consumed_qty numeric(12,4) NOT NULL,
    unit character varying(8) NOT NULL,
    source_storage_location_id uuid,
    unit_cost_snapshot numeric(12,4),
    cost_source character varying(16),
    shortfall_qty numeric(12,4)
);


--
-- Name: maker_production_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    planned_qty numeric(12,3) NOT NULL,
    output_storage_location_id uuid NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    total_cost numeric(12,2),
    production_date date,
    notes character varying(500),
    created_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    cancel_reason character varying(500),
    produced_item_id uuid,
    recipe_id uuid,
    actual_qty numeric(12,3),
    overproduced boolean DEFAULT false NOT NULL,
    scrap_qty numeric(12,3),
    unit_cost_snapshot numeric(12,4),
    reference_price_snapshot numeric(12,2),
    result_per_unit numeric(12,2),
    result_per_batch numeric(12,2),
    number character varying(32),
    short_at_create boolean DEFAULT false NOT NULL
);


--
-- Name: maker_recipe_cost_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipe_cost_lines (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    label character varying(120) NOT NULL,
    amount numeric(12,2) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: maker_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    batch_yield_qty numeric(12,4) DEFAULT '1'::numeric NOT NULL,
    batch_yield_uom_id uuid,
    process_steps jsonb,
    reference_price numeric(12,2),
    is_default boolean DEFAULT false NOT NULL,
    source_recipe_id uuid,
    source_snapshot_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: meal_plan_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_entries (
    id uuid NOT NULL,
    meal_plan_id uuid NOT NULL,
    date date NOT NULL,
    slot character varying(20) NOT NULL,
    recipe_id uuid NOT NULL,
    servings integer,
    notes text,
    "order" integer NOT NULL,
    CONSTRAINT ck_meal_plan_entries_slot CHECK (((slot)::text = ANY ((ARRAY['LUNCH'::character varying, 'BREAKFAST'::character varying, 'DINNER'::character varying, 'SNACK'::character varying])::text[])))
);


--
-- Name: meal_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plans (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255),
    start_date date NOT NULL,
    end_date date NOT NULL,
    enabled_slots jsonb NOT NULL,
    default_servings integer,
    shopping_list_id uuid,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    listed_meals jsonb
);


--
-- Name: module_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_installations (
    id uuid NOT NULL,
    module_name character varying(100) NOT NULL,
    installed_version character varying(50) NOT NULL,
    installed_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(1000) NOT NULL,
    type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    link character varying(255),
    meta_data jsonb
);


--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_invitations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    code character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    is_used boolean NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    role_id uuid,
    invited_email character varying(255),
    used_by_user_id uuid,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid,
    enabled_modules json NOT NULL,
    allowed_modules json,
    settings json NOT NULL,
    short_id character varying(20),
    active_profile_id character varying(50),
    onboarding_completed boolean DEFAULT false,
    focus_module character varying(50),
    pre_focus_enabled_modules json,
    pre_onboarding_manual_modules json,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'UTC'::character varying NOT NULL,
    tax_id character varying(50),
    country character varying(2),
    print_page_size character varying(10),
    address json,
    logo_url character varying(500)
);


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    type character varying(30) NOT NULL,
    tax_id character varying(50),
    is_consumer boolean DEFAULT false NOT NULL,
    email character varying(255),
    phone character varying(50),
    website character varying(500),
    contact_person character varying(255),
    address jsonb,
    notes text,
    is_active boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: picking_session_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_session_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    ingredient_id uuid,
    item_id uuid,
    quantity_consumed numeric(10,3),
    picked_items jsonb,
    consumed_valuation_rate numeric(12,2),
    status character varying(20) NOT NULL,
    ingredient_name character varying(255),
    required_quantity numeric(10,3),
    required_uom_symbol character varying(10)
);


--
-- Name: picking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    user_id uuid NOT NULL,
    servings integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    rating integer,
    scale numeric(10,3),
    meal_plan_entry_id uuid
);


--
-- Name: po_partner_pricelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_partner_pricelist (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    uom_id uuid,
    min_quantity numeric(12,3),
    valid_from date NOT NULL,
    valid_to date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_partner_pricelist_min_qty_positive CHECK (((min_quantity IS NULL) OR (min_quantity > (0)::numeric))),
    CONSTRAINT ck_po_partner_pricelist_unit_price_positive CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT ck_po_partner_pricelist_valid_range CHECK (((valid_to IS NULL) OR (valid_to >= valid_from)))
);


--
-- Name: po_reorder_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_reorder_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    min_quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    safety_stock numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    preferred_partner_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_reorder_rules_max_ge_min CHECK ((max_quantity >= min_quantity)),
    CONSTRAINT ck_po_reorder_rules_min_nonneg CHECK ((min_quantity >= (0)::numeric)),
    CONSTRAINT ck_po_reorder_rules_safety_nonneg CHECK ((safety_stock >= (0)::numeric))
);


--
-- Name: po_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    approval_threshold numeric(14,2),
    approval_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: print_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_agents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    printer_type character varying(50) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_version character varying(50),
    protocol_version integer
);


--
-- Name: print_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    labels jsonb NOT NULL,
    created_by uuid,
    attempts integer NOT NULL,
    lease_until timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    width_mm double precision DEFAULT 50.0 NOT NULL,
    height_mm double precision DEFAULT 24.0 NOT NULL,
    scale double precision,
    read_permissions jsonb NOT NULL
);


--
-- Name: product_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_templates (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    brand character varying(255),
    barcode character varying(50),
    sku character varying(50),
    uom_id uuid,
    weight_value numeric(14,6),
    weight_uom_id uuid,
    volume_value numeric(14,6),
    volume_uom_id uuid,
    image_url character varying(500),
    description character varying(500),
    min_quantity double precision,
    removal_strategy character varying(10),
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_lines (
    id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_template_id uuid,
    name character varying(255) NOT NULL,
    quantity_ordered numeric(12,3) NOT NULL,
    quantity_received numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_price numeric(12,2),
    uom_id uuid,
    tax_rate numeric(5,2),
    line_number integer NOT NULL,
    notes text,
    source_reorder_rule_id uuid
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    scheduled_date date,
    notes text,
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_capacity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_capacity (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_home_silenced; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_home_silenced (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_location_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_location_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    single_product boolean DEFAULT false NOT NULL
);


--
-- Name: putaway_rule_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rule_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    location_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: putaway_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    context_tag character varying(100),
    storage_type_code character varying(50),
    priority integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_putaway_rules_at_least_one_match CHECK (((product_template_id IS NOT NULL) OR (category_id IS NOT NULL) OR (context_tag IS NOT NULL) OR (storage_type_code IS NOT NULL)))
);


--
-- Name: recipe_collection_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collection_members (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(64),
    parent_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    template_id uuid,
    name character varying(255) NOT NULL,
    display_text character varying(500),
    ingredient_group_name character varying(100),
    quantity numeric(10,3) NOT NULL,
    uom_id uuid,
    original_quantity numeric(10,3),
    original_unit_text character varying(50),
    is_optional boolean NOT NULL,
    picking_skip boolean,
    sort_order integer NOT NULL,
    calories_kcal_per_100g numeric(8,2),
    price numeric(10,2),
    price_uom_id uuid,
    price_currency character varying(3),
    allergens jsonb NOT NULL,
    is_spice boolean NOT NULL
);


--
-- Name: recipe_tag_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_tag_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    instructions text,
    servings integer NOT NULL,
    prep_time_minutes integer,
    image_url text,
    source_url text,
    tags jsonb,
    is_favorite boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_requests (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    token character varying(255),
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    accepted_at timestamp with time zone,
    rejected_at timestamp with time zone,
    is_rejected boolean DEFAULT false NOT NULL,
    approved_by_id uuid
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shopping_exclusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_exclusions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    template_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_history (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    original_list_id uuid NOT NULL,
    original_list_name character varying(255) NOT NULL,
    item_name character varying(255) NOT NULL,
    quantity numeric(12,3) DEFAULT 1 NOT NULL,
    estimated_price numeric(10,2),
    purchased_at timestamp with time zone,
    purchased_by uuid,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_items (
    id uuid NOT NULL,
    shopping_list_id uuid NOT NULL,
    item_id uuid,
    category_id uuid,
    name character varying(255) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    notes text,
    estimated_price numeric(10,2),
    is_purchased boolean NOT NULL,
    purchased_at timestamp with time zone,
    purchased_by uuid,
    source character varying(50) NOT NULL,
    priority integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_id uuid,
    note_data jsonb
);


--
-- Name: shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_lists (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    completed_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_anchors (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_ledger_totals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_ledger_totals (
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    quantity numeric(18,3) NOT NULL
);


--
-- Name: stock_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_lots (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    is_serial boolean NOT NULL,
    expiry_date date,
    production_date date,
    use_by_date date,
    removal_strategy character varying(10) NOT NULL,
    status character varying(20) NOT NULL,
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: stock_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_moves (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    from_location_id uuid,
    to_location_id uuid,
    quantity numeric(12,3) NOT NULL,
    lot_id uuid,
    owner_id uuid,
    expiry_date date,
    state character varying(20) DEFAULT 'done'::character varying NOT NULL,
    reference_type character varying(20),
    reference_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_stock_moves_at_least_one_location CHECK (((from_location_id IS NOT NULL) OR (to_location_id IS NOT NULL))),
    CONSTRAINT ck_stock_moves_qty_positive CHECK ((quantity > (0)::numeric))
);


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    document_line_id uuid,
    anchor_id uuid NOT NULL,
    lot_id uuid,
    owner_id uuid,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_quants_from_records; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.stock_quants_from_records AS
 SELECT (md5((((((((((organization_id)::text || '/'::text) || (product_template_id)::text) || '/'::text) || COALESCE((storage_location_id)::text, '-'::text)) || '/'::text) || COALESCE((lot_id)::text, '-'::text)) || '/'::text) || COALESCE((owner_id)::text, '-'::text))))::uuid AS id,
    organization_id,
    product_template_id,
    storage_location_id,
    lot_id,
    owner_id,
    (COALESCE(sum(quantity), (0)::numeric))::numeric(12,3) AS quantity,
    (COALESCE(sum(reserved_quantity), (0)::numeric))::numeric(12,3) AS reserved_quantity,
    'FIFO'::character varying(10) AS removal_strategy,
    min(created_at) AS created_at,
    max(updated_at) AS updated_at
   FROM ( SELECT i.organization_id,
            i.template_id AS product_template_id,
            i.storage_location_id,
            i.lot_id,
            i.owner_id,
            NULLIF(i.quantity, 'NaN'::numeric) AS quantity,
            NULL::numeric AS reserved_quantity,
            i.created_at,
            i.updated_at
           FROM public.items i
          WHERE ((i.is_deleted IS FALSE) AND (i.template_id IS NOT NULL))
        UNION ALL
         SELECT a.organization_id,
            a.product_template_id,
            a.storage_location_id,
            r.lot_id,
            r.owner_id,
            NULL::numeric AS "numeric",
            r.quantity,
            r.created_at,
            r.created_at
           FROM (public.stock_reservations r
             JOIN public.stock_anchors a ON ((a.id = r.anchor_id)))) sides
  GROUP BY organization_id, product_template_id, storage_location_id, lot_id, owner_id;


--
-- Name: stock_take_closed_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_closed_locations (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    storage_location_id uuid,
    path text NOT NULL,
    empty boolean DEFAULT false NOT NULL,
    closed_by uuid,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_counts (
    id uuid NOT NULL,
    stock_take_item_id uuid NOT NULL,
    sequence integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    counted_by uuid,
    counted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_items (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    item_id uuid,
    item_name character varying(255) NOT NULL,
    item_brand character varying(255),
    uom_id uuid,
    assignee_id uuid,
    lot_id uuid,
    system_quantity numeric(12,3),
    counted_quantity numeric(10,3),
    location_in_storage character varying(255),
    notes text,
    discrepancy_reason character varying(255),
    is_discrepancy integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discrepancy_reason_code character varying(50),
    recount_requested boolean DEFAULT false NOT NULL,
    storage_location_id uuid,
    expected_location_id uuid
);


--
-- Name: stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_takes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    blind_mode boolean NOT NULL,
    require_full_count boolean NOT NULL,
    tolerance_percent numeric(5,2),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule_id uuid,
    adjustment_document_id uuid,
    CONSTRAINT ck_stock_takes_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: stock_valuation_layers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_valuation_layers (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    document_line_id uuid,
    quantity numeric(12,3) NOT NULL,
    remaining_qty numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    total_value numeric(14,2) NOT NULL,
    document_date date,
    currency character varying(3),
    direction character varying(10) NOT NULL,
    cost_basis character varying(10) NOT NULL,
    reason character varying(30),
    item_id uuid,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_svl_remaining_not_negative CHECK ((remaining_qty >= (0)::numeric))
);


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_id uuid,
    storage_type_id uuid,
    context_schema json DEFAULT '[]'::json NOT NULL,
    behavior_mode character varying(50) DEFAULT 'STOCK'::character varying NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    location_details character varying(255),
    short_code character varying(100),
    sequence integer,
    usage character varying(50) DEFAULT 'internal'::character varying NOT NULL,
    context_tag character varying(50),
    settings json,
    warehouse_config jsonb,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL
);


--
-- Name: storage_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_types (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    type_code character varying(50) NOT NULL,
    behavior_mode character varying(50) NOT NULL,
    context_schema json DEFAULT '[]'::json NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    icon character varying(100),
    is_system boolean NOT NULL,
    created_by uuid,
    default_settings json
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by uuid
);


--
-- Name: tax_rate_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    tax_rate_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    CONSTRAINT ck_tax_rate_assignments_one_target CHECK ((num_nonnulls(product_template_id, category_id) = 1))
);


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    rate numeric(5,2) NOT NULL,
    code character varying(10),
    country character varying(2),
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: unit_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_conversions (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    ingredient_key character varying(100) NOT NULL,
    ingredient_name character varying(200) NOT NULL,
    source_unit character varying(50) NOT NULL,
    metric_quantity numeric(10,3) NOT NULL,
    metric_unit character varying(10) NOT NULL,
    category character varying(50) NOT NULL,
    is_system boolean NOT NULL
);


--
-- Name: uom_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom_categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(50) NOT NULL
);


--
-- Name: uoms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uoms (
    id uuid NOT NULL,
    organization_id uuid,
    category_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL,
    factor numeric(18,9) NOT NULL,
    is_reference boolean NOT NULL,
    is_system boolean NOT NULL,
    rounding numeric(12,6) NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    blocking_reason character varying(500),
    failed_login_count bigint DEFAULT 0,
    locked_until timestamp with time zone,
    organization_id uuid
);


--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_delivery_logs (
    id uuid NOT NULL,
    webhook_endpoint_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload_json jsonb NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    attempt_number integer DEFAULT 1 NOT NULL,
    next_retry_at timestamp with time zone,
    delivery_status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    delivery_id character varying(36),
    abandon_reason character varying(40),
    last_attempt_at timestamp with time zone
);


--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_endpoints (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2048) NOT NULL,
    secret character varying(512),
    http_method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    event_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    retry_backoff_seconds integer DEFAULT 10 NOT NULL,
    timeout_seconds integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp with time zone,
    last_status_code integer,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auto_disabled_at timestamp with time zone
);


--
-- Name: wms_pick_line_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_line_lots (
    pick_line_id uuid NOT NULL,
    lot_id uuid NOT NULL,
    lot_name character varying(100) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_lines (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    pick_order integer NOT NULL,
    status character varying(20) NOT NULL,
    picked_quantity numeric(12,3) NOT NULL,
    bin_location character varying(255),
    product_name character varying(255),
    lot_name character varying(100),
    expected_quantity numeric(12,3) NOT NULL,
    uom_symbol character varying(10),
    anchor_id uuid,
    lot_id uuid,
    location_id uuid,
    expiry_date date
);


--
-- Name: wms_pick_session_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_session_documents (
    session_id uuid NOT NULL,
    document_id uuid NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    assigned_to uuid,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    meta_data jsonb,
    last_activity_at timestamp with time zone
);


--
-- Data for Name: ai_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version (version_num) VALUES ('ledgertotals02');


--
-- Data for Name: alembic_version_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_api_keys (version_num) VALUES ('007_scope_names_replace_scope');


--
-- Data for Name: alembic_version_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_approvals (version_num) VALUES ('007_workflow_requester_scope');


--
-- Data for Name: alembic_version_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_equipment (version_num) VALUES ('010_response_item_responded_at');


--
-- Data for Name: alembic_version_example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_example_widgets (version_num) VALUES ('001_initial');


--
-- Data for Name: alembic_version_maker; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_maker (version_num) VALUES ('015_default_result_margin');


--
-- Data for Name: alembic_version_printing; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_printing (version_num) VALUES ('007_job_read_permission');


--
-- Data for Name: alembic_version_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_purchase_orders (version_num) VALUES ('po_tzaware01');


--
-- Data for Name: alembic_version_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_recipes (version_num) VALUES ('013_meal_plan_listed_meals');


--
-- Data for Name: alembic_version_shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_shopping_lists (version_num) VALUES ('006_status_is_the_only_state');


--
-- Data for Name: alembic_version_stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_stock_takes (version_num) VALUES ('014_enums_are_text');


--
-- Data for Name: alembic_version_warehouse; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_warehouse (version_num) VALUES ('doc_tax_assign01');


--
-- Data for Name: alembic_version_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_webhooks (version_num) VALUES ('005_timestamps_carry_their_zone');


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('95a2cb5d-85db-4c62-afa2-d29332f42cfb', 'e6f3bf1f-064e-4341-a1de-40263c2ad170', 1, '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'APPROVED', NULL, '2026-10-31 01:38:17.832568+00', '2026-10-31 01:38:17.832568+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('338c2d1e-fb3b-4b4a-b8d4-ed7340584999', 'e6f3bf1f-064e-4341-a1de-40263c2ad170', 2, NULL, 'PENDING', NULL, NULL, '2026-10-30 22:38:17.832568+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('0d09a145-2a0e-4728-ad9f-cc398740b9e8', 'eb4091a1-fce7-4c98-abe6-35354630da53', 1, '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'APPROVED', NULL, '2026-10-24 01:38:17.832568+00', '2026-10-24 01:38:17.832568+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('ae4a3596-11a9-40df-ac61-6e6852e8af60', 'eb4091a1-fce7-4c98-abe6-35354630da53', 2, '2b510efc-b831-4b48-97e3-18a8659cf00f', 'APPROVED', NULL, '2026-10-24 04:38:17.832568+00', '2026-10-24 04:38:17.832568+00');


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('e6f3bf1f-064e-4341-a1de-40263c2ad170', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '6f48a415-fec6-4657-9430-e851d17624eb', 'purchase_order', '6e258647-da16-4407-8981-e0725b62cfad', 'IN_PROGRESS', 2, 2, '7fb93cd8-d0f5-4a14-b739-f72404792db5', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-10-30 22:38:17.832568+00', NULL, NULL);
INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('eb4091a1-fce7-4c98-abe6-35354630da53', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '6f48a415-fec6-4657-9430-e851d17624eb', 'purchase_order', '49156d77-1594-4f87-9924-91d3d1e6b68a', 'APPROVED', 2, 2, '7fb93cd8-d0f5-4a14-b739-f72404792db5', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-10-23 22:38:17.832568+00', NULL, NULL);


--
-- Data for Name: approval_workflows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_workflows (id, organization_id, target_type, name, stages, is_active, created_at, updated_at, archived_at, requester_scope) VALUES ('6f48a415-fec6-4657-9430-e851d17624eb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'purchase_order', 'Purchase orders over 10,000', '[{"order": 1, "role": "manager", "label": "Team lead", "approver_user_ids": []}, {"order": 2, "role": "admin", "label": "Finance", "approver_user_ids": []}]', true, '2026-11-02 21:38:18.76916+00', NULL, NULL, '{"everyone": true}');


--
-- Data for Name: audit_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_campaigns (id, organization_id, name, description, scope_type, scope_filter_id, launched_at, deadline, reminder_days_before, last_reminder_sent_at, status, email_subject, email_body, created_by, created_at, updated_at) VALUES ('e13d45f2-fe4c-424a-b9bc-5679b849dca6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Autumn equipment check', 'Confirm you still hold the equipment issued to you.', 'ALL', NULL, '2026-10-29 21:38:18.920421+00', '2026-11-19 23:59:00+00', 3, NULL, 'ACTIVE', NULL, NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-29 20:38:18.920421+00', '2026-11-02 21:38:18.921327+00');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('68ba8f62-c1bf-4b04-b89e-4de38b6e01b2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'module', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '{"name": "equipment", "subject": "profile:equipment_wms", "before": {"maintenance_warning_days": 7, "warranty_warning_days": 30}, "after": {"maintenance_warning_days": 14, "warranty_warning_days": 60}}', NULL, 'null', '2026-11-02 21:38:14.699725+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('236daf4f-c305-44d9-bda0-534717c5b965', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', 'd86f027b-8271-4c62-9e1b-9f8311d08ea3', '{"name": "UHT Milk 3.2%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": 48.0, "storage_location_id": "4b863cdb-567d-4e88-8c7e-ba625b663c95", "storage_location_name": "Fridge A", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-02 21:38:16.576226+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e7ce2b16-21cf-4d55-8530-383036f594de', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '17fea889-eefe-486a-8c87-a06a1e6f2cfa', '{"name": "Natural Yoghurt 400g", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": 24.0, "storage_location_id": "4b863cdb-567d-4e88-8c7e-ba625b663c95", "storage_location_name": "Fridge A", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-02 21:38:16.576227+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('ac3584b4-e5e2-4f36-8241-fb07812f8d91', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '{"name": "Butter Extra 82%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": 36.0, "storage_location_id": "4b863cdb-567d-4e88-8c7e-ba625b663c95", "storage_location_name": "Fridge A", "category_id": "04dea600-42e9-4ab1-a38d-c0f272e1ed52", "category_name": "Dairy", "category_code": "dairy"}', NULL, 'null', '2026-11-02 21:38:16.576228+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('2ba6becd-829e-4c8a-9e55-ec63dd6b7cb6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '{"name": "Gouda Cheese", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": 60.0, "storage_location_id": "11547469-399b-4f43-bb95-707e11abccb6", "storage_location_name": "Fridge B", "category_id": "566658f7-28ce-4ee5-8eb9-8fedcaea4d6d", "category_name": "Cheese", "category_code": "cheese"}', NULL, 'null', '2026-11-02 21:38:16.625245+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('1c7ce8f7-9856-47c7-8919-fac4f9d98e20', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '3a571895-6a7e-4037-9590-f5a136ac4f55', '{"name": "Sour Cream 18%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": 20.0, "storage_location_id": "11547469-399b-4f43-bb95-707e11abccb6", "storage_location_name": "Fridge B", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-02 21:38:16.625247+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('de025d43-d6a5-495b-b21e-40d0830bf547', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', 'bdd7d89a-3b1b-418a-834c-7b657ac843f0', '{"name": "Dell Latitude 5540", "brand": "Dell", "barcode": null, "sku": null, "quantity": 5.0, "storage_location_id": "db23efde-1a25-4356-9e42-4c8e5ddc0beb", "storage_location_name": "Server Rack A", "category_id": "73e43295-eeac-447d-b632-f3588ccd7741", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-11-02 21:38:16.658886+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5ec92db7-5726-4136-9ec5-b124628c2181', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '97b83666-9272-4d1b-8f6d-34ebb883509c', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": 3.0, "storage_location_id": "db23efde-1a25-4356-9e42-4c8e5ddc0beb", "storage_location_name": "Server Rack A", "category_id": "73e43295-eeac-447d-b632-f3588ccd7741", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-11-02 21:38:16.658888+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('03179c74-3233-42fe-99e9-0e16cf2f527a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', 'd86f027b-8271-4c62-9e1b-9f8311d08ea3', '{"name": "UHT Milk 3.2%", "before": {"quantity": "48.000"}, "after": {"quantity": "36.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "316f5842-f2c4-4251-a9f4-07ba08aae11f"}', '2026-11-02 21:38:16.749976+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('a1f7b46e-49ac-4487-bb09-6b42b1c6fdcf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '{"name": "Butter Extra 82%", "before": {"quantity": "36.000"}, "after": {"quantity": "28.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "316f5842-f2c4-4251-a9f4-07ba08aae11f"}', '2026-11-02 21:38:16.749978+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('3a2b46d2-8efc-42b2-9eb8-f8401e66bfa8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "wms_session_id": "70834e19-8f76-4868-b0a9-a07c90949aaf", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-02 21:38:17.186987+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('2e960edc-6e6f-4922-8cf0-ad0fe425681d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '{"number": "OUT/2026/004", "wms_session_id": "70834e19-8f76-4868-b0a9-a07c90949aaf", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-02 21:38:17.188779+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('8a9e7c07-74fd-44aa-8a38-9a1dcfe21707', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "wms_session_id": "70834e19-8f76-4868-b0a9-a07c90949aaf", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-02 21:38:17.358735+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e489ee44-19ae-4283-aaed-382a5ea229b7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '{"number": "OUT/2026/004", "wms_session_id": "70834e19-8f76-4868-b0a9-a07c90949aaf", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-02 21:38:17.359555+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('3c09fc19-61a6-49fa-b680-b01b3012544e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "weight_value": null}', NULL, 'null', '2026-11-02 21:38:17.387248+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('73c63103-8e9e-474a-a40d-73b9ae947710', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "name": "Natural Yoghurt 400g", "quantity": "6", "old_quantity": "0"}', NULL, 'null', '2026-11-02 21:38:17.411559+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('d8e45924-56dd-4006-a0dd-0de70bf70e30', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "weight_value": null}', NULL, 'null', '2026-11-02 21:38:17.430395+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('16924e21-a9e1-4392-b4ff-bb5dd355724f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "name": "Butter Extra 82%", "quantity": "4", "old_quantity": "0"}', NULL, 'null', '2026-11-02 21:38:17.453254+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('2a105916-eb9a-486b-a73d-61f2bff31e0f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', '17fea889-eefe-486a-8c87-a06a1e6f2cfa', '{"name": "Natural Yoghurt 400g", "before": {"quantity": "24.000"}, "after": {"quantity": "18.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "5ab457d6-477d-403c-bde8-4d5fdba0cd00"}', '2026-11-02 21:38:17.679196+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('6fa895a8-d0e4-4ff1-a99b-86c0a49c4564', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '{"name": "Butter Extra 82%", "before": {"quantity": "28.000"}, "after": {"quantity": "24.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "5ab457d6-477d-403c-bde8-4d5fdba0cd00"}', '2026-11-02 21:38:17.679198+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('96ab1d47-03e2-433a-8731-d910da9ff8ef', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '{"number": "OUT/2026/003", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-02 21:38:17.679198+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('19b05e4f-4af6-4a9f-8052-c57895a5c103', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '{"name": "Gouda Cheese", "before": {"quantity": "60.000"}, "after": {"quantity": "50.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2"}', '2026-11-02 21:38:17.796862+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('817a2705-0de9-4b98-9792-91e443886df7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', '3a571895-6a7e-4037-9590-f5a136ac4f55', '{"name": "Sour Cream 18%", "before": {"quantity": "20.000"}, "after": {"quantity": "15.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2"}', '2026-11-02 21:38:17.796864+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('781fdad2-51af-42aa-8e3a-0ed74d9a2543', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'document', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '{"number": "OUT/2026/004", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-02 21:38:17.796865+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('89782c64-7886-4258-a256-37724a003ced', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '0a4f19f1-493a-4417-aef1-d679e229b424', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": 3.0, "storage_location_id": "db23efde-1a25-4356-9e42-4c8e5ddc0beb", "storage_location_name": "Server Rack A", "category_id": "73e43295-eeac-447d-b632-f3588ccd7741", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-11-02 21:38:18.325856+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('0e722d74-a14b-4eb7-a83b-fd0eea68aeb6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'maker_production_order', '15d91c01-50ef-43c3-a1a1-e1924089351e', '{"name": "PR/2026/0001", "status": "DRAFT", "output": "Plum Butter", "planned_qty": 12.0}', NULL, 'null', '2026-11-02 21:38:18.521954+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('08408b3e-9a36-47ab-84c8-b31871c0cde4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', 'cf716a8c-de7d-411a-ae2d-b9b862906724', '{"name": "Damson Plums", "before": {"quantity": "40.000"}, "after": {"quantity": "13.600"}}', 'Production run PR/2026/0001', '{"production_order_id": "15d91c01-50ef-43c3-a1a1-e1924089351e"}', '2026-11-02 21:38:18.589504+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('d3e38a76-4517-4d18-8a42-3400ad2e2dc2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', '0ff3df72-b4e4-4188-b8ab-cea8be877f14', '{"name": "White Sugar", "before": {"quantity": "25.000"}, "after": {"quantity": "21.220"}}', 'Production run PR/2026/0001', '{"production_order_id": "15d91c01-50ef-43c3-a1a1-e1924089351e"}', '2026-11-02 21:38:18.619143+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('87b34c1a-9962-4301-a1d0-caf0b86be76c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGE', 'item', 'c102148e-b102-4e49-8ef1-ed8e2a214374', '{"name": "Cassia Cinnamon", "before": {"quantity": "0.500"}, "after": {"quantity": "0.440"}}', 'Production run PR/2026/0001', '{"production_order_id": "15d91c01-50ef-43c3-a1a1-e1924089351e"}', '2026-11-02 21:38:18.638772+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('661212fa-d3b4-433e-9e3e-16c567df0d29', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATE', 'item', '75ffde96-7a2f-48d8-bead-36eefe97df13', '{"name": "Plum Butter", "brand": null, "barcode": null, "sku": "PLB-001", "quantity": 11.4, "storage_location_id": "d44a51bc-01a1-472d-9e2b-273bf1864c2d", "storage_location_name": "Shelf A - Bottom", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-02 21:38:18.660305+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('39f69419-6ddc-4a3d-9ea3-c7973c38afba', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'UPDATE', 'maker_production_order', '15d91c01-50ef-43c3-a1a1-e1924089351e', '{"name": "PR/2026/0001", "old_status": "DRAFT", "new_status": "COMPLETED", "output": "Plum Butter", "quantity": 11.4, "total_cost": 95.358}', NULL, 'null', '2026-11-02 21:38:18.668207+00');


--
-- Data for Name: audit_response_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('58a2beb3-6e33-4603-8842-5b1458c33aa2', '359d47f5-af89-4588-a999-1219c8ac2119', '53d75cfe-48a8-472a-add5-c3c6e4223d68', 'c3b0367c-813a-476c-b764-9a59f2e9fe09', 'iPhone 15 Pro', 'SN-100025', 'CONFIRMED', NULL, NULL, '2026-11-02 21:38:18.925828+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('779577ce-7899-496d-bf8d-c2462e0cc764', '39e64a04-1563-4046-833c-01127110d689', '3b6a7e02-d2b9-44cc-83af-148867441792', 'b90f9f0c-3a4b-4e25-8f89-29c37d2d21f0', 'Dell Latitude 5540', 'SN-100001', 'DISPUTED', 'DAMAGED', 'The hinge on the lid is cracked and the screen flickers.', '2026-11-02 21:38:18.92583+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('0f35d06f-6048-4b3d-a11e-5dd3ff353c70', '5a95dd35-7542-43ef-89a0-510c6a9fcacb', '0ac47d62-4d4d-4375-a663-3d92c0f0daae', 'f6ac1916-f2bc-4e50-b5cf-ba2dd5f9c91f', 'Dell Latitude 5540', 'SN-100002', 'PENDING', NULL, NULL, '2026-11-02 21:38:18.92583+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('831d60c6-583c-420b-ad6f-5316905400f8', '2d0b5375-b532-4919-aec8-27dd75affe55', '85b9622c-50da-4e91-8786-e5d46b34e7dc', '70065571-f474-4978-8e86-793819fab86a', 'ThinkPad T14s Gen 4', 'SN-100003', 'PENDING', NULL, NULL, '2026-11-02 21:38:18.925831+00', NULL);


--
-- Data for Name: audit_responses; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('359d47f5-af89-4588-a999-1219c8ac2119', 'e13d45f2-fe4c-424a-b9bc-5679b849dca6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'admin@example.com', 'Demo Administrator', 'XHVjXvVMDYti-8yxv2GQitmdqoXnat3i9a-xTY82Z7Zt48Y7sIeJMZXI4KXa06viJUgjgOLlb_ZHRnzpVl80HQ', '2026-11-19 23:59:00+00', 'CONFIRMED', '2026-10-30 21:38:18.920421+00', NULL, NULL, NULL, NULL, '2026-10-29 21:38:18.920421+00', NULL, '2026-11-02 21:38:18.923018+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('39e64a04-1563-4046-833c-01127110d689', 'e13d45f2-fe4c-424a-b9bc-5679b849dca6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'priya.raman@example.com', 'Priya Raman', '5fyfBHgjPalxjYQacnCldEPnnzKtkccrQ5GmytHQT_G0x9qDeWUs078IrypCzqXYM-oypU05dEFmZavMv_IRNg', '2026-11-19 23:59:00+00', 'DISPUTED', '2026-10-30 22:38:18.920421+00', 'The hinge on the lid is cracked and the screen flickers.', 'DAMAGED', NULL, NULL, '2026-10-29 21:38:18.920421+00', NULL, '2026-11-02 21:38:18.92302+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('5a95dd35-7542-43ef-89a0-510c6a9fcacb', 'e13d45f2-fe4c-424a-b9bc-5679b849dca6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'marcus.webb@example.com', 'Marcus Webb', 'D77LU0BVXWtWawBelyJNr6aETZIonew9dBBrsk5BNw-__lM70PilqMJJOFeQgctrcb4TQe-QZzbRMu9Qpji8Ew', '2026-11-19 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-10-29 21:38:18.920421+00', NULL, '2026-11-02 21:38:18.92302+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('2d0b5375-b532-4919-aec8-27dd75affe55', 'e13d45f2-fe4c-424a-b9bc-5679b849dca6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'ava.brennan@example.com', 'Ava Brennan', 'cNG3f-g9qBmwVL585KVe1Aho_4VRkgKJek5gNUgevq2NXmT6G_Du167vDyWj-pzzOOqG_EMxnAFWaNx2_-hrLA', '2026-11-19 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-10-29 21:38:18.920421+00', NULL, '2026-11-02 21:38:18.923021+00');


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('73e43295-eeac-447d-b632-f3588ccd7741', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Laptop', 'LAPTOP', 'equipment', NULL, 'laptop', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "os", "type": "text", "label": "Operating System", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('12edfd54-4f28-4eed-8adb-447f3c453baf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Desktop Computer', 'DESKTOP', 'equipment', NULL, 'monitor', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d5609977-a4b1-403b-abb9-b8e889d0b754', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Monitor / Display', 'MONITOR', 'equipment', NULL, 'monitor-smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "size_inches", "type": "number", "label": "Screen Size (inches)", "visible": true, "required": false, "is_system": true}, {"key": "resolution", "type": "text", "label": "Resolution", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 7, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('fde4286d-25aa-4724-bb49-907a5cbf468b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Phone / Tablet', 'PHONE', 'equipment', NULL, 'smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "imei", "type": "text", "label": "IMEI", "visible": true, "required": false, "is_system": true}, {"key": "phone_number", "type": "text", "label": "Phone Number", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 3, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('96317341-b5f2-4dc3-9aeb-71935c716cdf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Seafood', 'seafood', 'cold_storage', 'FREEZER', 'Shell', NULL, NULL, 5, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('21f6cccb-2dd1-4392-bffe-813f39c14f90', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen meals', 'frozen_meals', 'cold_storage', 'FREEZER', 'Soup', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ca034932-30ef-4765-b488-2d7295dbd531', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen vegetables', 'frozen_vegetables', 'cold_storage', 'FREEZER', 'LeafyGreen', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b862c034-92c9-4b4f-a48e-bc26e5f06feb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen fruits', 'frozen_fruits', 'cold_storage', 'FREEZER', 'Apple', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8a553520-af81-42d7-8377-9f4bb692f23b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Ice cream and desserts', 'ice_cream', 'cold_storage', 'FREEZER', 'IceCream', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('5bed3eee-374b-4d13-beaa-df2e0b17877d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Network Device', 'NETWORK_DEVICE', 'equipment', NULL, 'wifi', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "mac_address", "type": "text", "label": "MAC Address", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 8, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('adb35b3c-24e9-49dc-b841-776202287861', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Peripheral', 'PERIPHERAL', 'equipment', NULL, 'mouse', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 4, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('76a9429c-6143-4089-b2a1-634fee1f4bb8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Server', 'SERVER', 'equipment', NULL, 'server', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "rack_position", "type": "text", "label": "Rack Position", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "cpu", "type": "text", "label": "CPU", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 10, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('69437a1f-208d-4eb0-aee9-baf140d2d200', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Other Equipment', 'OTHER_EQUIPMENT', 'equipment', NULL, 'package', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('53e7263d-13ad-4f78-8661-405a11c18552', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Pork', 'pork', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('6465d255-7551-4e8a-ad0b-17a524a2bdd9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Beef', 'beef', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('9654f31d-cbcd-4db5-aa4d-0b548e4f0187', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Poultry', 'poultry', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 3, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('f18b0d75-e2e9-4d96-907c-5172592adf3f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fish', 'fish', 'cold_storage', 'FREEZER', 'Fish', NULL, NULL, 4, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a2c0951c-16a4-4218-8f64-5cbe43fa4f77', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen pizza', 'frozen_pizza', 'cold_storage', 'FREEZER', 'Pizza', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('04dea600-42e9-4ab1-a38d-c0f272e1ed52', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dairy', 'dairy', 'cold_storage', 'FRIDGE', 'Milk', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('566658f7-28ce-4ee5-8eb9-8fedcaea4d6d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cheese', 'cheese', 'cold_storage', 'FRIDGE', 'Cheese', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('4fb2550f-5fe6-41a8-b662-98571cd14bf6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Deli', 'deli', 'cold_storage', 'FRIDGE', 'Beef', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('9dd72612-d39f-4ca4-9739-b9793ec0627d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Eggs', 'eggs', 'cold_storage', 'FRIDGE', 'Egg', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('c93b24f5-af18-4089-a62b-3ca2ea709c45', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fresh vegetables', 'fresh_vegetables', 'cold_storage', 'FRIDGE', 'LeafyGreen', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ac71d475-2bd8-476e-9264-e53abc0e0df9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fresh fruits', 'fresh_fruits', 'cold_storage', 'FRIDGE', 'Apple', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('09752f2b-e0c6-441d-ab5f-6a9e6eddd1ec', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Drinks', 'drinks', 'cold_storage', 'FRIDGE', 'GlassWater', NULL, NULL, 7, NULL, NULL, NULL, true, '[{"key": "abv", "is_system": true, "label": "Alcohol content (ABV %)", "type": "number", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('8c371fe3-ea8a-4330-b967-b52a856de96a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Sauces and dips', 'sauces', 'cold_storage', 'FRIDGE', 'Pint', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('cb1d2dd0-ab08-4c03-808a-a5f799206f9d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fresh meat', 'fresh_meat', 'cold_storage', 'FRIDGE', 'Drumstick', NULL, NULL, 9, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('9ca6ca17-bded-4bff-8197-d633d17fcc28', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fresh meals', 'fresh_meals', 'cold_storage', 'FRIDGE', 'CookingPot', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a3124554-8a96-49d5-8af4-c327bc6a249b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dry products', 'dry_products', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 1, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('fb222af9-20d1-40f9-9c71-031d7e3c40c2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Pasta', 'pasta', 'dry_goods', 'PANTRY', 'Utensils', NULL, NULL, 2, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('aae3d87d-d01c-4f09-92da-37eb5d16b6ec', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Rice and grains', 'rice_grains', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('75051917-0617-4e5d-9871-c8445b191699', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Canned goods', 'canned_goods', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Spices and herbs', 'spices_herbs', 'dry_goods', 'PANTRY', 'Leaf', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('fdf5770f-0648-42b0-8a68-a7b029ef3045', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Oils and vinegars', 'oils_vinegars', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d76b10ff-781b-466f-be04-2714ae417710', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Flours and sugars', 'flours_sugars', 'dry_goods', 'PANTRY', 'Box', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('bbd5db28-2750-499b-add6-68d4138dbfbc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Snacks', 'snacks', 'dry_goods', 'PANTRY', 'Cookie', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('7f257885-0225-488c-b07b-4998394931af', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Sweets', 'sweets', 'dry_goods', 'PANTRY', 'Candy', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d9ca2fff-71b4-4f2e-a667-67011a096dab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Beverages (non-refrigerated)', 'beverages', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('abd1db4d-3be0-43c0-a02f-34102db94664', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tea and coffee', 'tea_coffee', 'dry_goods', 'PANTRY', 'Coffee', NULL, NULL, 11, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('cd18809f-9eae-485d-b310-4c4335a6186f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cans and jars', 'cans_jars', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 12, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('c5c0b808-489e-46c5-97f8-5d5ff254c452', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Other', 'other', NULL, NULL, 'Archive', NULL, NULL, 100, NULL, NULL, NULL, true, '[]');


--
-- Data for Name: cycle_count_schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_extra_costs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('4c46a7de-3bf4-49d0-9170-b70324dfd552', '17d8ab1d-5f7b-4627-ae3f-3af4a4ea4500', '3032cdb9-2085-46d7-a034-e7e36b2be809', '550d3d31-b672-4970-9b5e-c340b8762506', 'Green Grapes', 'Green Acre', '2178682164889', 5.000, 5.000, 0.000, '0cf8f21a-3455-45f5-a61e-7cae190755d8', NULL, NULL, NULL, NULL, NULL, NULL, 9.90, 8.00, 49.50, 3.96, 53.46, 'USD', 1, NULL, '{"name": "Green Grapes", "seed": "SEED-DOC", "brand": "Green Acre"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('9cfb9dd0-a250-46a4-8c7f-33de6be6a622', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', 'd86f027b-8271-4c62-9e1b-9f8311d08ea3', '0f235c0d-8907-42ed-a359-c437e63adb06', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 48.000, 48.000, 48.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, 8.00, 216.00, 17.28, 233.28, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('8ba0b883-0043-450d-b9e4-e8a129123ab2', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '17fea889-eefe-486a-8c87-a06a1e6f2cfa', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 24.000, 24.000, 24.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, 8.00, 124.80, 9.98, 134.78, 'USD', 2, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('73a54928-ecd4-4d88-8be9-5ffb8e203378', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 36.000, 36.000, 36.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, 8.00, 320.40, 25.63, 346.03, 'USD', 3, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('659dfba1-c413-49d1-881e-822bfd08ce2f', 'c5e7cff4-5b85-4212-8f9a-2938457e9aec', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', 'Gouda Cheese', 'Meadowlane', '2000000000046', 60.000, 60.000, 60.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 750.00, 60.00, 810.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', '11547469-399b-4f43-bb95-707e11abccb6', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('cc1d3240-839e-4ad4-86f0-448301532d03', 'c5e7cff4-5b85-4212-8f9a-2938457e9aec', '3a571895-6a7e-4037-9590-f5a136ac4f55', '5b058779-639f-4d34-9201-7dc78d9700fd', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 20.000, 20.000, 20.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, 8.00, 82.00, 6.56, 88.56, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '11547469-399b-4f43-bb95-707e11abccb6', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('81ef289d-20ef-4792-9032-2504842c79c7', '560a4701-fc32-4747-8331-b7521c0e2883', 'bdd7d89a-3b1b-418a-834c-7b657ac843f0', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'Dell Latitude 5540', 'Dell', '5397184123456', 5.000, 5.000, 5.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 4200.00, 23.00, 21000.00, 4830.00, 25830.00, 'USD', 1, NULL, '{"name": "Dell Latitude 5540", "seed": "SEED-DOC", "brand": "Dell"}', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('0ff07ef2-61f1-4ba1-b849-f7978493a643', '560a4701-fc32-4747-8331-b7521c0e2883', '97b83666-9272-4d1b-8f6d-34ebb883509c', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 'ThinkPad T14s Gen 4', 'Lenovo', '0196881123456', 3.000, 3.000, 3.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, 23.00, 17400.00, 4002.00, 21402.00, 'USD', 2, NULL, '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC", "brand": "Lenovo"}', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('8572fef6-0eeb-4d55-8d89-731283b3c80d', '316f5842-f2c4-4251-a9f4-07ba08aae11f', 'd86f027b-8271-4c62-9e1b-9f8311d08ea3', '0f235c0d-8907-42ed-a359-c437e63adb06', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 12.000, 12.000, 12.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, 8.00, 54.00, 4.32, 58.32, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('ca73d1f0-7e5b-4001-8af2-a99a8bb139b9', '316f5842-f2c4-4251-a9f4-07ba08aae11f', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 8.000, 8.000, 8.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, 8.00, 71.20, 5.70, 76.90, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('8c0ec7bc-cdfe-479f-a83f-75fece007ee3', '4b02e500-558e-4ea7-8328-eea1381da923', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 0.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 125.00, 10.00, 135.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('1345dd29-8367-4b7f-8a45-266cbcda14a2', '996934c0-215a-4ab4-af9c-44fbcbd8eb04', '0a4f19f1-493a-4417-aef1-d679e229b424', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 'ThinkPad T14s Gen 4', NULL, NULL, 3.000, 3.000, 3.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, 23.00, 17400.00, 4002.00, 21402.00, 'USD', 1, '18e9c3df-cc76-41d8-9c87-881ee8b03f0e', '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC"}', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('5d4a79b1-3fd8-4741-b9d9-66edce4d1ef0', 'e027d414-a2ce-42a6-a730-0e69784fe4c2', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', 'Gouda Cheese', 'Meadowlane', '2000000000046', 8.000, 8.000, 0.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 100.00, 8.00, 108.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('786778f9-6214-46d3-8d26-255c46d78703', 'e027d414-a2ce-42a6-a730-0e69784fe4c2', '3a571895-6a7e-4037-9590-f5a136ac4f55', '5b058779-639f-4d34-9201-7dc78d9700fd', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 4.000, 4.000, 0.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, 8.00, 16.40, 1.31, 17.71, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('9f8c55e8-3470-4bc7-ae40-0e192116b043', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 10.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 125.00, 10.00, 135.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('74fb46b7-a7f1-4343-9a8f-6522dc37bb5b', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '3a571895-6a7e-4037-9590-f5a136ac4f55', '5b058779-639f-4d34-9201-7dc78d9700fd', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 5.000, 5.000, 5.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, 8.00, 20.50, 1.64, 22.14, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('e2d157d8-c8a6-4925-a167-6891159fe91c', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '17fea889-eefe-486a-8c87-a06a1e6f2cfa', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 6.000, 6.000, 6.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, 8.00, 31.20, 2.50, 33.70, 'USD', 1, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 0.000, '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('265efce9-0296-4acd-a15f-18879644d53d', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 4.000, 4.000, 4.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, 8.00, 35.60, 2.85, 38.45, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 0.000, '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, false);


--
-- Data for Name: document_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_number_sequences (organization_id, prefix, next_value) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'PR/2026/', 2);


--
-- Data for Name: document_package_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('5f8fcca7-ea34-4b7f-b468-eeee5dd0227d', 'f8570274-0bf5-4b34-a525-9f63969bd21d', 'e2d157d8-c8a6-4925-a167-6891159fe91c', 6.000, '2026-11-02 21:38:16.961346+00');
INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('f9b63a2b-85ce-479f-af8a-8f2ddb2a7949', 'a7df372e-3546-4922-b01f-29a18577c3dc', '265efce9-0296-4acd-a15f-18879644d53d', 4.000, '2026-11-02 21:38:16.961346+00');


--
-- Data for Name: document_packages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('f8570274-0bf5-4b34-a525-9f63969bd21d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', 1, NULL, '2026-11-02 21:38:16.961346+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('a7df372e-3546-4922-b01f-29a18577c3dc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', 2, NULL, '2026-11-02 21:38:16.961346+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');


--
-- Data for Name: document_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_profiles (id, organization_id, name, value_tracking_enabled, tax_handling, default_tax_rate, require_partner_tax_id, numbering_format, type_labels, default_unit, visible_line_fields, print_template, default_currency, default_template_id, approval_threshold, approval_required_for_types, created_at, updated_at, number_padding, require_unit_price, confirm_shelf_by_scan, tracking_url_templates, quarantine_location_id, pick_order_strategy) VALUES ('dbc1a24f-8c2f-4494-8934-f3ebbde79de0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Full Value', true, 'SIMPLE_RATE', NULL, NULL, '{TYPE}/{YEAR}/{SEQ:03d}', 'null', 'pcs', '[]', 'auto', NULL, NULL, NULL, NULL, '2026-11-02 21:38:14.706641+00', '2026-11-02 21:38:14.723678+00', 3, false, false, NULL, 'dc90f76d-06d9-4e33-a6b6-cd6850ad70bf', NULL);


--
-- Data for Name: document_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_shipments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_shipments (id, organization_id, document_id, carrier, tracking_number, shipped_at, shipped_by, notes, created_at) VALUES ('3f6e6571-51ce-4cd4-96d1-54fbf6a63fea', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', 'InPost', '620012345678901234567890', '2026-11-02 21:38:17.546257+00', '2b510efc-b831-4b48-97e3-18a8659cf00f', NULL, '2026-11-02 21:38:17.478502+00');


--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_type_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_warehouse_receiving; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_work_item_overlays; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('17d8ab1d-5f7b-4627-ae3f-3af4a4ea4500', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'INT', 'INT/2026/001', 'DRAFT', NULL, 'e3b6070a-033b-4c12-855b-bb78d26e9a37', '56c22ebc-1905-422e-a5c0-2d17743d5dae', '2026-11-01', NULL, NULL, 'null', NULL, NULL, 49.50, 3.96, 53.46, 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', NULL, NULL, '2026-11-01 09:35:00+00', '2026-11-02 21:38:18.874728+00', NULL, NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('316f5842-f2c4-4251-a9f4-07ba08aae11f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'OUT', 'OUT/2026/001', 'COMPLETED', '88a5eaa8-d849-448b-adf9-d4719a0c9a0c', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, '2026-10-29', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 125.20, 10.02, 135.22, 'USD', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-29 09:35:00+00', '2026-11-02 21:38:18.875131+00', '2026-10-29 10:45:00+00', '2026-10-29 12:15:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('4b02e500-558e-4ea7-8328-eea1381da923', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'OUT', 'OUT/2026/002', 'CONFIRMED', '9d042212-f75c-445f-9394-f278032ce250', '11547469-399b-4f43-bb95-707e11abccb6', NULL, '2026-10-31', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 125.00, 10.00, 135.00, 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', NULL, '2026-10-31 09:35:00+00', '2026-11-02 21:38:18.875522+00', '2026-10-31 10:45:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('560a4701-fc32-4747-8331-b7521c0e2883', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'IN', 'IN/2026/004', 'COMPLETED', 'a86bb670-47a6-4d43-9cbb-8d29c2824785', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-10-31', NULL, 'Delivery note 7313', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 38400.00, 8832.00, 47232.00, 'USD', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-31 10:50:00+00', '2026-11-02 21:38:18.875878+00', '2026-10-31 12:00:00+00', '2026-10-31 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('5ab457d6-477d-403c-bde8-4d5fdba0cd00', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'OUT', 'OUT/2026/003', 'COMPLETED', '88a5eaa8-d849-448b-adf9-d4719a0c9a0c', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, '2026-11-01', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 66.80, 5.35, 72.15, 'USD', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-11-01 11:20:00+00', '2026-11-02 21:38:18.87588+00', '2026-11-01 12:30:00+00', '2026-11-01 14:00:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'IN', 'IN/2026/002', 'COMPLETED', '6c35c2d3-06c1-4d99-8b65-6bc61e905e5c', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', '2026-10-24', NULL, 'Delivery note 7311', '{"code": "FFD-004", "name": "Freshfield Wholesale"}', NULL, NULL, 661.20, 52.89, 714.09, 'USD', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-24 10:50:00+00', '2026-11-02 21:38:18.87588+00', '2026-10-24 12:00:00+00', '2026-10-24 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('996934c0-215a-4ab4-af9c-44fbcbd8eb04', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'IN', 'IN/2026/001', 'COMPLETED', 'a86bb670-47a6-4d43-9cbb-8d29c2824785', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-10-16', NULL, 'PO/2026/003', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 17400.00, 4002.00, 21402.00, 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-10-16 08:10:00+00', '2026-11-02 21:38:18.87588+00', '2026-10-16 09:20:00+00', '2026-10-16 10:50:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('c5e7cff4-5b85-4212-8f9a-2938457e9aec', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'IN', 'IN/2026/003', 'COMPLETED', '73172d96-cc36-430e-bb97-9b420e053602', NULL, '11547469-399b-4f43-bb95-707e11abccb6', '2026-10-26', NULL, 'Delivery note 7312', '{"code": "MCC-005", "name": "Bulkline Cash & Carry"}', NULL, NULL, 832.00, 66.56, 898.56, 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-10-26 10:50:00+00', '2026-11-02 21:38:18.875881+00', '2026-10-26 12:00:00+00', '2026-10-26 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('e027d414-a2ce-42a6-a730-0e69784fe4c2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'OUT', 'OUT/2026/005', 'CONFIRMED', '88a5eaa8-d849-448b-adf9-d4719a0c9a0c', '11547469-399b-4f43-bb95-707e11abccb6', NULL, '2026-11-01', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 116.40, 9.31, 125.71, 'USD', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '680ca639-edea-48fe-8eb5-a03cfdbb8852', NULL, '2026-11-01 13:15:00+00', '2026-11-02 21:38:18.877008+00', '2026-11-01 14:25:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data) VALUES ('e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'OUT', 'OUT/2026/004', 'COMPLETED', '9d042212-f75c-445f-9394-f278032ce250', '11547469-399b-4f43-bb95-707e11abccb6', NULL, '2026-11-01', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 145.50, 11.64, 157.14, 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-11-01 12:05:00+00', '2026-11-02 21:38:18.877217+00', '2026-11-01 13:15:00+00', '2026-11-01 14:45:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL);


--
-- Data for Name: email_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('85b9622c-50da-4e91-8786-e5d46b34e7dc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '70065571-f474-4978-8e86-793819fab86a', NULL, '3d9a68be-2319-450a-91dd-07216b4b58b9', 'Ava Brennan', 'ava.brennan@example.com', '2026-10-19 21:38:18.424517+00', '2027-05-01 21:38:18.424521+00', NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-02 21:38:18.427215+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('0ac47d62-4d4d-4375-a663-3d92c0f0daae', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f6ac1916-f2bc-4e50-b5cf-ba2dd5f9c91f', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 'Marcus Webb', 'marcus.webb@example.com', '2026-10-10 21:38:18.424599+00', '2027-05-01 21:38:18.4246+00', NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-02 21:38:18.427217+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('3b6a7e02-d2b9-44cc-83af-148867441792', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'b90f9f0c-3a4b-4e25-8f89-29c37d2d21f0', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 'Priya Raman', 'priya.raman@example.com', '2026-10-01 21:38:18.424628+00', '2027-05-01 21:38:18.424629+00', NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-02 21:38:18.427217+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('53d75cfe-48a8-472a-add5-c3c6e4223d68', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c3b0367c-813a-476c-b764-9a59f2e9fe09', NULL, 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 'Demo Administrator', 'admin@example.com', '2026-09-23 21:38:18.899052+00', NULL, NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', NULL, 'Work phone, with case and charger.', NULL, NULL, '2026-11-02 21:38:18.905802+00');


--
-- Data for Name: equipment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_maintenance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('4d306277-248c-47b9-935a-0729877bd865', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd70ca8a9-998e-40f3-b2bf-f78b7c52d847', 'REPAIR', 'Replace failed PSU', 'Redundant power supply 2 reported a fault; unit sent to the vendor.', NULL, 'USD', '2026-10-30', 'Northgate IT Distribution', NULL, NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.760484+00', '2026-11-02 21:38:18.760486+00');
INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('ed92c132-916e-4341-bdf3-4d442204ec28', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'dbe8bf35-3617-4a8b-b2a2-9d7044c3165c', 'INSPECTION', 'Battery self-test and runtime check', 'Runtime at full load 11 min, within spec. Batteries due next year.', 120.00, 'USD', '2026-09-23', 'Northgate IT Distribution', NULL, '2027-09-23', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.760487+00', '2026-11-02 21:38:18.760488+00');


--
-- Data for Name: event_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: event_outbox; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ingredient_nutrition_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_periods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('8d9a65c9-9d3a-42ad-94eb-2ea2b39378b1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cf716a8c-de7d-411a-ae2d-b9b862906724', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGED', '{"old": "40.000", "new": "13.600", "reason": "Production run PR/2026/0001", "production_order_id": "15d91c01-50ef-43c3-a1a1-e1924089351e"}', NULL, '2026-11-02 21:38:18.587583+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1dfeb079-7867-4e65-bbff-cf47d3dba46a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0ff3df72-b4e4-4188-b8ab-cea8be877f14', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGED', '{"old": "25.000", "new": "21.220", "reason": "Production run PR/2026/0001", "production_order_id": "15d91c01-50ef-43c3-a1a1-e1924089351e"}', NULL, '2026-11-02 21:38:18.618484+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('46473f20-9af1-4cdb-8f98-c7d650e4bda3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c102148e-b102-4e49-8ef1-ed8e2a214374', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'QUANTITY_CHANGED', '{"old": "0.500", "new": "0.440", "reason": "Production run PR/2026/0001", "production_order_id": "15d91c01-50ef-43c3-a1a1-e1924089351e"}', NULL, '2026-11-02 21:38:18.638171+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('cadecefe-fe31-47a6-9945-7c0f8188db29', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '75ffde96-7a2f-48d8-bead-36eefe97df13', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'CREATED', '{"created": true}', NULL, '2026-11-02 21:38:18.661075+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d6134dd7-4a7e-4de3-9fd4-d1cca60ff33e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0a4f19f1-493a-4417-aef1-d679e229b424', '7fb93cd8-d0f5-4a14-b739-f72404792db5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/004", "from_template": "33b25eca-5f45-4957-9dcc-fd1aa463d155"}', '996934c0-215a-4ab4-af9c-44fbcbd8eb04', '2026-11-02 21:38:18.327122+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('40136cf2-2f58-4e92-b3ff-af342f490c21', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd86f027b-8271-4c62-9e1b-9f8311d08ea3', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "0f235c0d-8907-42ed-a359-c437e63adb06"}', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '2026-11-02 21:38:16.578309+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('839b156b-69f0-46b2-a531-1aa4595c5935', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '17fea889-eefe-486a-8c87-a06a1e6f2cfa', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "a3a9f3b1-19f5-428a-bf1e-19447790d174"}', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '2026-11-02 21:38:16.578312+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('ae648144-4d16-41de-b67c-93a8bb1fe2f0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "270eb47d-03bc-4642-9594-05b6a4b69ac3"}', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '2026-11-02 21:38:16.578312+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('73c02ebe-52e1-48cf-af3b-48a48bcf94a9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '7fb93cd8-d0f5-4a14-b739-f72404792db5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "3888bb38-abd7-4a67-ba60-761ade6fa2b9"}', 'c5e7cff4-5b85-4212-8f9a-2938457e9aec', '2026-11-02 21:38:16.625988+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('e8dbc62f-ffa0-4dab-bfe7-443fd9af7460', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3a571895-6a7e-4037-9590-f5a136ac4f55', '7fb93cd8-d0f5-4a14-b739-f72404792db5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "5b058779-639f-4d34-9201-7dc78d9700fd"}', 'c5e7cff4-5b85-4212-8f9a-2938457e9aec', '2026-11-02 21:38:16.625994+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('5d934aa3-1b55-4a2c-9b59-0e20ca791627', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd86f027b-8271-4c62-9e1b-9f8311d08ea3', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'QUANTITY_CHANGED', '{"old": "48.000", "new": "36.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', '316f5842-f2c4-4251-a9f4-07ba08aae11f', '2026-11-02 21:38:16.749081+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('6d841b68-669b-4cc9-b13a-464d77cb735c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'QUANTITY_CHANGED', '{"old": "36.000", "new": "28.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', '316f5842-f2c4-4251-a9f4-07ba08aae11f', '2026-11-02 21:38:16.749083+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('862f9761-43f3-4b4d-ac8f-3f1e4759dafe', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bdd7d89a-3b1b-418a-834c-7b657ac843f0', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "9d7a90d7-4431-4d3a-b1c0-78c247204b37"}', '560a4701-fc32-4747-8331-b7521c0e2883', '2026-11-02 21:38:16.65965+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1a0811c9-ee2c-416b-bd46-dc5c92b3cf5e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '97b83666-9272-4d1b-8f6d-34ebb883509c', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "33b25eca-5f45-4957-9dcc-fd1aa463d155"}', '560a4701-fc32-4747-8331-b7521c0e2883', '2026-11-02 21:38:16.659653+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('aa8fd8b8-5362-4ade-84d2-c64921d19733', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '17fea889-eefe-486a-8c87-a06a1e6f2cfa', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'QUANTITY_CHANGED', '{"old": "24.000", "new": "18.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '2026-11-02 21:38:17.676543+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('df988b07-eb60-4283-ac87-36f943cd31f1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b4fb054-971f-48e5-93ca-ad5ee6513b85', '680ca639-edea-48fe-8eb5-a03cfdbb8852', 'QUANTITY_CHANGED', '{"old": "28.000", "new": "24.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '2026-11-02 21:38:17.676546+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('8230c3ce-04f9-42d8-9582-849fb63c0412', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7fc36a64-c1cb-46b4-a394-dec062ea8c9b', '7fb93cd8-d0f5-4a14-b739-f72404792db5', 'QUANTITY_CHANGED', '{"old": "60.000", "new": "50.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '2026-11-02 21:38:17.7957+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('0119d766-29c9-4918-8f05-f14898823135', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3a571895-6a7e-4037-9590-f5a136ac4f55', '7fb93cd8-d0f5-4a14-b739-f72404792db5', 'QUANTITY_CHANGED', '{"old": "20.000", "new": "15.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '2026-11-02 21:38:17.795703+00');


--
-- Data for Name: item_import_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('cdd737cb-6026-4382-8319-b6d773f2b183', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 'd76b10ff-781b-466f-be04-2714ae417710', NULL, 'Vanilla Sugar', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 2.000, NULL, NULL, '2026-10-26', NULL, NULL, NULL, NULL, 5.30, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146168+00', '2026-11-02 21:38:15.146171+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d403c5d5-4291-4150-a533-8e2d42421b66', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'bbd5db28-2750-499b-add6-68d4138dbfbc', NULL, 'Butter Biscuits', 'Orchard & Oak', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', 1.000, NULL, NULL, '2026-10-15', NULL, NULL, NULL, NULL, 4.67, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146172+00', '2026-11-02 21:38:15.146173+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8f550850-d5ef-4f72-8e15-de1ff9b34c41', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0de06468-a565-463c-bf8f-4fe2abf476c8', '75051917-0617-4e5d-9871-c8445b191699', NULL, 'Canned White Beans', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '6ff4b2d0-15af-49fc-a4c3-a1c764cab204', 9.000, NULL, NULL, '2026-10-04', '2027-07-24', NULL, NULL, NULL, 4.72, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146174+00', '2026-11-02 21:38:15.146174+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a86b2e7e-1eb9-4c13-babf-a6260d3e4118', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Dried Oregano', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'fd58696b-450b-42d5-9a06-8f088f7af9ab', 3.000, NULL, NULL, '2026-09-23', '2026-11-09', NULL, NULL, NULL, 5.15, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146175+00', '2026-11-02 21:38:15.146175+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('50ccecf1-6858-432c-b6d7-3150e0f73a42', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 'fb222af9-20d1-40f9-9c71-031d7e3c40c2', NULL, 'Penne Pasta', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', 2.000, NULL, NULL, '2026-09-12', '2027-06-07', NULL, NULL, NULL, 5.49, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146176+00', '2026-11-02 21:38:15.146177+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7ff50584-14e7-4ff1-be1f-ddffe7d57671', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '75051917-0617-4e5d-9871-c8445b191699', NULL, 'Canned Chickpeas', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '4850e73d-f3e0-437b-978a-6286e64163b8', 9.000, NULL, NULL, '2026-09-01', '2027-06-23', NULL, NULL, NULL, 4.76, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146177+00', '2026-11-02 21:38:15.146178+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d84ca6ca-09bf-43e5-9b21-c50ffe869123', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'abd1db4d-3be0-43c0-a02f-34102db94664', NULL, 'Earl Grey Tea', 'Orchard & Oak', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '2624d047-5f42-4ec9-8865-e51c8feb672b', 1.000, NULL, NULL, '2026-10-24', '2027-09-10', NULL, NULL, NULL, 5.73, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146178+00', '2026-11-02 21:38:15.146179+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('91a89320-724b-48a2-b110-8fd4b9c32464', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 'bbd5db28-2750-499b-add6-68d4138dbfbc', NULL, 'Butter Biscuits', 'Orchard & Oak', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', 6.000, NULL, NULL, '2026-10-13', NULL, NULL, NULL, NULL, 4.46, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146179+00', '2026-11-02 21:38:15.146179+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a06f7097-e2d8-42a0-940d-d9889d275091', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'fb222af9-20d1-40f9-9c71-031d7e3c40c2', NULL, 'Penne Pasta', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', 4.000, NULL, NULL, '2026-10-02', NULL, NULL, NULL, NULL, 4.47, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.14618+00', '2026-11-02 21:38:15.14618+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dcf1dc07-091a-4d71-af58-ddf7bfbcf735', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 'cd18809f-9eae-485d-b310-4c4335a6186f', NULL, 'Tomato Paste', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', 2.000, NULL, NULL, '2026-09-21', '2027-09-03', NULL, NULL, NULL, 5.18, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146181+00', '2026-11-02 21:38:15.146181+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('25238103-9ba7-4a2d-ba45-85aa28b2a317', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0e17549e-2b77-4415-8a50-af6d60912ba9', 'fdf5770f-0648-42b0-8a68-a7b029ef3045', NULL, 'Soy Sauce', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '978975e2-b9a9-47ca-accc-272993e683a9', 6.000, NULL, NULL, '2026-09-10', '2027-05-01', NULL, NULL, NULL, 4.99, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146182+00', '2026-11-02 21:38:15.146182+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5ba05648-4e80-4f35-aaa2-c33817fd6d8e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '04dea600-42e9-4ab1-a38d-c0f272e1ed52', NULL, 'Butter Extra 82%', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 9.000, NULL, NULL, '2026-10-27', '2026-11-05', NULL, NULL, NULL, 5.26, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146183+00', '2026-11-02 21:38:15.146183+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8dbe8bdf-9478-41a1-99c5-389c11a888ea', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '7f257885-0225-488c-b07b-4998394931af', NULL, 'Wildflower Honey', 'Orchard & Oak', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', 8.000, NULL, NULL, '2026-10-22', NULL, NULL, NULL, NULL, 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146184+00', '2026-11-02 21:38:15.146184+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7b7f4260-6baf-4a43-9e59-a51df4ef1c9c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '7f257885-0225-488c-b07b-4998394931af', NULL, 'Strawberry Jam', 'Orchard & Oak', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '5d059874-8aa6-440f-ac9f-f87497631322', 3.000, NULL, NULL, '2026-10-11', '2026-12-19', NULL, NULL, NULL, 4.49, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146185+00', '2026-11-02 21:38:15.146185+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d02ba6f8-bfbd-4bcf-8cb1-226f773cca9e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '75051917-0617-4e5d-9871-c8445b191699', NULL, 'Tuna in Oil', 'Bluewater', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'ac6440cf-13bd-4a34-8da6-ad89c6d29e49', 4.000, NULL, NULL, '2026-09-30', '2027-06-03', NULL, NULL, NULL, 5.23, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146185+00', '2026-11-02 21:38:15.146186+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('003d4d05-cd11-46e8-8a28-330f10b8977d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '566658f7-28ce-4ee5-8eb9-8fedcaea4d6d', NULL, 'Gouda Cheese', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', 4.000, NULL, NULL, '2026-10-29', '2026-11-06', NULL, NULL, NULL, 4.45, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146186+00', '2026-11-02 21:38:15.146187+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('875b1a35-7f5d-4311-9a4b-b2926bb52012', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'a3124554-8a96-49d5-8af4-c327bc6a249b', NULL, 'Instant Tomato Soup', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '811175a1-fe78-435e-ae2b-65c46cdc638f', 8.000, NULL, NULL, '2026-09-08', '2026-11-08', NULL, NULL, NULL, 5.08, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146187+00', '2026-11-02 21:38:15.146188+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7e93df26-8f5a-4b66-994c-95dcd86c68fd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Ground Ginger', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '421dfd61-718d-4571-b801-4992bbcc7aa8', 6.000, NULL, NULL, '2026-08-28', '2027-06-10', NULL, NULL, NULL, 5.46, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146188+00', '2026-11-02 21:38:15.146189+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('327c9ce5-3a16-43e9-a25e-07341d720878', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Ground Black Pepper', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f74058cf-9946-472e-8d0d-34656a7e323d', 9.000, NULL, NULL, '2026-10-20', '2027-01-04', NULL, NULL, NULL, 4.73, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146189+00', '2026-11-02 21:38:15.14619+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('81b9a033-5eba-4094-9c44-baf2d45c77cd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0e17549e-2b77-4415-8a50-af6d60912ba9', 'bbd5db28-2750-499b-add6-68d4138dbfbc', NULL, 'Rice Cakes', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '72bdce9f-7935-43fd-927c-2d567cf5d756', 6.000, NULL, NULL, '2026-10-09', '2026-11-02', NULL, NULL, NULL, 5.04, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.14619+00', '2026-11-02 21:38:15.146191+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f9d0e5b3-3325-4893-be09-3143398ed74d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 'd76b10ff-781b-466f-be04-2714ae417710', NULL, 'Vanilla Sugar', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 8.000, NULL, NULL, '2026-09-28', '2027-06-10', NULL, NULL, NULL, 4.48, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146192+00', '2026-11-02 21:38:15.146192+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('78d5b9ea-9b6d-46c2-b0e8-7215eb8fd825', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '11547469-399b-4f43-bb95-707e11abccb6', 'c93b24f5-af18-4089-a62b-3ca2ea709c45', NULL, 'Broccoli', 'Green Acre', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '51321655-7803-4068-a127-4e7109105029', 6.000, NULL, NULL, '2026-10-29', '2026-11-07', NULL, NULL, NULL, 4.70, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146192+00', '2026-11-02 21:38:15.146193+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('733336ba-477c-46bc-b5f0-bd6e921931ed', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'a3124554-8a96-49d5-8af4-c327bc6a249b', NULL, 'Fruit Muesli', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cc9838d2-823c-4bc2-a531-f18a59b258f5', 1.000, NULL, NULL, '2026-09-06', NULL, NULL, NULL, NULL, 5.03, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146194+00', '2026-11-02 21:38:15.146194+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4972bc60-1cdf-433c-b114-8fdb5cc8f1e0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Sweet Paprika', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '13b63530-f895-4416-beb3-c2dca6919854', 5.000, NULL, NULL, '2026-08-26', '2027-05-18', NULL, NULL, NULL, 5.72, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146195+00', '2026-11-02 21:38:15.146195+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3d847c7d-87f3-4555-a5e9-61d4d340fcf9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'd76b10ff-781b-466f-be04-2714ae417710', NULL, 'Vanilla Sugar', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 1.000, NULL, NULL, '2026-10-18', '2027-10-01', NULL, NULL, NULL, 4.53, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146196+00', '2026-11-02 21:38:15.146196+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('76f4d898-19dd-4ee1-9131-320ea772ba09', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0e6131a5-bab6-4d95-ae7f-1639ac331989', 'b862c034-92c9-4b4f-a48e-bc26e5f06feb', NULL, 'Frozen Blueberries', 'Northwind Frozen', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 'fae8537d-d380-4433-973f-75d6083b9007', 4.000, NULL, NULL, '2026-10-07', '2027-11-26', NULL, NULL, NULL, 5.08, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146197+00', '2026-11-02 21:38:15.146197+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('261f884b-1a7a-4a86-a1ba-e7596b095755', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'd76b10ff-781b-466f-be04-2714ae417710', NULL, 'Vanilla Sugar', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 4.000, NULL, NULL, '2026-09-26', '2027-10-13', NULL, NULL, NULL, 4.85, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146198+00', '2026-11-02 21:38:15.146198+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f9b8010b-f35d-4533-8b13-58687cb86fa5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '11547469-399b-4f43-bb95-707e11abccb6', 'c93b24f5-af18-4089-a62b-3ca2ea709c45', NULL, 'Cherry Tomatoes', 'Green Acre', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', '7190ea91-16e3-47b8-81db-a8cfd3310441', 6.800, NULL, NULL, '2026-10-29', '2026-11-03', NULL, NULL, NULL, 4.36, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146199+00', '2026-11-02 21:38:15.146199+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3032cdb9-2085-46d7-a034-e7e36b2be809', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 'ac71d475-2bd8-476e-9264-e53abc0e0df9', NULL, 'Green Grapes', 'Green Acre', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', '550d3d31-b672-4970-9b5e-c340b8762506', 9.900, NULL, NULL, '2026-10-28', '2026-10-31', NULL, NULL, NULL, 5.71, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146199+00', '2026-11-02 21:38:15.1462+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('05e0bce9-c2cc-4a05-b68d-0ac607691dd3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0d5b4d7c-869e-4267-a51b-13a7da79194a', '09752f2b-e0c6-441d-ab5f-6a9e6eddd1ec', NULL, 'Orange Juice NFC', 'Orchard & Oak', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'ae63f584-19ed-4d90-bccb-b87a10a778b0', 7.000, NULL, NULL, '2026-08-24', NULL, NULL, NULL, NULL, 5.06, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.1462+00', '2026-11-02 21:38:15.1462+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6cd7ab67-0285-4f8a-ac89-5e0d0f0e736c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eec06978-11eb-4b74-a829-6106e5193a1a', '8c371fe3-ea8a-4330-b967-b52a856de96a', NULL, 'Tomato Ketchup', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '5d74ee73-5c5c-4b0c-bd20-6b5eba9dda07', 5.000, NULL, NULL, '2026-10-28', '2026-10-31', NULL, NULL, NULL, 5.65, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146201+00', '2026-11-02 21:38:15.146201+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d3466ed7-aa76-47ce-8c04-a444b6f9870e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Ground Ginger', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '421dfd61-718d-4571-b801-4992bbcc7aa8', 3.000, NULL, NULL, '2026-10-05', '2027-10-08', NULL, NULL, NULL, 5.35, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146201+00', '2026-11-02 21:38:15.146201+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('44f5d272-fafe-477c-8fbc-b230fd584acf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 'cd18809f-9eae-485d-b310-4c4335a6186f', NULL, 'Peeled Tomatoes 400g', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '240939e0-2b81-4a30-b303-e9798d591c02', 7.000, NULL, NULL, '2026-09-24', '2027-01-06', NULL, NULL, NULL, 4.84, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146202+00', '2026-11-02 21:38:15.146202+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b5e602d8-19af-4e36-a337-8632bbc91872', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0e17549e-2b77-4415-8a50-af6d60912ba9', 'd76b10ff-781b-466f-be04-2714ae417710', NULL, 'Vanilla Sugar', 'Harvest Row', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 8.000, NULL, NULL, '2026-09-13', '2027-04-20', NULL, NULL, NULL, 4.88, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146202+00', '2026-11-02 21:38:15.146203+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('610d165c-e861-4aed-b29a-b3e0627829a3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Sweet Paprika', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '13b63530-f895-4416-beb3-c2dca6919854', 7.000, NULL, NULL, '2026-09-02', NULL, NULL, NULL, NULL, 5.55, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146203+00', '2026-11-02 21:38:15.146203+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('db52f250-7499-4813-b45b-3d7f8b0e8fdf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 'cd18809f-9eae-485d-b310-4c4335a6186f', NULL, 'Tomato Paste', 'Harvest Row', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', 9.000, NULL, NULL, '2026-10-25', '2027-05-24', NULL, NULL, NULL, 4.43, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146204+00', '2026-11-02 21:38:15.146204+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('537a041b-24bb-4033-be75-662dafd9340c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Granulated Garlic', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '72f02ab4-94c5-476a-8e82-53b361859d75', 8.000, NULL, NULL, '2026-10-14', '2027-09-28', NULL, NULL, NULL, 4.64, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146204+00', '2026-11-02 21:38:15.146204+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('00a1c1fd-f00b-40c7-991c-d8c277494eb8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eec06978-11eb-4b74-a829-6106e5193a1a', '4fb2550f-5fe6-41a8-b662-98571cd14bf6', NULL, 'Pork Frankfurters', 'Fellbrook Farms', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', '7b3b5462-0278-4759-8945-f9ae3ae536b6', 3.000, NULL, NULL, '2026-10-31', '2026-11-04', NULL, NULL, NULL, 5.14, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146205+00', '2026-11-02 21:38:15.146205+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('28234322-fd99-4274-ad41-879d12e6f44c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', '04dea600-42e9-4ab1-a38d-c0f272e1ed52', NULL, 'Cottage Cheese', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '8f0c1f16-0931-4424-b79a-aa1dc5519c11', 6.000, NULL, NULL, '2026-10-30', '2026-11-02', NULL, NULL, NULL, 5.59, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146205+00', '2026-11-02 21:38:15.146206+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('646dfcc4-3297-4534-83be-3b20867c6926', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0de06468-a565-463c-bf8f-4fe2abf476c8', 'f9fd75dd-a44c-4b03-a672-ecc1c1f21fea', NULL, 'Ground Black Pepper', 'Saltmill', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f74058cf-9946-472e-8d0d-34656a7e323d', 2.000, NULL, NULL, '2026-09-11', NULL, NULL, NULL, NULL, 5.66, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.146206+00', '2026-11-02 21:38:15.146207+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fab3d27a-a6f0-456c-a67b-8a931354a3bb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd093050d-72ad-4663-840d-0b563efd6d55', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '116b428f-f07b-4bd5-b9e0-5fa352157681', 1.000, NULL, 'SN-100004', '2025-08-26', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-26", "warranty_until": "2028-08-25", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-26 09:00:00+00', '2026-11-02 21:38:15.226647+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('924a4ca6-715c-45d6-aab0-09f34f2f91b8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f7f1c414-5e10-4093-bd27-f232bb078e47', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '116b428f-f07b-4bd5-b9e0-5fa352157681', 1.000, NULL, 'SN-100005', '2025-05-21', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-21", "warranty_until": "2028-05-20", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-21 09:00:00+00', '2026-11-02 21:38:15.226648+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0bb9ec16-a15b-4fec-9347-da84d4d3bb63', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '116b428f-f07b-4bd5-b9e0-5fa352157681', 1.000, NULL, 'SN-100006', '2025-02-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-13", "warranty_until": "2028-02-13", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-13 09:00:00+00', '2026-11-02 21:38:15.226648+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e4a59d93-6182-4220-918c-7fdb6f98ce0a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '116b428f-f07b-4bd5-b9e0-5fa352157681', 1.000, NULL, 'SN-100007', '2024-11-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-08", "warranty_until": "2027-11-08", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-08 09:00:00+00', '2026-11-02 21:38:15.226648+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2b78ab9a-854f-4613-9596-796d9b21667a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', 1.000, NULL, 'SN-100008', '2024-08-03', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-03", "warranty_until": "2027-08-03", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-03 09:00:00+00', '2026-11-02 21:38:15.226649+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('22cf5f5c-4203-4ed0-8fa1-632a910661f8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', 1.000, NULL, 'SN-100009', '2024-04-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-28", "warranty_until": "2027-04-28", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-28 09:00:00+00', '2026-11-02 21:38:15.226649+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c1deaa2c-495b-4e58-bab4-4c04c447fabf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eccbc778-64cd-44fb-a806-9889659852cb', 1.000, NULL, 'SN-100010', '2024-01-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-22", "warranty_until": "2027-01-21", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-22 09:00:00+00', '2026-11-02 21:38:15.226649+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1a1d200d-1872-4672-9387-3da852b2deaf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eccbc778-64cd-44fb-a806-9889659852cb', 1.000, NULL, 'SN-100011', '2023-10-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-17", "warranty_until": "2026-10-16", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-17 09:00:00+00', '2026-11-02 21:38:15.22665+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4aba876e-e8d6-4388-bf0f-1551c82b61aa', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eccbc778-64cd-44fb-a806-9889659852cb', 1.000, NULL, 'SN-100012', '2026-07-16', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-16", "warranty_until": "2029-07-15", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-16 09:00:00+00', '2026-11-02 21:38:15.22665+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('68184d4e-b725-4720-ba79-8eb744fb3ab8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eccbc778-64cd-44fb-a806-9889659852cb', 1.000, NULL, 'SN-100013', '2026-04-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-10", "warranty_until": "2029-04-09", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-10 09:00:00+00', '2026-11-02 21:38:15.226651+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('84d6ddf5-9827-4721-af51-09e25737d35f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'db2ce2d0-bd7d-4ffd-9e6b-4e1932aa6d01', 1.000, NULL, 'SN-100015', '2025-09-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-28", "warranty_until": "2028-09-27", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-28 09:00:00+00', '2026-11-02 21:38:15.226652+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0fd8aae9-7a10-41d4-89ac-837d8808149c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8fd38393-964a-4094-add7-0baa69d27380', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'd3780b77-589a-4b0c-9fc0-cd81c5548b8f', 1.000, NULL, 'SN-100016', '2025-06-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-23", "warranty_until": "2028-06-22", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-23 09:00:00+00', '2026-11-02 21:38:15.226652+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1c2dd79c-8ac5-4dbc-875a-177ee1a94d8e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', 'd5609977-a4b1-403b-abb9-b8e889d0b754', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'c9032a28-5d75-4c27-b76b-432a1580c400', 1.000, NULL, 'SN-100017', '2025-03-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-18", "warranty_until": "2028-03-17", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-18 09:00:00+00', '2026-11-02 21:38:15.226652+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('05804795-7a6f-43dc-9f54-c36d12062589', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f7f1c414-5e10-4093-bd27-f232bb078e47', 'd5609977-a4b1-403b-abb9-b8e889d0b754', 'equipment', 'LG 27UK850-W', 'LG', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9b9ff3b1-258d-4abf-8728-294f35c724ae', 1.000, NULL, 'SN-100018', '2024-12-11', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-11", "warranty_until": "2027-12-11", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-11 09:00:00+00', '2026-11-02 21:38:15.226653+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b1ec6155-6be0-4e75-b8f7-01ceeff9499e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 'd5609977-a4b1-403b-abb9-b8e889d0b754', 'equipment', 'LG 27UK850-W', 'LG', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9b9ff3b1-258d-4abf-8728-294f35c724ae', 1.000, NULL, 'SN-100019', '2024-09-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-05", "warranty_until": "2027-09-05", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-05 09:00:00+00', '2026-11-02 21:38:15.226653+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('69a09b60-737c-4996-82c2-cc94b1498cfb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd093050d-72ad-4663-840d-0b563efd6d55', 'd5609977-a4b1-403b-abb9-b8e889d0b754', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 1.000, NULL, 'SN-100020', '2024-05-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-31", "warranty_until": "2027-05-31", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-31 09:00:00+00', '2026-11-02 21:38:15.226653+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a70733bb-7dbf-4c12-90fb-0a9a7b7cbec2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 'd5609977-a4b1-403b-abb9-b8e889d0b754', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 1.000, NULL, 'SN-100021', '2024-02-24', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-24", "warranty_until": "2027-02-23", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-24 09:00:00+00', '2026-11-02 21:38:15.226654+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('557c5fbd-24cc-47c1-a0fe-02c99f8e229e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', 'd5609977-a4b1-403b-abb9-b8e889d0b754', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 1.000, NULL, 'SN-100022', '2023-11-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-19", "warranty_until": "2026-11-18", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-19 09:00:00+00', '2026-11-02 21:38:15.226654+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1447ad8c-b49f-4391-8b6a-66f27388e5ce', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '12edfd54-4f28-4eed-8adb-447f3c453baf', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'eccbc778-64cd-44fb-a806-9889659852cb', 1.000, NULL, 'SN-100014', '2026-01-03', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-03", "warranty_until": "2029-01-02", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-03 09:00:00+00', '2026-11-02 21:38:18.940476+00', 'STM-0FLY', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1ef51736-b7f9-477c-8e58-b2d637afddd9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 1.000, NULL, 'SN-100000', '2026-09-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-18", "warranty_until": "2029-09-17", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-18 09:00:00+00', '2026-11-02 21:38:18.940477+00', 'STM-6SES', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('add83e2a-2b9b-4376-8542-ee44d4d83fa2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 1.000, NULL, 'SN-100023', '2026-08-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-18", "warranty_until": "2029-08-17", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-18 09:00:00+00', '2026-11-02 21:38:15.226654+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9235a76b-7e41-45e3-a6d6-bc7c91a41840', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f7f1c414-5e10-4093-bd27-f232bb078e47', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 1.000, NULL, 'SN-100024', '2026-05-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-13", "warranty_until": "2029-05-12", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-13 09:00:00+00', '2026-11-02 21:38:15.226655+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0dc3b89d-b103-4d2d-933c-feecf85c064d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 1.000, NULL, 'SN-100026', '2025-10-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-31", "warranty_until": "2028-10-30", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-31 09:00:00+00', '2026-11-02 21:38:15.226656+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e59d159a-d7d6-462d-a395-9b3fd905dc9f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 1.000, NULL, 'SN-100027', '2025-07-26', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-26", "warranty_until": "2028-07-25", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-26 09:00:00+00', '2026-11-02 21:38:15.226656+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('beab2939-2add-491e-99bb-8d30a7d8e929', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 1.000, NULL, 'SN-100028', '2025-04-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-20", "warranty_until": "2028-04-19", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-20 09:00:00+00', '2026-11-02 21:38:15.226656+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d0832f10-c70b-406a-bb90-779e5386996d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 1.000, NULL, 'SN-100029', '2025-01-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-13", "warranty_until": "2028-01-13", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-13 09:00:00+00', '2026-11-02 21:38:15.226657+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5d5b0d6a-66e6-41ac-b226-85e7abff3814', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'iPad Air M2', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'b5aa9619-72e3-4706-87cb-29c56478ab7c', 1.000, NULL, 'SN-100030', '2024-10-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-08", "warranty_until": "2027-10-08", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-08 09:00:00+00', '2026-11-02 21:38:15.226657+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a0800287-82ef-4d5b-a1ae-97228f3d470d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 1.000, NULL, 'SN-100032', '2024-03-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-28", "warranty_until": "2027-03-28", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-28 09:00:00+00', '2026-11-02 21:38:15.226658+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7a0cc931-72cd-4eaf-970d-3564938ce1d2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 1.000, NULL, 'SN-100033', '2023-12-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-22", "warranty_until": "2026-12-21", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-22 09:00:00+00', '2026-11-02 21:38:15.226658+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6f3c5029-24db-42b7-9a43-5872b29ab342', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d34f095-249a-4027-afa8-33fdd61f1383', 1.000, NULL, 'SN-100034', '2023-09-16', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-09-16", "warranty_until": "2026-09-15", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2023-09-16 09:00:00+00', '2026-11-02 21:38:15.226658+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('804acbd4-3267-4033-a2c5-0bdeec36b9c9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d34f095-249a-4027-afa8-33fdd61f1383', 1.000, NULL, 'SN-100035', '2026-06-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-15", "warranty_until": "2029-06-14", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-15 09:00:00+00', '2026-11-02 21:38:15.226659+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a23566f4-f835-49f9-a21d-f0a6b160f344', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d34f095-249a-4027-afa8-33fdd61f1383', 1.000, NULL, 'SN-100036', '2026-03-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-10", "warranty_until": "2029-03-09", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-10 09:00:00+00', '2026-11-02 21:38:15.226659+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d2f8b788-3927-4ea1-b686-d01f15ef4f12', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f2932f69-4af6-4d25-8800-0727bd3eee66', 1.000, NULL, 'SN-100037', '2025-12-03', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-03", "warranty_until": "2028-12-02", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-03 09:00:00+00', '2026-11-02 21:38:15.226659+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4ae1ab3e-a35b-4c01-8b09-6790f23abbaf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'f2932f69-4af6-4d25-8800-0727bd3eee66', 1.000, NULL, 'SN-100038', '2025-08-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-28", "warranty_until": "2028-08-27", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-28 09:00:00+00', '2026-11-02 21:38:15.22666+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b7604578-514b-400b-ace3-ccd9dc5f7f8e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 1.000, NULL, 'SN-100039', '2025-05-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-23", "warranty_until": "2028-05-22", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-23 09:00:00+00', '2026-11-02 21:38:15.22666+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f6788973-a56c-4982-b79f-6bb34f36ada3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9f59b212-5228-48cf-a250-dd7e6c2c2a71', 1.000, NULL, 'SN-100041', '2024-11-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-10", "warranty_until": "2027-11-10", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-10 09:00:00+00', '2026-11-02 21:38:15.226661+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b47d3313-fe4c-4775-bdff-3639e6fadb02', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '63c93362-2c11-442c-a0a0-330241624822', 1.000, NULL, 'SN-100042', '2024-08-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-05", "warranty_until": "2027-08-05", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-05 09:00:00+00', '2026-11-02 21:38:15.226661+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bb6334b6-d852-4728-87cb-e9d8d40eba07', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '63c93362-2c11-442c-a0a0-330241624822', 1.000, NULL, 'SN-100043', '2024-04-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-30", "warranty_until": "2027-04-30", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-30 09:00:00+00', '2026-11-02 21:38:15.226662+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('71c0894f-f530-450a-b047-59f085c7c636', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3d9a68be-2319-450a-91dd-07216b4b58b9', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 1.000, NULL, 'SN-100044', '2024-01-24', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-24", "warranty_until": "2027-01-23", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-24 09:00:00+00', '2026-11-02 21:38:15.226662+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('39868387-27dc-4418-8a5c-9af20c3b4302', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd093050d-72ad-4663-840d-0b563efd6d55', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 1.000, NULL, 'SN-100045', '2023-10-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-19", "warranty_until": "2026-10-18", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-19 09:00:00+00', '2026-11-02 21:38:15.226662+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('59185ada-a555-4355-ab11-980bbdc12c4b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 1.000, NULL, 'SN-100046', '2026-07-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-18", "warranty_until": "2029-07-17", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-18 09:00:00+00', '2026-11-02 21:38:15.226662+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('95da205b-b886-4c42-8dd1-386be796cb5c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 1.000, NULL, 'SN-100047', '2026-04-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-12", "warranty_until": "2029-04-11", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-12 09:00:00+00', '2026-11-02 21:38:15.226663+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7797842f-3baa-44bc-a164-d0dd3a504769', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd093050d-72ad-4663-840d-0b563efd6d55', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', 1.000, NULL, 'SN-100048', '2026-01-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-05", "warranty_until": "2029-01-04", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-05 09:00:00+00', '2026-11-02 21:38:15.226663+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0939c0d3-bd22-4e80-a659-31bf9d38b8db', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8fd38393-964a-4094-add7-0baa69d27380', 'adb35b3c-24e9-49dc-b841-776202287861', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', 1.000, NULL, 'SN-100049', '2025-09-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-30", "warranty_until": "2028-09-29", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-30 09:00:00+00', '2026-11-02 21:38:15.226663+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('adffa7da-107d-4a21-9ef7-d7c2399b7d34', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 1.000, NULL, 'SN-100051', '2025-03-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-20", "warranty_until": "2028-03-19", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-20 09:00:00+00', '2026-11-02 21:38:15.226664+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0cad6224-18cd-4fb1-9558-bacbb30fe163', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd093050d-72ad-4663-840d-0b563efd6d55', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 1.000, NULL, 'SN-100052', '2024-12-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-13", "warranty_until": "2027-12-13", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-13 09:00:00+00', '2026-11-02 21:38:15.226665+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5106f32b-9108-4b77-a439-aff49286b1d9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd093050d-72ad-4663-840d-0b563efd6d55', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 1.000, NULL, 'SN-100053', '2024-09-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-07", "warranty_until": "2027-09-07", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-07 09:00:00+00', '2026-11-02 21:38:15.226665+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6d22aa1b-d598-495d-b607-5c4b897a339c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 1.000, NULL, 'SN-100054', '2024-06-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-02", "warranty_until": "2027-06-02", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-02 09:00:00+00', '2026-11-02 21:38:15.226666+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a275d173-0f04-4f06-9a4a-73f70ebd6c77', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 1.000, NULL, 'SN-100055', '2024-02-26', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-26", "warranty_until": "2027-02-25", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-26 09:00:00+00', '2026-11-02 21:38:15.226666+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e157bcce-b0e3-42e8-a2a7-6f53de1a917f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '19751a32-491b-4a06-8dac-86943c9b3b66', 1.000, NULL, 'SN-100056', '2023-11-21', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-21", "warranty_until": "2026-11-20", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-21 09:00:00+00', '2026-11-02 21:38:15.226666+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('06a8d70d-6616-450e-affc-20a51018ac33', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '19751a32-491b-4a06-8dac-86943c9b3b66', 1.000, NULL, 'SN-100057', '2026-08-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-20", "warranty_until": "2029-08-19", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-20 09:00:00+00', '2026-11-02 21:38:15.226667+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0405996d-101a-458c-b352-c146ceecd3c1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '19751a32-491b-4a06-8dac-86943c9b3b66', 1.000, NULL, 'SN-100058', '2026-05-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-15", "warranty_until": "2029-05-14", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-15 09:00:00+00', '2026-11-02 21:38:15.226667+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c7baa9ca-b800-4d6e-a16c-a096da699e6e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '19751a32-491b-4a06-8dac-86943c9b3b66', 1.000, NULL, 'SN-100059', '2026-02-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-07", "warranty_until": "2029-02-06", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-07 09:00:00+00', '2026-11-02 21:38:15.226667+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ea49a3b3-26b9-4f16-af0b-39ed1cf1e7db', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '69437a1f-208d-4eb0-aee9-baf140d2d200', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 1.000, NULL, 'SN-100061', '2025-07-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-28", "warranty_until": "2028-07-27", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-28 09:00:00+00', '2026-11-02 21:38:15.226668+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('323d45d7-73a0-4fdf-91ab-7b816621d4d3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '69437a1f-208d-4eb0-aee9-baf140d2d200', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 1.000, NULL, 'SN-100062', '2025-04-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-22", "warranty_until": "2028-04-21", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-22 09:00:00+00', '2026-11-02 21:38:15.226668+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('51ce3a22-e8bb-4915-a707-26ab4d4776da', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '69437a1f-208d-4eb0-aee9-baf140d2d200', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 1.000, NULL, 'SN-100063', '2025-01-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-15", "warranty_until": "2028-01-15", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-15 09:00:00+00', '2026-11-02 21:38:15.226669+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7d71576b-33af-4f5e-817b-a5f1cdc7c3b9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '69437a1f-208d-4eb0-aee9-baf140d2d200', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 1.000, NULL, 'SN-100064', '2024-10-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-10", "warranty_until": "2027-10-10", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-10 09:00:00+00', '2026-11-02 21:38:15.226669+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('76f512bb-17fb-4844-9e73-44f30278d719', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f7f1c414-5e10-4093-bd27-f232bb078e47', '69437a1f-208d-4eb0-aee9-baf140d2d200', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 1.000, NULL, 'SN-100065', '2024-07-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-05", "warranty_until": "2027-07-05", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-05 09:00:00+00', '2026-11-02 21:38:15.226669+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('70065571-f474-4978-8e86-793819fab86a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3d9a68be-2319-450a-91dd-07216b4b58b9', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 1.000, NULL, 'SN-100003', '2025-12-01', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-01", "warranty_until": "2028-11-30", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-01 09:00:00+00', '2026-11-02 21:38:18.425238+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('cf716a8c-de7d-411a-ae2d-b9b862906724', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 'Damson Plums', 'Green Acre', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', '5d36a701-5479-482d-b364-a0dc01ecccb5', 13.600, NULL, NULL, '2026-10-30', NULL, NULL, NULL, NULL, 3.40, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.268649+00', '2026-11-02 21:38:18.58535+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('97b83666-9272-4d1b-8f6d-34ebb883509c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 3.000, NULL, NULL, '2026-10-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-10-31", "warranty_until": "2029-10-30", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-31 13:30:00+00', '2026-11-02 21:38:16.674854+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bdd7d89a-3b1b-418a-834c-7b657ac843f0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 5.000, NULL, NULL, '2026-10-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-10-31", "warranty_until": "2029-10-30", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-31 13:30:00+00', '2026-11-02 21:38:16.674859+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d86f027b-8271-4c62-9e1b-9f8311d08ea3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 'UHT Milk 3.2%', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '0f235c0d-8907-42ed-a359-c437e63adb06', 36.000, NULL, NULL, '2026-10-24', NULL, NULL, NULL, '{}', 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-10-24 13:30:00+00', '2026-11-02 21:38:16.722353+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('17fea889-eefe-486a-8c87-a06a1e6f2cfa', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, NULL, 'Natural Yoghurt 400g', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', 18.000, NULL, NULL, '2026-10-24', NULL, NULL, NULL, '{}', 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-10-24 13:30:00+00', '2026-11-02 21:38:17.615816+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5b4fb054-971f-48e5-93ca-ad5ee6513b85', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '04dea600-42e9-4ab1-a38d-c0f272e1ed52', NULL, 'Butter Extra 82%', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 24.000, NULL, NULL, '2026-10-24', NULL, NULL, NULL, '{}', 8.90, 'USD', false, false, NULL, NULL, NULL, '2026-10-24 13:30:00+00', '2026-11-02 21:38:17.646918+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('7fc36a64-c1cb-46b4-a394-dec062ea8c9b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '11547469-399b-4f43-bb95-707e11abccb6', '566658f7-28ce-4ee5-8eb9-8fedcaea4d6d', NULL, 'Gouda Cheese', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', 50.000, NULL, NULL, '2026-10-26', NULL, NULL, NULL, '{}', 12.50, 'USD', false, false, NULL, NULL, NULL, '2026-10-26 13:30:00+00', '2026-11-02 21:38:17.768415+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3a571895-6a7e-4037-9590-f5a136ac4f55', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '11547469-399b-4f43-bb95-707e11abccb6', NULL, NULL, 'Sour Cream 18%', 'Meadowlane', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '5b058779-639f-4d34-9201-7dc78d9700fd', 15.000, NULL, NULL, '2026-10-26', NULL, NULL, NULL, '{}', 4.10, 'USD', false, false, NULL, NULL, NULL, '2026-10-26 13:30:00+00', '2026-11-02 21:38:17.786918+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0a4f19f1-493a-4417-aef1-d679e229b424', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 3.000, NULL, NULL, '2026-10-16', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-10-16", "warranty_until": "2029-10-15", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-16 10:50:00+00', '2026-11-02 21:38:18.343893+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b90f9f0c-3a4b-4e25-8f89-29c37d2d21f0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 1.000, NULL, 'SN-100001', '2026-06-13', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-13", "warranty_until": "2029-06-12", "equipment_status": "DEPLOYED"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-13 09:00:00+00', '2026-11-02 21:38:18.425239+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f6ac1916-f2bc-4e50-b5cf-ba2dd5f9c91f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '73e43295-eeac-447d-b632-f3588ccd7741', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 1.000, NULL, 'SN-100002', '2026-03-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-08", "warranty_until": "2029-03-07", "equipment_status": "DEPLOYED"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-08 09:00:00+00', '2026-11-02 21:38:18.425239+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0ff3df72-b4e4-4188-b8ab-cea8be877f14', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', NULL, NULL, 'White Sugar', 'Harvest Row', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 21.220, NULL, NULL, '2026-10-13', NULL, NULL, NULL, NULL, 1.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.268653+00', '2026-11-02 21:38:18.617684+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c102148e-b102-4e49-8ef1-ed8e2a214374', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', NULL, NULL, 'Cassia Cinnamon', 'Saltmill', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 0.440, NULL, NULL, '2026-09-29', NULL, NULL, NULL, NULL, 24.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:15.268653+00', '2026-11-02 21:38:18.637361+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('75ffde96-7a2f-48d8-bead-36eefe97df13', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', NULL, NULL, 'Plum Butter', NULL, NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', '2f1b6282-567c-422c-bb1d-704f79f71d08', 11.400, NULL, NULL, '2026-11-02', NULL, NULL, NULL, '{}', 8.36, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 21:38:18.657134+00', '2026-11-02 21:38:18.657136+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c3b0367c-813a-476c-b764-9a59f2e9fe09', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 'fde4286d-25aa-4724-bb49-907a5cbf468b', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 1.000, NULL, 'SN-100025', '2026-02-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-05", "warranty_until": "2029-02-04", "equipment_status": "DEPLOYED"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-05 09:00:00+00', '2026-11-02 21:38:18.904949+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('30475588-c340-4613-b56a-7e71aa945477', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 1.000, NULL, 'SN-100040', '2025-02-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-15", "warranty_until": "2028-02-15", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-15 09:00:00+00', '2026-11-02 21:38:18.940478+00', 'STM-CP1E', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3766caf2-10a3-4ea5-83a4-4c62b81127cd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '5bed3eee-374b-4d13-beaa-df2e0b17877d', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 1.000, NULL, 'SN-100031', '2024-07-03', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-03", "warranty_until": "2027-07-03", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-03 09:00:00+00', '2026-11-02 21:38:18.940478+00', 'STM-MO2B', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d70ca8a9-998e-40f3-b2bf-f78b7c52d847', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '76a9429c-6143-4089-b2a1-634fee1f4bb8', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '22f82d93-9a18-4d55-bdf0-2375e9548227', 1.000, NULL, 'SN-100050', '2025-06-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-25", "warranty_until": "2028-06-24", "equipment_status": "MAINTENANCE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-25 09:00:00+00', '2026-11-02 21:38:18.940479+00', 'STM-YU6M', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dbe8bf35-3617-4a8b-b2a2-9d7044c3165c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cd904356-14c5-4fda-aada-68590ffeb22c', '69437a1f-208d-4eb0-aee9-baf140d2d200', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', '13a8b910-883c-4d3d-9fda-3d14c1d8ac5e', 1.000, NULL, 'SN-100060', '2025-11-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-02", "warranty_until": "2028-11-01", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-02 09:00:00+00', '2026-11-02 21:38:18.940479+00', 'STM-YRDD', NULL, NULL, NULL, NULL);


--
-- Data for Name: label_pool; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('9447f74b-89d6-4cf4-a8da-7a9b5df6920e', 'STM-YRDD', true, '2026-10-22 21:38:18.93901+00', 'dbe8bf35-3617-4a8b-b2a2-9d7044c3165c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('915d94f7-b433-4b38-9308-00ff666a9066', 'STM-MO2B', true, '2026-10-22 21:38:18.93901+00', '3766caf2-10a3-4ea5-83a4-4c62b81127cd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('fdb8acaf-a364-4b16-82fd-f29047a03287', 'STM-CP1E', true, '2026-10-22 21:38:18.93901+00', '30475588-c340-4613-b56a-7e71aa945477', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('56b1a84d-3bd9-448d-8539-d1d3d817dce2', 'STM-6SES', true, '2026-10-22 21:38:18.93901+00', '1ef51736-b7f9-477c-8e58-b2d637afddd9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('dfd5f016-5226-41f6-9fb4-ec8dfba7ef83', 'STM-0FLY', true, '2026-10-22 21:38:18.93901+00', '1447ad8c-b49f-4391-8b6a-66f27388e5ce', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('81670ac3-4a54-4bb3-b703-ac1e8ba0a833', 'STM-YU6M', true, '2026-10-22 21:38:18.93901+00', 'd70ca8a9-998e-40f3-b2bf-f78b7c52d847', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('f5370e82-443e-4818-879d-eb9c80217429', 'STM-CN1G', false, NULL, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('2d7d660b-ce7b-4aae-aff9-83b9c96953a5', 'STM-159N', false, NULL, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('f67676fa-c23c-455c-b2cc-965792b5fe4f', 'STM-AAU3', false, NULL, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('b6dfdf77-2f8c-427d-911b-e855fe837c55', 'STM-TWWE', false, NULL, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('60782813-188e-4627-a5aa-1293e6f7ae18', 'STM-M6HO', false, NULL, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('e427c9cf-c779-4a34-96d4-e56014e3102f', 'STM-KUWJ', false, NULL, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'GENERIC', NULL, NULL, NULL, '2026-10-21 21:38:18.93901+00', '2026-10-21 21:38:18.93901+00', 0, NULL);


--
-- Data for Name: location_relocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_bom_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('39f438bb-a32d-45cf-b13e-48c74b96bc03', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', '5d36a701-5479-482d-b364-a0dc01ecccb5', 'kg', 10.00, 'stone fruit', '2026-11-02 21:38:15.037377+00', '2026-11-02 21:38:15.037381+00', '783cff26-eae1-4986-a27e-5c02d7348172', 2.0000, '0cf8f21a-3455-45f5-a61e-7cae190755d8');
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('bf37bece-b80d-439d-8599-b673e3e379c7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 'kg', 5.00, 'sweetener', '2026-11-02 21:38:15.037383+00', '2026-11-02 21:38:15.037383+00', '783cff26-eae1-4986-a27e-5c02d7348172', 0.3000, '0cf8f21a-3455-45f5-a61e-7cae190755d8');
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('cd23eb65-dc4b-48ba-8b8f-5f4c24329216', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 'kg', 0.00, 'spice', '2026-11-02 21:38:15.037385+00', '2026-11-02 21:38:15.037385+00', '783cff26-eae1-4986-a27e-5c02d7348172', 0.0050, '0cf8f21a-3455-45f5-a61e-7cae190755d8');


--
-- Data for Name: maker_module_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_module_settings (organization_id, reference_direction, created_at, updated_at, allow_overproduction, availability_check_scope, create_on_shortage_strategy) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'MARGIN', '2026-11-02 21:38:18.471571+00', '2026-11-02 21:38:18.471574+00', true, 'GLOBAL', 'WARN');


--
-- Data for Name: maker_production_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('fd6ccb22-3a13-484b-8e37-60ad1b210e6c', '15d91c01-50ef-43c3-a1a1-e1924089351e', '5d36a701-5479-482d-b364-a0dc01ecccb5', 26.4000, 'kg', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 3.4000, 'fifo', NULL);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('94904d27-e10f-4360-8ba5-1155f1b73a89', '15d91c01-50ef-43c3-a1a1-e1924089351e', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 3.7800, 'kg', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 1.1000, 'fifo', NULL);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('7d0fb20a-27a2-4950-a068-166393f133f1', '15d91c01-50ef-43c3-a1a1-e1924089351e', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 0.0600, 'kg', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 24.0000, 'fifo', NULL);


--
-- Data for Name: maker_production_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_orders (id, organization_id, output_template_id, planned_qty, output_storage_location_id, status, total_cost, production_date, notes, created_by, completed_by, created_at, completed_at, cancel_reason, produced_item_id, recipe_id, actual_qty, overproduced, scrap_qty, unit_cost_snapshot, reference_price_snapshot, result_per_unit, result_per_batch, number, short_at_create) VALUES ('15d91c01-50ef-43c3-a1a1-e1924089351e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', 12.000, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 'COMPLETED', 95.36, '2026-11-02', 'Autumn batch, first of the season.', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.517441+00', '2026-11-02 21:38:18.667908+00', NULL, '75ffde96-7a2f-48d8-bead-36eefe97df13', '783cff26-eae1-4986-a27e-5c02d7348172', 11.400, false, 0.600, 8.3647, 18.00, 9.64, 9.64, 'PR/2026/0001', false);


--
-- Data for Name: maker_recipe_cost_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_recipes (id, organization_id, output_template_id, name, batch_yield_qty, batch_yield_uom_id, process_steps, reference_price, is_default, source_recipe_id, source_snapshot_at, created_at, updated_at) VALUES ('783cff26-eae1-4986-a27e-5c02d7348172', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', 'Plum Butter', 1.0000, NULL, NULL, 18.00, true, NULL, NULL, '2026-11-02 21:38:15.019283+00', '2026-11-02 21:38:15.019287+00');


--
-- Data for Name: meal_plan_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('034e7482-09cd-40c3-994d-83c79ecb0efe', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-02', 'BREAKFAST', 'abc579fd-7f7f-4c2e-bc12-484defdb8003', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('f40ddec8-026f-4c6e-adda-255b98be90fa', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-02', 'DINNER', 'e41767e3-f622-4275-9782-86af27e9b5ae', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('a544b5f4-142b-4133-931e-cda8fa879a4f', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-03', 'DINNER', 'b2414068-1110-42d8-bbbe-b0f7ca360ab6', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('a2fb2b1a-ee33-4020-89f9-43963da3d37e', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-04', 'BREAKFAST', 'abc579fd-7f7f-4c2e-bc12-484defdb8003', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('070ee1b4-0e6f-46a4-9a06-a3f4d6dff3db', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-04', 'DINNER', 'd4ae5c31-4450-497b-9e73-9ffbf5001c43', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('1569cd2b-5df0-4a6a-90ff-b223d72f6a7d', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-05', 'DINNER', '1f134b4a-168d-4f0d-a46e-78e17c491036', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('f65a5aef-d265-45ce-bb0b-1b7c07d53c43', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-06', 'DINNER', 'fd8bea76-e7f6-4441-92cd-a010fd6c7d29', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('46628510-c4a5-4d2c-8adc-1227acf30324', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-07', 'BREAKFAST', '0208d80b-e308-4a63-bf06-9c98a0917e80', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('3e45dbd8-3f00-4168-8d29-7a6912a8169e', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-07', 'DINNER', '50d55785-cccb-4451-9278-6943eb9cf00c', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('e6865472-ad0e-4b92-a9e3-4fca546cbcde', '399d4cbd-d206-4b11-bb67-814f83151210', '2026-11-08', 'BREAKFAST', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', NULL, NULL, 0);


--
-- Data for Name: meal_plans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plans (id, organization_id, name, start_date, end_date, enabled_slots, default_servings, shopping_list_id, notes, created_by, created_at, updated_at, listed_meals) VALUES ('399d4cbd-d206-4b11-bb67-814f83151210', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'This week', '2026-11-02', '2026-11-08', '["BREAKFAST", "DINNER"]', NULL, '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.733226+00', '2026-11-02 21:38:18.733228+00', NULL);


--
-- Data for Name: module_installations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.organizations (id, name, created_at, created_by, enabled_modules, allowed_modules, settings, short_id, active_profile_id, onboarding_completed, focus_module, pre_focus_enabled_modules, pre_onboarding_manual_modules, currency, timezone, tax_id, country, print_page_size, address, logo_url) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'Larkspur Trading Co.', '2026-11-02 21:38:14.570361+00', '2b510efc-b831-4b48-97e3-18a8659cf00f', '["categories", "nutrition", "maker", "purchase_orders", "items", "equipment", "printing", "recipes", "core", "warehouse", "stock_takes", "locations", "partners", "approvals", "shopping_lists", "stats", "announcements"]', NULL, '{"module:equipment": {"warranty_warning_days": 60, "maintenance_warning_days": 14, "__schema_version": 1}, "module:stats": {"enable_analytics": true, "show_inventory_value": true, "__schema_version": 1}, "show_module_data": true, "module:approvals": {"allow_admin_self_approve": true}, "demo_last_reset_at": "2026-11-02T21:38:19.161966+00:00"}', NULL, 'equipment_wms', true, NULL, NULL, NULL, 'USD', 'UTC', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('a86bb670-47a6-4d43-9cbb-8d29c2824785', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Eurodata Systems', 'SUP-001', 'SUPPLIER', NULL, false, 'orders@eurodata.example.com', '+44 20 7946 0101', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046307+00', '2026-11-02 21:38:15.04631+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('77f49e68-7245-4416-8f9a-8ce695a06494', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Northgate IT Distribution', 'ITD-002', 'SUPPLIER', NULL, false, 'sales@northgate-it.example.com', '+44 20 7946 0102', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046311+00', '2026-11-02 21:38:15.046311+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('712bb923-0f79-4677-9d51-9cbabadb8417', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'TechSupply Europe', 'TSE-003', 'SUPPLIER', NULL, false, 'orders@techsupply.example.net', '+44 20 7946 0103', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046312+00', '2026-11-02 21:38:15.046312+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('6c35c2d3-06c1-4d99-8b65-6bc61e905e5c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Freshfield Wholesale', 'FFD-004', 'SUPPLIER', NULL, false, 'orders@freshfield.example.com', '+44 20 7946 0104', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046313+00', '2026-11-02 21:38:15.046313+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('73172d96-cc36-430e-bb97-9b420e053602', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Bulkline Cash & Carry', 'MCC-005', 'SUPPLIER', NULL, false, 'b2b@bulkline.example.com', '+44 20 7946 0105', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046313+00', '2026-11-02 21:38:15.046314+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('2354ff07-5399-42b4-a0f8-b894876af9da', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cornerstore Deliveries', 'ZAB-006', 'SUPPLIER', NULL, false, 'deliveries@cornerstore.example.com', '+44 20 7946 0106', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046314+00', '2026-11-02 21:38:15.046314+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('a088577a-e782-4baa-a8f6-ec3d5d456898', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cisco Systems', 'CSC-007', 'MANUFACTURER', NULL, false, 'enterprise@cisco.example.com', '+44 20 7946 0107', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046315+00', '2026-11-02 21:38:15.046315+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('465ef5fd-6790-4f22-97c2-7bdedb3bc3ba', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dell Technologies', 'DLL-008', 'MANUFACTURER', NULL, false, 'enterprise@dell.example.com', '+44 20 7946 0108', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046315+00', '2026-11-02 21:38:15.046316+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('cfa59ce9-4ad7-4499-9c84-88d9aebbaeee', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Hewlett Packard Enterprise', 'HPE-009', 'MANUFACTURER', NULL, false, 'sales@hpe.example.com', '+44 20 7946 0109', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046316+00', '2026-11-02 21:38:15.046317+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('9147a632-ffcf-4c41-9734-b8e807e65cd6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Apple', 'APL-010', 'MANUFACTURER', NULL, false, 'business@apple.example.com', '+44 20 7946 0110', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046317+00', '2026-11-02 21:38:15.046317+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('88a5eaa8-d849-448b-adf9-d4719a0c9a0c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Harper Catering', 'CUS-011', 'CUSTOMER', NULL, false, 'orders@harpercatering.example.com', '+44 20 7946 0111', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046318+00', '2026-11-02 21:38:15.046318+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('9d042212-f75c-445f-9394-f278032ce250', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Officeworks Services', 'CUS-012', 'CUSTOMER', NULL, false, 'office@officeworks.example.net', '+44 20 7946 0112', NULL, NULL, NULL, NULL, true, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:15.046318+00', '2026-11-02 21:38:15.046319+00');


--
-- Data for Name: picking_session_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: picking_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: po_partner_pricelist; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('df8c9456-0ec8-4b4a-8fa6-629bf57c9589', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '6c35c2d3-06c1-4d99-8b65-6bc61e905e5c', '5d36a701-5479-482d-b364-a0dc01ecccb5', 3.2000, 'USD', '0cf8f21a-3455-45f5-a61e-7cae190755d8', NULL, '2026-09-03', NULL, NULL, '2026-11-02 21:38:18.979086+00', '2026-11-02 21:38:18.979089+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('89504596-74fe-437a-8b54-55709fe8664b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '73172d96-cc36-430e-bb97-9b420e053602', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 1.0500, 'USD', '0cf8f21a-3455-45f5-a61e-7cae190755d8', NULL, '2026-09-03', NULL, NULL, '2026-11-02 21:38:18.979091+00', '2026-11-02 21:38:18.979091+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('9f41708d-db68-40d5-a416-338beb02be18', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '73172d96-cc36-430e-bb97-9b420e053602', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 22.5000, 'USD', '0cf8f21a-3455-45f5-a61e-7cae190755d8', NULL, '2026-09-03', NULL, NULL, '2026-11-02 21:38:18.979092+00', '2026-11-02 21:38:18.979092+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('68d6e6bb-ec21-47a6-b9be-0c7b66ca63f8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a86bb670-47a6-4d43-9cbb-8d29c2824785', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 4100.0000, 'USD', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, '2026-09-03', NULL, NULL, '2026-11-02 21:38:18.979093+00', '2026-11-02 21:38:18.979093+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('58f52880-ab18-4860-b1c8-f25287d18451', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '77f49e68-7245-4416-8f9a-8ce695a06494', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 4180.0000, 'USD', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, '2026-09-03', NULL, NULL, '2026-11-02 21:38:18.979093+00', '2026-11-02 21:38:18.979094+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('7c27ab65-912f-4e91-bfab-dc85e0e0f016', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '77f49e68-7245-4416-8f9a-8ce695a06494', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 5650.0000, 'USD', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, '2026-09-03', NULL, NULL, '2026-11-02 21:38:18.979094+00', '2026-11-02 21:38:18.979095+00');


--
-- Data for Name: po_reorder_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('30360fa1-f64e-4a26-bf0a-022d6eb01e7a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 20.000, 40.000, 10.000, '6c35c2d3-06c1-4d99-8b65-6bc61e905e5c', NULL, '2026-11-02 21:38:18.968303+00', '2026-11-02 21:38:18.968306+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('936f8909-3e73-4643-8088-322f82f64ae2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 5.000, 25.000, 2.000, '73172d96-cc36-430e-bb97-9b420e053602', NULL, '2026-11-02 21:38:18.968307+00', '2026-11-02 21:38:18.968307+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('41179e21-25ad-4a3d-8e58-02feadd4607a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 0.100, 0.500, 0.100, '73172d96-cc36-430e-bb97-9b420e053602', NULL, '2026-11-02 21:38:18.968308+00', '2026-11-02 21:38:18.968308+00');


--
-- Data for Name: po_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_settings (id, organization_id, approval_threshold, approval_required, created_at, updated_at) VALUES ('fa67516c-790b-4c0f-8dcd-210ca1091bbf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 10000.00, false, '2026-11-02 21:38:18.888502+00', '2026-11-02 21:38:18.888506+00');


--
-- Data for Name: print_agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: print_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0f235c0d-8907-42ed-a359-c437e63adb06', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.2, "carbs_g": 4.8, "protein_g": 3.2, "calories_kcal": 62}}', '2026-11-02 21:38:14.988889+00', '2026-11-02 21:38:14.988892+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a3a9f3b1-19f5-428a-bf1e-19447790d174', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 7.5, "protein_g": 4.0, "calories_kcal": 67}}', '2026-11-02 21:38:14.988893+00', '2026-11-02 21:38:14.988894+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('270eb47d-03bc-4642-9594-05b6a4b69ac3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Butter Extra 82%', 'Meadowlane', '2000000000039', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 200.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 82.0, "carbs_g": 0.8, "protein_g": 0.5, "calories_kcal": 748}}', '2026-11-02 21:38:14.988894+00', '2026-11-02 21:38:14.988895+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3888bb38-abd7-4a67-ba60-761ade6fa2b9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Gouda Cheese', 'Meadowlane', '2000000000046', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 300.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 1.3, "protein_g": 24.0, "calories_kcal": 356}}', '2026-11-02 21:38:14.988895+00', '2026-11-02 21:38:14.988895+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5b058779-639f-4d34-9201-7dc78d9700fd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Sour Cream 18%', 'Meadowlane', '2000000000053', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 300.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 18.0, "carbs_g": 3.4, "protein_g": 2.5, "calories_kcal": 182}}', '2026-11-02 21:38:14.988896+00', '2026-11-02 21:38:14.988896+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8f0c1f16-0931-4424-b79a-aa1dc5519c11', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cottage Cheese', 'Meadowlane', '2000000000060', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 200.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 5.0, "protein_g": 9.0, "calories_kcal": 125}}', '2026-11-02 21:38:14.988897+00', '2026-11-02 21:38:14.988897+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5bbe071f-194c-4a19-81fa-4c4da1cfa7fe', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Lean Quark', 'Meadowlane', '2000000000077', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 250.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 3.5, "protein_g": 18.0, "calories_kcal": 85}}', '2026-11-02 21:38:14.988897+00', '2026-11-02 21:38:14.988897+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e4c1dab6-db64-409e-95a0-700a60e64d71', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Eggs Medium 10pk', 'Fellbrook Farms', '2000000000084', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 600.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 1.1, "protein_g": 13.0, "calories_kcal": 155}}', '2026-11-02 21:38:14.988898+00', '2026-11-02 21:38:14.988898+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('66ab28cb-fdea-4cdb-b706-b38125c8e655', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Chicken Ham', 'Fellbrook Farms', '2000000000091', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 4.5, "carbs_g": 1.0, "protein_g": 16.0, "calories_kcal": 110}}', '2026-11-02 21:38:14.988898+00', '2026-11-02 21:38:14.988899+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7b3b5462-0278-4759-8945-f9ae3ae536b6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Pork Frankfurters', 'Fellbrook Farms', '2000000000107', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 22.0, "carbs_g": 2.0, "protein_g": 12.0, "calories_kcal": 253}}', '2026-11-02 21:38:14.988899+00', '2026-11-02 21:38:14.988899+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('38e68159-255b-4cc9-94ce-2d842befd46a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Smoked Sausage', 'Fellbrook Farms', '2000000000114', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 3.0, "protein_g": 12.0, "calories_kcal": 301}}', '2026-11-02 21:38:14.9889+00', '2026-11-02 21:38:14.9889+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b5ed13e4-8b7d-42ee-acfe-c986f8658d8b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Smoked Bacon', 'Fellbrook Farms', '2000000000121', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 38.0, "carbs_g": 1.0, "protein_g": 12.0, "calories_kcal": 393}}', '2026-11-02 21:38:14.9889+00', '2026-11-02 21:38:14.988901+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('069febec-5955-4641-9501-77630729af46', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Chicken Breast Fillet', 'Fellbrook Farms', '2000000000138', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 600.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.2, "carbs_g": 0.0, "protein_g": 23.0, "calories_kcal": 110}}', '2026-11-02 21:38:14.988901+00', '2026-11-02 21:38:14.988901+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c844b40e-cfef-474f-8320-a42ad0a3c8a9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Smoked Salmon', 'Bluewater', '2000000000145', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 150.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 13.0, "carbs_g": 0.0, "protein_g": 20.0, "calories_kcal": 196}}', '2026-11-02 21:38:14.988902+00', '2026-11-02 21:38:14.988902+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9b9dc98b-d953-4ac5-a328-0d4f9a37bff9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Mayonnaise', 'Harvest Row', '2000000000152', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 300.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 79.0, "carbs_g": 1.0, "protein_g": 1.0, "calories_kcal": 714}}', '2026-11-02 21:38:14.988902+00', '2026-11-02 21:38:14.988903+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5d74ee73-5c5c-4b0c-bd20-6b5eba9dda07', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tomato Ketchup', 'Harvest Row', '2000000000169', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 26.0, "protein_g": 1.0, "calories_kcal": 112}}', '2026-11-02 21:38:14.988903+00', '2026-11-02 21:38:14.988903+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ae63f584-19ed-4d90-bccb-b87a10a778b0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Orange Juice NFC', 'Orchard & Oak', '2000000000176', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.7, "calories_kcal": 45}}', '2026-11-02 21:38:14.988904+00', '2026-11-02 21:38:14.988904+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('65c992a4-73af-43ee-85d5-91343c5b5849', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Chocolate Milk Drink', 'Meadowlane', '2000000000183', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 14.0, "protein_g": 3.2, "calories_kcal": 84}}', '2026-11-02 21:38:14.988904+00', '2026-11-02 21:38:14.988905+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('90589813-f47f-4cc7-a1cf-28e75d7e27d3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Classic Hummus', 'Green Acre', '2000000000190', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 200.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 14.0, "carbs_g": 14.0, "protein_g": 7.0, "calories_kcal": 215}}', '2026-11-02 21:38:14.988905+00', '2026-11-02 21:38:14.988905+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('474fda51-e5ff-49f6-882a-d3c9d44a0c0f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Red Pesto', 'Harvest Row', '2000000000206', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 190.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 25.0, "carbs_g": 5.0, "protein_g": 3.0, "calories_kcal": 267}}', '2026-11-02 21:38:14.988906+00', '2026-11-02 21:38:14.988906+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('226a2bcb-ddbb-4ba6-a28c-32039fcb0eea', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Carrots 1kg', 'Green Acre', '4651922764332', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.9, "calories_kcal": 41}}', '2026-11-02 21:38:14.988906+00', '2026-11-02 21:38:14.988907+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('51321655-7803-4068-a127-4e7109105029', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Broccoli', 'Green Acre', '7671591271129', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 7.0, "protein_g": 2.8, "calories_kcal": 34}}', '2026-11-02 21:38:14.988907+00', '2026-11-02 21:38:14.988907+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7190ea91-16e3-47b8-81db-a8cfd3310441', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cherry Tomatoes', 'Green Acre', '1461382306422', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 3.9, "protein_g": 0.9, "calories_kcal": 18}}', '2026-11-02 21:38:14.988908+00', '2026-11-02 21:38:14.988908+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('baebba91-48ba-4527-8408-9df663bf32b0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cucumber', 'Green Acre', '3824875293377', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 300.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 3.6, "protein_g": 0.7, "calories_kcal": 16}}', '2026-11-02 21:38:14.988908+00', '2026-11-02 21:38:14.988908+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('82e43300-fc62-41b3-87b6-0ee6c0b2e922', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fuji Apples', 'Green Acre', '0774915747311', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 14.0, "protein_g": 0.3, "calories_kcal": 52}}', '2026-11-02 21:38:14.988909+00', '2026-11-02 21:38:14.988909+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('550d3d31-b672-4970-9b5e-c340b8762506', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Green Grapes', 'Green Acre', '2178682164889', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 18.0, "protein_g": 0.7, "calories_kcal": 69}}', '2026-11-02 21:38:14.988909+00', '2026-11-02 21:38:14.98891+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5f245ab7-3507-41f6-8b07-5f91896352fd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Strawberries', 'Green Acre', '9922816702736', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 7.7, "protein_g": 0.7, "calories_kcal": 32}}', '2026-11-02 21:38:14.98891+00', '2026-11-02 21:38:14.98891+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c9e17da0-af64-4058-b18d-d3383cbbbd2f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Bananas', 'Green Acre', '6348208271001', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 23.0, "protein_g": 1.1, "calories_kcal": 89}}', '2026-11-02 21:38:14.988911+00', '2026-11-02 21:38:14.988911+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6244d889-ac21-4c5e-8d35-f3a8e31ff515', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Vanilla Ice Cream', 'Northwind Frozen', '2000000000299', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 24.0, "protein_g": 3.5, "calories_kcal": 207}}', '2026-11-02 21:38:14.988911+00', '2026-11-02 21:38:14.988911+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ad9bdc0d-3479-4560-8d7c-d626c551a265', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen Pepperoni Pizza', 'Northwind Frozen', '2000000000305', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 350.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 12.0, "carbs_g": 28.0, "protein_g": 11.0, "calories_kcal": 266}}', '2026-11-02 21:38:14.988912+00', '2026-11-02 21:38:14.988912+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6ce6c608-9a9e-4c83-b95f-7e9f808e4a48', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Potato and Cheese Dumplings', 'Northwind Frozen', '2000000000312', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 600.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 28.0, "protein_g": 5.0, "calories_kcal": 196}}', '2026-11-02 21:38:14.988913+00', '2026-11-02 21:38:14.988913+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fc21b238-33e9-49a2-8a29-b46f18917712', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fish Fingers', 'Bluewater', '2000000000329', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 10.0, "carbs_g": 22.0, "protein_g": 10.0, "calories_kcal": 215}}', '2026-11-02 21:38:14.988913+00', '2026-11-02 21:38:14.988914+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f8af9743-a6f8-4a7e-98fb-8ba6d070f2ed', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen Mixed Vegetables', 'Northwind Frozen', '2000000000336', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 750.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 5.0, "protein_g": 2.0, "calories_kcal": 35}}', '2026-11-02 21:38:14.988914+00', '2026-11-02 21:38:14.988914+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0fad138b-eaa4-47ae-9569-2f49e9b49dbe', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen Green Peas', 'Northwind Frozen', '2000000000343', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 450.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 14.0, "protein_g": 5.0, "calories_kcal": 81}}', '2026-11-02 21:38:14.988915+00', '2026-11-02 21:38:14.988915+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2bbab2d4-f589-4aa3-b2b4-53abe0b1f729', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen Chips', 'Northwind Frozen', '2000000000350', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 750.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 5.0, "carbs_g": 24.0, "protein_g": 2.5, "calories_kcal": 152}}', '2026-11-02 21:38:14.988915+00', '2026-11-02 21:38:14.988915+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fae8537d-d380-4433-973f-75d6083b9007', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen Blueberries', 'Northwind Frozen', '2000000000367', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 14.0, "protein_g": 0.7, "calories_kcal": 57}}', '2026-11-02 21:38:14.988916+00', '2026-11-02 21:38:14.988916+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1bb1c2c3-065f-44c0-9149-12347fdfa6d4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Frozen Sour Cherries', 'Northwind Frozen', '2000000000374', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 12.0, "protein_g": 1.0, "calories_kcal": 50}}', '2026-11-02 21:38:14.988916+00', '2026-11-02 21:38:14.988916+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a3fd14a0-f03e-4bf9-9c6b-fe019136e43d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Minced Pork', 'Fellbrook Farms', '2000000000381', NULL, '0cf8f21a-3455-45f5-a61e-7cae190755d8', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 19.0, "carbs_g": 0.0, "protein_g": 15.0, "calories_kcal": 242}}', '2026-11-02 21:38:14.988917+00', '2026-11-02 21:38:14.988917+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fa08611d-cfe1-430e-bf01-48d0854442e4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Spaghetti 500g', 'Harvest Row', '2000000000398', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-02 21:38:14.988917+00', '2026-11-02 21:38:14.988918+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('95c923ad-aaf0-42c4-94d5-499cb99b9f56', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Penne Pasta', 'Harvest Row', '2000000000404', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-02 21:38:14.988918+00', '2026-11-02 21:38:14.988918+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('db6bb65d-c2b6-4318-a6f3-22bd400c6364', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fusilli Pasta', 'Harvest Row', '2000000000411', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-02 21:38:14.988918+00', '2026-11-02 21:38:14.988919+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5319895c-6bd2-4eb3-8d48-63d5d26cfcd8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Jasmine Rice 1kg', 'Harvest Row', '2000000000428', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 78.0, "protein_g": 7.0, "calories_kcal": 348}}', '2026-11-02 21:38:14.988919+00', '2026-11-02 21:38:14.988919+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('681a828c-7837-41a4-81ae-b3f0acd44b55', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Buckwheat Groats', 'Harvest Row', '2000000000435', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.0, "carbs_g": 62.0, "protein_g": 12.0, "calories_kcal": 343}}', '2026-11-02 21:38:14.98892+00', '2026-11-02 21:38:14.98892+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('86b74cd9-765b-41fc-8df3-4850519f5ff6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Rolled Oats', 'Harvest Row', '2000000000442', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 68.0, "protein_g": 13.0, "calories_kcal": 379}}', '2026-11-02 21:38:14.98892+00', '2026-11-02 21:38:14.98892+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cc9838d2-823c-4bc2-a531-f18a59b258f5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fruit Muesli', 'Harvest Row', '2000000000459', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 67.0, "protein_g": 9.0, "calories_kcal": 398}}', '2026-11-02 21:38:14.988921+00', '2026-11-02 21:38:14.988921+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ff783fa4-3b38-458a-84d0-d1293e0f29e2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Corn Flakes', 'Harvest Row', '2000000000466', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 375.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 84.0, "protein_g": 6.0, "calories_kcal": 361}}', '2026-11-02 21:38:14.988921+00', '2026-11-02 21:38:14.988921+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('feb3e156-256c-4558-9c4b-c75591e6e8f4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Wheat Flour Type 550', 'Harvest Row', '2000000000473', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 72.0, "protein_g": 10.0, "calories_kcal": 341}}', '2026-11-02 21:38:14.988922+00', '2026-11-02 21:38:14.988922+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e278bb5c-836a-4327-8c73-9955fdd7b3c3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'White Sugar 1kg', 'Harvest Row', '2000000000480', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 100.0, "protein_g": 0.0, "calories_kcal": 387}}', '2026-11-02 21:38:14.988922+00', '2026-11-02 21:38:14.988923+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ecdfecf5-42df-472b-8c9d-fd3f5d5cad66', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Iodised Salt', 'Saltmill', '2000000000497', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988923+00', '2026-11-02 21:38:14.988923+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f74058cf-9946-472e-8d0d-34656a7e323d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Ground Black Pepper', 'Saltmill', '2000000000503', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 40.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988923+00', '2026-11-02 21:38:14.988924+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fd58696b-450b-42d5-9a06-8f088f7af9ab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dried Oregano', 'Saltmill', '2000000000510', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 15.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988924+00', '2026-11-02 21:38:14.988924+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0a444fe6-23d2-41e3-981c-500a6a38cea8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dried Basil', 'Saltmill', '2000000000527', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 10.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988924+00', '2026-11-02 21:38:14.988925+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('72f02ab4-94c5-476a-8e82-53b361859d75', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Granulated Garlic', 'Saltmill', '2000000000534', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 25.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988925+00', '2026-11-02 21:38:14.988925+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ae2c08af-73e8-4225-8eb4-b8b3d58bfae5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Extra Virgin Olive Oil', 'Harvest Row', '2000000000541', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 750.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-02 21:38:14.988926+00', '2026-11-02 21:38:14.988926+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1293cd6e-96e9-4108-8d62-408f6366b243', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Sunflower Oil', 'Harvest Row', '2000000000558', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-02 21:38:14.988926+00', '2026-11-02 21:38:14.988926+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a5c96c3f-6ac7-421f-8ecf-c8093a336ec8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tomato Passata', 'Harvest Row', '2000000000565', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 700.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 5.5, "protein_g": 1.5, "calories_kcal": 32}}', '2026-11-02 21:38:14.988927+00', '2026-11-02 21:38:14.988927+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('240939e0-2b81-4a30-b303-e9798d591c02', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Peeled Tomatoes 400g', 'Harvest Row', '2000000000572', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 4.0, "protein_g": 1.2, "calories_kcal": 26}}', '2026-11-02 21:38:14.988927+00', '2026-11-02 21:38:14.988928+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4850e73d-f3e0-437b-978a-6286e64163b8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Canned Chickpeas', 'Harvest Row', '2000000000589', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.6, "carbs_g": 27.0, "protein_g": 9.0, "calories_kcal": 164}}', '2026-11-02 21:38:14.988928+00', '2026-11-02 21:38:14.988928+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ff43a68c-478e-4693-9a19-bad8f36eb66b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Canned Sweetcorn', 'Harvest Row', '2000000000602', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 340.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 19.0, "protein_g": 3.0, "calories_kcal": 96}}', '2026-11-02 21:38:14.988929+00', '2026-11-02 21:38:14.988929+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ac6440cf-13bd-4a34-8da6-ad89c6d29e49', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tuna in Oil', 'Bluewater', '2000000000619', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 160.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 0.0, "protein_g": 26.0, "calories_kcal": 198}}', '2026-11-02 21:38:14.98893+00', '2026-11-02 21:38:14.98893+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fe94c1f3-917c-4603-a2e9-a973ef3e9282', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Chicken Stock', 'Harvest Row', '2000000000626', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 120.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.98893+00', '2026-11-02 21:38:14.988931+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2624d047-5f42-4ec9-8865-e51c8feb672b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Earl Grey Tea', 'Orchard & Oak', '2000000000633', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 50.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988931+00', '2026-11-02 21:38:14.988931+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('25104593-b455-4937-a0dc-59839ece2624', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Ground Coffee', 'Orchard & Oak', '2000000000640', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 250.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988931+00', '2026-11-02 21:38:14.988932+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5f05ec46-3aeb-47fd-823e-9fb41d05480a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Coffee Beans', 'Orchard & Oak', '2000000000657', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988932+00', '2026-11-02 21:38:14.988932+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('42de920f-8978-45a8-8f7f-484b375b8515', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Peanut Butter', 'Orchard & Oak', '2000000000671', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 250.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 20.0, "protein_g": 25.0, "calories_kcal": 588}}', '2026-11-02 21:38:14.988933+00', '2026-11-02 21:38:14.988934+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('94faab7a-2e4c-4bb7-af04-64c583b8dcc8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dark Chocolate 85%', 'Orchard & Oak', '2000000000688', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 100.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 44.0, "carbs_g": 39.0, "protein_g": 8.0, "calories_kcal": 598}}', '2026-11-02 21:38:14.988934+00', '2026-11-02 21:38:14.988934+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4c9cf0d0-e869-4dce-8583-26f50db01002', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Salted Potato Crisps', 'Orchard & Oak', '2000000000695', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 165.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 35.0, "carbs_g": 53.0, "protein_g": 4.0, "calories_kcal": 536}}', '2026-11-02 21:38:14.988934+00', '2026-11-02 21:38:14.988935+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('72bdce9f-7935-43fd-927c-2d567cf5d756', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Rice Cakes', 'Harvest Row', '2000000000701', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 120.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.0, "carbs_g": 82.0, "protein_g": 7.0, "calories_kcal": 387}}', '2026-11-02 21:38:14.988935+00', '2026-11-02 21:38:14.988935+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('95297129-3d3b-4d4d-85ad-86d2c3b26f24', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Butter Biscuits', 'Orchard & Oak', '2000000000718', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 200.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 17.0, "carbs_g": 71.0, "protein_g": 6.0, "calories_kcal": 454}}', '2026-11-02 21:38:14.988936+00', '2026-11-02 21:38:14.988936+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('eb45cb98-1edf-4366-8368-ab2ea153bb9c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tomato Paste', 'Harvest Row', '2000000000732', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 170.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 9.0, "protein_g": 3.0, "calories_kcal": 55}}', '2026-11-02 21:38:14.988937+00', '2026-11-02 21:38:14.988937+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3dff72bd-f27c-4b1d-8dcb-02e760699c5a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Potato Starch', 'Harvest Row', '2000000000749', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 500.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 85.0, "protein_g": 0.5, "calories_kcal": 341}}', '2026-11-02 21:38:14.988937+00', '2026-11-02 21:38:14.988937+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d7cb91a9-1b2f-4194-9e30-6e49fb3e2bb4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Baking Powder', 'Harvest Row', '2000000000756', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 50.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988938+00', '2026-11-02 21:38:14.988938+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c744d549-fc8b-4f99-a86b-c6fb07ece59a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dry Yeast', 'Harvest Row', '2000000000763', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 14.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988938+00', '2026-11-02 21:38:14.988938+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Vanilla Sugar', 'Harvest Row', '2000000000770', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 32.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988939+00', '2026-11-02 21:38:14.988939+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('59f4e747-a861-4686-9615-9139aaa49146', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Ground Cinnamon', 'Saltmill', '2000000000787', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 20.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.98894+00', '2026-11-02 21:38:14.98894+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('13b63530-f895-4416-beb3-c2dca6919854', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Sweet Paprika', 'Saltmill', '2000000000794', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 30.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.98894+00', '2026-11-02 21:38:14.98894+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('bd3d3894-7ae4-4e8f-8a7a-068b4de4bfdc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Curry Powder', 'Saltmill', '2000000000800', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 25.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988941+00', '2026-11-02 21:38:14.988941+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('421dfd61-718d-4571-b801-4992bbcc7aa8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Ground Ginger', 'Saltmill', '2000000000817', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 20.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988941+00', '2026-11-02 21:38:14.988941+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Wildflower Honey', 'Orchard & Oak', '2000000000824', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 82.0, "protein_g": 0.3, "calories_kcal": 304}}', '2026-11-02 21:38:14.988942+00', '2026-11-02 21:38:14.988942+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d321c217-0978-4c72-8d42-5307962d1092', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Walnuts', 'Green Acre', '2000000000831', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 200.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 65.0, "carbs_g": 14.0, "protein_g": 15.0, "calories_kcal": 654}}', '2026-11-02 21:38:14.988942+00', '2026-11-02 21:38:14.988943+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e7d048bb-38a4-4a01-84f3-7337017b25f1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Almonds', 'Green Acre', '2000000000848', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 200.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 22.0, "protein_g": 21.0, "calories_kcal": 579}}', '2026-11-02 21:38:14.988943+00', '2026-11-02 21:38:14.988943+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('811175a1-fe78-435e-ae2b-65c46cdc638f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Instant Tomato Soup', 'Harvest Row', '2000000000855', NULL, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', 85.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-02 21:38:14.988943+00', '2026-11-02 21:38:14.988944+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cddf4368-31e0-4700-b43f-732425756cb6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cocoa Powder', 'Orchard & Oak', '2000000000862', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 100.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 15.0, "carbs_g": 36.0, "protein_g": 24.0, "calories_kcal": 348}}', '2026-11-02 21:38:14.988944+00', '2026-11-02 21:38:14.988944+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dell Latitude 5540', 'Dell', '5397184123456', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-1345U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-02 21:38:15.005853+00', '2026-11-02 21:38:15.005857+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('33b25eca-5f45-4957-9dcc-fd1aa463d155', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ThinkPad T14s Gen 4', 'Lenovo', '0196881123456', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "AMD Ryzen 7 PRO", "ram": "32GB", "storage": "1TB SSD"}}', '2026-11-02 21:38:15.005858+00', '2026-11-02 21:38:15.005858+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('116b428f-f07b-4bd5-b9e0-5fa352157681', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'MacBook Pro 14 M3', 'Apple', '0194252123456', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Apple M3 Pro", "ram": "18GB", "storage": "512GB SSD"}}', '2026-11-02 21:38:15.005859+00', '2026-11-02 21:38:15.005859+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3f194adb-f44e-4d5d-80c1-02b6dd60edc8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'HP EliteBook 840 G10', 'HP', '0196882123456', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-1365U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-02 21:38:15.00586+00', '2026-11-02 21:38:15.00586+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('eccbc778-64cd-44fb-a806-9889659852cb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dell OptiPlex 7010', 'Dell', '5397184234567', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-13500", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-02 21:38:15.005861+00', '2026-11-02 21:38:15.005861+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('db2ce2d0-bd7d-4ffd-9e6b-4e1932aa6d01', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'HP ProDesk 400 G9', 'HP', '0196883234567', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-12500", "ram": "8GB", "storage": "256GB SSD"}}', '2026-11-02 21:38:15.005862+00', '2026-11-02 21:38:15.005862+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d3780b77-589a-4b0c-9fc0-cd81c5548b8f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Lenovo ThinkCentre M90q', 'Lenovo', '0196884234567', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-13700", "ram": "16GB", "storage": "1TB SSD"}}', '2026-11-02 21:38:15.005863+00', '2026-11-02 21:38:15.005863+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c9032a28-5d75-4c27-b76b-432a1580c400', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dell UltraSharp U2723QE', 'Dell', '5397184345678', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-02 21:38:15.005864+00', '2026-11-02 21:38:15.005864+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9b9ff3b1-258d-4abf-8728-294f35c724ae', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'LG 27UK850-W', 'LG', '8806097345678', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-02 21:38:15.005865+00', '2026-11-02 21:38:15.005865+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cfae9b7b-7fad-47dc-be5f-76e97329c960', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Samsung Odyssey G5', 'Samsung', '8806098345678', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "32\"", "panel": "VA", "resolution": "2560x1440"}}', '2026-11-02 21:38:15.005866+00', '2026-11-02 21:38:15.005866+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('be4f49ab-92cc-4682-8edc-7b71251649e1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'iPhone 15 Pro', 'Apple', '0194253456789', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Natural Titanium", "storage": "256GB"}}', '2026-11-02 21:38:15.005867+00', '2026-11-02 21:38:15.005867+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Samsung Galaxy S24', 'Samsung', '8806099456789', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Phantom Black", "storage": "128GB"}}', '2026-11-02 21:38:15.005868+00', '2026-11-02 21:38:15.005868+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b5aa9619-72e3-4706-87cb-29c56478ab7c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'iPad Air M2', 'Apple', '0194254456789', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Space Gray", "storage": "128GB"}}', '2026-11-02 21:38:15.005869+00', '2026-11-02 21:38:15.005869+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e57ab104-305a-4562-bb09-555ee3c0a5f5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cisco Catalyst 9200L', 'Cisco', '0882658567890', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE", "management": "DNA Center"}}', '2026-11-02 21:38:15.00587+00', '2026-11-02 21:38:15.00587+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9d34f095-249a-4027-afa8-33fdd61f1383', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', '8100014567890', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "48x 1GbE + 4x 10GbE"}}', '2026-11-02 21:38:15.005871+00', '2026-11-02 21:38:15.005871+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f2932f69-4af6-4d25-8800-0727bd3eee66', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'TP-Link TL-SG3428', 'TP-Link', '6935364567890', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE + 4x SFP"}}', '2026-11-02 21:38:15.005871+00', '2026-11-02 21:38:15.005872+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cisco Meraki MR46', 'Cisco', '0882659567890', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"speed": "AX5400", "standard": "Wi-Fi 6"}}', '2026-11-02 21:38:15.005872+00', '2026-11-02 21:38:15.005873+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9f59b212-5228-48cf-a250-dd7e6c2c2a71', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Logitech MX Keys S', 'Logitech', '0978551678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Mechanical", "layout": "US"}}', '2026-11-02 21:38:15.005873+00', '2026-11-02 21:38:15.005874+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('63c93362-2c11-442c-a0a0-330241624822', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Logitech MX Master 3S', 'Logitech', '0978552678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"dpi": 8000, "buttons": 7}}', '2026-11-02 21:38:15.005874+00', '2026-11-02 21:38:15.005874+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a67bbcae-4150-47ab-95f2-f418ec3b841b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Logitech C920 HD Pro', 'Logitech', '0978553678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"fps": 30, "resolution": "1080p"}}', '2026-11-02 21:38:15.005875+00', '2026-11-02 21:38:15.005875+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e068506d-dd84-4eb8-a7c7-5c4176203b37', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Jabra Evolve2 65', 'Jabra', '5707054678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Headset", "connection": "Bluetooth"}}', '2026-11-02 21:38:15.005876+00', '2026-11-02 21:38:15.005876+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('22f82d93-9a18-4d55-bdf0-2375e9548227', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Dell PowerEdge R750', 'Dell', '5397185678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4314", "ram": "64GB", "storage": "2x 480GB SSD"}}', '2026-11-02 21:38:15.005877+00', '2026-11-02 21:38:15.005877+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cb9749b7-8ba5-46af-bf97-40b5254d7880', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'HPE ProLiant DL380 Gen10', 'HPE', '8881825678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Gold 5318Y", "ram": "128GB", "storage": "4x 960GB SSD"}}', '2026-11-02 21:38:15.005878+00', '2026-11-02 21:38:15.005878+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('19751a32-491b-4a06-8dac-86943c9b3b66', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Supermicro SYS-1029U', 'Supermicro', '1234565678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4214", "ram": "96GB", "storage": "2x 1TB SSD"}}', '2026-11-02 21:38:15.005879+00', '2026-11-02 21:38:15.005879+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('13a8b910-883c-4d3d-9fda-3d14c1d8ac5e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'APC Smart-UPS 3000VA', 'APC', '0731303678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"runtime": "~15min at full load", "capacity": "3000VA/2700W"}}', '2026-11-02 21:38:15.00588+00', '2026-11-02 21:38:15.00588+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('58fb09d9-302d-4e60-9312-0ba414cb7a35', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Rack 42U Open Frame', 'Rittal', '4017304678901', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "42U", "width": "19 inch"}}', '2026-11-02 21:38:15.00588+00', '2026-11-02 21:38:15.005881+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2f1b6282-567c-422c-bb1d-704f79f71d08', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Plum Butter', 'Hollow Lane Orchard', '2000000009018', 'PLB-001', '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-02 21:38:15.015219+00', '2026-11-02 21:38:15.015222+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5d36a701-5479-482d-b364-a0dc01ecccb5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Damson Plums', 'Green Acre', '2000000009025', 'PLM-001', '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-02 21:38:15.015223+00', '2026-11-02 21:38:15.015223+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('012cff9e-43c0-4593-977e-2fad7b12bbcf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'White Sugar', 'Harvest Row', '2000000009032', 'SUG-001', '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-02 21:38:15.015223+00', '2026-11-02 21:38:15.015224+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Cassia Cinnamon', 'Saltmill', '2000000009049', 'CIN-001', '0cf8f21a-3455-45f5-a61e-7cae190755d8', 1000.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-02 21:38:15.015224+00', '2026-11-02 21:38:15.015224+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5d059874-8aa6-440f-ac9f-f87497631322', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Strawberry Jam', 'Orchard & Oak', '2000000000664', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 350.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 3, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 65.0, "protein_g": 0.5, "calories_kcal": 264}}', '2026-11-02 21:38:14.988933+00', '2026-11-02 21:38:15.143767+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6ff4b2d0-15af-49fc-a4c3-a1c764cab204', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Canned White Beans', 'Harvest Row', '2000000000596', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 400.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 9, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 25.0, "protein_g": 9.0, "calories_kcal": 139}}', '2026-11-02 21:38:14.988929+00', '2026-11-02 21:38:15.143772+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('978975e2-b9a9-47ca-accc-272993e683a9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Soy Sauce', 'Harvest Row', '2000000000725', NULL, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 250.000000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, NULL, NULL, 6, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 5.0, "protein_g": 8.0, "calories_kcal": 53}}', '2026-11-02 21:38:14.988936+00', '2026-11-02 21:38:15.143772+00');


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('48cff907-d4d4-4d54-b227-e1352ab04a7b', '6e258647-da16-4407-8981-e0725b62cfad', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'Dell Latitude 5540', 4.000, 0.000, 4200.00, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 23.00, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('81b4ecb6-5e4c-4ea7-921a-ff17ba794d6c', '49156d77-1594-4f87-9924-91d3d1e6b68a', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'Dell Latitude 5540', 6.000, 0.000, 4200.00, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 23.00, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('b58c6d2d-d06a-4e3a-bb83-71a62979a71f', '49156d77-1594-4f87-9924-91d3d1e6b68a', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 'ThinkPad T14s Gen 4', 2.000, 0.000, 5800.00, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 23.00, 2, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('18e9c3df-cc76-41d8-9c87-881ee8b03f0e', '982d0221-8690-42bf-abda-d4d622cf7f58', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 'ThinkPad T14s Gen 4', 5.000, 3.000, 5800.00, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 23.00, 1, NULL, NULL);


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('982d0221-8690-42bf-abda-d4d622cf7f58', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'PO/2026/003', 'CONFIRMED', 'a86bb670-47a6-4d43-9cbb-8d29c2824785', '2026-10-20', 'Partly delivered; the rest is on back order with the supplier.', 'USD', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-13 21:38:17.832568+00', NULL, NULL, '2026-10-13 21:38:17.832568+00', '2026-11-02 21:38:18.825131+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('49156d77-1594-4f87-9924-91d3d1e6b68a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'PO/2026/002', 'CONFIRMED', '77f49e68-7245-4416-8f9a-8ce695a06494', '2026-10-30', 'Quarterly refresh of the support desk.', 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-24 05:38:17.832568+00', NULL, NULL, '2026-10-23 21:38:17.832568+00', '2026-11-02 21:38:18.892948+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('6e258647-da16-4407-8981-e0725b62cfad', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'PO/2026/001', 'PENDING_APPROVAL', '77f49e68-7245-4416-8f9a-8ce695a06494', '2026-11-06', 'Laptops for the two November starters and two for the loan pool.', 'USD', '7fb93cd8-d0f5-4a14-b739-f72404792db5', NULL, NULL, NULL, NULL, '2026-10-30 21:38:17.832568+00', '2026-11-02 21:38:18.893481+00');


--
-- Data for Name: putaway_capacity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_home_silenced; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_location_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_rule_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('bf570629-1158-4102-a4f5-0bf0fe104a10', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'da281e96-ac6f-4b32-992a-babdd9ea4e05', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('32d48307-590b-4806-a7c4-ed5d5c5bb314', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'da281e96-ac6f-4b32-992a-babdd9ea4e05', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('32a9997e-6283-4aed-b86b-a419206a55a0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '12b232d2-629d-435b-bf7d-25832a7321f1', '0e6131a5-bab6-4d95-ae7f-1639ac331989', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('3de97f2a-3e28-447e-97c3-612367766cfc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '12b232d2-629d-435b-bf7d-25832a7321f1', '7b6d690e-d6ef-4a81-8aae-8c138bb04ccb', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('6fb8f574-9785-4b61-b8c2-f89f4e69c1ca', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '1dbd919a-3fb8-4e86-9342-fc08d7396cd4', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('1f30e8a3-3ec7-474d-9c3c-54e48217cce0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '1dbd919a-3fb8-4e86-9342-fc08d7396cd4', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 1);


--
-- Data for Name: putaway_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('da281e96-ac6f-4b32-992a-babdd9ea4e05', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, '04dea600-42e9-4ab1-a38d-c0f272e1ed52', NULL, NULL, 50, true, '2026-11-02 21:38:18.76916+00', '2026-11-02 21:38:18.76916+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('12b232d2-629d-435b-bf7d-25832a7321f1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, '21f6cccb-2dd1-4392-bffe-813f39c14f90', NULL, NULL, 50, true, '2026-11-02 21:38:18.76916+00', '2026-11-02 21:38:18.76916+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('1dbd919a-3fb8-4e86-9342-fc08d7396cd4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', NULL, NULL, NULL, 10, true, '2026-11-02 21:38:18.76916+00', '2026-11-02 21:38:18.76916+00');


--
-- Data for Name: recipe_collection_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('05e7016b-d0d2-40d7-8d5a-f82b3dc77341', 'e41767e3-f622-4275-9782-86af27e9b5ae', '4850e73d-f3e0-437b-978a-6286e64163b8', 'Canned Chickpeas', NULL, NULL, 2.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('01ecc598-a883-4ee8-abe0-50edf2819fa0', 'e41767e3-f622-4275-9782-86af27e9b5ae', 'a5c96c3f-6ac7-421f-8ecf-c8093a336ec8', 'Tomato Passata', NULL, NULL, 500.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f5a89fbe-8a6c-4224-81f4-7d07f081fdf0', 'e41767e3-f622-4275-9782-86af27e9b5ae', 'ae2c08af-73e8-4225-8eb4-b8b3d58bfae5', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d3874f4c-3b00-4e0b-ab54-d1b3ce55ac39', 'e41767e3-f622-4275-9782-86af27e9b5ae', '13b63530-f895-4416-beb3-c2dca6919854', 'Sweet Paprika', NULL, NULL, 3.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ca18ca44-6a8a-4678-8f56-14b9b8c917db', 'b2414068-1110-42d8-bbbe-b0f7ca360ab6', 'fa08611d-cfe1-430e-bf01-48d0854442e4', 'Spaghetti 500g', NULL, NULL, 200.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b3656cbb-5f84-4572-8ae2-b32101b7080c', 'b2414068-1110-42d8-bbbe-b0f7ca360ab6', 'ae2c08af-73e8-4225-8eb4-b8b3d58bfae5', 'Extra Virgin Olive Oil', NULL, NULL, 40.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('8b10a232-e867-48bd-88e8-df6a99bb22fc', 'b2414068-1110-42d8-bbbe-b0f7ca360ab6', '72f02ab4-94c5-476a-8e82-53b361859d75', 'Granulated Garlic', NULL, NULL, 3.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('95079ab2-a4a2-44c6-9000-e483949d2e3d', 'b2414068-1110-42d8-bbbe-b0f7ca360ab6', 'ecdfecf5-42df-472b-8c9d-fd3f5d5cad66', 'Iodised Salt', NULL, NULL, 10.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('e84db208-658a-4a69-beda-64934ce9756e', 'd4ae5c31-4450-497b-9e73-9ffbf5001c43', '069febec-5955-4641-9501-77630729af46', 'Chicken Breast Fillet', NULL, NULL, 600.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ca7366b6-0afc-4fc3-8b40-9d02673f84a8', 'd4ae5c31-4450-497b-9e73-9ffbf5001c43', '5319895c-6bd2-4eb3-8d48-63d5d26cfcd8', 'Jasmine Rice 1kg', NULL, NULL, 300.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('98894e83-28f3-4ef4-8733-fa7250bbc2c7', 'd4ae5c31-4450-497b-9e73-9ffbf5001c43', 'bd3d3894-7ae4-4e8f-8a7a-068b4de4bfdc', 'Curry Powder', NULL, NULL, 10.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('5ae4e6e5-adf7-4e07-87c9-e539a7d58978', 'd4ae5c31-4450-497b-9e73-9ffbf5001c43', '240939e0-2b81-4a30-b303-e9798d591c02', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('20c63aa1-636f-4f44-9489-d8e3020d20b4', 'd4ae5c31-4450-497b-9e73-9ffbf5001c43', NULL, 'Coconut Milk', NULL, NULL, 400.000, '8f256be8-3468-4bb5-aeac-8f8dc007d8e3', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('178895fc-efc0-4a07-bfac-29d680c5ed60', 'fd8bea76-e7f6-4441-92cd-a010fd6c7d29', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', 'Penne Pasta', NULL, NULL, 200.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('9de03185-a010-46d3-89a8-f731b7e792d1', 'fd8bea76-e7f6-4441-92cd-a010fd6c7d29', '474fda51-e5ff-49f6-882a-d3c9d44a0c0f', 'Red Pesto', NULL, NULL, 90.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b0285494-fa5a-4c1a-8400-f7cf51bbf10f', 'fd8bea76-e7f6-4441-92cd-a010fd6c7d29', '7190ea91-16e3-47b8-81db-a8cfd3310441', 'Cherry Tomatoes', NULL, NULL, 250.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b2ac1bf1-a509-4f84-b0d9-023d11e4267f', 'fd8bea76-e7f6-4441-92cd-a010fd6c7d29', NULL, 'Parmesan', NULL, NULL, 40.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f7c3e96b-98eb-4b60-af6d-567c3a50335f', 'abc579fd-7f7f-4c2e-bc12-484defdb8003', '86b74cd9-765b-41fc-8df3-4850519f5ff6', 'Rolled Oats', NULL, NULL, 100.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('eb66ac42-b3c5-42e4-bb7c-eb58be92574d', 'abc579fd-7f7f-4c2e-bc12-484defdb8003', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', 'Natural Yoghurt 400g', NULL, NULL, 300.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3d307787-464b-437a-878a-2718889fd2a4', 'abc579fd-7f7f-4c2e-bc12-484defdb8003', 'fae8537d-d380-4433-973f-75d6083b9007', 'Frozen Blueberries', NULL, NULL, 120.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('fd0d1b9f-f5e6-476a-a359-b57cf0ce3999', 'abc579fd-7f7f-4c2e-bc12-484defdb8003', 'e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', 'Wildflower Honey', NULL, NULL, 20.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('28ffd20d-f867-456e-876f-82d2f244417b', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'c9e17da0-af64-4058-b18d-d3383cbbbd2f', 'Bananas', NULL, NULL, 500.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('105a1126-fad8-4f6a-9129-3524bc46a704', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'feb3e156-256c-4558-9c4b-c75591e6e8f4', 'Wheat Flour Type 550', NULL, NULL, 250.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1da46fc3-2e02-48e4-9c36-3da55e9734e2', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'e278bb5c-836a-4327-8c73-9955fdd7b3c3', 'White Sugar 1kg', NULL, NULL, 150.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('07715e54-cda3-4281-9a37-a67b804af94c', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'e4c1dab6-db64-409e-95a0-700a60e64d71', 'Eggs Medium 10pk', NULL, NULL, 1.000, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d09c9fa0-3844-4f58-afe3-df8203b65549', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 'Butter Extra 82%', NULL, NULL, 100.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('51301a7b-84a0-49ae-8630-2b9afa674f6f', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'd7cb91a9-1b2f-4194-9e30-6e49fb3e2bb4', 'Baking Powder', NULL, NULL, 8.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0c31c818-4eeb-4388-8acd-7276ca90d11a', '8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'd321c217-0978-4c72-8d42-5307962d1092', 'Walnuts', NULL, NULL, 100.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 6, NULL, NULL, NULL, NULL, '["nuts"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('fda38403-54de-43fe-a565-4fd9637ade2b', '50d55785-cccb-4451-9278-6943eb9cf00c', 'e4c1dab6-db64-409e-95a0-700a60e64d71', 'Eggs Medium 10pk', NULL, NULL, 1.000, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6019b9dd-8bb2-4368-b4f0-8b45a4f48271', '50d55785-cccb-4451-9278-6943eb9cf00c', '240939e0-2b81-4a30-b303-e9798d591c02', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('998f9fc5-1490-4b54-8ec7-5aa4cf89629d', '50d55785-cccb-4451-9278-6943eb9cf00c', '13b63530-f895-4416-beb3-c2dca6919854', 'Sweet Paprika', NULL, NULL, 3.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('2d0c92bf-87e6-4d99-a0d7-a6b2ba2d18f1', '50d55785-cccb-4451-9278-6943eb9cf00c', 'ae2c08af-73e8-4225-8eb4-b8b3d58bfae5', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('cbebca70-1d07-4d2b-837d-0ae29b3e3537', '50d55785-cccb-4451-9278-6943eb9cf00c', NULL, 'Onion', NULL, NULL, 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('71a18e8a-aa8f-4ff9-b08e-50e3663f1436', '0208d80b-e308-4a63-bf06-9c98a0917e80', 'feb3e156-256c-4558-9c4b-c75591e6e8f4', 'Wheat Flour Type 550', NULL, NULL, 250.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('86d8819f-3b8b-445a-923d-caed9c2f21a8', '0208d80b-e308-4a63-bf06-9c98a0917e80', '0f235c0d-8907-42ed-a359-c437e63adb06', 'UHT Milk 3.2%', NULL, NULL, 500.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a0a97b22-15f2-4b6d-8b86-279cee343a99', '0208d80b-e308-4a63-bf06-9c98a0917e80', 'e4c1dab6-db64-409e-95a0-700a60e64d71', 'Eggs Medium 10pk', NULL, NULL, 1.000, 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ac191135-9c73-49c9-a8dd-4b6d7de5c7a0', '0208d80b-e308-4a63-bf06-9c98a0917e80', '5f245ab7-3507-41f6-8b07-5f91896352fd', 'Strawberries', NULL, NULL, 300.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('7628976a-895b-4c1d-af7f-bc3a47723466', '0208d80b-e308-4a63-bf06-9c98a0917e80', '1293cd6e-96e9-4108-8d62-408f6366b243', 'Sunflower Oil', NULL, NULL, 25.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('4be1c6db-1f75-4104-90a3-fd022f458d9c', '1f134b4a-168d-4f0d-a46e-78e17c491036', 'db6bb65d-c2b6-4318-a6f3-22bd400c6364', 'Fusilli Pasta', NULL, NULL, 300.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('662e34b5-9064-48a0-ab82-2e24eac57b81', '1f134b4a-168d-4f0d-a46e-78e17c491036', 'ac6440cf-13bd-4a34-8da6-ad89c6d29e49', 'Tuna in Oil', NULL, NULL, 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["fish"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('17a05473-3037-483f-8bc2-760bd023719c', '1f134b4a-168d-4f0d-a46e-78e17c491036', 'ff43a68c-478e-4693-9a19-bad8f36eb66b', 'Canned Sweetcorn', NULL, NULL, 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('73dbeaab-9b96-44cf-897d-4b4b6b4e271b', '1f134b4a-168d-4f0d-a46e-78e17c491036', '9b9dc98b-d953-4ac5-a328-0d4f9a37bff9', 'Mayonnaise', NULL, NULL, 75.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6d524fcd-6132-44ad-9a0b-a780260b7183', '1f134b4a-168d-4f0d-a46e-78e17c491036', 'baebba91-48ba-4527-8408-9df663bf32b0', 'Cucumber', NULL, NULL, 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a37892ee-c49d-4772-8187-07e7b7c622b4', '1f134b4a-168d-4f0d-a46e-78e17c491036', NULL, 'Fresh Basil', NULL, NULL, 10.000, '653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);


--
-- Data for Name: recipe_tag_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('0208d80b-e308-4a63-bf06-9c98a0917e80', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Pancakes with Strawberries', 'Saturday breakfast, twelve thin pancakes.', '1. Whisk the flour, milk and eggs into a thin batter; rest it ten minutes.
2. Fry in a lightly oiled pan, a ladle at a time.
3. Serve with sliced strawberries.', 4, 30, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/0208d80b-e308-4a63-bf06-9c98a0917e80/cover.jpg', NULL, '["breakfast"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.721097+00', '2026-11-02 21:38:19.130559+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('1f134b4a-168d-4f0d-a46e-78e17c491036', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tuna Pasta Salad', 'A lunchbox that keeps until Wednesday.', '1. Cook the fusilli and cool it under running water.
2. Mix with the tuna, sweetcorn, diced cucumber and mayonnaise.
3. Tear the basil over the top before serving.', 3, 20, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/1f134b4a-168d-4f0d-a46e-78e17c491036/cover.jpg', NULL, '["quick", "pasta"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.722395+00', '2026-11-02 21:38:19.130562+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('50d55785-cccb-4451-9278-6943eb9cf00c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Shakshuka', 'Eggs poached in a spiced tomato sauce, straight from the pan.', '1. Soften the sliced onion in the oil with the paprika.
2. Add the tomatoes and simmer until thick.
3. Make four wells, crack in the eggs, cover and cook until set.', 2, 25, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/50d55785-cccb-4451-9278-6943eb9cf00c/cover.jpg', NULL, '["breakfast", "vegetarian"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.719422+00', '2026-11-02 21:38:19.130562+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('8d1795e7-2c2f-43fa-b2ce-acc65d9c5765', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Banana Bread', 'What the bananas going brown on the counter are for.', '1. Mash the bananas and beat in the melted butter, sugar and eggs.
2. Fold in the flour, baking powder and chopped walnuts.
3. Bake in a lined loaf tin at 175 C for about an hour.', 8, 70, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/8d1795e7-2c2f-43fa-b2ce-acc65d9c5765/cover.jpg', NULL, '["baking"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.718113+00', '2026-11-02 21:38:19.130563+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('abc579fd-7f7f-4c2e-bc12-484defdb8003', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Overnight Oats with Blueberries', 'Made the evening before, eaten on the way out.', '1. Stir the oats into the yoghurt with a spoon of honey.
2. Fold in the blueberries straight from the freezer.
3. Cover and leave in the fridge overnight.', 2, 10, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/abc579fd-7f7f-4c2e-bc12-484defdb8003/cover.jpg', NULL, '["breakfast", "vegetarian"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.716786+00', '2026-11-02 21:38:19.130563+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('b2414068-1110-42d8-bbbe-b0f7ca360ab6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Spaghetti with Garlic and Oil', 'The five-ingredient supper worth knowing by heart.', '1. Cook the spaghetti in well-salted water.
2. Warm the oil gently with the garlic; do not let it brown.
3. Toss the drained pasta in the oil with a splash of cooking water.', 2, 20, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/b2414068-1110-42d8-bbbe-b0f7ca360ab6/cover.jpg', NULL, '["quick", "pasta"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.710059+00', '2026-11-02 21:38:19.130563+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('d4ae5c31-4450-497b-9e73-9ffbf5001c43', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Chicken Curry with Jasmine Rice', 'A weeknight curry from the freezer and the spice drawer.', '1. Brown the diced chicken, then stir in the curry powder.
2. Add the tomatoes and coconut milk; simmer for twenty minutes.
3. Serve over the rice.', 4, 40, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/d4ae5c31-4450-497b-9e73-9ffbf5001c43/cover.jpg', NULL, '["dinner"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.713838+00', '2026-11-02 21:38:19.130564+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('e41767e3-f622-4275-9782-86af27e9b5ae', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tomato and Chickpea Stew', 'One pot, thirty minutes, everything from the pantry shelf.', '1. Warm the oil and toast the paprika for thirty seconds.
2. Add the passata and the drained chickpeas.
3. Simmer for twenty minutes, season and serve with bread.', 4, 30, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/e41767e3-f622-4275-9782-86af27e9b5ae/cover.jpg', NULL, '["quick", "vegetarian"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.708202+00', '2026-11-02 21:38:19.130564+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('fd8bea76-e7f6-4441-92cd-a010fd6c7d29', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Penne with Red Pesto', 'Fifteen minutes, one pan, no chopping board.', '1. Cook the penne.
2. Halve the tomatoes and warm them in the pesto.
3. Toss with the pasta and finish with grated parmesan.', 2, 15, 'd6301fab-e457-41b9-8ee6-16ecc6683985/recipes/fd8bea76-e7f6-4441-92cd-a010fd6c7d29/cover.jpg', NULL, '["quick", "pasta", "vegetarian"]', false, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.715425+00', '2026-11-02 21:38:19.130564+00');


--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_exclusions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('12c03165-422b-47c3-8e17-012621b09f57', '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, NULL, 'Coconut Milk', 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'For the curry on Wednesday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-02 21:38:18.735577+00', '2026-11-02 21:38:18.73558+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('d8db93b2-9138-4870-8f06-ccc4e4eedd8a', '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, NULL, 'Parmesan', 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'For the penne on Friday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-02 21:38:18.735582+00', '2026-11-02 21:38:18.735582+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('78055293-8159-4a61-ba68-12ecc89dad51', '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, NULL, 'Onion', 3.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'Shakshuka on Saturday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-02 21:38:18.735583+00', '2026-11-02 21:38:18.735583+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('584d8faa-bbc5-45b7-978d-792c9bd9878c', '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, NULL, 'Fresh Basil', 1.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', 'Tuna pasta salad', NULL, false, NULL, NULL, 'manual', 0, '2026-11-02 21:38:18.735584+00', '2026-11-02 21:38:18.735585+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('e21c6d7b-e3c0-4394-ac8d-cbe92c4bb06b', '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, NULL, 'UHT Milk 3.2%', 2.000, '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-02 21:38:18.735585+00', '2026-11-02 21:38:18.735586+00', '0f235c0d-8907-42ed-a359-c437e63adb06', NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('19faf151-ef2a-4806-8388-77a555770c45', '0faddacc-8d04-43e0-827e-fe28acd02168', NULL, NULL, 'Bananas', 1.000, '0cf8f21a-3455-45f5-a61e-7cae190755d8', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-02 21:38:18.735587+00', '2026-11-02 21:38:18.735587+00', 'c9e17da0-af64-4058-b18d-d3383cbbbd2f', NULL);


--
-- Data for Name: shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_lists (id, organization_id, name, status, completed_at, archived_at, created_by, created_at, updated_at) VALUES ('0faddacc-8d04-43e0-827e-fe28acd02168', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Weekly shop', 'active', NULL, NULL, '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.730793+00', '2026-11-02 21:38:18.730796+00');


--
-- Data for Name: stock_anchors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c68f686d-8174-49f6-b6e1-90d5026d119f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('35a73512-8985-4809-94eb-181e268d82d5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5512b538-4212-49a5-948b-6cb6f1d3a53e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '6ff4b2d0-15af-49fc-a4c3-a1c764cab204', '0de06468-a565-463c-bf8f-4fe2abf476c8', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5aabf0d2-9250-4318-972e-101aec23ad3b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'fd58696b-450b-42d5-9a06-8f088f7af9ab', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('af600d32-b0a3-4468-bdf5-a82411fe5c56', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9955997a-c562-416c-ae45-18cd3189997f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4850e73d-f3e0-437b-978a-6286e64163b8', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f6460b2e-6f46-4390-a3a6-982ae5b4ddd1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2624d047-5f42-4ec9-8865-e51c8feb672b', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('370f7f2e-6182-48e5-b550-0a47f50b927b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('21b2105e-7ca0-40b1-9d81-8ded9aa53122', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('601e0abe-d832-48d8-853f-c9688e01be54', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6e624b2d-4d53-446b-8305-443525967237', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '978975e2-b9a9-47ca-accc-272993e683a9', '0e17549e-2b77-4415-8a50-af6d60912ba9', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bf4f3adb-9be5-4e83-89d5-ebb2e1e4af17', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('65a8d00d-d435-48d1-8232-1eae8b20331f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cd830e3d-8321-4d30-9672-d91d272e997c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d059874-8aa6-440f-ac9f-f87497631322', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('03ccddcd-19ed-449c-a81b-4341ccc5ac3b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ac6440cf-13bd-4a34-8da6-ad89c6d29e49', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('64007b7a-8b25-4803-897a-9b72cb3e45a8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9f3c10a3-2e8c-4f4c-a2ea-fdd1e5751f84', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '811175a1-fe78-435e-ae2b-65c46cdc638f', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e20a2ade-ae31-4c5d-8d2e-e5b91d377adf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e6285d7c-3b07-4690-ad1b-241fccb186c2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('20bfd608-ac87-48c8-b996-c955f201415a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '72bdce9f-7935-43fd-927c-2d567cf5d756', '0e17549e-2b77-4415-8a50-af6d60912ba9', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ddb77790-2753-4e9c-b112-65b55665a319', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('806a6a71-d2fc-4f9c-ac9b-122c40a26f47', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '51321655-7803-4068-a127-4e7109105029', '11547469-399b-4f43-bb95-707e11abccb6', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('182d96e6-53fb-4d6f-a7d6-da44f3670089', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cc9838d2-823c-4bc2-a531-f18a59b258f5', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f492ac37-3f91-46e1-8336-0b91cee9812c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6ee38b83-ead8-47d4-929e-a8c304c68f9d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('12c7591f-83b1-43de-ad63-1179711a0546', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'fae8537d-d380-4433-973f-75d6083b9007', '0e6131a5-bab6-4d95-ae7f-1639ac331989', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f6bbc2db-dc89-4058-90d8-e3a51d1b96e3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7190ea91-16e3-47b8-81db-a8cfd3310441', '11547469-399b-4f43-bb95-707e11abccb6', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7a37650a-223d-414d-a55f-f3867bdce347', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '550d3d31-b672-4970-9b5e-c340b8762506', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c319b8ac-fe20-43fd-97fc-07b7dcfff16a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ae63f584-19ed-4d90-bccb-b87a10a778b0', '0d5b4d7c-869e-4267-a51b-13a7da79194a', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a1fa25a3-6496-4577-b037-2ac53b5c0a7d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d74ee73-5c5c-4b0c-bd20-6b5eba9dda07', 'eec06978-11eb-4b74-a829-6106e5193a1a', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7d12f2e9-8c46-4725-829b-4481db9a2440', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('43539eda-9d31-449c-a74a-001c8ef0fa83', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '240939e0-2b81-4a30-b303-e9798d591c02', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('38d7a4a0-099f-4daf-ab23-8f98ebaa6486', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', '0e17549e-2b77-4415-8a50-af6d60912ba9', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0177c949-2db1-4b87-8be6-a5b674a563ab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('02c544b1-5048-4a3e-b38c-dd50aeccae22', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '72f02ab4-94c5-476a-8e82-53b361859d75', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('962b905b-b891-4752-bc18-2b0ac654948d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7b3b5462-0278-4759-8945-f9ae3ae536b6', 'eec06978-11eb-4b74-a829-6106e5193a1a', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0a38c428-2239-4441-9237-097ad8e10f21', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8f0c1f16-0931-4424-b79a-aa1dc5519c11', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1eaffd52-b35f-4d19-84a0-97d77c60bc97', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', '0de06468-a565-463c-bf8f-4fe2abf476c8', '2026-11-02 21:38:15.054921+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('18d80962-624c-489b-a4c0-30893a3fc650', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0b643e5a-6b31-4825-b49a-122f7fab94d9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e8d5efb4-17c9-4f0a-a754-20a48709a32c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('474fbd0b-e4b8-4d77-844f-167418d0472a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', '3d9a68be-2319-450a-91dd-07216b4b58b9', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('308309ff-3ab2-405e-b6c8-902cdea04914', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', 'd093050d-72ad-4663-840d-0b563efd6d55', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('84e1bf02-3eeb-46ab-b22e-8ac9c4d760a4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', 'f7f1c414-5e10-4093-bd27-f232bb078e47', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('43fb8a9b-b779-49c2-b4f8-0d519ebb3985', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ec33341b-a077-4d01-9c39-0c3d8fc58e95', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8cbd55b2-e61b-4480-ab4c-9e8aa99f93c0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('84e5ac50-6c1b-4fde-a9e8-5cd39c6a773f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2dfee0f6-1f16-4e5b-925c-4dbd6ce5e48f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('39cff541-4318-437b-80a3-075b27467d64', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('391441d4-ae0a-4df2-9530-f289a3120d8b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('39206c5e-fbb9-4cc4-9665-f1aafcca99b8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db2ce2d0-bd7d-4ffd-9e6b-4e1932aa6d01', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('11818137-cde1-4c3f-bd05-bf6c5f96568a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd3780b77-589a-4b0c-9fc0-cd81c5548b8f', '8fd38393-964a-4094-add7-0baa69d27380', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('666386b2-6de2-4b7d-8d04-2130b1253bfa', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c9032a28-5d75-4c27-b76b-432a1580c400', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('29e74eed-adc8-4f51-9f22-c12f895d5265', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', 'f7f1c414-5e10-4093-bd27-f232bb078e47', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c004a005-4596-458a-8b06-9e4c5ff9942e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('51dd11c6-8c1b-4ad0-ad02-d15378fdebe1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 'd093050d-72ad-4663-840d-0b563efd6d55', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('69c756fa-aa9a-4a52-aed7-5ca95dcf1a13', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9fb16f3e-ef52-4c6b-bc1a-00be567679cf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5ad6d999-2e00-4475-8550-31eb6ea01fe9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3266d4cd-1f0a-4626-a2e2-16e5cfa5c7ff', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 'f7f1c414-5e10-4093-bd27-f232bb078e47', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0509c00b-f67d-4f92-8c2a-837c66518400', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('37484eae-e70d-4487-a8b1-9414497702d8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e06688dc-4104-4437-91e9-6775432281ca', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('aeb4f25d-2227-40b5-bcae-87b99a0a7e4d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f56dec64-5848-4a67-87c1-a77151e7df3d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'b5aa9619-72e3-4706-87cb-29c56478ab7c', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1123d031-3ac3-4b81-8381-0c4924457db6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ab83a72c-e54a-4664-bad6-5898cafcdf36', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('718c16c4-09c5-4809-b858-ed80d394bb1c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f3388cee-6ac9-4612-9be8-9481ecd66d4c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('226ece57-3852-4d15-9128-ef3a95edb126', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('000cd014-9641-4ee0-84fc-76c506adfbc4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('26bc06fd-a951-4650-891c-a532962dd3c6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('93942e7e-7706-48b8-b7f1-82355cb76be3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('dc700358-66c4-43b0-b690-ee4561b52d46', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f1f20473-aa4a-43ac-a62a-199bc7dc031c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4c903348-7d9c-42aa-862d-d903f7a16e1c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9f59b212-5228-48cf-a250-dd7e6c2c2a71', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('20645804-949d-48c2-a937-dae471071bd3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('20abf29c-0288-463f-ab49-c15b6df238cb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b369ebb4-dca9-4c36-95d9-82152f465141', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', '3d9a68be-2319-450a-91dd-07216b4b58b9', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ac8f69ab-8f5e-4b80-ad83-064106b6b8ab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 'd093050d-72ad-4663-840d-0b563efd6d55', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('20adeafb-9c72-4735-9696-b2c3b83b9fc6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('52d43329-83ed-4560-98a8-589591e580c0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('80974d0a-6923-4866-b636-9cffdf01ae52', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', 'd093050d-72ad-4663-840d-0b563efd6d55', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5e303012-b1d6-4d02-862a-a785c1145e71', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', '8fd38393-964a-4094-add7-0baa69d27380', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6fd49510-ee88-4b38-87ee-8e1407eb9e03', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '22f82d93-9a18-4d55-bdf0-2375e9548227', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a517b771-8144-433f-a87f-4aca26a8618d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d6899a91-6d71-48f6-99e9-d81a6e58bbdf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 'd093050d-72ad-4663-840d-0b563efd6d55', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7173073e-986e-403a-9c80-76e9832fe5ea', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f1a21bd2-2c9d-41a6-a6ed-a2941dd4ad6b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('98868424-db78-44cb-938f-a1299b32839b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0d3ea5aa-8a76-4bb6-a513-4f9f27cb1b6e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4a1baa88-ce6f-4404-b469-f5bca5c5eb70', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13a8b910-883c-4d3d-9fda-3d14c1d8ac5e', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3c2021b6-c9f8-4572-b0d9-3f9431094eba', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('15ba1ae0-b692-49ac-8fdc-cbde7964c17b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3c68d349-8e8d-4aa7-8029-007e46f6fa26', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 'cd904356-14c5-4fda-aada-68590ffeb22c', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f065d442-00a5-470e-a2c7-f0c16b29013c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 'f7f1c414-5e10-4093-bd27-f232bb078e47', '2026-11-02 21:38:15.16503+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b67fcad9-16a2-43d8-a5bc-466beab89610', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '2026-11-02 21:38:15.247702+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5d3d2e6d-2b4e-4840-bf3a-fe27fb173f70', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.247702+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('63b09b2e-f874-4382-8607-798450139b6b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:15.247702+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('48720571-bd80-4df2-97b2-55e92954f85d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0f235c0d-8907-42ed-a359-c437e63adb06', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '2026-11-02 21:38:16.338448+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4fedb70a-4c66-4cac-99fb-74667ca91182', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '2026-11-02 21:38:16.338448+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('08ceb310-4c8d-4606-b0b5-deaa55ce7727', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '11547469-399b-4f43-bb95-707e11abccb6', '2026-11-02 21:38:16.338448+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1a7648ce-cf2c-4f0c-9eff-02dd1ea7fb02', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b058779-639f-4d34-9201-7dc78d9700fd', '11547469-399b-4f43-bb95-707e11abccb6', '2026-11-02 21:38:16.338448+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6a563b56-4d1c-475a-9a75-4fb4a197a35e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:16.338448+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5f0ff58e-f8ef-4f90-ad1d-f9654782783a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', '2026-11-02 21:38:16.338448+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('aaeeab28-c365-4359-9f07-e85f8b907f27', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', '2026-11-02 21:38:18.45413+00');


--
-- Data for Name: stock_ledger_totals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', '3d9a68be-2319-450a-91dd-07216b4b58b9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'b5aa9619-72e3-4706-87cb-29c56478ab7c', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9f59b212-5228-48cf-a250-dd7e6c2c2a71', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 'd093050d-72ad-4663-840d-0b563efd6d55', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'c9032a28-5d75-4c27-b76b-432a1580c400', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'd3780b77-589a-4b0c-9fc0-cd81c5548b8f', '8fd38393-964a-4094-add7-0baa69d27380', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '22f82d93-9a18-4d55-bdf0-2375e9548227', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'db2ce2d0-bd7d-4ffd-9e6b-4e1932aa6d01', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', '8fd38393-964a-4094-add7-0baa69d27380', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '13a8b910-883c-4d3d-9fda-3d14c1d8ac5e', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', '3d9a68be-2319-450a-91dd-07216b4b58b9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '6ff4b2d0-15af-49fc-a4c3-a1c764cab204', '0de06468-a565-463c-bf8f-4fe2abf476c8', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'fd58696b-450b-42d5-9a06-8f088f7af9ab', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '4850e73d-f3e0-437b-978a-6286e64163b8', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '2624d047-5f42-4ec9-8865-e51c8feb672b', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '978975e2-b9a9-47ca-accc-272993e683a9', '0e17549e-2b77-4415-8a50-af6d60912ba9', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 33.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '5d059874-8aa6-440f-ac9f-f87497631322', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'ac6440cf-13bd-4a34-8da6-ad89c6d29e49', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '811175a1-fe78-435e-ae2b-65c46cdc638f', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '72bdce9f-7935-43fd-927c-2d567cf5d756', '0e17549e-2b77-4415-8a50-af6d60912ba9', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '51321655-7803-4068-a127-4e7109105029', '11547469-399b-4f43-bb95-707e11abccb6', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'cc9838d2-823c-4bc2-a531-f18a59b258f5', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'fae8537d-d380-4433-973f-75d6083b9007', '0e6131a5-bab6-4d95-ae7f-1639ac331989', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '550d3d31-b672-4970-9b5e-c340b8762506', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 9.900);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '7190ea91-16e3-47b8-81db-a8cfd3310441', '11547469-399b-4f43-bb95-707e11abccb6', 6.800);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'ae63f584-19ed-4d90-bccb-b87a10a778b0', '0d5b4d7c-869e-4267-a51b-13a7da79194a', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '5d74ee73-5c5c-4b0c-bd20-6b5eba9dda07', 'eec06978-11eb-4b74-a829-6106e5193a1a', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 18.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '240939e0-2b81-4a30-b303-e9798d591c02', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', '0e17549e-2b77-4415-8a50-af6d60912ba9', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '11547469-399b-4f43-bb95-707e11abccb6', 50.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '72f02ab4-94c5-476a-8e82-53b361859d75', '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '5b058779-639f-4d34-9201-7dc78d9700fd', '11547469-399b-4f43-bb95-707e11abccb6', 15.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 11.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '7b3b5462-0278-4759-8945-f9ae3ae536b6', 'eec06978-11eb-4b74-a829-6106e5193a1a', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '8f0c1f16-0931-4424-b79a-aa1dc5519c11', 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', '0de06468-a565-463c-bf8f-4fe2abf476c8', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 13.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 21.220);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 0.440);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 11.400);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '0f235c0d-8907-42ed-a359-c437e63adb06', '4b863cdb-567d-4e88-8c7e-ba625b663c95', 36.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('d6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 5.000);


--
-- Data for Name: stock_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_moves; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cd49a13f-18a9-4d94-ae8c-132eb8216c3c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', NULL, 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6f3c5029-24db-42b7-9a43-5872b29ab342', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2023-09-16 07:00:00+00', '2026-11-02 21:38:15.312595+00', '2023-09-16 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3f936e1f-c9e7-49d7-856c-ccc9243e843d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1a1d200d-1872-4672-9387-3da852b2deaf', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2023-10-17 08:07:00+00', '2026-11-02 21:38:15.331111+00', '2023-10-17 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('88fe6d9d-f7fc-4355-98ba-53cbc314fe3a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '39868387-27dc-4418-8a5c-9af20c3b4302', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2023-10-19 09:14:00+00', '2026-11-02 21:38:15.337781+00', '2023-10-19 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('99bf9d29-c814-4dd8-be59-1958fc5dd44b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '557c5fbd-24cc-47c1-a0fe-02c99f8e229e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2023-11-19 10:21:00+00', '2026-11-02 21:38:15.344397+00', '2023-11-19 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7e4c184b-7ebd-42c9-8ab8-dea2fed8a29d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e157bcce-b0e3-42e8-a2a7-6f53de1a917f', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2023-11-21 11:28:00+00', '2026-11-02 21:38:15.351765+00', '2023-11-21 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a237f31b-f54b-4ed8-8f59-83df50a4c153', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7a0cc931-72cd-4eaf-970d-3564938ce1d2', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2023-12-22 12:35:00+00', '2026-11-02 21:38:15.359732+00', '2023-12-22 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cc299b74-94ea-404d-8c0d-170f9c987c18', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c1deaa2c-495b-4e58-bab4-4c04c447fabf', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-01-22 13:42:00+00', '2026-11-02 21:38:15.366694+00', '2024-01-22 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('43e7d7ab-2cd4-4e89-bdb2-f5a5f965633e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, '3d9a68be-2319-450a-91dd-07216b4b58b9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '71c0894f-f530-450a-b047-59f085c7c636', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-01-24 14:49:00+00', '2026-11-02 21:38:15.373164+00', '2024-01-24 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d976002a-7709-475b-80ef-cdf7b20d7e3e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a70733bb-7dbf-4c12-90fb-0a9a7b7cbec2', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-02-24 15:56:00+00', '2026-11-02 21:38:15.378745+00', '2024-02-24 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('af322295-e77d-4535-9d5c-4dd80ef10b69', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a275d173-0f04-4f06-9a4a-73f70ebd6c77', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-02-26 16:03:00+00', '2026-11-02 21:38:15.387189+00', '2024-02-26 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7c83098c-6b81-435b-b0ad-6744cf48a96f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', NULL, 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a0800287-82ef-4d5b-a1ae-97228f3d470d', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-03-28 07:10:00+00', '2026-11-02 21:38:15.392744+00', '2024-03-28 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2b947151-1c80-4e9c-a491-124f11f969b4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', NULL, '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '22cf5f5c-4203-4ed0-8fa1-632a910661f8', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-04-28 08:17:00+00', '2026-11-02 21:38:15.397501+00', '2024-04-28 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0803ff6f-60f2-483d-a9e9-80e99e1d5f82', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bb6334b6-d852-4728-87cb-e9d8d40eba07', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-04-30 09:24:00+00', '2026-11-02 21:38:15.40205+00', '2024-04-30 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('14920e5e-4379-41a2-bb6e-7ddbf1f170bb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', NULL, 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '69a09b60-737c-4996-82c2-cc94b1498cfb', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-05-31 10:31:00+00', '2026-11-02 21:38:15.408868+00', '2024-05-31 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('12e927e2-4648-4054-adf2-4a0a9a183ee0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6d22aa1b-d598-495d-b607-5c4b897a339c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-06-02 11:38:00+00', '2026-11-02 21:38:15.415456+00', '2024-06-02 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7c0b4c23-6629-4577-bedb-9e3da1aeef18', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3766caf2-10a3-4ea5-83a4-4c62b81127cd', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-07-03 12:45:00+00', '2026-11-02 21:38:15.422908+00', '2024-07-03 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('12f1551c-6286-4e9a-90ff-4c89446d0d01', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '76f512bb-17fb-4844-9e73-44f30278d719', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-07-05 13:52:00+00', '2026-11-02 21:38:15.428984+00', '2024-07-05 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('33fb5ec8-21c1-46f2-8888-4688cf31b362', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2b78ab9a-854f-4613-9596-796d9b21667a', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-08-03 14:59:00+00', '2026-11-02 21:38:15.434248+00', '2024-08-03 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dc6b964d-eca7-4cea-8786-49e80a738a8a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b47d3313-fe4c-4775-bdff-3639e6fadb02', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-08-05 15:06:00+00', '2026-11-02 21:38:15.441029+00', '2024-08-05 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f722751c-aac2-4bf5-92c5-f26cba894725', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b1ec6155-6be0-4e75-b8f7-01ceeff9499e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-09-05 16:13:00+00', '2026-11-02 21:38:15.447708+00', '2024-09-05 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b550ddc9-e15d-491c-86d9-ba1b07923b21', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5106f32b-9108-4b77-a439-aff49286b1d9', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-09-07 07:20:00+00', '2026-11-02 21:38:15.454143+00', '2024-09-07 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('70e7cc90-25d7-4f18-b0fc-d0b4b0a46406', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'b5aa9619-72e3-4706-87cb-29c56478ab7c', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5d5b0d6a-66e6-41ac-b226-85e7abff3814', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-10-08 08:27:00+00', '2026-11-02 21:38:15.462497+00', '2024-10-08 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e132c24d-869f-490a-9422-6960923c309c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7d71576b-33af-4f5e-817b-a5f1cdc7c3b9', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-10-10 09:34:00+00', '2026-11-02 21:38:15.470951+00', '2024-10-10 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('164d0481-7c7b-42d8-9489-8b6d68bd6dc8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e4a59d93-6182-4220-918c-7fdb6f98ce0a', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-11-08 10:41:00+00', '2026-11-02 21:38:15.47691+00', '2024-11-08 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ec62c2d8-c3d1-4447-9d80-96641b14ce3c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9f59b212-5228-48cf-a250-dd7e6c2c2a71', NULL, 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f6788973-a56c-4982-b79f-6bb34f36ada3', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-11-10 11:48:00+00', '2026-11-02 21:38:15.482566+00', '2024-11-10 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c9826a40-6f5c-4ce5-af88-89fef1f11781', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', NULL, 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '05804795-7a6f-43dc-9f54-c36d12062589', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-12-11 12:55:00+00', '2026-11-02 21:38:15.488109+00', '2024-12-11 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('86144347-0e81-452f-be12-c9ed04534ecc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0cad6224-18cd-4fb1-9558-bacbb30fe163', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2024-12-13 13:02:00+00', '2026-11-02 21:38:15.49278+00', '2024-12-13 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ca979e70-8a56-48fd-99e1-b4b9bb4a4dce', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd0832f10-c70b-406a-bb90-779e5386996d', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-01-13 14:09:00+00', '2026-11-02 21:38:15.499613+00', '2025-01-13 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('97cbc5fc-f6c4-4d18-a9db-5334b955d0a4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '51ce3a22-e8bb-4915-a707-26ab4d4776da', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-01-15 15:16:00+00', '2026-11-02 21:38:15.506186+00', '2025-01-15 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e48c3bce-cef5-43d1-851c-c9c618c50d9c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0bb9ec16-a15b-4fec-9347-da84d4d3bb63', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-02-13 16:23:00+00', '2026-11-02 21:38:15.513294+00', '2025-02-13 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dc1b46de-43fe-46dd-8fca-26d4c8ca09a4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '30475588-c340-4613-b56a-7e71aa945477', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-02-15 07:30:00+00', '2026-11-02 21:38:15.520267+00', '2025-02-15 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d53f6026-f693-4631-b3d9-2d6625bf0d50', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c9032a28-5d75-4c27-b76b-432a1580c400', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1c2dd79c-8ac5-4dbc-875a-177ee1a94d8e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-03-18 08:37:00+00', '2026-11-02 21:38:15.527577+00', '2025-03-18 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('023d724d-9460-4c15-853b-8be82206898f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'adffa7da-107d-4a21-9ef7-d7c2399b7d34', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-03-20 09:44:00+00', '2026-11-02 21:38:15.534604+00', '2025-03-20 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f9b35cac-906b-4b2c-9e3f-f78784ef6016', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'beab2939-2add-491e-99bb-8d30a7d8e929', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-04-20 10:51:00+00', '2026-11-02 21:38:15.54257+00', '2025-04-20 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('75ab402e-783f-4df9-8876-c09f170adb2f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '323d45d7-73a0-4fdf-91ab-7b816621d4d3', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-04-22 11:58:00+00', '2026-11-02 21:38:15.548078+00', '2025-04-22 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('881d92e8-f183-483b-b291-7d6aaf4b25dc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '924a4ca6-715c-45d6-aab0-09f34f2f91b8', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-05-21 12:05:00+00', '2026-11-02 21:38:15.554819+00', '2025-05-21 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('48963b0f-d2bd-4274-a0c3-6cbbe6b542d3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b7604578-514b-400b-ace3-ccd9dc5f7f8e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-05-23 13:12:00+00', '2026-11-02 21:38:15.56387+00', '2025-05-23 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e41bc9c9-0cae-4f24-8013-5f8babf561f9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd3780b77-589a-4b0c-9fc0-cd81c5548b8f', NULL, '8fd38393-964a-4094-add7-0baa69d27380', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0fd8aae9-7a10-41d4-89ac-837d8808149c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-06-23 14:19:00+00', '2026-11-02 21:38:15.570432+00', '2025-06-23 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2a551133-282a-4560-b688-e653d3e46d76', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '22f82d93-9a18-4d55-bdf0-2375e9548227', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd70ca8a9-998e-40f3-b2bf-f78b7c52d847', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-06-25 15:26:00+00', '2026-11-02 21:38:15.577739+00', '2025-06-25 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('31586840-f5b5-4ca8-b8fc-919bd0391522', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e59d159a-d7d6-462d-a395-9b3fd905dc9f', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-07-26 16:33:00+00', '2026-11-02 21:38:15.584529+00', '2025-07-26 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9b7e77a3-dded-4e95-a39e-d394b88cbca3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ea49a3b3-26b9-4f16-af0b-39ed1cf1e7db', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-07-28 07:40:00+00', '2026-11-02 21:38:15.591241+00', '2025-07-28 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fc2acdb4-8667-4d67-8adf-cb2ccb76905c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fab3d27a-a6f0-456c-a67b-8a931354a3bb', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-08-26 08:47:00+00', '2026-11-02 21:38:15.59739+00', '2025-08-26 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f996a39c-2f9c-4b64-bc2a-b1d51fece39d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4ae1ab3e-a35b-4c01-8b09-6790f23abbaf', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-08-28 09:54:00+00', '2026-11-02 21:38:15.603306+00', '2025-08-28 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5b8f7e6b-5cba-43d6-bcb6-decba99a69c7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db2ce2d0-bd7d-4ffd-9e6b-4e1932aa6d01', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '84d6ddf5-9827-4721-af51-09e25737d35f', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-09-28 10:01:00+00', '2026-11-02 21:38:15.611356+00', '2025-09-28 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1cd0a350-1feb-403f-a870-cca8b042f639', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', NULL, '8fd38393-964a-4094-add7-0baa69d27380', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0939c0d3-bd22-4e80-a659-31bf9d38b8db', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-09-30 11:08:00+00', '2026-11-02 21:38:15.617987+00', '2025-09-30 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('82a6b99a-e445-442c-b9f5-408211827f16', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 'ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0dc3b89d-b103-4d2d-933c-feecf85c064d', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-10-31 12:15:00+00', '2026-11-02 21:38:15.625548+00', '2025-10-31 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ba045871-86d1-4e5b-8361-e22800bca9ab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13a8b910-883c-4d3d-9fda-3d14c1d8ac5e', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'dbe8bf35-3617-4a8b-b2a2-9d7044c3165c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-11-02 13:22:00+00', '2026-11-02 21:38:15.632787+00', '2025-11-02 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('49a89dc6-fcd8-40ed-89fd-9fe7e7ecf2ca', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', NULL, '3d9a68be-2319-450a-91dd-07216b4b58b9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '70065571-f474-4978-8e86-793819fab86a', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-12-01 14:29:00+00', '2026-11-02 21:38:15.638407+00', '2025-12-01 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ec823b14-81b8-44ec-b38c-4558c610c19a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd2f8b788-3927-4ea1-b686-d01f15ef4f12', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2025-12-03 15:36:00+00', '2026-11-02 21:38:15.644591+00', '2025-12-03 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d475d0af-ec12-4957-a715-5a7cbd2c5411', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1447ad8c-b49f-4391-8b6a-66f27388e5ce', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-01-03 16:43:00+00', '2026-11-02 21:38:15.649618+00', '2026-01-03 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('905ee378-4b01-4b1b-b258-9578480a6607', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', NULL, 'd093050d-72ad-4663-840d-0b563efd6d55', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '7797842f-3baa-44bc-a164-d0dd3a504769', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-01-05 07:50:00+00', '2026-11-02 21:38:15.654879+00', '2026-01-05 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('097153cd-53c7-4adc-b61f-178dc0068873', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', NULL, 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c3b0367c-813a-476c-b764-9a59f2e9fe09', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-02-05 08:57:00+00', '2026-11-02 21:38:15.660625+00', '2026-02-05 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1971e4d2-d2af-4f1f-b26d-6eac51073064', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, '28673b78-0bf1-4f0b-ab61-4e0649a5384f', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c7baa9ca-b800-4d6e-a16c-a096da699e6e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-02-07 09:04:00+00', '2026-11-02 21:38:15.666132+00', '2026-02-07 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5bd9d3a6-59b1-48c7-b35c-26351f488964', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f6ac1916-f2bc-4e50-b5cf-ba2dd5f9c91f', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-03-08 10:11:00+00', '2026-11-02 21:38:15.672557+00', '2026-03-08 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ecf9c582-fa8c-4d99-a2bd-9afedcecda7e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a23566f4-f835-49f9-a21d-f0a6b160f344', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-03-10 11:18:00+00', '2026-11-02 21:38:15.680324+00', '2026-03-10 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d251d095-9e7c-4826-a9af-b42a7e71ef6d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '68184d4e-b725-4720-ba79-8eb744fb3ab8', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-04-10 12:25:00+00', '2026-11-02 21:38:15.684814+00', '2026-04-10 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f1f01bbc-2706-4c23-a176-fa2b82b62ced', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '95da205b-b886-4c42-8dd1-386be796cb5c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-04-12 13:32:00+00', '2026-11-02 21:38:15.69202+00', '2026-04-12 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('73d24ec8-8b86-41b8-8fa8-75d5b9de1033', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', NULL, 'f7f1c414-5e10-4093-bd27-f232bb078e47', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9235a76b-7e41-45e3-a6d6-bc7c91a41840', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-05-13 14:39:00+00', '2026-11-02 21:38:15.698683+00', '2026-05-13 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c5649bba-5b94-4283-a704-bf89f75ecf1c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0405996d-101a-458c-b352-c146ceecd3c1', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-05-15 15:46:00+00', '2026-11-02 21:38:15.705087+00', '2026-05-15 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('801a0707-17b6-45a4-94ca-6a997e42c8ec', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b90f9f0c-3a4b-4e25-8f89-29c37d2d21f0', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-06-13 16:53:00+00', '2026-11-02 21:38:15.710819+00', '2026-06-13 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dd24e8bf-65bd-4444-a195-948f94c37103', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '804acbd4-3267-4033-a2c5-0bdeec36b9c9', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-06-15 07:00:00+00', '2026-11-02 21:38:15.716006+00', '2026-06-15 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('da858b86-8f45-4fd9-8b28-f8002155c071', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 'f8d40ee5-f923-4354-9050-6e350bb32fd3', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4aba876e-e8d6-4388-bf0f-1551c82b61aa', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-07-16 08:07:00+00', '2026-11-02 21:38:15.722409+00', '2026-07-16 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e28b5152-81c7-4c81-aeac-cf8d0d5945cf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 'cd904356-14c5-4fda-aada-68590ffeb22c', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '59185ada-a555-4355-ab11-980bbdc12c4b', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-07-18 09:14:00+00', '2026-11-02 21:38:15.73+00', '2026-07-18 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('83cb102c-21dc-4d70-a049-6cc1c52d673d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'add83e2a-2b9b-4376-8542-ee44d4d83fa2', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-08-18 10:21:00+00', '2026-11-02 21:38:15.734664+00', '2026-08-18 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('29591ffe-b4fc-46d9-8e8d-e1f93626b6a8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 'bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '06a8d70d-6616-450e-affc-20a51018ac33', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-08-20 11:28:00+00', '2026-11-02 21:38:15.737965+00', '2026-08-20 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bcbf697e-5da4-434d-80ba-d44f3caae31b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 'a0d877e1-da04-4af0-aedf-7e9b409bfed2', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1ef51736-b7f9-477c-8e58-b2d637afddd9', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-18 12:35:00+00', '2026-11-02 21:38:15.744949+00', '2026-09-18 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b150644d-9eb1-49e6-962a-7995033e25d4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'cdd737cb-6026-4382-8319-b6d773f2b183', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-26 13:42:00+00', '2026-11-02 21:38:15.749008+00', '2026-10-26 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('628766bf-7773-420d-9fc0-82fffc7f5202', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', NULL, '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd403c5d5-4291-4150-a533-8e2d42421b66', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-15 14:49:00+00', '2026-11-02 21:38:15.757348+00', '2026-10-15 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('abc59b40-b074-4cc1-8e12-0771d696c38b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '6ff4b2d0-15af-49fc-a4c3-a1c764cab204', NULL, '0de06468-a565-463c-bf8f-4fe2abf476c8', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '8f550850-d5ef-4f72-8e15-de1ff9b34c41', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-04 15:56:00+00', '2026-11-02 21:38:15.763046+00', '2026-10-04 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('689622f9-be19-4029-a960-748b5145e186', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'fd58696b-450b-42d5-9a06-8f088f7af9ab', NULL, '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a86b2e7e-1eb9-4c13-babf-a6260d3e4118', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-23 16:03:00+00', '2026-11-02 21:38:15.769352+00', '2026-09-23 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8daaa803-cdd6-4c45-82a4-9a2cc5a87589', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', NULL, '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', '50ccecf1-6858-432c-b6d7-3150e0f73a42', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-12 07:10:00+00', '2026-11-02 21:38:15.775454+00', '2026-09-12 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c424e45f-251d-47a2-ba01-63d968b27b47', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4850e73d-f3e0-437b-978a-6286e64163b8', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '7ff50584-14e7-4ff1-be1f-ddffe7d57671', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-01 08:17:00+00', '2026-11-02 21:38:15.780855+00', '2026-09-01 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e5509307-2919-4767-9f57-220ff685ac9e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2624d047-5f42-4ec9-8865-e51c8feb672b', NULL, '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd84ca6ca-09bf-43e5-9b21-c50ffe869123', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-24 09:24:00+00', '2026-11-02 21:38:15.786017+00', '2026-10-24 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ead38cdf-da3e-4264-ab6e-51106efcd8e8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', NULL, '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '91a89320-724b-48a2-b110-8fd4b9c32464', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-13 10:31:00+00', '2026-11-02 21:38:15.791135+00', '2026-10-13 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0a8dbcfb-34c5-428b-84cc-39c77e5cdaf5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a06f7097-e2d8-42a0-940d-d9889d275091', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-02 11:38:00+00', '2026-11-02 21:38:15.795926+00', '2026-10-02 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('82c9c3a9-ca26-4349-8995-219ed4ffd470', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', NULL, '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'dcf1dc07-091a-4d71-af58-ddf7bfbcf735', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-21 12:45:00+00', '2026-11-02 21:38:15.801482+00', '2026-09-21 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1aafa198-7f47-4e5b-aa20-8419e03dd130', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '978975e2-b9a9-47ca-accc-272993e683a9', NULL, '0e17549e-2b77-4415-8a50-af6d60912ba9', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '25238103-9ba7-4a2d-ba45-85aa28b2a317', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-10 13:52:00+00', '2026-11-02 21:38:15.80718+00', '2026-09-10 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ea94e30e-d1e5-41e0-9f60-53bf2dc6a247', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '5ba05648-4e80-4f35-aaa2-c33817fd6d8e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-27 14:59:00+00', '2026-11-02 21:38:15.812701+00', '2026-10-27 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('20108223-655e-4cd6-b0a9-7e198308126d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', NULL, '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '8dbe8bdf-9478-41a1-99c5-389c11a888ea', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-22 15:06:00+00', '2026-11-02 21:38:15.818845+00', '2026-10-22 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('abfce7a3-dd48-46d0-9ad3-5ad64c85088e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d059874-8aa6-440f-ac9f-f87497631322', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '7b7f4260-6baf-4a43-9e59-a51df4ef1c9c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-11 16:13:00+00', '2026-11-02 21:38:15.824561+00', '2026-10-11 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7012d377-fc22-46d9-a062-b36dd0f65f40', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ac6440cf-13bd-4a34-8da6-ad89c6d29e49', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd02ba6f8-bfbd-4bcf-8cb1-226f773cca9e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-30 07:20:00+00', '2026-11-02 21:38:15.831675+00', '2026-09-30 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5e293692-c48c-4de3-810f-f1c27b86e5ce', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '003d4d05-cd11-46e8-8a28-330f10b8977d', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-29 08:27:00+00', '2026-11-02 21:38:15.838577+00', '2026-10-29 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c2dd201c-5cee-43c2-872d-9ef49571cde6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '811175a1-fe78-435e-ae2b-65c46cdc638f', NULL, '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '875b1a35-7f5d-4311-9a4b-b2926bb52012', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-08 09:34:00+00', '2026-11-02 21:38:15.844823+00', '2026-09-08 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4e903fe4-5abb-43a0-8d37-3593cd1c2c01', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', NULL, '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '7e93df26-8f5a-4b66-994c-95dcd86c68fd', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-08-28 10:41:00+00', '2026-11-02 21:38:15.851334+00', '2026-08-28 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a3633b16-c900-4ad6-8e17-9d658bf4f8de', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '327c9ce5-3a16-43e9-a25e-07341d720878', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-20 11:48:00+00', '2026-11-02 21:38:15.857011+00', '2026-10-20 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('016a6d92-8ce3-4e3c-8239-64cf6a7bd9d1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '72bdce9f-7935-43fd-927c-2d567cf5d756', NULL, '0e17549e-2b77-4415-8a50-af6d60912ba9', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '81b9a033-5eba-4094-9c44-baf2d45c77cd', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-09 12:55:00+00', '2026-11-02 21:38:15.863356+00', '2026-10-09 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a6390834-844b-4128-b7d6-128acbbb6e54', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '51321655-7803-4068-a127-4e7109105029', NULL, '11547469-399b-4f43-bb95-707e11abccb6', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '78d5b9ea-9b6d-46c2-b0e8-7215eb8fd825', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-29 13:02:00+00', '2026-11-02 21:38:15.869462+00', '2026-10-29 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4b9a882a-7a99-4d2f-939d-ca9e74acee38', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f9d0e5b3-3325-4893-be09-3143398ed74d', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-28 14:09:00+00', '2026-11-02 21:38:15.877255+00', '2026-09-28 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0d210cbe-3b3e-4595-834a-88226016a5b1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cc9838d2-823c-4bc2-a531-f18a59b258f5', NULL, '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '733336ba-477c-46bc-b5f0-bd6e921931ed', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-06 15:16:00+00', '2026-11-02 21:38:15.883032+00', '2026-09-06 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3a5bbdca-0176-4db7-a738-945a5fb66290', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', NULL, '98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '4972bc60-1cdf-433c-b114-8fdb5cc8f1e0', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-08-26 16:23:00+00', '2026-11-02 21:38:15.88973+00', '2026-08-26 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ea2fa560-c43d-484a-8b18-a44343e410cc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3d847c7d-87f3-4555-a5e9-61d4d340fcf9', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-18 07:30:00+00', '2026-11-02 21:38:15.895214+00', '2026-10-18 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6f99e885-8b6b-44f2-a59b-517887da09b1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'fae8537d-d380-4433-973f-75d6083b9007', NULL, '0e6131a5-bab6-4d95-ae7f-1639ac331989', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '76f4d898-19dd-4ee1-9131-320ea772ba09', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-07 08:37:00+00', '2026-11-02 21:38:15.901279+00', '2026-10-07 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('abcf015a-5544-40e3-ad1d-fb9075d8d4c5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '261f884b-1a7a-4a86-a1ba-e7596b095755', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-26 09:44:00+00', '2026-11-02 21:38:15.905857+00', '2026-09-26 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('85ce0f65-79fe-4f39-95b3-47f0e36c9ac9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '550d3d31-b672-4970-9b5e-c340b8762506', NULL, 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 9.900, NULL, NULL, NULL, 'done', 'opening_balance', '3032cdb9-2085-46d7-a034-e7e36b2be809', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-28 10:51:00+00', '2026-11-02 21:38:15.910644+00', '2026-10-28 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4e9cc6a2-dcbe-4546-9ae7-241c9c6334c0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7190ea91-16e3-47b8-81db-a8cfd3310441', NULL, '11547469-399b-4f43-bb95-707e11abccb6', 6.800, NULL, NULL, NULL, 'done', 'opening_balance', 'f9b8010b-f35d-4533-8b13-58687cb86fa5', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-29 11:58:00+00', '2026-11-02 21:38:16.104118+00', '2026-10-29 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('372b0fab-f639-4b93-80d0-9001ffe35c0e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ae63f584-19ed-4d90-bccb-b87a10a778b0', NULL, '0d5b4d7c-869e-4267-a51b-13a7da79194a', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '05e0bce9-c2cc-4a05-b68d-0ac607691dd3', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-08-24 12:05:00+00', '2026-11-02 21:38:16.112291+00', '2026-08-24 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1555e16c-56b5-4f0b-a8f3-400f4baef814', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d74ee73-5c5c-4b0c-bd20-6b5eba9dda07', NULL, 'eec06978-11eb-4b74-a829-6106e5193a1a', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '6cd7ab67-0285-4f8a-ac89-5e0d0f0e736c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-28 13:12:00+00', '2026-11-02 21:38:16.117336+00', '2026-10-28 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('233407e7-1414-4844-a4ed-2504ee02ea95', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd3466ed7-aa76-47ce-8c04-a444b6f9870e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-05 14:19:00+00', '2026-11-02 21:38:16.123335+00', '2026-10-05 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a34f3dd9-7313-4761-9d84-c48b88767813', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '240939e0-2b81-4a30-b303-e9798d591c02', NULL, '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '44f5d272-fafe-477c-8fbc-b230fd584acf', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-24 15:26:00+00', '2026-11-02 21:38:16.130357+00', '2026-09-24 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('27f757ce-f94a-4161-9091-625b0ddc9c4a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, '0e17549e-2b77-4415-8a50-af6d60912ba9', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b5e602d8-19af-4e36-a337-8632bbc91872', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-13 16:33:00+00', '2026-11-02 21:38:16.137475+00', '2026-09-13 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('74148d6e-b2b1-44b6-83b7-c2dffe6f39b2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '610d165c-e861-4aed-b29a-b3e0627829a3', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-02 07:40:00+00', '2026-11-02 21:38:16.144865+00', '2026-09-02 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('174cd72c-6bae-4312-aeaf-f3cafcb56e25', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '72f02ab4-94c5-476a-8e82-53b361859d75', NULL, '65c7b767-ecbf-4d26-834f-71c6e5f1d926', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', '537a041b-24bb-4033-be75-662dafd9340c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-14 08:47:00+00', '2026-11-02 21:38:16.151528+00', '2026-10-14 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c5392b85-d413-4f1d-a7be-fd6e1f1fe412', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', NULL, '1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', 'db52f250-7499-4813-b45b-3d7f8b0e8fdf', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-25 09:54:00+00', '2026-11-02 21:38:16.157408+00', '2026-10-25 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9c851890-9f5d-4414-807a-8c00d09c312f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7b3b5462-0278-4759-8945-f9ae3ae536b6', NULL, 'eec06978-11eb-4b74-a829-6106e5193a1a', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '00a1c1fd-f00b-40c7-991c-d8c277494eb8', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-31 10:01:00+00', '2026-11-02 21:38:16.162134+00', '2026-10-31 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('31c237e9-efef-422c-a688-92866e48049f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8f0c1f16-0931-4424-b79a-aa1dc5519c11', NULL, 'e3b6070a-033b-4c12-855b-bb78d26e9a37', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '28234322-fd99-4274-ad41-879d12e6f44c', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-30 11:08:00+00', '2026-11-02 21:38:16.166588+00', '2026-10-30 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5e426d3d-3a92-4ed1-98a6-3f2f2114221c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', NULL, '0de06468-a565-463c-bf8f-4fe2abf476c8', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', '646dfcc4-3297-4534-83be-3b20867c6926', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-11 12:15:00+00', '2026-11-02 21:38:16.173739+00', '2026-09-11 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cfee8e07-b0db-4fa5-ade9-0d7c1c1ffe1a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', 40.000, NULL, NULL, NULL, 'done', 'opening_balance', 'cf716a8c-de7d-411a-ae2d-b9b862906724', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-30 13:22:00+00', '2026-11-02 21:38:16.179955+00', '2026-10-30 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c19e19dc-1eb1-4b89-a64b-71c2ae396fd7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 25.000, NULL, NULL, NULL, 'done', 'opening_balance', '0ff3df72-b4e4-4188-b8ab-cea8be877f14', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-10-13 14:29:00+00', '2026-11-02 21:38:16.185716+00', '2026-10-13 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('95883402-9743-4392-9542-14dd2e84de47', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 0.500, NULL, NULL, NULL, 'done', 'opening_balance', 'c102148e-b102-4e49-8ef1-ed8e2a214374', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-09-29 15:36:00+00', '2026-11-02 21:38:16.191927+00', '2026-09-29 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a8285097-6154-44ae-a998-5487b28c6d85', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, 26.400, NULL, NULL, NULL, 'done', 'maker_production', '15d91c01-50ef-43c3-a1a1-e1924089351e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.59168+00', '2026-11-02 21:38:18.591682+00', '2026-11-02 21:38:18.590903+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e19cb3ca-a8c8-43c6-bdf4-71d12d459178', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', NULL, 3.780, NULL, NULL, NULL, 'done', 'maker_production', '15d91c01-50ef-43c3-a1a1-e1924089351e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.620282+00', '2026-11-02 21:38:18.620283+00', '2026-11-02 21:38:18.620141+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dd45fa9a-7cfa-4bb8-9270-f98651d127e9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', NULL, 0.060, NULL, NULL, NULL, 'done', 'maker_production', '15d91c01-50ef-43c3-a1a1-e1924089351e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.639974+00', '2026-11-02 21:38:18.639976+00', '2026-11-02 21:38:18.6398+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1ef9da4d-291b-4326-9331-37320b0a43fa', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', NULL, 'd44a51bc-01a1-472d-9e2b-273bf1864c2d', 11.400, NULL, NULL, NULL, 'done', 'maker_production', '15d91c01-50ef-43c3-a1a1-e1924089351e', '2b510efc-b831-4b48-97e3-18a8659cf00f', '2026-11-02 21:38:18.662749+00', '2026-11-02 21:38:18.66275+00', '2026-11-02 21:38:18.662333+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('052e05e5-08f2-49c8-84bb-653b5e7ec152', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 3.000, NULL, NULL, NULL, 'done', 'document', '996934c0-215a-4ab4-af9c-44fbcbd8eb04', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-10-16 10:50:00+00', '2026-11-02 21:38:18.856044+00', '2026-10-16 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ff1e6c7d-2ed1-410e-b2a0-bc879bc09e3e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0f235c0d-8907-42ed-a359-c437e63adb06', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', 48.000, NULL, NULL, NULL, 'done', 'document', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-24 13:30:00+00', '2026-11-02 21:38:18.862382+00', '2026-10-24 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f4f0bcd7-9b56-4d00-8858-42f90f561f6e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', 24.000, NULL, NULL, NULL, 'done', 'document', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-24 13:30:00+00', '2026-11-02 21:38:18.862382+00', '2026-10-24 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('db7c8158-1e63-40c4-98bd-5a9032403686', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', 36.000, NULL, NULL, NULL, 'done', 'document', '6fb0b4a2-1f14-4548-a3e9-3b99c202d91f', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-24 13:30:00+00', '2026-11-02 21:38:18.862382+00', '2026-10-24 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a07706c1-84d6-4a43-b47b-e7d97c244600', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', NULL, '11547469-399b-4f43-bb95-707e11abccb6', 60.000, NULL, NULL, NULL, 'done', 'document', 'c5e7cff4-5b85-4212-8f9a-2938457e9aec', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-10-26 13:30:00+00', '2026-11-02 21:38:18.864334+00', '2026-10-26 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cddca019-854b-40d1-98ca-7a06b7006747', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b058779-639f-4d34-9201-7dc78d9700fd', NULL, '11547469-399b-4f43-bb95-707e11abccb6', 20.000, NULL, NULL, NULL, 'done', 'document', 'c5e7cff4-5b85-4212-8f9a-2938457e9aec', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-10-26 13:30:00+00', '2026-11-02 21:38:18.864334+00', '2026-10-26 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5c2b707e-b2ae-4a04-a97d-b1c5066ac9cb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0f235c0d-8907-42ed-a359-c437e63adb06', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, 12.000, NULL, NULL, NULL, 'done', 'document', '316f5842-f2c4-4251-a9f4-07ba08aae11f', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-29 12:15:00+00', '2026-11-02 21:38:18.865914+00', '2026-10-29 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bd6dabdb-9feb-4f08-bd1b-7570d584c23d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, 8.000, NULL, NULL, NULL, 'done', 'document', '316f5842-f2c4-4251-a9f4-07ba08aae11f', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-29 12:15:00+00', '2026-11-02 21:38:18.865914+00', '2026-10-29 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6455e17e-e21c-49d7-8666-c13821ad2f5c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 5.000, NULL, NULL, NULL, 'done', 'document', '560a4701-fc32-4747-8331-b7521c0e2883', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-31 13:30:00+00', '2026-11-02 21:38:18.867952+00', '2026-10-31 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('412a1866-74af-439d-ad88-e24da4177063', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', NULL, 'db23efde-1a25-4356-9e42-4c8e5ddc0beb', 3.000, NULL, NULL, NULL, 'done', 'document', '560a4701-fc32-4747-8331-b7521c0e2883', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-10-31 13:30:00+00', '2026-11-02 21:38:18.867952+00', '2026-10-31 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a6b6a276-ab72-4035-9594-cc7bccfab60b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, 6.000, NULL, NULL, NULL, 'done', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-11-01 14:00:00+00', '2026-11-02 21:38:18.869817+00', '2026-11-01 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4e5ac8c8-a7ab-4f17-a230-58b1deba8190', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL, 4.000, NULL, NULL, NULL, 'done', 'document', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '680ca639-edea-48fe-8eb5-a03cfdbb8852', '2026-11-01 14:00:00+00', '2026-11-02 21:38:18.869817+00', '2026-11-01 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cbbca2e3-d612-4569-83bc-e905e7c88d6c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '11547469-399b-4f43-bb95-707e11abccb6', NULL, 10.000, NULL, NULL, NULL, 'done', 'document', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-11-01 14:45:00+00', '2026-11-02 21:38:18.872141+00', '2026-11-01 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('918cb00e-3cfc-4384-9ea0-c3c5675ee6ee', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b058779-639f-4d34-9201-7dc78d9700fd', '11547469-399b-4f43-bb95-707e11abccb6', NULL, 5.000, NULL, NULL, NULL, 'done', 'document', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', '7fb93cd8-d0f5-4a14-b739-f72404792db5', '2026-11-01 14:45:00+00', '2026-11-02 21:38:18.872141+00', '2026-11-01 14:45:00+00');


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('7c325eee-3847-4a92-b3f0-f57a4447fdc3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b02e500-558e-4ea7-8328-eea1381da923', '8c0ec7bc-cdfe-479f-a83f-75fece007ee3', '08ceb310-4c8d-4606-b0b5-deaa55ce7727', NULL, NULL, 10.000, '2026-11-02 21:38:16.780134+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('d42009c0-1d2b-42a6-9e67-18d8d0b012db', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e027d414-a2ce-42a6-a730-0e69784fe4c2', '5d4a79b1-3fd8-4741-b9d9-66edce4d1ef0', '08ceb310-4c8d-4606-b0b5-deaa55ce7727', NULL, NULL, 8.000, '2026-11-02 21:38:16.912706+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('f52c5be5-69bd-48bf-bab0-add1cdb66845', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e027d414-a2ce-42a6-a730-0e69784fe4c2', '786778f9-6214-46d3-8d26-255c46d78703', '1a7648ce-cf2c-4f0c-9eff-02dd1ea7fb02', NULL, NULL, 4.000, '2026-11-02 21:38:16.921395+00');


--
-- Data for Name: stock_take_closed_locations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_counts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('360424da-db8a-4986-b554-d1dc66b47461', 'f618e380-553b-4496-9043-dd495632c21e', 'cdd737cb-6026-4382-8319-b6d773f2b183', 'Vanilla Sugar', 'Harvest Row', 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, NULL, 2.000, 1.000, NULL, NULL, NULL, 1, '2026-11-02 21:38:18.69934+00', '2026-11-02 21:38:18.699342+00', 'MISCOUNT', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('cad5c4eb-d83d-43cb-92a7-45ba25bfa0c6', 'f618e380-553b-4496-9043-dd495632c21e', 'd403c5d5-4291-4150-a533-8e2d42421b66', 'Butter Biscuits', 'Orchard & Oak', 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, NULL, 1.000, 1.000, NULL, NULL, NULL, 0, '2026-11-02 21:38:18.699343+00', '2026-11-02 21:38:18.699343+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('7d7d552f-ac1c-446d-9a7f-62b433833724', 'f618e380-553b-4496-9043-dd495632c21e', '8f550850-d5ef-4f72-8e15-de1ff9b34c41', 'Canned White Beans', 'Harvest Row', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, 9.000, 9.000, NULL, NULL, NULL, 0, '2026-11-02 21:38:18.699344+00', '2026-11-02 21:38:18.699344+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('ada29d6a-3ee0-468e-bb5c-08acf8e632df', 'f618e380-553b-4496-9043-dd495632c21e', 'a86b2e7e-1eb9-4c13-babf-a6260d3e4118', 'Dried Oregano', 'Saltmill', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, 3.000, 1.000, NULL, NULL, NULL, 1, '2026-11-02 21:38:18.699345+00', '2026-11-02 21:38:18.699345+00', 'DAMAGE', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('17137fd6-233e-4ec0-8a94-fb2fcb22e11c', 'f618e380-553b-4496-9043-dd495632c21e', '50ccecf1-6858-432c-b6d7-3150e0f73a42', 'Penne Pasta', 'Harvest Row', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, 2.000, 2.000, NULL, NULL, NULL, 0, '2026-11-02 21:38:18.699345+00', '2026-11-02 21:38:18.699346+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('e823dada-58c7-4c2b-8e2a-cadc1294e573', 'f618e380-553b-4496-9043-dd495632c21e', '7ff50584-14e7-4ff1-be1f-ddffe7d57671', 'Canned Chickpeas', 'Harvest Row', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, 9.000, 10.000, NULL, NULL, NULL, 1, '2026-11-02 21:38:18.699346+00', '2026-11-02 21:38:18.699346+00', 'WRONG_LOCATION', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('83408019-2659-4a03-bfb8-935f55fa08e8', 'f618e380-553b-4496-9043-dd495632c21e', 'd84ca6ca-09bf-43e5-9b21-c50ffe869123', 'Earl Grey Tea', 'Orchard & Oak', '9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, NULL, 1.000, 1.000, NULL, NULL, NULL, 0, '2026-11-02 21:38:18.699347+00', '2026-11-02 21:38:18.699347+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('ce343db1-23c4-4426-ae52-d89b840f86cf', 'f618e380-553b-4496-9043-dd495632c21e', '91a89320-724b-48a2-b110-8fd4b9c32464', 'Butter Biscuits', 'Orchard & Oak', 'dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, NULL, 6.000, 6.000, NULL, NULL, NULL, 0, '2026-11-02 21:38:18.699347+00', '2026-11-02 21:38:18.699348+00', NULL, false, NULL, NULL);


--
-- Data for Name: stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_takes (id, user_id, organization_id, storage_location_id, name, description, status, started_at, completed_at, notes, blind_mode, require_full_count, tolerance_percent, deleted_at, created_at, updated_at, schedule_id, adjustment_document_id) VALUES ('f618e380-553b-4496-9043-dd495632c21e', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'Dry Goods count', 'Quarterly count of the dry goods shelves.', 'completed', '2026-10-30 19:38:18.696414+00', '2026-10-30 21:38:18.696423+00', NULL, false, true, 2.00, NULL, '2026-11-02 21:38:18.697126+00', '2026-11-02 21:38:18.825839+00', NULL, NULL);


--
-- Data for Name: stock_valuation_layers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4fd11811-d0b6-482a-88af-9dafefc1a601', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2023-09-16', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.324262+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2a738df8-3c26-4d69-999e-d6fe0b1e07e4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2023-10-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.33498+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e82f894e-5f64-454c-b570-b309852a290e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 1.000, 1.000, 350.0000, 350.00, '2023-10-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.341256+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1923b9d2-2f88-4f98-a04d-8ac6f4bec6c8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2023-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.34874+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2cfd2f65-637a-4c58-b664-8bffe93840d2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2023-11-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.356323+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6547e095-8e7f-4c9b-be49-14893bf69046', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2023-12-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.363556+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('22cdf6bf-c00e-4d5e-9aaa-8950ec0cecab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2024-01-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.370084+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8d98283c-ce10-4c04-9fe9-4660b6394dfc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 1.000, 1.000, 350.0000, 350.00, '2024-01-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.376+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('37041a79-bf5e-4106-94d5-f1ae2c620282', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2024-02-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.382459+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aff555ca-3f9a-436b-95fd-c26042ee326f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-02-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.390336+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7554ed86-8968-43bb-b2ac-cee99deebd7a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-03-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.395213+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f61789e4-9cac-43eb-8863-3187f9444237', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-04-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.399988+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('75217054-ccc8-4539-9e3b-ba9dcaa99e42', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-04-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.405424+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b83e3d72-aa65-4fa9-846f-c7f72a7e7550', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cfae9b7b-7fad-47dc-be5f-76e97329c960', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2024-05-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.412568+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('247f5a0c-8c23-4d3f-b443-054e50c84c44', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-06-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.419561+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d6eae19b-0237-469b-8356-eb65a88bed62', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e57ab104-305a-4562-bb09-555ee3c0a5f5', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-07-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.426181+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f5f900cd-8fe0-4d43-bf0f-165a9ac60cb0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-07-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.43172+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('edfe6bf5-bfb0-48c7-9186-9d89fee75866', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3f194adb-f44e-4d5d-80c1-02b6dd60edc8', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-08-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.437578+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e3216626-ebad-43f7-bae7-3fb23011e974', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '63c93362-2c11-442c-a0a0-330241624822', NULL, 1.000, 1.000, 400.0000, 400.00, '2024-08-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.444749+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8893cf53-bb77-4318-9a73-5b7aee477c03', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2024-09-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.451026+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6ca9320c-9c9b-43e5-9354-59ff483df9b1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-09-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.458018+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('366df7bc-b7d0-45c9-a693-4da7f9158182', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'b5aa9619-72e3-4706-87cb-29c56478ab7c', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2024-10-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.467642+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('78c8f48a-d4d7-4eb6-a0c5-7102f6e0a1f3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-10-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.474118+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9b170bff-97ef-4caf-b5e5-336b40163c73', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2024-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.479979+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('200de863-dcfd-46e3-8e4b-cf33971f7c48', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9f59b212-5228-48cf-a250-dd7e6c2c2a71', NULL, 1.000, 1.000, 450.0000, 450.00, '2024-11-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.485361+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c81b3207-0aa3-43bd-ab59-e7a5181a094a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9b9ff3b1-258d-4abf-8728-294f35c724ae', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2024-12-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.491267+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('75a5e31c-1633-4da1-a13b-474c798c1450', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2024-12-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.496888+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4934fef2-119c-4cb7-9c9f-c3f09d7d9feb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-01-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.502864+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('57507ade-299f-46db-ac51-8494016c4956', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-01-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.51003+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3dc08068-926f-4b03-99b3-fa0ea0350a38', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2025-02-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.516932+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('51ecdb8e-79e3-42a0-8245-15b92eae09c5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-02-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.523616+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('70b24c47-eb5d-4aa0-a856-89927e5c7a08', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c9032a28-5d75-4c27-b76b-432a1580c400', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2025-03-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.53261+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e0c58d1f-3786-4b55-a800-0240f2134e4f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cb9749b7-8ba5-46af-bf97-40b5254d7880', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2025-03-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.539688+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('264272d2-f613-4279-a645-7702ebae34a0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-04-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.546286+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7f3d1165-2c70-494b-89e0-20a456d4c511', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-04-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.551756+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b874d562-1bec-4002-8a13-75683954b3a4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2025-05-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.559822+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('77ea1670-2b46-432a-8927-fdcb8b63d7fe', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e43fd5d3-d6d0-4a51-8c3b-2698c375c30c', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-05-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.567624+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5f5cf2e6-0233-4eef-9234-38e8ff0b3bbc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'd3780b77-589a-4b0c-9fc0-cd81c5548b8f', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2025-06-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.57469+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5369aa9d-6519-40ad-8c01-6b6e2a60c058', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '22f82d93-9a18-4d55-bdf0-2375e9548227', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2025-06-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.581852+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5c58d89a-a210-43c4-8086-d435986ff176', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-07-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.587924+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('74c39737-1fbb-4366-9b72-fc3d81961cc3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '58fb09d9-302d-4e60-9312-0ba414cb7a35', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-07-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.594713+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f152bd48-02fe-48c1-b6c1-006cacb6aa68', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '116b428f-f07b-4bd5-b9e0-5fa352157681', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2025-08-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.600337+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6d01430a-a349-4d62-9397-98d9314f9886', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', NULL, 1.000, 1.000, 950.0000, 950.00, '2025-08-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.60706+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3fd79f01-e1ad-447b-bef2-bae5a302b0b9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'db2ce2d0-bd7d-4ffd-9e6b-4e1932aa6d01', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-09-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.614939+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('a9b5272a-2626-417e-a081-83688618ec5a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', NULL, 1.000, 1.000, 650.0000, 650.00, '2025-09-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.621827+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8b46bcaf-2231-4bde-a7f2-6e66e49c9a98', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f5049ed0-99d0-47e7-a9a2-7935a6912c63', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.629484+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('681664f3-dc29-42c3-beed-b3eac5dd7f0f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13a8b910-883c-4d3d-9fda-3d14c1d8ac5e', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2025-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.635775+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('230e140a-5224-4074-a80a-5b2963265800', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-12-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.641022+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aa0eb7f3-a0ac-445b-ad99-04ed0e0027cb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f2932f69-4af6-4d25-8800-0727bd3eee66', NULL, 1.000, 1.000, 950.0000, 950.00, '2025-12-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.647085+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('991db156-36e3-4a87-9972-b1564e97f24e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-01-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.652251+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6d00f8ab-858c-4d89-a172-b035590406ae', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e068506d-dd84-4eb8-a7c7-5c4176203b37', NULL, 1.000, 1.000, 650.0000, 650.00, '2026-01-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.658042+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6e3cdab1-f7f2-4667-8018-29d9eb75b061', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2026-02-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.66377+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c7519097-defe-4a33-b212-ca577e71db19', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2026-02-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.668994+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5e79f7eb-80b3-42ce-9391-20a7c25dc070', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-03-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.677356+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('de5797a2-52ee-4a06-8932-81ed0db5d956', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-03-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.683383+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('26faf26b-02ea-4535-befc-b5adf6a0d196', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-04-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.68858+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('af394f84-5c61-4cc8-b4ef-e3c97be8ef7a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 1.000, 1.000, 350.0000, 350.00, '2026-04-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.69552+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('bba886a2-b3e0-40a1-8267-9c52c153c477', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2026-05-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.702232+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('73d89208-897a-4416-a273-fce886351973', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2026-05-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.708292+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4bbb03b4-6c37-43f0-872f-28f779ec609e', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-06-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.713513+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2ec4aec1-844a-46c4-95a0-e529e5846680', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d34f095-249a-4027-afa8-33fdd61f1383', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-06-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.720729+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7d7d91c8-2a50-418d-a861-5376c8c22a1b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eccbc778-64cd-44fb-a806-9889659852cb', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-07-16', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.726004+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('31663e1e-439d-44cc-8a66-15c56652dd76', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a67bbcae-4150-47ab-95f2-f418ec3b841b', NULL, 1.000, 1.000, 350.0000, 350.00, '2026-07-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.732528+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('18f1e498-32fe-45e4-b216-3776cf80d80d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'be4f49ab-92cc-4682-8edc-7b71251649e1', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2026-08-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.736766+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('642c52b0-93c3-4f8e-be40-693b1b03a4cd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '19751a32-491b-4a06-8dac-86943c9b3b66', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2026-08-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.742689+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ecf0b585-5b41-473f-8bf7-ca9a5dc57103', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-09-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.747192+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('544b96e6-1e43-4405-a1c3-f6ee81b6904f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 2.000, 2.000, 5.3000, 10.60, '2026-10-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.755392+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b17fdf97-8cea-4153-b8f9-7213fea0e2f6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', NULL, 1.000, 1.000, 4.6700, 4.67, '2026-10-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.760814+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('0da99591-78fd-4348-8df9-617f7b326010', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '6ff4b2d0-15af-49fc-a4c3-a1c764cab204', NULL, 9.000, 9.000, 4.7200, 42.48, '2026-10-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.766234+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('911f2783-ee1e-42dc-9a46-9f20e8842c92', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'fd58696b-450b-42d5-9a06-8f088f7af9ab', NULL, 3.000, 3.000, 5.1500, 15.45, '2026-09-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.772972+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('dfc4afa6-4960-46e1-8ffb-823bef386098', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', NULL, 2.000, 2.000, 5.4900, 10.98, '2026-09-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.778617+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('27a420ae-06ab-47ee-b064-458d1881083a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4850e73d-f3e0-437b-978a-6286e64163b8', NULL, 9.000, 9.000, 4.7600, 42.84, '2026-09-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.783818+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('41213534-9980-4dd9-be7d-79ae78ffe16a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2624d047-5f42-4ec9-8865-e51c8feb672b', NULL, 1.000, 1.000, 5.7300, 5.73, '2026-10-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.788956+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5cd58b2f-f69d-46bc-8c51-513394f1b208', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95297129-3d3b-4d4d-85ad-86d2c3b26f24', NULL, 6.000, 6.000, 4.4600, 26.76, '2026-10-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.79401+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('81db9a0b-895f-4df1-a985-a66f533423d6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '95c923ad-aaf0-42c4-94d5-499cb99b9f56', NULL, 4.000, 4.000, 4.4700, 17.88, '2026-10-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.799242+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('99a37137-5625-43dd-95f8-5972b83126f1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', NULL, 2.000, 2.000, 5.1800, 10.36, '2026-09-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.804617+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aaf6d264-a4a5-486a-bf7f-68b9e73304b9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '978975e2-b9a9-47ca-accc-272993e683a9', NULL, 6.000, 6.000, 4.9900, 29.94, '2026-09-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.810701+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('54c6c55b-5b86-4e5f-ab48-3cf6fb1a4209', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', NULL, 9.000, 9.000, 5.2600, 47.34, '2026-10-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.816376+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ee993ec6-303d-45ac-affa-44dddb7e1902', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'e2c11f9c-a829-4e1f-a958-e0a8ae1e0231', NULL, 8.000, 8.000, 4.5000, 36.00, '2026-10-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.822139+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9f63698d-b2ea-408b-99ef-f0ea46557a19', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d059874-8aa6-440f-ac9f-f87497631322', NULL, 3.000, 3.000, 4.4900, 13.47, '2026-10-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.829256+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('965523ff-1d49-4dc1-8eb8-7689ffed0cf3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ac6440cf-13bd-4a34-8da6-ad89c6d29e49', NULL, 4.000, 4.000, 5.2300, 20.92, '2026-09-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.836024+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('a31839a6-8343-4e87-9c1f-50ffaf9600ab', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', NULL, 4.000, 4.000, 4.4500, 17.80, '2026-10-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.842607+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2038cfd7-761a-411f-9ea5-95d745af64e0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '811175a1-fe78-435e-ae2b-65c46cdc638f', NULL, 8.000, 8.000, 5.0800, 40.64, '2026-09-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.848902+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('21c9bda2-bcb3-41d3-965c-9b601cd453dc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', NULL, 6.000, 6.000, 5.4600, 32.76, '2026-08-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.854664+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('32020227-c830-465b-9c13-e3f237249164', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', NULL, 9.000, 9.000, 4.7300, 42.57, '2026-10-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.861255+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1d045368-ea4b-40b8-a93e-7c4b0761a5da', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '72bdce9f-7935-43fd-927c-2d567cf5d756', NULL, 6.000, 6.000, 5.0400, 30.24, '2026-10-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.866297+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6ae92909-b96b-45a2-bb5a-a9b179b181d6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '51321655-7803-4068-a127-4e7109105029', NULL, 6.000, 6.000, 4.7000, 28.20, '2026-10-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.874078+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c5e3a6b1-cf7d-4368-bc9d-27d5e3e71823', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 8.000, 8.000, 4.4800, 35.84, '2026-09-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.880885+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ba263390-0579-4e6a-877f-c28c3a50c791', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cc9838d2-823c-4bc2-a531-f18a59b258f5', NULL, 1.000, 1.000, 5.0300, 5.03, '2026-09-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.887018+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('53f0daba-651e-457a-8468-e2667c13bec3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', NULL, 5.000, 5.000, 5.7200, 28.60, '2026-08-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.893148+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e6567030-575f-414a-a30d-45d36501b902', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 1.000, 1.000, 4.5300, 4.53, '2026-10-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.898266+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8a9bf5a8-4be8-4061-9753-65ec2e6561f4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'fae8537d-d380-4433-973f-75d6083b9007', NULL, 4.000, 4.000, 5.0800, 20.32, '2026-10-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.904642+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('55b9446d-088c-4aae-8bc2-3a3de22b3836', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 4.000, 4.000, 4.8500, 19.40, '2026-09-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:15.908623+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7a526076-76b9-4297-8b03-9e095cefa1a2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '550d3d31-b672-4970-9b5e-c340b8762506', NULL, 9.900, 9.900, 5.7100, 56.53, '2026-10-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.101219+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('39e4a211-7b32-4c5b-a4e2-87a63d10556b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7190ea91-16e3-47b8-81db-a8cfd3310441', NULL, 6.800, 6.800, 4.3600, 29.65, '2026-10-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.109558+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('93762a43-1890-4f82-b8b6-5e57d40341da', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'ae63f584-19ed-4d90-bccb-b87a10a778b0', NULL, 7.000, 7.000, 5.0600, 35.42, '2026-08-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.115307+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('00237295-7adc-4f45-a4ff-f5bab46d77f0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d74ee73-5c5c-4b0c-bd20-6b5eba9dda07', NULL, 5.000, 5.000, 5.6500, 28.25, '2026-10-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.120391+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f10ce640-f2cb-46bd-a5a0-a7f309215373', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '421dfd61-718d-4571-b801-4992bbcc7aa8', NULL, 3.000, 3.000, 5.3500, 16.05, '2026-10-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.126546+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('cf1e9b3c-1d53-4144-8449-32d95d9ccac9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '240939e0-2b81-4a30-b303-e9798d591c02', NULL, 7.000, 7.000, 4.8400, 33.88, '2026-09-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.134877+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e14ad783-91fa-4561-a42d-dd3ac4b2a38a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '37aaf29f-4c0e-49ac-a458-8dd2515ba0d5', NULL, 8.000, 8.000, 4.8800, 39.04, '2026-09-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.142181+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b2408021-aa6f-475b-bcec-5a9ca40cd2ec', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '13b63530-f895-4416-beb3-c2dca6919854', NULL, 7.000, 7.000, 5.5500, 38.85, '2026-09-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.14858+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('86572c2e-657b-470a-9647-394386048fd3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '72f02ab4-94c5-476a-8e82-53b361859d75', NULL, 8.000, 8.000, 4.6400, 37.12, '2026-10-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.156043+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('bce933bf-bfb0-4457-a4dc-b2f1227b9e52', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'eb45cb98-1edf-4366-8368-ab2ea153bb9c', NULL, 9.000, 9.000, 4.4300, 39.87, '2026-10-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.160162+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('896a848d-59ca-4489-8c6d-8aa9c988fe66', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '7b3b5462-0278-4759-8945-f9ae3ae536b6', NULL, 3.000, 3.000, 5.1400, 15.42, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.164938+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('72171a08-3cd6-4490-be3b-880cb7912f2f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8f0c1f16-0931-4424-b79a-aa1dc5519c11', NULL, 6.000, 6.000, 5.5900, 33.54, '2026-10-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.171152+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e55600fb-fa2a-4136-8694-645650415c3b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f74058cf-9946-472e-8d0d-34656a7e323d', NULL, 2.000, 2.000, 5.6600, 11.32, '2026-09-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.177742+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f98a4880-0b4c-4e9c-99f0-7ea0634f8a1b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '9d7a90d7-4431-4d3a-b1c0-78c247204b37', '81ef289d-20ef-4792-9032-2504842c79c7', 5.000, 5.000, 4200.0000, 21000.00, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.661542+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9a721f7e-899c-4bc9-a9f9-744efd2b262c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', '0ff07ef2-61f1-4ba1-b849-f7978493a643', 3.000, 3.000, 5800.0000, 17400.00, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.661543+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c1ba4bc0-d3ab-44a9-9a60-e26ff664bca0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0f235c0d-8907-42ed-a359-c437e63adb06', '9cfb9dd0-a250-46a4-8c7f-33de6be6a622', 48.000, 36.000, 4.5000, 216.00, '2026-10-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.587159+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('0dcb56f6-8e77-43d5-8258-7dc26a1cbbc7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', '8ba0b883-0043-450d-b9e4-e8a129123ab2', 24.000, 18.000, 5.2000, 124.80, '2026-10-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.587162+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b5f93491-4648-4b70-bc82-f23323cfa546', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', '73a54928-ecd4-4d88-8be9-5ffb8e203378', 36.000, 24.000, 8.9000, 320.40, '2026-10-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.587162+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9e6d12d1-25df-43aa-b3a7-aff11f78f761', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', NULL, 40.000, 13.600, 3.4000, 136.00, '2026-10-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.183186+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ea23846c-9307-4fbb-9ac4-ce685c4968a5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', NULL, 25.000, 21.220, 1.1000, 27.50, '2026-10-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.189525+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f8472344-f1cb-4648-a8dc-83395dc1ab91', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', NULL, 0.500, 0.440, 24.0000, 12.00, '2026-09-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.195338+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7e381b01-644c-4bb8-b693-74b7a837c0c3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0f235c0d-8907-42ed-a359-c437e63adb06', '8572fef6-0eeb-4d55-8d89-731283b3c80d', 12.000, 0.000, 4.5000, 54.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-02 21:38:16.750877+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aaa4f502-0fe0-4dc3-b9b3-d1ffc13f7261', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', 'ca73d1f0-7e5b-4001-8af2-a99a8bb139b9', 8.000, 0.000, 8.9000, 71.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-02 21:38:16.750879+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3702798d-e3ec-4569-8935-39d1ba2645e1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'a3a9f3b1-19f5-428a-bf1e-19447790d174', 'e2d157d8-c8a6-4925-a167-6891159fe91c', 6.000, 0.000, 5.2000, 31.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-02 21:38:17.681199+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2fa29dc4-09c1-4ca6-9915-b3fa29b82dd5', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '270eb47d-03bc-4642-9594-05b6a4b69ac3', '265efce9-0296-4acd-a15f-18879644d53d', 4.000, 0.000, 8.9000, 35.60, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-02 21:38:17.6812+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1352e908-0be9-4cb0-a5d9-74c10f6e9d27', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '659dfba1-c413-49d1-881e-822bfd08ce2f', 60.000, 50.000, 12.5000, 750.00, '2026-10-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.627511+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2ef0fc6f-e422-4143-833e-47abc17a1e2f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b058779-639f-4d34-9201-7dc78d9700fd', 'cc1d3240-839e-4ad4-86f0-448301532d03', 20.000, 15.000, 4.1000, 82.00, '2026-10-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:16.627512+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4f0bbc89-7bb3-4543-97b1-a1eb69d829a2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '3888bb38-abd7-4a67-ba60-761ade6fa2b9', '9f8c55e8-3470-4bc7-ae40-0e192116b043', 10.000, 0.000, 12.5000, 125.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-02 21:38:17.798481+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('66865a11-b8b6-493a-b59f-944b5a034680', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5b058779-639f-4d34-9201-7dc78d9700fd', '74fb46b7-a7f1-4343-9a8f-6522dc37bb5b', 5.000, 0.000, 4.1000, 20.50, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-02 21:38:17.798483+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aeacbac2-1e1f-453d-b91b-02297d821a00', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '33b25eca-5f45-4957-9dcc-fd1aa463d155', '1345dd29-8367-4b7f-8a45-266cbcda14a2', 3.000, 3.000, 5800.0000, 17400.00, '2026-10-16', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:18.330884+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5b0ece9f-0812-4925-ac2f-37e62c1b15b4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5d36a701-5479-482d-b364-a0dc01ecccb5', NULL, 26.400, 0.000, 3.4000, 89.76, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-02 21:38:18.606033+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('45a647e6-c05e-454e-b37e-ea013aa39a36', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '012cff9e-43c0-4593-977e-2fad7b12bbcf', NULL, 3.780, 0.000, 1.1000, 4.16, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-02 21:38:18.625862+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d0bf69f3-2a88-4201-bc81-c0e295f87c61', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'c643fd6c-c2d3-4a9e-9eb5-5febb1a6a073', NULL, 0.060, 0.000, 24.0000, 1.44, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-02 21:38:18.644966+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('46f5565c-563a-45ef-a052-6a459bdacd77', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2f1b6282-567c-422c-bb1d-704f79f71d08', NULL, 11.400, 11.400, 8.3647, 95.36, NULL, 'USD', 'IN', 'stated', NULL, NULL, '2026-11-02 21:38:18.667449+00');


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('14678c11-4461-4c9c-acc1-ae58acf41d47', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, NULL, '[]', 'STOCK', '[]', 'Main Warehouse', 'Receiving and dispatch — shared by every module', NULL, NULL, 1, 'internal', NULL, '{"seed": {"code": "MAIN_WAREHOUSE", "name": "Main Warehouse"}}', NULL, '2026-11-02 21:38:14.693019+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0f0fe9ca-7062-4432-b220-ca249ab77fe2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, NULL, '[]', 'NONE', '[]', 'Server Room', 'Primary server room / data center', NULL, NULL, 44, 'internal', 'equipment', '{"seed": {"code": "SERVER_ROOM", "name": "Server Room"}}', NULL, '2026-11-02 21:38:14.693023+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('45f57889-4802-4a37-8161-662cb1a5230c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'c15cee25-338d-471f-b2c8-f26b455bb5f4', '[]', 'STOCK', '[]', 'Production (Virtual)', NULL, 'System location', NULL, 42, 'production', NULL, '{"seed": {"code": "PRODUCTION_VIRTUAL", "name": "Production (Virtual)"}}', NULL, '2026-11-02 21:38:14.718266+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('92fa01c1-78bd-4cea-ab4b-982c6d9b18ae', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, NULL, '[]', 'NONE', '[]', 'IT Storage', 'IT equipment storage and logistics warehouse', NULL, NULL, 40, 'internal', 'equipment', '{"seed": {"code": "IT_STORAGE", "name": "IT Storage"}}', NULL, '2026-11-02 21:38:14.693024+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('06b3305c-0a49-49aa-984c-27d539818141', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5a7a4bc4-78bd-4867-abaf-635de10b015f', '9f8a7704-47b2-4d45-a2d9-dddb7b3277be', '[]', 'STOCK', '[]', 'Server Room', NULL, NULL, 'C', 25, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.950098+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c3d52c78-0fe5-4bc1-93d2-1a96ffd9ec47', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'c15cee25-338d-471f-b2c8-f26b455bb5f4', '[]', 'STOCK', '[]', 'Inventory Loss (Virtual)', NULL, 'System location', NULL, 41, 'inventory', NULL, '{"seed": {"code": "LOSS_VIRTUAL", "name": "Inventory Loss (Virtual)"}}', NULL, '2026-11-02 21:38:14.717174+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('dc90f76d-06d9-4e33-a6b6-cd6850ad70bf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, '3dc17414-2ccc-4a9e-81ad-b52e7a3208ee', '[]', 'STOCK', '[]', 'Quarantine', NULL, NULL, NULL, 43, 'internal', NULL, '{"seed": {"code": "QUARANTINE", "name": "Quarantine"}}', NULL, '2026-11-02 21:38:14.720942+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f0a54f15-027b-4ddc-9713-fcbceff65183', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, 'c15cee25-338d-471f-b2c8-f26b455bb5f4', '[]', 'STOCK', '[]', 'Consumed (Virtual)', NULL, 'System location', NULL, 39, 'customer', NULL, '{"seed": {"code": "CONSUMED_VIRTUAL", "name": "Consumed (Virtual)"}}', NULL, '2026-11-02 21:38:14.715885+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0d5b4d7c-869e-4267-a51b-13a7da79194a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8809d243-d280-48d1-8e98-70036f776bdc', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'STOCK', '[]', 'Beverage Rack 2', NULL, NULL, 'G-02', 23, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.94823+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0db2cbe1-fd99-4ae5-9856-95623f802779', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5a7a4bc4-78bd-4867-abaf-635de10b015f', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Workstations', NULL, NULL, 'E', 34, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.957982+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0de06468-a565-463c-bf8f-4fe2abf476c8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Shelf A - Middle', NULL, NULL, 'F-02', 16, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.942606+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0e17549e-2b77-4415-8a50-af6d60912ba9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Shelf B - Top', NULL, NULL, 'F-04', 18, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.944194+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0e6131a5-bab6-4d95-ae7f-1639ac331989', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f84a8b07-fda6-4c0a-8bdc-58c6fe5ac715', '5e571842-431f-4775-857b-c0774df34021', '[]', 'FREEZING', '[]', 'Chest Freezer', NULL, NULL, 'B-03', 12, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.938549+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('10ef3e3d-dd80-4e34-9146-b7e0609a3cef', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '8809d243-d280-48d1-8e98-70036f776bdc', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'STOCK', '[]', 'Beverage Rack 1', NULL, NULL, 'G-01', 22, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.947457+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('11547469-399b-4f43-bb95-707e11abccb6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '90e120c7-8134-4544-bf69-cda51950a864', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Fridge B', NULL, NULL, 'A-02', 6, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.933124+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('1bfc59b1-40f6-4abb-8b95-8b0ef892fdb7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Shelf A - Top', NULL, NULL, 'F-01', 15, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.941739+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('2229b888-3461-4bfe-a30f-dda517c3e4dd', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '90e120c7-8134-4544-bf69-cda51950a864', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Fridge C', NULL, NULL, 'A-03', 7, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.934089+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('28673b78-0bf1-4f0b-ab61-4e0649a5384f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '06b3305c-0a49-49aa-984c-27d539818141', '9f8a7704-47b2-4d45-a2d9-dddb7b3277be', '[]', 'STOCK', '[]', 'Server Rack B', NULL, NULL, 'C-02', 27, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.951922+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('2e1aed8f-680b-4ed0-94bc-29e36017f6c0', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5a7a4bc4-78bd-4867-abaf-635de10b015f', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'IT Workshop', NULL, NULL, 'D', 30, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.954345+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('3d9a68be-2319-450a-91dd-07216b4b58b9', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2e1aed8f-680b-4ed0-94bc-29e36017f6c0', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Spare Parts Bin', NULL, NULL, 'D-03', 33, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.957077+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('4b863cdb-567d-4e88-8c7e-ba625b663c95', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '90e120c7-8134-4544-bf69-cda51950a864', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Fridge A', NULL, NULL, 'A-01', 3, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.930413+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('56c22ebc-1905-422e-a5c0-2d17743d5dae', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Fridge A - Top Shelf', NULL, NULL, 'A-01-01', 4, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.931419+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('65c7b767-ecbf-4d26-834f-71c6e5f1d926', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Shelf B - Bottom', NULL, NULL, 'F-06', 20, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.945753+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7b6d690e-d6ef-4a81-8aae-8c138bb04ccb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f84a8b07-fda6-4c0a-8bdc-58c6fe5ac715', '5e571842-431f-4775-857b-c0774df34021', '[]', 'FREEZING', '[]', 'Freezer 1', NULL, NULL, 'B-01', 10, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.936675+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7fb3b183-5295-4bb2-866e-3054d9f0062f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f84a8b07-fda6-4c0a-8bdc-58c6fe5ac715', '5e571842-431f-4775-857b-c0774df34021', '[]', 'FREEZING', '[]', 'Freezer 2', NULL, NULL, 'B-02', 11, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.937568+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('8809d243-d280-48d1-8e98-70036f776bdc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cf95e969-f3c6-4bd6-bf5f-884bc2ae45a2', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'STOCK', '[]', 'Beverages', NULL, NULL, 'G', 21, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.946593+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('8fd38393-964a-4094-add7-0baa69d27380', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0db2cbe1-fd99-4ae5-9856-95623f802779', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Floor 1 - Row A', NULL, NULL, 'E-01', 35, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.958959+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('90e120c7-8134-4544-bf69-cda51950a864', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '14678c11-4461-4c9c-acc1-ae58acf41d47', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Cold Storage', NULL, NULL, 'A', 2, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.928959+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('98c80ba0-01fe-40fd-bd22-e0a609a0d7dc', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Shelf B - Middle', NULL, NULL, 'F-05', 19, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.944923+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('a0d877e1-da04-4af0-aedf-7e9b409bfed2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0db2cbe1-fd99-4ae5-9856-95623f802779', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Floor 2 - Row A', NULL, NULL, 'E-03', 37, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.960737+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('bc2249d0-b9b5-4193-810d-9ad3b2d4e0e8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '06b3305c-0a49-49aa-984c-27d539818141', '9f8a7704-47b2-4d45-a2d9-dddb7b3277be', '[]', 'STOCK', '[]', 'Patch Panel', NULL, NULL, 'C-04', 29, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.953542+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ca3eb548-d5f4-4889-8f09-fe6dd6050a45', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2e1aed8f-680b-4ed0-94bc-29e36017f6c0', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Workshop Shelf 1', NULL, NULL, 'D-01', 31, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.955306+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('cd904356-14c5-4fda-aada-68590ffeb22c', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0db2cbe1-fd99-4ae5-9856-95623f802779', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Floor 1 - Row B', NULL, NULL, 'E-02', 36, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.959869+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('d093050d-72ad-4663-840d-0b563efd6d55', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '06b3305c-0a49-49aa-984c-27d539818141', '9f8a7704-47b2-4d45-a2d9-dddb7b3277be', '[]', 'STOCK', '[]', 'UPS Bay', NULL, NULL, 'C-03', 28, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.952768+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('d44a51bc-01a1-472d-9e2b-273bf1864c2d', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'f22fdc71-20d7-4328-aa66-5d45758b55e7', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Shelf A - Bottom', NULL, NULL, 'F-03', 17, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.943428+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('db23efde-1a25-4356-9e42-4c8e5ddc0beb', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '06b3305c-0a49-49aa-984c-27d539818141', '9f8a7704-47b2-4d45-a2d9-dddb7b3277be', '[]', 'STOCK', '[]', 'Server Rack A', NULL, NULL, 'C-01', 26, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.95095+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('e3b6070a-033b-4c12-855b-bb78d26e9a37', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '4b863cdb-567d-4e88-8c7e-ba625b663c95', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Fridge A - Door', NULL, NULL, 'A-01-02', 5, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.932246+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('eec06978-11eb-4b74-a829-6106e5193a1a', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '90e120c7-8134-4544-bf69-cda51950a864', '62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', '[]', 'EXPIRY', '[]', 'Walk-in Cooler', NULL, NULL, 'A-04', 8, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.934979+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f22fdc71-20d7-4328-aa66-5d45758b55e7', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'cf95e969-f3c6-4bd6-bf5f-884bc2ae45a2', 'b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', '[]', 'EXPIRY', '[]', 'Dry Goods', NULL, NULL, 'F', 14, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.940745+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f7f1c414-5e10-4093-bd27-f232bb078e47', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '2e1aed8f-680b-4ed0-94bc-29e36017f6c0', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Workshop Shelf 2', NULL, NULL, 'D-02', 32, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.956194+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f84a8b07-fda6-4c0a-8bdc-58c6fe5ac715', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '14678c11-4461-4c9c-acc1-ae58acf41d47', '5e571842-431f-4775-857b-c0774df34021', '[]', 'FREEZING', '[]', 'Freezer Zone', NULL, NULL, 'B', 9, 'internal', 'food', NULL, NULL, '2026-11-02 21:38:14.935838+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f8d40ee5-f923-4354-9050-6e350bb32fd3', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '0db2cbe1-fd99-4ae5-9856-95623f802779', '248064f8-783c-410d-8fc9-8358190a9293', '[]', 'STOCK', '[]', 'Floor 2 - Row B', NULL, NULL, 'E-04', 38, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.962562+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('5a7a4bc4-78bd-4867-abaf-635de10b015f', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, '3dc17414-2ccc-4a9e-81ad-b52e7a3208ee', '[]', 'STOCK', '[]', 'Office Building', NULL, NULL, 'LOC-7SDP', 24, 'internal', 'equipment', NULL, NULL, '2026-11-02 21:38:14.949322+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('cf95e969-f3c6-4bd6-bf5f-884bc2ae45a2', 'd6301fab-e457-41b9-8ee6-16ecc6683985', NULL, '3dc17414-2ccc-4a9e-81ad-b52e7a3208ee', '[]', 'STOCK', '[]', 'Pantry Building', NULL, NULL, 'LOC-M401', 13, 'internal', NULL, NULL, NULL, '2026-11-02 21:38:14.939787+00', '2b510efc-b831-4b48-97e3-18a8659cf00f');


--
-- Data for Name: storage_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('d5c293b8-13e1-40b6-96db-5e8a44bc30b8', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Shelf / Cabinet', 'SHELF', 'STOCK', '["quantity", "unit"]', '[]', 'BookOpen', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('3dc17414-2ccc-4a9e-81ad-b52e7a3208ee', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Storage Room', 'STORAGE_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Warehouse', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('c15cee25-338d-471f-b2c8-f26b455bb5f4', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'System', 'SYSTEM', 'NONE', '[]', '[]', 'Settings', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('e0943a30-1be5-46d3-946b-0997f13f0904', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Tool Room', 'TOOL_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Wrench', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('d22cd933-1cfe-48a2-b7bd-fc8f7554b7f1', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Maintenance Bay', 'MAINTENANCE_BAY', 'NONE', '["quantity", "unit"]', '[]', 'Hammer', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('9f8a7704-47b2-4d45-a2d9-dddb7b3277be', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Server Room', 'SERVER_ROOM', 'NONE', '["serial_number", "manufacturer", "model", "ip_address", "equipment_status"]', '[]', 'server', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('248064f8-783c-410d-8fc9-8358190a9293', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'IT Storage / Warehouse', 'IT_STORAGE', 'NONE', '["serial_number", "manufacturer", "model", "equipment_status"]', '[]', 'warehouse', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('5e571842-431f-4775-857b-c0774df34021', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Freezer', 'FREEZER', 'FREEZING', '[]', '[]', 'Snowflake', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('62ad2f0f-75e1-4e1f-b723-48b1ff7db57b', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Fridge', 'FRIDGE', 'EXPIRY', '[]', '[]', 'Refrigerator', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('b1f8ea52-e8f1-4047-95be-f2c1a4c25c84', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Pantry', 'PANTRY', 'EXPIRY', '[]', '[]', 'ShoppingBasket', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('aabd6fcc-c2f5-4915-9a72-def4ebefa2c6', 'd6301fab-e457-41b9-8ee6-16ecc6683985', 'Medicine Cabinet', 'MEDICINE_CABINET', 'EXPIRY', '[]', '[]', 'Cross', true, NULL, '{"check_expiry": true}');


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_settings (key, value, updated_at, updated_by) VALUES ('default_org_limits', '{"max_members": null, "max_products": null, "ai_scans_monthly": null, "ai_requests_monthly": 20}', '2026-11-02 21:38:19.158007+00', NULL);


--
-- Data for Name: tax_rate_assignments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unit_conversions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: uom_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('ae3cccc0-5c6c-483e-8495-63f5685b7138', NULL, 'Weight');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('ddb4d544-8673-413b-9d1f-0586ae7dd166', NULL, 'Volume');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('d19e2c7f-452f-4c15-91b9-d8d6d9415a91', NULL, 'Unit');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('35ce670c-6a92-4970-b529-cbb13a0557f4', NULL, 'Length');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('7ddbdc8f-9317-402f-8c2d-3d8313b36fd7', NULL, 'Pack');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('c472ab28-3831-48e3-a515-254270883682', NULL, 'Can');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('94d44fba-2b9c-46ba-8052-6f832669ffba', NULL, 'Bottle');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('f69a38be-6d09-42bb-ab4a-f58460538e93', NULL, 'Box');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('e9f0f311-f89a-4c0f-a84e-fa43e542776a', NULL, 'Bag');


--
-- Data for Name: uoms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('653f4d21-e5bf-4d23-aca9-44481982cc7e', NULL, 'ae3cccc0-5c6c-483e-8495-63f5685b7138', 'Gram', 'g', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('0cf8f21a-3455-45f5-a61e-7cae190755d8', NULL, 'ae3cccc0-5c6c-483e-8495-63f5685b7138', 'Kilogram', 'kg', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('95404491-694b-4876-a5df-ba5c07e4fb4e', NULL, 'ae3cccc0-5c6c-483e-8495-63f5685b7138', 'Milligram', 'mg', 0.001000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('12310a5d-ba7f-4df9-a867-bb625e42203d', NULL, 'ae3cccc0-5c6c-483e-8495-63f5685b7138', 'Ounce', 'oz', 28.349500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('35b7b9e4-58ff-42dd-861c-a9c19dcc91ae', NULL, 'ae3cccc0-5c6c-483e-8495-63f5685b7138', 'Pound', 'lb', 453.592000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8f256be8-3468-4bb5-aeac-8f8dc007d8e3', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Milliliter', 'ml', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('5eed73a0-c884-44f6-b6bf-1e7a6d2f043c', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Liter', 'l', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('9e4be7f9-7351-4f67-adb2-f4a2a1d0199d', NULL, 'd19e2c7f-452f-4c15-91b9-d8d6d9415a91', 'Piece', 'pcs', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('dad34f3b-d23a-4706-80a2-7339f7cf46e4', NULL, '7ddbdc8f-9317-402f-8c2d-3d8313b36fd7', 'Pack', 'pack', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('20ef95d1-f011-47e1-8217-b70e951554a8', NULL, 'c472ab28-3831-48e3-a515-254270883682', 'Can', 'can', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('63c7a43f-b00c-4322-b65a-2abd60d78a9c', NULL, '94d44fba-2b9c-46ba-8052-6f832669ffba', 'Bottle', 'bottle', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('fe7d5d6f-20f2-4fb4-819f-5be4d43fb12c', NULL, 'f69a38be-6d09-42bb-ab4a-f58460538e93', 'Box', 'box', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('2ce4607f-2fb7-4bb7-8f5c-646becc61750', NULL, 'e9f0f311-f89a-4c0f-a84e-fa43e542776a', 'Bag', 'bag', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8ce813c5-0766-4530-8b7a-9a50eeebc02c', NULL, '35ce670c-6a92-4970-b529-cbb13a0557f4', 'Centimeter', 'cm', 1.000000000, true, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('58741936-cd13-4283-a8b4-215a55bce677', NULL, '35ce670c-6a92-4970-b529-cbb13a0557f4', 'Meter', 'm', 100.000000000, false, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('1333b667-5725-453a-8d5c-f27e32dd4028', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Fluid Ounce', 'fl oz', 29.573500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('49195fe8-acfe-45ad-8bac-5248a14c6a75', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Cup (US)', 'cup', 236.588000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('62f2427d-7401-43b1-a038-64061563f38f', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Pint (US)', 'pt', 473.176000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('2ef3c3c7-01d4-4564-9621-7e6d13eaa47b', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Quart (US)', 'qt', 946.353000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('98e79619-45e7-4a1f-b53e-c18191345d5e', NULL, 'ddb4d544-8673-413b-9d1f-0586ae7dd166', 'Gallon (US)', 'gal', 3785.410000000, false, true, 0.001000);


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('2b510efc-b831-4b48-97e3-18a8659cf00f', 'admin@example.com', '$2b$04$3WiBY9L/7by61p/DJOfntuzm3LhEt0mE1INFa/9iuQCGwdOEQyqJq', 'Demo Administrator', '2026-11-02 21:38:14.567224+00', '2026-11-02 21:38:14.579071+00', 'en', 'admin', true, false, false, NULL, NULL, 0, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('7fb93cd8-d0f5-4a14-b739-f72404792db5', 'ava.brennan@example.com', '$2b$04$ncmBYZ5LIlgyIp894VSrNuxm6xhgCEGuati1kgmGKGB.BpzlZcyCC', 'Ava Brennan', '2026-11-02 21:38:18.83015+00', '2026-11-02 21:38:18.830154+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('680ca639-edea-48fe-8eb5-a03cfdbb8852', 'marcus.webb@example.com', '$2b$04$B85fb/dWU3IJqbcpPEstmeyHf1IKSKJgErmMZLeSBO2.r.282bLiq', 'Marcus Webb', '2026-11-02 21:38:18.830157+00', '2026-11-02 21:38:18.830158+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, 'd6301fab-e457-41b9-8ee6-16ecc6683985');


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_line_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('38af6b85-fc12-4d29-8e88-b72a696ebbc8', '70834e19-8f76-4868-b0a9-a07c90949aaf', '9f8c55e8-3470-4bc7-ae40-0e192116b043', 2, 'picked', 10.000, 'A-02 · Fridge B', 'Gouda Cheese', NULL, 10.000, 'pcs', '08ceb310-4c8d-4606-b0b5-deaa55ce7727', NULL, '11547469-399b-4f43-bb95-707e11abccb6', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('8f4d78fc-a1f4-4a3b-96f9-abd5108ec7bb', '70834e19-8f76-4868-b0a9-a07c90949aaf', '74fb46b7-a7f1-4343-9a8f-6522dc37bb5b', 3, 'picked', 5.000, 'A-02 · Fridge B', 'Sour Cream 18%', NULL, 5.000, 'pcs', '1a7648ce-cf2c-4f0c-9eff-02dd1ea7fb02', NULL, '11547469-399b-4f43-bb95-707e11abccb6', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('d7cfc99f-5477-4c2a-8c89-1b15c677dd2a', '70834e19-8f76-4868-b0a9-a07c90949aaf', 'e2d157d8-c8a6-4925-a167-6891159fe91c', 0, 'picked', 6.000, 'A-01 · Fridge A', 'Natural Yoghurt 400g', NULL, 6.000, 'pcs', '4fedb70a-4c66-4cac-99fb-74667ca91182', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('f8d81c32-86c5-45e5-9059-fdccded9f621', '70834e19-8f76-4868-b0a9-a07c90949aaf', '265efce9-0296-4acd-a15f-18879644d53d', 1, 'picked', 4.000, 'A-01 · Fridge A', 'Butter Extra 82%', NULL, 4.000, 'pcs', 'bf4f3adb-9be5-4e83-89d5-ebb2e1e4af17', NULL, '4b863cdb-567d-4e88-8c7e-ba625b663c95', NULL);


--
-- Data for Name: wms_pick_session_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('70834e19-8f76-4868-b0a9-a07c90949aaf', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', 0);
INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('70834e19-8f76-4868-b0a9-a07c90949aaf', 'e0aab802-2bbf-42a7-9d2f-6e7c3ecdbdd2', 1);


--
-- Data for Name: wms_pick_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_sessions (id, organization_id, document_id, assigned_to, status, started_at, completed_at, meta_data, last_activity_at) VALUES ('70834e19-8f76-4868-b0a9-a07c90949aaf', 'd6301fab-e457-41b9-8ee6-16ecc6683985', '5ab457d6-477d-403c-bde8-4d5fdba0cd00', '2b510efc-b831-4b48-97e3-18a8659cf00f', 'completed', '2026-11-02 21:38:17.065463+00', '2026-11-02 21:38:17.355072+00', 'null', '2026-11-02 21:38:17.327489+00');


--
-- Name: ai_connections ai_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version_api_keys alembic_version_api_keys_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_api_keys
    ADD CONSTRAINT alembic_version_api_keys_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_approvals alembic_version_approvals_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_approvals
    ADD CONSTRAINT alembic_version_approvals_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_equipment alembic_version_equipment_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_equipment
    ADD CONSTRAINT alembic_version_equipment_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_example_widgets alembic_version_example_widgets_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_example_widgets
    ADD CONSTRAINT alembic_version_example_widgets_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_maker alembic_version_maker_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_maker
    ADD CONSTRAINT alembic_version_maker_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_printing alembic_version_printing_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_printing
    ADD CONSTRAINT alembic_version_printing_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_purchase_orders alembic_version_purchase_orders_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_purchase_orders
    ADD CONSTRAINT alembic_version_purchase_orders_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_recipes alembic_version_recipes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_recipes
    ADD CONSTRAINT alembic_version_recipes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_shopping_lists alembic_version_shopping_lists_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_shopping_lists
    ADD CONSTRAINT alembic_version_shopping_lists_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_stock_takes alembic_version_stock_takes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_stock_takes
    ADD CONSTRAINT alembic_version_stock_takes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_warehouse alembic_version_warehouse_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_warehouse
    ADD CONSTRAINT alembic_version_warehouse_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_webhooks alembic_version_webhooks_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_webhooks
    ADD CONSTRAINT alembic_version_webhooks_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approval_decisions approval_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: approval_workflows approval_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);


--
-- Name: audit_campaigns audit_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_response_items audit_response_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_pkey PRIMARY KEY (id);


--
-- Name: audit_responses audit_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cycle_count_schedules cycle_count_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_pkey PRIMARY KEY (id);


--
-- Name: document_extra_costs document_extra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_pkey PRIMARY KEY (id);


--
-- Name: document_lines document_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_pkey PRIMARY KEY (id);


--
-- Name: document_number_sequences document_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_pkey PRIMARY KEY (organization_id, prefix);


--
-- Name: document_package_lines document_package_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_pkey PRIMARY KEY (id);


--
-- Name: document_packages document_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_pkey PRIMARY KEY (id);


--
-- Name: document_profiles document_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_pkey PRIMARY KEY (id);


--
-- Name: document_relations document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_pkey PRIMARY KEY (id);


--
-- Name: document_shipments document_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: document_type_configs document_type_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_pkey PRIMARY KEY (id);


--
-- Name: document_warehouse_receiving document_warehouse_receiving_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_pkey PRIMARY KEY (id);


--
-- Name: document_work_item_overlays document_work_item_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_jobs email_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_jobs
    ADD CONSTRAINT email_jobs_pkey PRIMARY KEY (id);


--
-- Name: equipment_assignments equipment_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_pkey PRIMARY KEY (id);


--
-- Name: equipment_attachments equipment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_pkey PRIMARY KEY (id);


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: event_deliveries event_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT event_deliveries_pkey PRIMARY KEY (id);


--
-- Name: event_outbox event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox
    ADD CONSTRAINT event_outbox_pkey PRIMARY KEY (id);


--
-- Name: example_widgets example_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_pkey PRIMARY KEY (id);


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_pkey PRIMARY KEY (id);


--
-- Name: inventory_periods inventory_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_pkey PRIMARY KEY (id);


--
-- Name: item_attachments item_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_pkey PRIMARY KEY (id);


--
-- Name: item_history item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_pkey PRIMARY KEY (id);


--
-- Name: item_import_jobs item_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: label_pool label_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_pkey PRIMARY KEY (id);


--
-- Name: location_relocations location_relocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_pkey PRIMARY KEY (id);


--
-- Name: maker_bom_lines maker_bom_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_module_settings maker_module_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: maker_production_order_lines maker_production_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_production_orders maker_production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_pkey PRIMARY KEY (id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_recipes maker_recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_entries meal_plan_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_pkey PRIMARY KEY (id);


--
-- Name: meal_plans meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_pkey PRIMARY KEY (id);


--
-- Name: module_installations module_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_installations
    ADD CONSTRAINT module_installations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: picking_session_items picking_session_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_pkey PRIMARY KEY (id);


--
-- Name: picking_sessions picking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_pkey PRIMARY KEY (id);


--
-- Name: po_partner_pricelist po_partner_pricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_pkey PRIMARY KEY (id);


--
-- Name: po_reorder_rules po_reorder_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_pkey PRIMARY KEY (id);


--
-- Name: po_settings po_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_pkey PRIMARY KEY (id);


--
-- Name: print_agents print_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_pkey PRIMARY KEY (id);


--
-- Name: print_jobs print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_pkey PRIMARY KEY (id);


--
-- Name: product_templates product_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: putaway_capacity putaway_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_pkey PRIMARY KEY (id);


--
-- Name: putaway_home_silenced putaway_home_silenced_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_pkey PRIMARY KEY (id);


--
-- Name: putaway_location_settings putaway_location_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_pkey PRIMARY KEY (id);


--
-- Name: putaway_rule_locations putaway_rule_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_pkey PRIMARY KEY (id);


--
-- Name: putaway_rules putaway_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_pkey PRIMARY KEY (id);


--
-- Name: recipe_collection_members recipe_collection_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_pkey PRIMARY KEY (id);


--
-- Name: recipe_collections recipe_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipe_tag_configs recipe_tag_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shopping_exclusions shopping_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_history shopping_list_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_items shopping_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_pkey PRIMARY KEY (id);


--
-- Name: shopping_lists shopping_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_pkey PRIMARY KEY (id);


--
-- Name: stock_anchors stock_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger_totals stock_ledger_totals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_pkey PRIMARY KEY (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_lots stock_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_pkey PRIMARY KEY (id);


--
-- Name: stock_moves stock_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_closed_locations stock_take_closed_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_counts stock_take_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_take_items stock_take_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);


--
-- Name: stock_takes stock_takes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);


--
-- Name: stock_valuation_layers stock_valuation_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: storage_types storage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tax_rate_assignments tax_rate_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_pkey PRIMARY KEY (id);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: unit_conversions unit_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom_categories uom_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_pkey PRIMARY KEY (id);


--
-- Name: uoms uoms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_pkey PRIMARY KEY (id);


--
-- Name: ai_connections uq_ai_connections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT uq_ai_connections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_bom_lines uq_bom_recipe_child; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT uq_bom_recipe_child UNIQUE (recipe_id, child_template_id);


--
-- Name: document_type_configs uq_doctype_config_org_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT uq_doctype_config_org_type UNIQUE (organization_id, document_type);


--
-- Name: documents uq_document_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT uq_document_org_number UNIQUE (organization_id, number);


--
-- Name: document_package_lines uq_document_package_lines_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT uq_document_package_lines_line UNIQUE (document_package_id, document_line_id);


--
-- Name: document_packages uq_document_packages_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT uq_document_packages_number UNIQUE (document_id, number);


--
-- Name: document_profiles uq_document_profile_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT uq_document_profile_org UNIQUE (organization_id);


--
-- Name: document_shipments uq_document_shipments_document; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT uq_document_shipments_document UNIQUE (document_id);


--
-- Name: document_warehouse_receiving uq_document_warehouse_receiving_org_warehouse; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT uq_document_warehouse_receiving_org_warehouse UNIQUE (organization_id, warehouse_id);


--
-- Name: event_deliveries uq_event_deliveries_event_handler; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT uq_event_deliveries_event_handler UNIQUE (event_id, handler);


--
-- Name: ingredient_nutrition_defaults uq_ingredient_defaults_org_lang_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT uq_ingredient_defaults_org_lang_name UNIQUE (organization_id, lang, name_normalized);


--
-- Name: inventory_periods uq_inventory_period_org_year_month; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT uq_inventory_period_org_year_month UNIQUE (organization_id, year, month);


--
-- Name: label_pool uq_label_pool_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT uq_label_pool_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: stock_lots uq_lot_org_product_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT uq_lot_org_product_name UNIQUE (organization_id, product_template_id, name);


--
-- Name: meal_plan_entries uq_meal_plan_entries_plan_date_slot_order; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT uq_meal_plan_entries_plan_date_slot_order UNIQUE (meal_plan_id, date, slot, "order");


--
-- Name: partners uq_partner_org_name_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT uq_partner_org_name_type UNIQUE (organization_id, name, type);


--
-- Name: po_reorder_rules uq_po_reorder_rules_org_product_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT uq_po_reorder_rules_org_product_loc UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: po_settings uq_po_settings_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT uq_po_settings_org UNIQUE (organization_id);


--
-- Name: print_agents uq_print_agents_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT uq_print_agents_org_name UNIQUE (organization_id, name);


--
-- Name: purchase_orders uq_purchase_orders_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT uq_purchase_orders_org_number UNIQUE (organization_id, number);


--
-- Name: putaway_capacity uq_putaway_capacity_org_loc_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT uq_putaway_capacity_org_loc_product UNIQUE (organization_id, location_id, product_template_id);


--
-- Name: putaway_home_silenced uq_putaway_home_silenced_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT uq_putaway_home_silenced_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: putaway_location_settings uq_putaway_location_settings_org_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT uq_putaway_location_settings_org_loc UNIQUE (organization_id, location_id);


--
-- Name: putaway_rule_locations uq_putaway_rule_locations_rule_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT uq_putaway_rule_locations_rule_loc UNIQUE (rule_id, location_id);


--
-- Name: recipe_collection_members uq_recipe_collection_members; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT uq_recipe_collection_members UNIQUE (collection_id, recipe_id);


--
-- Name: recipe_collections uq_recipe_collections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT uq_recipe_collections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_recipes uq_recipe_org_template_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT uq_recipe_org_template_name UNIQUE (organization_id, output_template_id, name);


--
-- Name: recipe_tag_configs uq_recipe_tag_configs_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT uq_recipe_tag_configs_org_name UNIQUE (organization_id, name);


--
-- Name: shopping_exclusions uq_shopping_exclusions_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT uq_shopping_exclusions_org_name UNIQUE (organization_id, name_normalized);


--
-- Name: stock_anchors uq_stock_anchor_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT uq_stock_anchor_group UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_take_closed_locations uq_stock_take_closed_locations_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT uq_stock_take_closed_locations_location UNIQUE (stock_take_id, storage_location_id);


--
-- Name: storage_locations uq_storage_locations_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT uq_storage_locations_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_category; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_category UNIQUE (organization_id, category_id);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: unit_conversions uq_unit_conv_org_ingredient_unit_lang; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT uq_unit_conv_org_ingredient_unit_lang UNIQUE (organization_id, ingredient_key, source_unit, lang);


--
-- Name: uom_categories uq_uom_category_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uq_uom_category_org_name UNIQUE (organization_id, name);


--
-- Name: uoms uq_uom_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uq_uom_org_name UNIQUE (organization_id, name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pkey PRIMARY KEY (pick_line_id, lot_id);


--
-- Name: wms_pick_lines wms_pick_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_session_documents wms_pick_session_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_pkey PRIMARY KEY (session_id, document_id);


--
-- Name: wms_pick_sessions wms_pick_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_connections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_connections_organization_id ON public.ai_connections USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_created_at ON public.ai_usage_logs USING btree (created_at);


--
-- Name: ix_ai_usage_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_organization_id ON public.ai_usage_logs USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_user_id ON public.ai_usage_logs USING btree (user_id);


--
-- Name: ix_api_keys_hashed_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_api_keys_hashed_key ON public.api_keys USING btree (hashed_key);


--
-- Name: ix_api_keys_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_organization_id ON public.api_keys USING btree (organization_id);


--
-- Name: ix_approval_decisions_approval_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_decisions_approval_request_id ON public.approval_decisions USING btree (approval_request_id);


--
-- Name: ix_approval_requests_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_organization_id ON public.approval_requests USING btree (organization_id);


--
-- Name: ix_approval_requests_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_target ON public.approval_requests USING btree (target_type, target_id, organization_id);


--
-- Name: ix_approval_workflows_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_workflows_organization_id ON public.approval_workflows USING btree (organization_id);


--
-- Name: ix_audit_campaigns_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_org ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_campaigns_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_organization_id ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_log_org_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_created_at_id ON public.audit_log USING btree (organization_id, created_at DESC, id);


--
-- Name: ix_audit_log_org_type_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_type_created_at ON public.audit_log USING btree (organization_id, target_type, created_at DESC, id);


--
-- Name: ix_audit_log_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_organization_id ON public.audit_log USING btree (organization_id);


--
-- Name: ix_audit_log_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_target ON public.audit_log USING btree (target_type, target_id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_audit_response_items_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_assignment_id ON public.audit_response_items USING btree (assignment_id);


--
-- Name: ix_audit_response_items_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_item_id ON public.audit_response_items USING btree (item_id);


--
-- Name: ix_audit_response_items_response_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_response_id ON public.audit_response_items USING btree (response_id);


--
-- Name: ix_audit_responses_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_assignment_id ON public.audit_responses USING btree (assignment_id);


--
-- Name: ix_audit_responses_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_id ON public.audit_responses USING btree (campaign_id);


--
-- Name: ix_audit_responses_campaign_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_status ON public.audit_responses USING btree (campaign_id, status);


--
-- Name: ix_audit_responses_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_organization_id ON public.audit_responses USING btree (organization_id);


--
-- Name: ix_audit_responses_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_responses_token ON public.audit_responses USING btree (token);


--
-- Name: ix_bom_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_org ON public.maker_bom_lines USING btree (organization_id);


--
-- Name: ix_bom_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_parent ON public.maker_bom_lines USING btree (parent_template_id);


--
-- Name: ix_bom_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_recipe ON public.maker_bom_lines USING btree (recipe_id);


--
-- Name: ix_categories_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_code ON public.categories USING btree (code);


--
-- Name: ix_categories_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_context_tag ON public.categories USING btree (context_tag);


--
-- Name: ix_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_is_active ON public.categories USING btree (is_active);


--
-- Name: ix_categories_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_module_name ON public.categories USING btree (module_name);


--
-- Name: ix_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_organization_id ON public.categories USING btree (organization_id);


--
-- Name: ix_cycle_count_schedules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cycle_count_schedules_organization_id ON public.cycle_count_schedules USING btree (organization_id);


--
-- Name: ix_doc_relation_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_source ON public.document_relations USING btree (source_document_id);


--
-- Name: ix_doc_relation_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_target ON public.document_relations USING btree (target_document_id);


--
-- Name: ix_doc_templates_org_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_templates_org_module ON public.document_templates USING btree (organization_id, module);


--
-- Name: ix_document_extra_costs_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_document ON public.document_extra_costs USING btree (document_id);


--
-- Name: ix_document_extra_costs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_organization_id ON public.document_extra_costs USING btree (organization_id);


--
-- Name: ix_document_lines_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_brand_trgm ON public.document_lines USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_document_lines_corrects_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_corrects_line_id ON public.document_lines USING btree (corrects_line_id);


--
-- Name: ix_document_lines_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_document_id ON public.document_lines USING btree (document_id);


--
-- Name: ix_document_lines_held; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_held ON public.document_lines USING btree (document_id) WHERE (held_quantity > (0)::numeric);


--
-- Name: ix_document_lines_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_name_trgm ON public.document_lines USING gin (name public.gin_trgm_ops);


--
-- Name: ix_document_lines_puts_away_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_puts_away_line_id ON public.document_lines USING btree (puts_away_line_id);


--
-- Name: ix_document_lines_source_po_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_source_po_line_id ON public.document_lines USING btree (source_po_line_id);


--
-- Name: ix_document_org_partner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_partner ON public.documents USING btree (organization_id, partner_id);


--
-- Name: ix_document_org_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_status_created_at ON public.documents USING btree (organization_id, status, created_at);


--
-- Name: ix_document_org_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_type_status ON public.documents USING btree (organization_id, type, status);


--
-- Name: ix_document_package_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_line_id ON public.document_package_lines USING btree (document_line_id);


--
-- Name: ix_document_package_lines_document_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_package_id ON public.document_package_lines USING btree (document_package_id);


--
-- Name: ix_document_packages_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_document_id ON public.document_packages USING btree (document_id);


--
-- Name: ix_document_packages_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_organization_id ON public.document_packages USING btree (organization_id);


--
-- Name: ix_document_profiles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_profiles_organization_id ON public.document_profiles USING btree (organization_id);


--
-- Name: ix_document_shipments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shipments_organization_id ON public.document_shipments USING btree (organization_id);


--
-- Name: ix_document_templates_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_module ON public.document_templates USING btree (module);


--
-- Name: ix_document_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_organization_id ON public.document_templates USING btree (organization_id);


--
-- Name: ix_document_type_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_type_configs_organization_id ON public.document_type_configs USING btree (organization_id);


--
-- Name: ix_document_warehouse_receiving_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_warehouse_receiving_organization_id ON public.document_warehouse_receiving USING btree (organization_id);


--
-- Name: ix_document_work_item_overlays_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_work_item_overlays_organization_id ON public.document_work_item_overlays USING btree (organization_id);


--
-- Name: ix_documents_backorder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_backorder_id ON public.documents USING btree (backorder_id);


--
-- Name: ix_documents_corrects_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_corrects_document_id ON public.documents USING btree (corrects_document_id);


--
-- Name: ix_documents_external_reference_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_external_reference_trgm ON public.documents USING gin (external_reference public.gin_trgm_ops);


--
-- Name: ix_documents_notes_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_notes_trgm ON public.documents USING gin (notes public.gin_trgm_ops);


--
-- Name: ix_documents_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_number_trgm ON public.documents USING gin (number public.gin_trgm_ops);


--
-- Name: ix_documents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_organization_id ON public.documents USING btree (organization_id);


--
-- Name: ix_documents_partner_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_partner_name_trgm ON public.documents USING gin (((partner_snapshot ->> 'name'::text)) public.gin_trgm_ops);


--
-- Name: ix_email_jobs_next_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_next_attempt_at ON public.email_jobs USING btree (next_attempt_at);


--
-- Name: ix_email_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_organization_id ON public.email_jobs USING btree (organization_id);


--
-- Name: ix_email_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_status ON public.email_jobs USING btree (status);


--
-- Name: ix_eq_assignments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_assignments_org_item ON public.equipment_assignments USING btree (organization_id, item_id);


--
-- Name: ix_eq_attachments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_attachments_org_item ON public.equipment_attachments USING btree (organization_id, item_id);


--
-- Name: ix_eq_maintenance_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_maintenance_org_item ON public.equipment_maintenance_logs USING btree (organization_id, item_id);


--
-- Name: ix_equipment_assignments_assignee_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_assignee_partner_id ON public.equipment_assignments USING btree (assignee_partner_id);


--
-- Name: ix_equipment_assignments_checkout_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_checkout_location_id ON public.equipment_assignments USING btree (checkout_location_id);


--
-- Name: ix_equipment_assignments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_item_id ON public.equipment_assignments USING btree (item_id);


--
-- Name: ix_equipment_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_organization_id ON public.equipment_assignments USING btree (organization_id);


--
-- Name: ix_equipment_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_item_id ON public.equipment_attachments USING btree (item_id);


--
-- Name: ix_equipment_attachments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_organization_id ON public.equipment_attachments USING btree (organization_id);


--
-- Name: ix_equipment_maintenance_logs_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_item_id ON public.equipment_maintenance_logs USING btree (item_id);


--
-- Name: ix_equipment_maintenance_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_organization_id ON public.equipment_maintenance_logs USING btree (organization_id);


--
-- Name: ix_event_deliveries_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_organization_id ON public.event_deliveries USING btree (organization_id);


--
-- Name: ix_event_deliveries_status_next_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_status_next_attempt ON public.event_deliveries USING btree (status, next_attempt_at);


--
-- Name: ix_event_outbox_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_organization_id ON public.event_outbox USING btree (organization_id);


--
-- Name: ix_event_outbox_unpublished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_unpublished ON public.event_outbox USING btree (created_at) WHERE (published_at IS NULL);


--
-- Name: ix_example_widgets_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_example_widgets_organization_id ON public.example_widgets USING btree (organization_id);


--
-- Name: ix_ingredient_defaults_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_defaults_lookup ON public.ingredient_nutrition_defaults USING btree (name_normalized, lang, organization_id);


--
-- Name: ix_ingredient_nutrition_defaults_name_normalized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_name_normalized ON public.ingredient_nutrition_defaults USING btree (name_normalized);


--
-- Name: ix_ingredient_nutrition_defaults_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_organization_id ON public.ingredient_nutrition_defaults USING btree (organization_id);


--
-- Name: ix_item_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_attachments_item_id ON public.item_attachments USING btree (item_id);


--
-- Name: ix_item_history_item_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_item_created ON public.item_history USING btree (item_id, created_at);


--
-- Name: ix_item_history_org_action_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_org_action_created ON public.item_history USING btree (organization_id, action, created_at);


--
-- Name: ix_item_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_organization_id ON public.item_history USING btree (organization_id);


--
-- Name: ix_item_history_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_source_document_id ON public.item_history USING btree (source_document_id);


--
-- Name: ix_item_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_user_id ON public.item_history USING btree (user_id);


--
-- Name: ix_item_import_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_import_jobs_organization_id ON public.item_import_jobs USING btree (organization_id);


--
-- Name: ix_items_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode ON public.items USING btree (barcode);


--
-- Name: ix_items_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode_trgm ON public.items USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_items_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_brand_trgm ON public.items USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_items_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_created_at ON public.items USING btree (created_at);


--
-- Name: ix_items_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_expiry_date ON public.items USING btree (expiry_date);


--
-- Name: ix_items_is_catalog_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_catalog_entry ON public.items USING btree (is_catalog_entry);


--
-- Name: ix_items_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_deleted ON public.items USING btree (is_deleted);


--
-- Name: ix_items_label_code_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_label_code_trgm ON public.items USING gin (label_code public.gin_trgm_ops);


--
-- Name: ix_items_meta_data_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_meta_data_gin ON public.items USING gin (meta_data);


--
-- Name: ix_items_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_module_name ON public.items USING btree (module_name);


--
-- Name: ix_items_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_name_trgm ON public.items USING gin (name public.gin_trgm_ops);


--
-- Name: ix_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_barcode_active ON public.items USING btree (organization_id, barcode, is_deleted);


--
-- Name: ix_items_org_category_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_category_active ON public.items USING btree (organization_id, category_id, is_deleted);


--
-- Name: ix_items_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_created ON public.items USING btree (organization_id, is_deleted, created_at DESC);


--
-- Name: ix_items_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_name ON public.items USING btree (organization_id, is_deleted, name);


--
-- Name: ix_items_org_not_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_not_deleted ON public.items USING btree (organization_id, is_deleted);


--
-- Name: ix_items_org_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_template_active ON public.items USING btree (organization_id, template_id, is_deleted);


--
-- Name: ix_items_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_organization_id ON public.items USING btree (organization_id);


--
-- Name: ix_items_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_partner_id ON public.items USING btree (partner_id);


--
-- Name: ix_items_quantity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_quantity ON public.items USING btree (quantity);


--
-- Name: ix_items_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number ON public.items USING btree (serial_number);


--
-- Name: ix_items_serial_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number_trgm ON public.items USING gin (serial_number public.gin_trgm_ops);


--
-- Name: ix_items_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_source_document_id ON public.items USING btree (source_document_id);


--
-- Name: ix_items_stock_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_stock_group ON public.items USING btree (organization_id, template_id, storage_location_id, lot_id, owner_id) INCLUDE (quantity, is_deleted);


--
-- Name: ix_items_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_storage_location_id ON public.items USING btree (storage_location_id);


--
-- Name: ix_label_pool_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_context_tag ON public.label_pool USING btree (context_tag);


--
-- Name: ix_label_pool_is_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_is_assigned ON public.label_pool USING btree (is_assigned);


--
-- Name: ix_location_relocations_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_relocations_org_moved_at ON public.location_relocations USING btree (organization_id, moved_at);


--
-- Name: ix_lot_org_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_org_expiry ON public.stock_lots USING btree (organization_id, expiry_date);


--
-- Name: ix_meal_plan_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_date ON public.meal_plan_entries USING btree (date);


--
-- Name: ix_meal_plan_entries_meal_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_meal_plan_id ON public.meal_plan_entries USING btree (meal_plan_id);


--
-- Name: ix_meal_plan_entries_plan_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_plan_date ON public.meal_plan_entries USING btree (meal_plan_id, date);


--
-- Name: ix_meal_plan_entries_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_recipe ON public.meal_plan_entries USING btree (recipe_id);


--
-- Name: ix_meal_plans_org_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_end ON public.meal_plans USING btree (organization_id, end_date);


--
-- Name: ix_meal_plans_org_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_start ON public.meal_plans USING btree (organization_id, start_date);


--
-- Name: ix_meal_plans_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_organization_id ON public.meal_plans USING btree (organization_id);


--
-- Name: ix_module_installations_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_module_installations_module_name ON public.module_installations USING btree (module_name);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_organization_invitations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organization_invitations_code ON public.organization_invitations USING btree (code);


--
-- Name: ix_organizations_short_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_short_id ON public.organizations USING btree (short_id);


--
-- Name: ix_partners_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_code ON public.partners USING btree (code);


--
-- Name: ix_partners_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_is_active ON public.partners USING btree (is_active);


--
-- Name: ix_partners_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_name_trgm ON public.partners USING gin (name public.gin_trgm_ops);


--
-- Name: ix_partners_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_organization_id ON public.partners USING btree (organization_id);


--
-- Name: ix_picking_session_items_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_session_items_session_id ON public.picking_session_items USING btree (session_id);


--
-- Name: ix_picking_sessions_meal_plan_entry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_meal_plan_entry_id ON public.picking_sessions USING btree (meal_plan_entry_id);


--
-- Name: ix_picking_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_organization_id ON public.picking_sessions USING btree (organization_id);


--
-- Name: ix_picking_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_user_id ON public.picking_sessions USING btree (user_id);


--
-- Name: ix_po_partner_pricelist_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_organization_id ON public.po_partner_pricelist USING btree (organization_id);


--
-- Name: ix_po_partner_pricelist_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_partner_id ON public.po_partner_pricelist USING btree (partner_id);


--
-- Name: ix_po_partner_pricelist_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_product_template_id ON public.po_partner_pricelist USING btree (product_template_id);


--
-- Name: ix_po_partner_pricelist_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_template_active ON public.po_partner_pricelist USING btree (product_template_id, valid_from, valid_to);


--
-- Name: ix_po_reorder_rules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_organization_id ON public.po_reorder_rules USING btree (organization_id);


--
-- Name: ix_po_reorder_rules_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_product_template_id ON public.po_reorder_rules USING btree (product_template_id);


--
-- Name: ix_po_reorder_rules_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_storage_location_id ON public.po_reorder_rules USING btree (storage_location_id);


--
-- Name: ix_po_settings_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_settings_organization_id ON public.po_settings USING btree (organization_id);


--
-- Name: ix_print_agents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_agents_organization_id ON public.print_agents USING btree (organization_id);


--
-- Name: ix_print_jobs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_agent_id ON public.print_jobs USING btree (agent_id);


--
-- Name: ix_print_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_organization_id ON public.print_jobs USING btree (organization_id);


--
-- Name: ix_print_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_status ON public.print_jobs USING btree (status);


--
-- Name: ix_prod_line_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_line_order ON public.maker_production_order_lines USING btree (production_order_id);


--
-- Name: ix_prod_org_output; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_output ON public.maker_production_orders USING btree (organization_id, output_template_id);


--
-- Name: ix_prod_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_status ON public.maker_production_orders USING btree (organization_id, status);


--
-- Name: ix_product_templates_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode ON public.product_templates USING btree (barcode);


--
-- Name: ix_product_templates_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode_trgm ON public.product_templates USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_product_templates_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_name_trgm ON public.product_templates USING gin (name public.gin_trgm_ops);


--
-- Name: ix_product_templates_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_org_name ON public.product_templates USING btree (organization_id, name);


--
-- Name: ix_product_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_organization_id ON public.product_templates USING btree (organization_id);


--
-- Name: ix_product_templates_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku ON public.product_templates USING btree (sku);


--
-- Name: ix_product_templates_sku_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku_trgm ON public.product_templates USING gin (sku public.gin_trgm_ops);


--
-- Name: ix_purchase_order_lines_purchase_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_purchase_order_id ON public.purchase_order_lines USING btree (purchase_order_id);


--
-- Name: ix_purchase_order_lines_source_reorder_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_source_reorder_rule_id ON public.purchase_order_lines USING btree (source_reorder_rule_id);


--
-- Name: ix_purchase_orders_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_number ON public.purchase_orders USING btree (number);


--
-- Name: ix_purchase_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_organization_id ON public.purchase_orders USING btree (organization_id);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_putaway_capacity_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_capacity_org ON public.putaway_capacity USING btree (organization_id);


--
-- Name: ix_putaway_home_silenced_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_home_silenced_organization_id ON public.putaway_home_silenced USING btree (organization_id);


--
-- Name: ix_putaway_rule_locations_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rule_locations_rule ON public.putaway_rule_locations USING btree (rule_id);


--
-- Name: ix_putaway_rules_org_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_category ON public.putaway_rules USING btree (organization_id, category_id);


--
-- Name: ix_putaway_rules_org_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_priority ON public.putaway_rules USING btree (organization_id, priority);


--
-- Name: ix_putaway_rules_org_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_product ON public.putaway_rules USING btree (organization_id, product_template_id);


--
-- Name: ix_recipe_collection_members_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_collection_id ON public.recipe_collection_members USING btree (collection_id);


--
-- Name: ix_recipe_collection_members_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_recipe_id ON public.recipe_collection_members USING btree (recipe_id);


--
-- Name: ix_recipe_collections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_organization_id ON public.recipe_collections USING btree (organization_id);


--
-- Name: ix_recipe_collections_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_parent_id ON public.recipe_collections USING btree (parent_id);


--
-- Name: ix_recipe_cost_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_org ON public.maker_recipe_cost_lines USING btree (organization_id);


--
-- Name: ix_recipe_cost_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_recipe ON public.maker_recipe_cost_lines USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_ingredient_group_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_ingredient_group_name ON public.recipe_ingredients USING btree (ingredient_group_name);


--
-- Name: ix_recipe_ingredients_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_recipe_id ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_template_id ON public.recipe_ingredients USING btree (template_id);


--
-- Name: ix_recipe_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_org_template ON public.maker_recipes USING btree (organization_id, output_template_id);


--
-- Name: ix_recipe_tag_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_tag_configs_organization_id ON public.recipe_tag_configs USING btree (organization_id);


--
-- Name: ix_recipes_is_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_is_favorite ON public.recipes USING btree (is_favorite);


--
-- Name: ix_recipes_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_organization_id ON public.recipes USING btree (organization_id);


--
-- Name: ix_registration_requests_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);


--
-- Name: ix_registration_requests_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_token ON public.registration_requests USING btree (token);


--
-- Name: ix_reservation_anchor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_anchor ON public.stock_reservations USING btree (anchor_id);


--
-- Name: ix_reservation_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_document ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_reservation_org_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_org_doc ON public.stock_reservations USING btree (organization_id, document_id);


--
-- Name: ix_roles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_organization_id ON public.roles USING btree (organization_id);


--
-- Name: ix_shopping_exclusions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_exclusions_organization_id ON public.shopping_exclusions USING btree (organization_id);


--
-- Name: ix_shopping_list_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_organization_id ON public.shopping_list_history USING btree (organization_id);


--
-- Name: ix_shopping_list_history_original_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_original_list_id ON public.shopping_list_history USING btree (original_list_id);


--
-- Name: ix_shopping_list_items_is_purchased; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_items_is_purchased ON public.shopping_list_items USING btree (is_purchased);


--
-- Name: ix_shopping_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_lists_status ON public.shopping_lists USING btree (status);


--
-- Name: ix_stock_anchors_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_product_template_id ON public.stock_anchors USING btree (product_template_id);


--
-- Name: ix_stock_anchors_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_storage_location_id ON public.stock_anchors USING btree (storage_location_id);


--
-- Name: ix_stock_ledger_totals_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_product_template_id ON public.stock_ledger_totals USING btree (product_template_id);


--
-- Name: ix_stock_ledger_totals_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_storage_location_id ON public.stock_ledger_totals USING btree (storage_location_id);


--
-- Name: ix_stock_lots_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_expiry_date ON public.stock_lots USING btree (expiry_date);


--
-- Name: ix_stock_lots_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_organization_id ON public.stock_lots USING btree (organization_id);


--
-- Name: ix_stock_lots_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_product_template_id ON public.stock_lots USING btree (product_template_id);


--
-- Name: ix_stock_moves_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_completed_at ON public.stock_moves USING btree (completed_at);


--
-- Name: ix_stock_moves_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_at ON public.stock_moves USING btree (created_at);


--
-- Name: ix_stock_moves_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_by ON public.stock_moves USING btree (created_by);


--
-- Name: ix_stock_moves_from_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_from_loc ON public.stock_moves USING btree (from_location_id);


--
-- Name: ix_stock_moves_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_lot_id ON public.stock_moves USING btree (lot_id);


--
-- Name: ix_stock_moves_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_moved_at ON public.stock_moves USING btree (organization_id, COALESCE(completed_at, created_at) DESC, id);


--
-- Name: ix_stock_moves_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_template ON public.stock_moves USING btree (organization_id, product_template_id);


--
-- Name: ix_stock_moves_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_organization_id ON public.stock_moves USING btree (organization_id);


--
-- Name: ix_stock_moves_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_owner_id ON public.stock_moves USING btree (owner_id);


--
-- Name: ix_stock_moves_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_product_template_id ON public.stock_moves USING btree (product_template_id);


--
-- Name: ix_stock_moves_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_reference ON public.stock_moves USING btree (reference_type, reference_id);


--
-- Name: ix_stock_moves_to_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_to_loc ON public.stock_moves USING btree (to_location_id);


--
-- Name: ix_stock_reservations_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_document_id ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_stock_reservations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_organization_id ON public.stock_reservations USING btree (organization_id);


--
-- Name: ix_stock_take_closed_locations_stock_take_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_closed_locations_stock_take_id ON public.stock_take_closed_locations USING btree (stock_take_id);


--
-- Name: ix_stock_take_counts_stock_take_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_counts_stock_take_item_id ON public.stock_take_counts USING btree (stock_take_item_id);


--
-- Name: ix_stock_takes_schedule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_takes_schedule_id ON public.stock_takes USING btree (schedule_id);


--
-- Name: ix_stock_valuation_layers_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_organization_id ON public.stock_valuation_layers USING btree (organization_id);


--
-- Name: ix_stock_valuation_layers_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_product_template_id ON public.stock_valuation_layers USING btree (product_template_id);


--
-- Name: ix_storage_locations_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_context_tag ON public.storage_locations USING btree (context_tag);


--
-- Name: ix_storage_locations_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_org_name ON public.storage_locations USING btree (organization_id, name);


--
-- Name: ix_storage_locations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_organization_id ON public.storage_locations USING btree (organization_id);


--
-- Name: ix_storage_locations_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_parent_id ON public.storage_locations USING btree (parent_id);


--
-- Name: ix_svl_org_direction_dated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_dated_at ON public.stock_valuation_layers USING btree (organization_id, direction, COALESCE(document_date, ((created_at AT TIME ZONE 'UTC'::text))::date), created_at, id);


--
-- Name: ix_svl_org_direction_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_reason ON public.stock_valuation_layers USING btree (organization_id, direction, reason);


--
-- Name: ix_svl_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_template ON public.stock_valuation_layers USING btree (organization_id, product_template_id);


--
-- Name: ix_svl_template_remaining; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_template_remaining ON public.stock_valuation_layers USING btree (organization_id, product_template_id, remaining_qty);


--
-- Name: ix_tax_rate_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_organization_id ON public.tax_rate_assignments USING btree (organization_id);


--
-- Name: ix_tax_rate_assignments_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_tax_rate_id ON public.tax_rate_assignments USING btree (tax_rate_id);


--
-- Name: ix_tax_rates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rates_organization_id ON public.tax_rates USING btree (organization_id);


--
-- Name: ix_unit_conv_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conv_lookup ON public.unit_conversions USING btree (ingredient_key, source_unit, lang, organization_id);


--
-- Name: ix_unit_conversions_ingredient_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_ingredient_key ON public.unit_conversions USING btree (ingredient_key);


--
-- Name: ix_unit_conversions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_organization_id ON public.unit_conversions USING btree (organization_id);


--
-- Name: ix_uom_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uom_categories_organization_id ON public.uom_categories USING btree (organization_id);


--
-- Name: ix_uoms_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uoms_organization_id ON public.uoms USING btree (organization_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_is_superuser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_is_superuser ON public.users USING btree (is_superuser);


--
-- Name: ix_users_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_organization_id ON public.users USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_organization_id ON public.webhook_delivery_logs USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_webhook_endpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_webhook_endpoint_id ON public.webhook_delivery_logs USING btree (webhook_endpoint_id);


--
-- Name: ix_webhook_endpoints_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_endpoints_organization_id ON public.webhook_endpoints USING btree (organization_id);


--
-- Name: ix_wms_pick_line_lots_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_line_lots_lot_id ON public.wms_pick_line_lots USING btree (lot_id);


--
-- Name: ix_wms_pick_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_document_line_id ON public.wms_pick_lines USING btree (document_line_id);


--
-- Name: ix_wms_pick_lines_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_session_id ON public.wms_pick_lines USING btree (session_id);


--
-- Name: ix_wms_pick_session_documents_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_session_documents_document_id ON public.wms_pick_session_documents USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_document_id ON public.wms_pick_sessions USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_organization_id ON public.wms_pick_sessions USING btree (organization_id);


--
-- Name: uq_document_org_post_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_org_post_key ON public.documents USING btree (organization_id, post_key) WHERE (post_key IS NOT NULL);


--
-- Name: uq_document_work_item_overlays_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_work_item_overlays_source ON public.document_work_item_overlays USING btree (organization_id, source_kind, source_id) WHERE (source_id IS NOT NULL);


--
-- Name: uq_eq_assignments_active_per_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_eq_assignments_active_per_item ON public.equipment_assignments USING btree (item_id) WHERE (checked_in_at IS NULL);


--
-- Name: uq_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_barcode_active ON public.items USING btree (organization_id, barcode) WHERE ((barcode IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_items_org_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_serial ON public.items USING btree (organization_id, serial_number) WHERE ((serial_number IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_partner_org_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_partner_org_code ON public.partners USING btree (organization_id, code) WHERE (code IS NOT NULL);


--
-- Name: uq_pending_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pending_request ON public.approval_requests USING btree (organization_id, target_type, target_id) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying])::text[]));


--
-- Name: uq_prod_org_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_prod_org_number ON public.maker_production_orders USING btree (organization_id, number) WHERE (number IS NOT NULL);


--
-- Name: uq_recipe_default_per_template; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_recipe_default_per_template ON public.maker_recipes USING btree (organization_id, output_template_id) WHERE (is_default = true);


--
-- Name: uq_stock_moves_backfill_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_stock_moves_backfill_ref ON public.stock_moves USING btree (reference_type, reference_id) WHERE ((reference_type)::text = 'item_history'::text);


--
-- Name: uq_templates_org_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_barcode ON public.product_templates USING btree (organization_id, barcode) WHERE (barcode IS NOT NULL);


--
-- Name: uq_templates_org_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_sku ON public.product_templates USING btree (organization_id, sku) WHERE (sku IS NOT NULL);


--
-- Name: uq_uom_category_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uom_category_reference ON public.uoms USING btree (category_id) WHERE (is_reference = true);


--
-- Name: uq_workflow_org_target; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_workflow_org_target ON public.approval_workflows USING btree (organization_id, target_type) WHERE (archived_at IS NULL);


--
-- Name: audit_log audit_log_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_log_immutable BEFORE DELETE OR UPDATE ON public.audit_log FOR EACH ROW EXECUTE FUNCTION public.audit_log_immutable();


--
-- Name: items ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER UPDATE OF quantity, lot_id, owner_id, storage_location_id, template_id, is_deleted ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL) AND ((new.is_deleted IS NOT FALSE) OR (new.template_id IS DISTINCT FROM old.template_id) OR (new.storage_location_id IS DISTINCT FROM old.storage_location_id) OR (new.lot_id IS DISTINCT FROM old.lot_id) OR (new.owner_id IS DISTINCT FROM old.owner_id) OR (new.quantity IS NULL) OR (new.quantity = 'NaN'::numeric) OR (new.quantity < old.quantity)))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_reservations ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER INSERT OR UPDATE OF quantity, anchor_id, lot_id, owner_id ON public.stock_reservations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: items ck_stock_holds_within_stock_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock_on_delete AFTER DELETE ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_moves stock_ledger_totals_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_delete AFTER DELETE ON public.stock_moves REFERENCING OLD TABLE AS old_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_insert AFTER INSERT ON public.stock_moves REFERENCING NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_update AFTER UPDATE ON public.stock_moves REFERENCING OLD TABLE AS old_moves NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: ai_connections ai_connections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approval_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approval_request_id_fkey FOREIGN KEY (approval_request_id) REFERENCES public.approval_requests(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.approval_workflows(id) ON DELETE RESTRICT;


--
-- Name: approval_workflows approval_workflows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_campaigns audit_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_campaigns audit_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_response_items audit_response_items_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_response_id_fkey FOREIGN KEY (response_id) REFERENCES public.audit_responses(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.audit_campaigns(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: categories categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_extra_costs document_extra_costs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_corrects_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_corrects_line_id_fkey FOREIGN KEY (corrects_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_executed_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_executed_location_id_fkey FOREIGN KEY (executed_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_puts_away_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_puts_away_line_id_fkey FOREIGN KEY (puts_away_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: document_number_sequences document_number_sequences_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_package_id_fkey FOREIGN KEY (document_package_id) REFERENCES public.document_packages(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_packages document_packages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_default_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_default_template_id_fkey FOREIGN KEY (default_template_id) REFERENCES public.document_templates(id) ON DELETE SET NULL;


--
-- Name: document_profiles document_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_quarantine_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_quarantine_location_id_fkey FOREIGN KEY (quarantine_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_relations document_relations_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_relations document_relations_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_shipped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_shipped_by_fkey FOREIGN KEY (shipped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_type_configs document_type_configs_default_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_source_location_id_fkey FOREIGN KEY (default_source_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_default_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_target_location_id_fkey FOREIGN KEY (default_target_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_receiving_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_receiving_location_id_fkey FOREIGN KEY (receiving_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: document_work_item_overlays document_work_item_overlays_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_backorder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_backorder_id_fkey FOREIGN KEY (backorder_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: documents documents_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_corrects_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_corrects_document_id_fkey FOREIGN KEY (corrects_document_id) REFERENCES public.documents(id) ON DELETE RESTRICT;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: documents documents_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: documents documents_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_assignee_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_assignee_partner_id_fkey FOREIGN KEY (assignee_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_in_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_in_by_fkey FOREIGN KEY (checked_in_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_out_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_out_by_fkey FOREIGN KEY (checked_out_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checkout_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checkout_location_id_fkey FOREIGN KEY (checkout_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_assignments equipment_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_service_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_service_partner_id_fkey FOREIGN KEY (service_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: example_widgets example_widgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests fk_approval_requests_consumed_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_approval_requests_consumed_by_users FOREIGN KEY (consumed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_history fk_item_history_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_stock_anchor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_stock_anchor FOREIGN KEY (organization_id, template_id, storage_location_id) REFERENCES public.stock_anchors(organization_id, product_template_id, storage_location_id);


--
-- Name: label_pool fk_label_pool_item_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_item_id FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: organizations fk_organizations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT fk_organizations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: picking_sessions fk_picking_sessions_meal_plan_entry_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT fk_picking_sessions_meal_plan_entry_id FOREIGN KEY (meal_plan_entry_id) REFERENCES public.meal_plan_entries(id) ON DELETE SET NULL;


--
-- Name: stock_reservations fk_stock_reservations_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT fk_stock_reservations_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_expected_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_expected_location_id FOREIGN KEY (expected_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_storage_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_storage_location_id FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: users fk_users_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wms_pick_lines fk_wms_pick_lines_anchor_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_anchor_id FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines fk_wms_pick_lines_lot_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_lot_id FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_periods inventory_periods_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_reopened_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_reopened_by_fkey FOREIGN KEY (reopened_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_attachments item_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_import_jobs item_import_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_import_jobs item_import_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: items items_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: items items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: items items_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: items items_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: items items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id);


--
-- Name: items items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: label_pool label_pool_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: label_pool label_pool_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: label_pool label_pool_target_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_target_storage_location_id_fkey FOREIGN KEY (target_storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_from_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_from_parent_id_fkey FOREIGN KEY (from_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: location_relocations location_relocations_to_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_to_parent_id_fkey FOREIGN KEY (to_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: maker_bom_lines maker_bom_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_parent_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_parent_template_id_fkey FOREIGN KEY (parent_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_module_settings maker_module_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_order_lines maker_production_order_lines_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_source_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_source_storage_location_id_fkey FOREIGN KEY (source_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_orders maker_production_orders_output_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_storage_location_id_fkey FOREIGN KEY (output_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_orders maker_production_orders_produced_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_produced_item_id_fkey FOREIGN KEY (produced_item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_batch_yield_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_batch_yield_uom_id_fkey FOREIGN KEY (batch_yield_uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_recipes maker_recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_meal_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_meal_plan_id_fkey FOREIGN KEY (meal_plan_id) REFERENCES public.meal_plans(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: meal_plans meal_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: meal_plans meal_plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: organization_invitations organization_invitations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: organization_invitations organization_invitations_used_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_used_by_user_id_fkey FOREIGN KEY (used_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_session_items picking_session_items_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.recipe_ingredients(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.picking_sessions(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: po_partner_pricelist po_partner_pricelist_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_preferred_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_preferred_partner_id_fkey FOREIGN KEY (preferred_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: po_settings po_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_agents print_agents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.print_agents(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_jobs print_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_volume_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_volume_uom_id_fkey FOREIGN KEY (volume_uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_weight_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_weight_uom_id_fkey FOREIGN KEY (weight_uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_order_lines purchase_order_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines purchase_order_lines_source_reorder_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_source_reorder_rule_id_fkey FOREIGN KEY (source_reorder_rule_id) REFERENCES public.po_reorder_rules(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_orders purchase_orders_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: putaway_capacity putaway_capacity_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.putaway_rules(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipe_collections recipe_collections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_price_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_price_uom_id_fkey FOREIGN KEY (price_uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_tag_configs recipe_tag_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipes recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: registration_requests registration_requests_approved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_approved_by_id_fkey FOREIGN KEY (approved_by_id) REFERENCES public.users(id);


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: shopping_exclusions shopping_exclusions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_exclusions shopping_exclusions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_history shopping_list_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_list_history shopping_list_history_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: shopping_list_items shopping_list_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_shopping_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_shopping_list_id_fkey FOREIGN KEY (shopping_list_id) REFERENCES public.shopping_lists(id) ON DELETE CASCADE;


--
-- Name: shopping_list_items shopping_list_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: shopping_lists shopping_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shopping_lists shopping_lists_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_anchor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_anchor_id_fkey FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_counted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_counted_by_fkey FOREIGN KEY (counted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_stock_take_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_stock_take_item_id_fkey FOREIGN KEY (stock_take_item_id) REFERENCES public.stock_take_items(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: stock_take_items stock_take_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_take_items stock_take_items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id);


--
-- Name: stock_take_items stock_take_items_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: stock_takes stock_takes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.cycle_count_schedules(id) ON DELETE SET NULL;


--
-- Name: stock_takes stock_takes_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers stock_valuation_layers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_locations storage_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: storage_locations storage_locations_storage_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_storage_type_id_fkey FOREIGN KEY (storage_type_id) REFERENCES public.storage_types(id);


--
-- Name: storage_types storage_types_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_types storage_types_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tax_rate_assignments tax_rate_assignments_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_tax_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_tax_rate_id_fkey FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rates(id) ON DELETE CASCADE;


--
-- Name: tax_rates tax_rates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: unit_conversions unit_conversions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uom_categories uom_categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uoms uoms_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.uom_categories(id);


--
-- Name: uoms uoms_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_webhook_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_webhook_endpoint_id_fkey FOREIGN KEY (webhook_endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pick_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pick_line_id_fkey FOREIGN KEY (pick_line_id) REFERENCES public.wms_pick_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines wms_pick_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: wms_pick_sessions wms_pick_sessions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


