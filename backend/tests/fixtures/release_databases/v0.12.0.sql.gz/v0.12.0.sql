-- Inventari v0.12.0: the database the release leaves on disk.
-- Cut by scripts/release-db-snapshot.sh from 00a9cb534499915c9fa4eebd9482acd270ef9fcc.
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: audit_log_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_log_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_log rows are immutable: % operation not allowed', TG_OP;
    RETURN NULL;
END;
$$;


--
-- Name: stock_holds_within_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_holds_within_stock() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    DECLARE
        g_anchor uuid;
        g_lot uuid;
        g_owner uuid;
        anchor stock_anchors%ROWTYPE;
        held numeric;
        on_hand numeric;
    BEGIN
        IF TG_TABLE_NAME = 'stock_reservations' THEN
            g_anchor := NEW.anchor_id;
            g_lot := NEW.lot_id;
            g_owner := NEW.owner_id;
        ELSE
            SELECT id INTO g_anchor FROM stock_anchors
             WHERE organization_id = OLD.organization_id
               AND product_template_id = OLD.template_id
               AND storage_location_id = OLD.storage_location_id;
            g_lot := OLD.lot_id;
            g_owner := OLD.owner_id;
        END IF;
        -- A group with no anchor has no reservation rows to hold it.
        IF g_anchor IS NULL THEN
            RETURN NULL;
        END IF;
    
        SELECT coalesce(sum(quantity), 0) INTO held
          FROM stock_reservations
         WHERE anchor_id = g_anchor
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner;
        IF held = 0 THEN
            RETURN NULL;
        END IF;
    
        SELECT * INTO anchor FROM stock_anchors WHERE id = g_anchor;
        SELECT coalesce(sum(nullif(quantity, 'NaN'::numeric)), 0) INTO on_hand
          FROM items
         WHERE organization_id = anchor.organization_id
           AND template_id = anchor.product_template_id
           AND storage_location_id = anchor.storage_location_id
           AND lot_id IS NOT DISTINCT FROM g_lot
           AND owner_id IS NOT DISTINCT FROM g_owner
           AND is_deleted IS FALSE;
    
        IF held > on_hand THEN
            RAISE EXCEPTION
                'ck_stock_holds_within_stock: % reserved of a grain holding %',
                held, on_hand
            USING ERRCODE = 'check_violation',
                  CONSTRAINT = 'ck_stock_holds_within_stock',
                  DETAIL = format(
                      'product %s, shelf %s, batch %s, owner %s',
                      anchor.product_template_id,
                      anchor.storage_location_id,
                      coalesce(g_lot::text, '-'),
                      coalesce(g_owner::text, '-')
                  );
        END IF;
        RETURN NULL;
    END $$;


--
-- Name: stock_ledger_totals_follow_moves(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_ledger_totals_follow_moves() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    BEGIN
        IF TG_OP IN ('INSERT', 'UPDATE') THEN
            INSERT INTO stock_ledger_totals AS t
                (organization_id, product_template_id, storage_location_id, quantity)
            SELECT organization_id, product_template_id, location_id, sum(qty)
            FROM (
                SELECT organization_id, product_template_id,
                       to_location_id AS location_id, quantity AS qty
                FROM new_moves
                WHERE state = 'done' AND to_location_id IS NOT NULL
                UNION ALL
                SELECT organization_id, product_template_id,
                       from_location_id, -quantity
                FROM new_moves
                WHERE state = 'done' AND from_location_id IS NOT NULL
            ) AS sides
            GROUP BY organization_id, product_template_id, location_id
            ORDER BY organization_id, product_template_id, location_id
            ON CONFLICT (organization_id, product_template_id, storage_location_id)
            DO UPDATE SET quantity = t.quantity + EXCLUDED.quantity;
        END IF;
        IF TG_OP IN ('UPDATE', 'DELETE') THEN
            UPDATE stock_ledger_totals AS t
            SET quantity = t.quantity - gone.qty
            FROM (
                SELECT organization_id, product_template_id, location_id,
                       sum(qty) AS qty
                FROM (
                    SELECT organization_id, product_template_id,
                           to_location_id AS location_id, quantity AS qty
                    FROM old_moves
                    WHERE state = 'done' AND to_location_id IS NOT NULL
                    UNION ALL
                    SELECT organization_id, product_template_id,
                           from_location_id, -quantity
                    FROM old_moves
                    WHERE state = 'done' AND from_location_id IS NOT NULL
                ) AS sides
                GROUP BY organization_id, product_template_id, location_id
            ) AS gone
            WHERE t.organization_id = gone.organization_id
              AND t.product_template_id = gone.product_template_id
              AND t.storage_location_id = gone.location_id;
        END IF;
        RETURN NULL;
    END
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_connections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    api_key_enc character varying DEFAULT ''::character varying NOT NULL,
    api_base_url character varying(512) DEFAULT ''::character varying NOT NULL,
    model_name character varying(255) DEFAULT ''::character varying NOT NULL,
    temperature double precision,
    max_tokens integer,
    top_p double precision,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    capability_checks jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage_logs (
    id uuid NOT NULL,
    user_id uuid,
    organization_id uuid NOT NULL,
    model_name character varying(255) NOT NULL,
    provider character varying(100),
    prompt_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    total_tokens integer NOT NULL,
    estimated_cost_usd double precision,
    cost_is_estimated boolean DEFAULT false NOT NULL,
    action_type character varying(100),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_api_keys (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_approvals (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_equipment (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_example_widgets (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_maker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_maker (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_printing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_printing (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_purchase_orders (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_recipes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_shopping_lists (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_stock_takes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_warehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_warehouse (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_webhooks (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) NOT NULL,
    active_from timestamp with time zone NOT NULL,
    active_until timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    hashed_key character varying(64) NOT NULL,
    key_prefix character varying(15) NOT NULL,
    is_active boolean NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    scope_names jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: approval_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_decisions (
    id uuid NOT NULL,
    approval_request_id uuid NOT NULL,
    stage_order integer NOT NULL,
    approver_id uuid,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    notes text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    current_stage integer DEFAULT 1 NOT NULL,
    total_stages integer NOT NULL,
    created_by uuid NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    consumed_by uuid
);


--
-- Name: approval_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_workflows (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    stages json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    archived_at timestamp with time zone,
    requester_scope jsonb DEFAULT '{"everyone": true}'::jsonb NOT NULL
);


--
-- Name: audit_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_campaigns (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    scope_type character varying(20) NOT NULL,
    scope_filter_id uuid,
    launched_at timestamp with time zone,
    deadline timestamp with time zone NOT NULL,
    reminder_days_before integer NOT NULL,
    last_reminder_sent_at timestamp with time zone,
    status character varying(20) NOT NULL,
    email_subject character varying(255),
    email_body text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    snapshot json,
    reason character varying(500),
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_response_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_response_items (
    id uuid NOT NULL,
    response_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    item_id uuid NOT NULL,
    item_name character varying(255) NOT NULL,
    serial_number character varying(100),
    status character varying(20) NOT NULL,
    dispute_type character varying(30),
    dispute_reason text,
    created_at timestamp with time zone NOT NULL,
    responded_at timestamp with time zone
);


--
-- Name: audit_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_responses (
    id uuid NOT NULL,
    campaign_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    assignment_id uuid,
    assignee_email character varying(255) NOT NULL,
    assignee_name character varying(255) NOT NULL,
    token character varying(86) NOT NULL,
    token_expires_at timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    responded_at timestamp with time zone,
    dispute_reason text,
    dispute_type character varying(30),
    response_ip character varying(45),
    response_user_agent character varying(500),
    email_sent_at timestamp with time zone,
    reminder_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    code character varying(100),
    context_tag character varying(100),
    group_label character varying(50),
    icon character varying(100),
    emoji character varying(32),
    color character varying(16),
    sort_order integer NOT NULL,
    meta_data jsonb,
    default_removal_strategy character varying(10),
    module_name character varying(50),
    is_active boolean NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL
);


--
-- Name: cycle_count_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cycle_count_schedules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    frequency character varying(20) NOT NULL,
    scope character varying(20) NOT NULL,
    scope_filter json,
    sample_size integer,
    tolerance_percent numeric(5,2),
    is_active boolean NOT NULL,
    last_run_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_cycle_count_schedules_frequency CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying])::text[]))),
    CONSTRAINT ck_cycle_count_schedules_scope CHECK (((scope)::text = ANY ((ARRAY['all'::character varying, 'zone'::character varying, 'category'::character varying])::text[])))
);


--
-- Name: document_extra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extra_costs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    allocation_method character varying(10) DEFAULT 'value'::character varying NOT NULL,
    note character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_extra_costs_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_lines (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    item_id uuid,
    product_template_id uuid,
    name character varying(255),
    brand character varying(255),
    barcode character varying(50),
    quantity numeric(12,3) NOT NULL,
    expected_quantity numeric(12,3) NOT NULL,
    done_quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    batch_number character varying(100),
    serial_number character varying(100),
    expiry_date date,
    notes text,
    discrepancy_code character varying(50),
    discrepancy_reason text,
    unit_price numeric(12,2),
    tax_rate numeric(5,2),
    line_value numeric(14,2),
    line_tax numeric(14,2),
    line_gross numeric(14,2),
    currency character varying(3),
    line_number integer NOT NULL,
    source_po_line_id uuid,
    product_snapshot jsonb,
    executed_location_id uuid,
    corrects_line_id uuid,
    target_location_id uuid,
    held_quantity numeric(12,3) DEFAULT 0 NOT NULL,
    source_location_id uuid,
    puts_away_line_id uuid,
    meta_data jsonb,
    expected_is_count boolean DEFAULT false NOT NULL
);


--
-- Name: document_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_number_sequences (
    organization_id uuid NOT NULL,
    prefix character varying(120) NOT NULL,
    next_value integer DEFAULT 1 NOT NULL
);


--
-- Name: document_package_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_package_lines (
    id uuid NOT NULL,
    document_package_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_document_package_lines_quantity CHECK ((quantity > (0)::numeric))
);


--
-- Name: document_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_packages (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    number integer NOT NULL,
    weight_kg numeric(10,3),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_packages_weight CHECK ((weight_kg > (0)::numeric))
);


--
-- Name: document_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    value_tracking_enabled boolean NOT NULL,
    tax_handling character varying(20) NOT NULL,
    default_tax_rate numeric(5,2),
    require_partner_tax_id boolean,
    numbering_format character varying(100) NOT NULL,
    type_labels json,
    default_unit character varying(20) NOT NULL,
    visible_line_fields json,
    print_template character varying(50) NOT NULL,
    default_currency character varying(3),
    default_template_id uuid,
    approval_threshold numeric(14,2),
    approval_required_for_types json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    number_padding smallint NOT NULL,
    require_unit_price boolean DEFAULT false NOT NULL,
    confirm_shelf_by_scan boolean DEFAULT false NOT NULL,
    tracking_url_templates json,
    quarantine_location_id uuid,
    pick_order_strategy character varying(50)
);


--
-- Name: document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_relations (
    id uuid NOT NULL,
    source_document_id uuid NOT NULL,
    target_document_id uuid NOT NULL,
    relation_type character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_shipments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    carrier character varying(100) NOT NULL,
    tracking_number character varying(100),
    shipped_at timestamp with time zone NOT NULL,
    shipped_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    module character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(50) NOT NULL,
    body_html text NOT NULL,
    version integer NOT NULL,
    source_builtin character varying(255),
    source_checksum character varying(64),
    is_default boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: document_type_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_type_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_type character varying(15) NOT NULL,
    default_source_location_id uuid,
    default_target_location_id uuid,
    sequence_format character varying(50) NOT NULL,
    require_partner boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_warehouse_receiving; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_warehouse_receiving (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    two_step boolean DEFAULT false NOT NULL,
    receiving_location_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    free_placement boolean DEFAULT false NOT NULL
);


--
-- Name: document_work_item_overlays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_work_item_overlays (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    source_kind character varying(48) NOT NULL,
    source_id uuid,
    assignee_id uuid,
    title character varying(200),
    due_date date,
    done_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    type character varying(15) NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    source_location_id uuid,
    target_location_id uuid,
    scheduled_date date,
    notes text,
    external_reference character varying(100),
    partner_snapshot jsonb,
    corrects_document_id uuid,
    backorder_id uuid,
    total_net numeric(14,2),
    total_tax numeric(14,2),
    total_gross numeric(14,2),
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    completed_at timestamp with time zone,
    reason_code character varying(50),
    is_opening boolean DEFAULT false NOT NULL,
    stock_already_applied boolean DEFAULT false NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    complete_on_approval boolean DEFAULT false NOT NULL,
    post_key character varying(64),
    held_by character varying(64),
    meta_data jsonb,
    print_snapshot jsonb
);


--
-- Name: email_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_jobs (
    id uuid NOT NULL,
    organization_id uuid,
    to_email character varying(320) NOT NULL,
    subject character varying(500) NOT NULL,
    html_content text NOT NULL,
    attachment_bytes bytea,
    attachment_filename character varying(255),
    smtp_config_enc text,
    failure_notice_enc text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone
);


--
-- Name: equipment_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    assignee_partner_id uuid,
    checkout_location_id uuid,
    assigned_to_name character varying(255) NOT NULL,
    assigned_to_email character varying(255),
    checked_out_at timestamp with time zone NOT NULL,
    expected_return_at timestamp with time zone,
    checked_in_at timestamp with time zone,
    checked_out_by uuid NOT NULL,
    checked_in_by uuid,
    checkout_notes text,
    checkin_notes text,
    checkin_condition character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_type character varying(30) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_maintenance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_maintenance_logs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    maintenance_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    cost numeric(10,2),
    currency character varying(3),
    performed_at date NOT NULL,
    performed_by character varying(255),
    service_partner_id uuid,
    next_maintenance_at date,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_deliveries (
    id uuid NOT NULL,
    event_id character varying(64) NOT NULL,
    event character varying(100) NOT NULL,
    handler character varying(255) NOT NULL,
    organization_id uuid,
    payload jsonb NOT NULL,
    status character varying(16) NOT NULL,
    attempts integer NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_outbox (
    id uuid NOT NULL,
    organization_id uuid,
    event character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    emitter_module character varying(64),
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    published_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.example_widgets (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(30) DEFAULT 'blue'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ingredient_nutrition_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_nutrition_defaults (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    calories_kcal numeric(8,2) NOT NULL,
    protein_g numeric(8,2),
    fat_g numeric(8,2),
    carbs_g numeric(8,2),
    fiber_g numeric(8,2),
    sugar_g numeric(8,2),
    salt_g numeric(8,2),
    source character varying(50) NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_periods (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    reopened_at timestamp with time zone,
    reopened_by uuid,
    notes text
);


--
-- Name: item_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_attachments (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_history (
    id uuid NOT NULL,
    organization_id uuid,
    item_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    changes json,
    source_document_id uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_import_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    total integer NOT NULL,
    processed integer NOT NULL,
    result json,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    category_id uuid,
    module_name character varying(50),
    name character varying(255) NOT NULL,
    brand character varying(255),
    description character varying(500),
    uom_id uuid,
    template_id uuid,
    quantity numeric(12,3) NOT NULL,
    barcode character varying(50),
    serial_number character varying(100),
    added_date date NOT NULL,
    expiry_date date,
    shelf_location character varying(255),
    image_url character varying(500),
    meta_data jsonb,
    purchase_price numeric(10,2),
    currency character varying(3),
    is_deleted boolean NOT NULL,
    is_catalog_entry boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    label_code character varying(20),
    partner_id uuid,
    lot_id uuid,
    owner_id uuid,
    source_document_id uuid,
    CONSTRAINT ck_items_quantity_nonneg CHECK ((quantity >= (0)::numeric))
);


--
-- Name: label_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_pool (
    id uuid NOT NULL,
    short_code character varying(100) NOT NULL,
    is_assigned boolean NOT NULL,
    assigned_at timestamp with time zone,
    item_id uuid,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    label_type character varying(50) NOT NULL,
    description character varying(255),
    target_storage_location_id uuid,
    context_tag character varying(50),
    created_at timestamp with time zone NOT NULL,
    printed_at timestamp with time zone,
    scan_count integer NOT NULL,
    last_scanned_at timestamp with time zone
);


--
-- Name: location_relocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_relocations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid,
    location_name character varying(255) NOT NULL,
    from_parent_id uuid,
    to_parent_id uuid,
    from_path text,
    to_path text,
    moved_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: maker_bom_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_bom_lines (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_template_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    unit character varying(8) NOT NULL,
    yield_loss_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id uuid NOT NULL,
    qty_per_batch numeric(12,4) NOT NULL,
    uom_id uuid,
    CONSTRAINT ck_bom_no_self CHECK ((parent_template_id <> child_template_id)),
    CONSTRAINT ck_bom_qty CHECK ((qty_per_batch > (0)::numeric)),
    CONSTRAINT ck_bom_yield_range CHECK (((yield_loss_pct >= (0)::numeric) AND (yield_loss_pct <= (100)::numeric)))
);


--
-- Name: maker_module_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_module_settings (
    organization_id uuid NOT NULL,
    reference_direction character varying(10) DEFAULT 'MARGIN'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    allow_overproduction boolean DEFAULT true NOT NULL,
    availability_check_scope character varying(15) DEFAULT 'GLOBAL'::character varying NOT NULL,
    create_on_shortage_strategy character varying(10) DEFAULT 'WARN'::character varying NOT NULL
);


--
-- Name: maker_production_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_order_lines (
    id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    consumed_qty numeric(12,4) NOT NULL,
    unit character varying(8) NOT NULL,
    source_storage_location_id uuid,
    unit_cost_snapshot numeric(12,4),
    cost_source character varying(16),
    shortfall_qty numeric(12,4)
);


--
-- Name: maker_production_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    planned_qty numeric(12,3) NOT NULL,
    output_storage_location_id uuid NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    total_cost numeric(12,2),
    production_date date,
    notes character varying(500),
    created_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    cancel_reason character varying(500),
    produced_item_id uuid,
    recipe_id uuid,
    actual_qty numeric(12,3),
    overproduced boolean DEFAULT false NOT NULL,
    scrap_qty numeric(12,3),
    unit_cost_snapshot numeric(12,4),
    reference_price_snapshot numeric(12,2),
    result_per_unit numeric(12,2),
    result_per_batch numeric(12,2),
    number character varying(32),
    short_at_create boolean DEFAULT false NOT NULL
);


--
-- Name: maker_recipe_cost_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipe_cost_lines (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    label character varying(120) NOT NULL,
    amount numeric(12,2) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: maker_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    batch_yield_qty numeric(12,4) DEFAULT '1'::numeric NOT NULL,
    batch_yield_uom_id uuid,
    process_steps jsonb,
    reference_price numeric(12,2),
    is_default boolean DEFAULT false NOT NULL,
    source_recipe_id uuid,
    source_snapshot_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: meal_plan_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_entries (
    id uuid NOT NULL,
    meal_plan_id uuid NOT NULL,
    date date NOT NULL,
    slot character varying(20) NOT NULL,
    recipe_id uuid NOT NULL,
    servings integer,
    notes text,
    "order" integer NOT NULL,
    CONSTRAINT ck_meal_plan_entries_slot CHECK (((slot)::text = ANY ((ARRAY['LUNCH'::character varying, 'BREAKFAST'::character varying, 'DINNER'::character varying, 'SNACK'::character varying])::text[])))
);


--
-- Name: meal_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plans (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255),
    start_date date NOT NULL,
    end_date date NOT NULL,
    enabled_slots jsonb NOT NULL,
    default_servings integer,
    shopping_list_id uuid,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    listed_meals jsonb
);


--
-- Name: module_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_installations (
    id uuid NOT NULL,
    module_name character varying(100) NOT NULL,
    installed_version character varying(50) NOT NULL,
    installed_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(1000) NOT NULL,
    type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    link character varying(255),
    meta_data jsonb
);


--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_invitations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    code character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    is_used boolean NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    role_id uuid,
    invited_email character varying(255),
    used_by_user_id uuid,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid,
    enabled_modules json NOT NULL,
    allowed_modules json,
    settings json NOT NULL,
    short_id character varying(20),
    active_profile_id character varying(50),
    onboarding_completed boolean DEFAULT false,
    focus_module character varying(50),
    pre_focus_enabled_modules json,
    pre_onboarding_manual_modules json,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'UTC'::character varying NOT NULL,
    tax_id character varying(50),
    country character varying(2),
    print_page_size character varying(10),
    address json,
    logo_url character varying(500)
);


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    type character varying(30) NOT NULL,
    tax_id character varying(50),
    is_consumer boolean DEFAULT false NOT NULL,
    email character varying(255),
    phone character varying(50),
    website character varying(500),
    contact_person character varying(255),
    address jsonb,
    notes text,
    is_active boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: picking_session_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_session_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    ingredient_id uuid,
    item_id uuid,
    quantity_consumed numeric(10,3),
    picked_items jsonb,
    consumed_valuation_rate numeric(12,2),
    status character varying(20) NOT NULL,
    ingredient_name character varying(255),
    required_quantity numeric(10,3),
    required_uom_symbol character varying(10)
);


--
-- Name: picking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    user_id uuid NOT NULL,
    servings integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    rating integer,
    scale numeric(10,3),
    meal_plan_entry_id uuid
);


--
-- Name: po_partner_pricelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_partner_pricelist (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    uom_id uuid,
    min_quantity numeric(12,3),
    valid_from date NOT NULL,
    valid_to date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_partner_pricelist_min_qty_positive CHECK (((min_quantity IS NULL) OR (min_quantity > (0)::numeric))),
    CONSTRAINT ck_po_partner_pricelist_unit_price_positive CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT ck_po_partner_pricelist_valid_range CHECK (((valid_to IS NULL) OR (valid_to >= valid_from)))
);


--
-- Name: po_reorder_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_reorder_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    min_quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    safety_stock numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    preferred_partner_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_reorder_rules_max_ge_min CHECK ((max_quantity >= min_quantity)),
    CONSTRAINT ck_po_reorder_rules_min_nonneg CHECK ((min_quantity >= (0)::numeric)),
    CONSTRAINT ck_po_reorder_rules_safety_nonneg CHECK ((safety_stock >= (0)::numeric))
);


--
-- Name: po_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    approval_threshold numeric(14,2),
    approval_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: print_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_agents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    printer_type character varying(50) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_version character varying(50),
    protocol_version integer
);


--
-- Name: print_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    labels jsonb NOT NULL,
    created_by uuid,
    attempts integer NOT NULL,
    lease_until timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    width_mm double precision DEFAULT 50.0 NOT NULL,
    height_mm double precision DEFAULT 24.0 NOT NULL,
    scale double precision,
    read_permissions jsonb NOT NULL
);


--
-- Name: product_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_templates (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    brand character varying(255),
    barcode character varying(50),
    sku character varying(50),
    uom_id uuid,
    weight_value numeric(14,6),
    weight_uom_id uuid,
    volume_value numeric(14,6),
    volume_uom_id uuid,
    image_url character varying(500),
    description character varying(500),
    min_quantity double precision,
    removal_strategy character varying(10),
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_lines (
    id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_template_id uuid,
    name character varying(255) NOT NULL,
    quantity_ordered numeric(12,3) NOT NULL,
    quantity_received numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_price numeric(12,2),
    uom_id uuid,
    tax_rate numeric(5,2),
    line_number integer NOT NULL,
    notes text,
    source_reorder_rule_id uuid
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    scheduled_date date,
    notes text,
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_capacity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_capacity (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_home_silenced; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_home_silenced (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_location_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_location_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    single_product boolean DEFAULT false NOT NULL
);


--
-- Name: putaway_rule_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rule_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    location_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: putaway_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    context_tag character varying(100),
    storage_type_code character varying(50),
    priority integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_putaway_rules_at_least_one_match CHECK (((product_template_id IS NOT NULL) OR (category_id IS NOT NULL) OR (context_tag IS NOT NULL) OR (storage_type_code IS NOT NULL)))
);


--
-- Name: recipe_collection_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collection_members (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(64),
    parent_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    template_id uuid,
    name character varying(255) NOT NULL,
    display_text character varying(500),
    ingredient_group_name character varying(100),
    quantity numeric(10,3) NOT NULL,
    uom_id uuid,
    original_quantity numeric(10,3),
    original_unit_text character varying(50),
    is_optional boolean NOT NULL,
    picking_skip boolean,
    sort_order integer NOT NULL,
    calories_kcal_per_100g numeric(8,2),
    price numeric(10,2),
    price_uom_id uuid,
    price_currency character varying(3),
    allergens jsonb NOT NULL,
    is_spice boolean NOT NULL
);


--
-- Name: recipe_tag_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_tag_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    instructions text,
    servings integer NOT NULL,
    prep_time_minutes integer,
    image_url text,
    source_url text,
    tags jsonb,
    is_favorite boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_requests (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    token character varying(255),
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    accepted_at timestamp with time zone,
    rejected_at timestamp with time zone,
    is_rejected boolean DEFAULT false NOT NULL,
    approved_by_id uuid
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shopping_exclusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_exclusions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    template_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_history (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    original_list_id uuid NOT NULL,
    original_list_name character varying(255) NOT NULL,
    item_name character varying(255) NOT NULL,
    quantity numeric(12,3) DEFAULT 1 NOT NULL,
    estimated_price numeric(10,2),
    purchased_at timestamp with time zone,
    purchased_by uuid,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_items (
    id uuid NOT NULL,
    shopping_list_id uuid NOT NULL,
    item_id uuid,
    category_id uuid,
    name character varying(255) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    notes text,
    estimated_price numeric(10,2),
    is_purchased boolean NOT NULL,
    purchased_at timestamp with time zone,
    purchased_by uuid,
    source character varying(50) NOT NULL,
    priority integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_id uuid,
    note_data jsonb
);


--
-- Name: shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_lists (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    completed_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_anchors (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_ledger_totals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_ledger_totals (
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    quantity numeric(18,3) NOT NULL
);


--
-- Name: stock_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_lots (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    is_serial boolean NOT NULL,
    expiry_date date,
    production_date date,
    use_by_date date,
    removal_strategy character varying(10) NOT NULL,
    status character varying(20) NOT NULL,
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: stock_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_moves (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    from_location_id uuid,
    to_location_id uuid,
    quantity numeric(12,3) NOT NULL,
    lot_id uuid,
    owner_id uuid,
    expiry_date date,
    state character varying(20) DEFAULT 'done'::character varying NOT NULL,
    reference_type character varying(20),
    reference_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_stock_moves_at_least_one_location CHECK (((from_location_id IS NOT NULL) OR (to_location_id IS NOT NULL))),
    CONSTRAINT ck_stock_moves_qty_positive CHECK ((quantity > (0)::numeric))
);


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    document_line_id uuid,
    anchor_id uuid NOT NULL,
    lot_id uuid,
    owner_id uuid,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_quants_from_records; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.stock_quants_from_records AS
 SELECT (md5((((((((((organization_id)::text || '/'::text) || (product_template_id)::text) || '/'::text) || COALESCE((storage_location_id)::text, '-'::text)) || '/'::text) || COALESCE((lot_id)::text, '-'::text)) || '/'::text) || COALESCE((owner_id)::text, '-'::text))))::uuid AS id,
    organization_id,
    product_template_id,
    storage_location_id,
    lot_id,
    owner_id,
    (COALESCE(sum(quantity), (0)::numeric))::numeric(12,3) AS quantity,
    (COALESCE(sum(reserved_quantity), (0)::numeric))::numeric(12,3) AS reserved_quantity,
    'FIFO'::character varying(10) AS removal_strategy,
    min(created_at) AS created_at,
    max(updated_at) AS updated_at
   FROM ( SELECT i.organization_id,
            i.template_id AS product_template_id,
            i.storage_location_id,
            i.lot_id,
            i.owner_id,
            NULLIF(i.quantity, 'NaN'::numeric) AS quantity,
            NULL::numeric AS reserved_quantity,
            i.created_at,
            i.updated_at
           FROM public.items i
          WHERE ((i.is_deleted IS FALSE) AND (i.template_id IS NOT NULL))
        UNION ALL
         SELECT a.organization_id,
            a.product_template_id,
            a.storage_location_id,
            r.lot_id,
            r.owner_id,
            NULL::numeric AS "numeric",
            r.quantity,
            r.created_at,
            r.created_at
           FROM (public.stock_reservations r
             JOIN public.stock_anchors a ON ((a.id = r.anchor_id)))) sides
  GROUP BY organization_id, product_template_id, storage_location_id, lot_id, owner_id;


--
-- Name: stock_take_closed_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_closed_locations (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    storage_location_id uuid,
    path text NOT NULL,
    empty boolean DEFAULT false NOT NULL,
    closed_by uuid,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_counts (
    id uuid NOT NULL,
    stock_take_item_id uuid NOT NULL,
    sequence integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    counted_by uuid,
    counted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_items (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    item_id uuid,
    item_name character varying(255) NOT NULL,
    item_brand character varying(255),
    uom_id uuid,
    assignee_id uuid,
    lot_id uuid,
    system_quantity numeric(12,3),
    counted_quantity numeric(10,3),
    location_in_storage character varying(255),
    notes text,
    discrepancy_reason character varying(255),
    is_discrepancy integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discrepancy_reason_code character varying(50),
    recount_requested boolean DEFAULT false NOT NULL,
    storage_location_id uuid,
    expected_location_id uuid
);


--
-- Name: stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_takes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    blind_mode boolean NOT NULL,
    require_full_count boolean NOT NULL,
    tolerance_percent numeric(5,2),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule_id uuid,
    adjustment_document_id uuid,
    CONSTRAINT ck_stock_takes_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: stock_valuation_layers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_valuation_layers (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    document_line_id uuid,
    quantity numeric(12,3) NOT NULL,
    remaining_qty numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    total_value numeric(14,2) NOT NULL,
    document_date date,
    currency character varying(3),
    direction character varying(10) NOT NULL,
    cost_basis character varying(10) NOT NULL,
    reason character varying(30),
    item_id uuid,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_svl_remaining_not_negative CHECK ((remaining_qty >= (0)::numeric))
);


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_id uuid,
    storage_type_id uuid,
    context_schema json DEFAULT '[]'::json NOT NULL,
    behavior_mode character varying(50) DEFAULT 'STOCK'::character varying NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    location_details character varying(255),
    short_code character varying(100),
    sequence integer,
    usage character varying(50) DEFAULT 'internal'::character varying NOT NULL,
    context_tag character varying(50),
    settings json,
    warehouse_config jsonb,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL
);


--
-- Name: storage_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_types (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    type_code character varying(50) NOT NULL,
    behavior_mode character varying(50) NOT NULL,
    context_schema json DEFAULT '[]'::json NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    icon character varying(100),
    is_system boolean NOT NULL,
    created_by uuid,
    default_settings json
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by uuid
);


--
-- Name: tax_rate_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    tax_rate_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    CONSTRAINT ck_tax_rate_assignments_one_target CHECK ((num_nonnulls(product_template_id, category_id) = 1))
);


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    rate numeric(5,2) NOT NULL,
    code character varying(10),
    country character varying(2),
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: unit_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_conversions (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    ingredient_key character varying(100) NOT NULL,
    ingredient_name character varying(200) NOT NULL,
    source_unit character varying(50) NOT NULL,
    metric_quantity numeric(10,3) NOT NULL,
    metric_unit character varying(10) NOT NULL,
    category character varying(50) NOT NULL,
    is_system boolean NOT NULL
);


--
-- Name: uom_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom_categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(50) NOT NULL
);


--
-- Name: uoms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uoms (
    id uuid NOT NULL,
    organization_id uuid,
    category_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL,
    factor numeric(18,9) NOT NULL,
    is_reference boolean NOT NULL,
    is_system boolean NOT NULL,
    rounding numeric(12,6) NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    blocking_reason character varying(500),
    failed_login_count bigint DEFAULT 0,
    locked_until timestamp with time zone,
    organization_id uuid
);


--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_delivery_logs (
    id uuid NOT NULL,
    webhook_endpoint_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload_json jsonb NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    attempt_number integer DEFAULT 1 NOT NULL,
    next_retry_at timestamp with time zone,
    delivery_status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    delivery_id character varying(36),
    abandon_reason character varying(40),
    last_attempt_at timestamp with time zone
);


--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_endpoints (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2048) NOT NULL,
    secret character varying(512),
    http_method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    event_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    retry_backoff_seconds integer DEFAULT 10 NOT NULL,
    timeout_seconds integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp with time zone,
    last_status_code integer,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auto_disabled_at timestamp with time zone
);


--
-- Name: wms_pick_line_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_line_lots (
    pick_line_id uuid NOT NULL,
    lot_id uuid NOT NULL,
    lot_name character varying(100) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_lines (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    pick_order integer NOT NULL,
    status character varying(20) NOT NULL,
    picked_quantity numeric(12,3) NOT NULL,
    bin_location character varying(255),
    product_name character varying(255),
    lot_name character varying(100),
    expected_quantity numeric(12,3) NOT NULL,
    uom_symbol character varying(10),
    anchor_id uuid,
    lot_id uuid,
    location_id uuid,
    expiry_date date
);


--
-- Name: wms_pick_session_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_session_documents (
    session_id uuid NOT NULL,
    document_id uuid NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    assigned_to uuid,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    meta_data jsonb,
    last_activity_at timestamp with time zone
);


--
-- Data for Name: ai_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version (version_num) VALUES ('auditidx03');


--
-- Data for Name: alembic_version_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_api_keys (version_num) VALUES ('009_key_prefix_column_narrows');


--
-- Data for Name: alembic_version_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_approvals (version_num) VALUES ('007_workflow_requester_scope');


--
-- Data for Name: alembic_version_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_equipment (version_num) VALUES ('010_response_item_responded_at');


--
-- Data for Name: alembic_version_example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_example_widgets (version_num) VALUES ('001_initial');


--
-- Data for Name: alembic_version_maker; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_maker (version_num) VALUES ('015_default_result_margin');


--
-- Data for Name: alembic_version_printing; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_printing (version_num) VALUES ('007_job_read_permission');


--
-- Data for Name: alembic_version_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_purchase_orders (version_num) VALUES ('po_tzaware01');


--
-- Data for Name: alembic_version_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_recipes (version_num) VALUES ('013_meal_plan_listed_meals');


--
-- Data for Name: alembic_version_shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_shopping_lists (version_num) VALUES ('007_history_quantity_default');


--
-- Data for Name: alembic_version_stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_stock_takes (version_num) VALUES ('014_enums_are_text');


--
-- Data for Name: alembic_version_warehouse; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_warehouse (version_num) VALUES ('doc_print_snapshot01');


--
-- Data for Name: alembic_version_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_webhooks (version_num) VALUES ('005_timestamps_carry_their_zone');


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('6443ff61-c598-4d6c-8438-e370a1abdb1b', '56c703d2-894c-4561-8938-d74ce3c23a72', 1, 'f513905d-ce7d-43a4-a772-b43279005f82', 'APPROVED', NULL, '2026-11-07 00:29:59.862538+00', '2026-11-07 00:29:59.862538+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('a4befc95-7746-4de3-b971-3edfcf7299df', '56c703d2-894c-4561-8938-d74ce3c23a72', 2, NULL, 'PENDING', NULL, NULL, '2026-11-06 21:29:59.862538+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('ce54108f-048a-4cb1-9935-282d8db7e65a', 'b36cacf1-79f5-458d-b479-9807b7411c9b', 1, 'f513905d-ce7d-43a4-a772-b43279005f82', 'APPROVED', NULL, '2026-10-31 00:29:59.862538+00', '2026-10-31 00:29:59.862538+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('d3d7d227-c696-4837-b180-02cfd33f7e62', 'b36cacf1-79f5-458d-b479-9807b7411c9b', 2, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'APPROVED', NULL, '2026-10-31 03:29:59.862538+00', '2026-10-31 03:29:59.862538+00');


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('56c703d2-894c-4561-8938-d74ce3c23a72', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c883ed6e-6fb4-47df-847e-794fb88074dd', 'purchase_order', '4c455c38-8700-4b97-987a-e402b3fd551d', 'IN_PROGRESS', 2, 2, '6e228bca-4488-4535-9fd3-0d4b0549bd49', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-11-06 21:29:59.862538+00', NULL, NULL);
INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('b36cacf1-79f5-458d-b479-9807b7411c9b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c883ed6e-6fb4-47df-847e-794fb88074dd', 'purchase_order', 'd3779d22-c7c7-47ec-88b4-b4c7fe450482', 'APPROVED', 2, 2, '6e228bca-4488-4535-9fd3-0d4b0549bd49', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-10-30 21:29:59.862538+00', NULL, NULL);


--
-- Data for Name: approval_workflows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_workflows (id, organization_id, target_type, name, stages, is_active, created_at, updated_at, archived_at, requester_scope) VALUES ('c883ed6e-6fb4-47df-847e-794fb88074dd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'purchase_order', 'Purchase orders over 10,000', '[{"order": 1, "role": "manager", "label": "Team lead", "approver_user_ids": []}, {"order": 2, "role": "admin", "label": "Finance", "approver_user_ids": []}]', true, '2026-11-09 20:30:00.558739+00', NULL, NULL, '{"everyone": true}');


--
-- Data for Name: audit_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_campaigns (id, organization_id, name, description, scope_type, scope_filter_id, launched_at, deadline, reminder_days_before, last_reminder_sent_at, status, email_subject, email_body, created_by, created_at, updated_at) VALUES ('78daf7f8-3a6a-4ddf-aa19-56d04010ce68', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Autumn equipment check', 'Confirm you still hold the equipment issued to you.', 'ALL', NULL, '2026-11-05 20:30:01.041017+00', '2026-11-26 23:59:00+00', 3, NULL, 'ACTIVE', NULL, NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-05 19:30:01.041017+00', '2026-11-09 20:30:01.04233+00');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('3b13bc96-271a-4d83-8dba-79654aa6af32', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'module', '00e8db4f-deff-45c2-82ee-95c459b73161', '{"name": "equipment", "subject": "profile:equipment_wms", "before": {"maintenance_warning_days": 7, "warranty_warning_days": 30}, "after": {"maintenance_warning_days": 14, "warranty_warning_days": 60}}', NULL, 'null', '2026-11-09 20:29:57.080476+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('c8e1cd54-ad3b-4063-a9de-8ae66d8ae76e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', '901a2389-0145-4457-90b7-d2b61cbc3abe', '{"name": "UHT Milk 3.2%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "48.000", "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "storage_location_name": "Fridge A", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-09 20:29:58.672524+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('813e6339-a380-45f5-9ae0-c1bdbde00026', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', 'dd07e024-7797-4e3e-b6da-85394471f19d', '{"name": "Natural Yoghurt 400g", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "24.000", "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "storage_location_name": "Fridge A", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-09 20:29:58.672527+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('df227707-fdb1-4ed9-83c9-1769a393eafc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', 'b73207ab-580c-4077-b1f7-13b94a855ed2', '{"name": "Butter Extra 82%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "36.000", "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "storage_location_name": "Fridge A", "category_id": "7fccadf3-255b-49ce-99be-4073275efcec", "category_name": "Dairy", "category_code": "dairy"}', NULL, 'null', '2026-11-09 20:29:58.672528+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('875673b0-82b7-4952-94bb-bd59f18a5ecd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', '{"name": "Gouda Cheese", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "60.000", "storage_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1", "storage_location_name": "Fridge B", "category_id": "0389990b-d447-4ecd-ba0b-b4df565eee4e", "category_name": "Cheese", "category_code": "cheese"}', NULL, 'null', '2026-11-09 20:29:58.724055+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('969d27b3-3470-46df-9dad-67875146bc8b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', '{"name": "Sour Cream 18%", "brand": "Meadowlane", "barcode": null, "sku": null, "quantity": "20.000", "storage_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1", "storage_location_name": "Fridge B", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-09 20:29:58.724056+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('b73ea809-39bc-472d-a9b9-0edde6665a54', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', '5530d507-8782-45c5-bf59-4fa3e85eeb6a', '{"name": "Dell Latitude 5540", "brand": "Dell", "barcode": null, "sku": null, "quantity": "5.000", "storage_location_id": "9fc409ab-02e4-45f0-a6a8-55344aafe2e0", "storage_location_name": "Server Rack A", "category_id": "51f7e51a-6382-4973-99a9-5f9353991362", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-11-09 20:29:58.755739+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('6c41b268-1567-4c45-a556-50cf4ef1960f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', '41043f6d-7863-49f4-ba89-f7c702978b9d', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": "3.000", "storage_location_id": "9fc409ab-02e4-45f0-a6a8-55344aafe2e0", "storage_location_name": "Server Rack A", "category_id": "51f7e51a-6382-4973-99a9-5f9353991362", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-11-09 20:29:58.755741+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('766d7af4-a4c3-4704-bc6b-936e0636c78b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', '901a2389-0145-4457-90b7-d2b61cbc3abe', '{"name": "UHT Milk 3.2%", "before": {"quantity": "48.000"}, "after": {"quantity": "36.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "ad73fd07-f37d-4e7e-9f1b-876850e847fe"}', '2026-11-09 20:29:58.83949+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('ce2e5969-25ad-474f-ad88-fbf82fd032a2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', 'b73207ab-580c-4077-b1f7-13b94a855ed2', '{"name": "Butter Extra 82%", "before": {"quantity": "36.000"}, "after": {"quantity": "28.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "ad73fd07-f37d-4e7e-9f1b-876850e847fe"}', '2026-11-09 20:29:58.839491+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('cd71c447-9273-4d4e-876e-95cc02ca1608', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "wms_session_id": "a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-09 20:29:59.383072+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9aa3fd4c-a68c-4e7d-a5f3-e841ae8923c1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', '8a59913a-b433-4654-8783-6a3e9994e96f', '{"number": "OUT/2026/004", "wms_session_id": "a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-09 20:29:59.384246+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f6a41ad3-4c20-490e-92a3-63afa5fac166', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "wms_session_id": "a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-09 20:29:59.508252+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e17ca02c-4796-4d91-b4de-340e723e112a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', '8a59913a-b433-4654-8783-6a3e9994e96f', '{"number": "OUT/2026/004", "wms_session_id": "a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-11-09 20:29:59.508723+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4cb0794a-996f-44c9-86c3-4f3b6dc97be8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "weight_value": null}', NULL, 'null', '2026-11-09 20:29:59.52708+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5c056322-1c55-41fa-a192-a2aa558404d5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "name": "Natural Yoghurt 400g", "quantity": "6", "old_quantity": "0"}', NULL, 'null', '2026-11-09 20:29:59.545387+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('ef4e8282-b94c-40a7-b20b-ae2d63f35db2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "weight_value": null}', NULL, 'null', '2026-11-09 20:29:59.558914+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('0e267048-2cc6-46cb-b08c-97c392c5bcb7', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "name": "Butter Extra 82%", "quantity": "4", "old_quantity": "0"}', NULL, 'null', '2026-11-09 20:29:59.573879+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5ca0ca7d-837c-4ead-ba35-03d594daa3f8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', 'dd07e024-7797-4e3e-b6da-85394471f19d', '{"name": "Natural Yoghurt 400g", "before": {"quantity": "24.000"}, "after": {"quantity": "18.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "e7b9f838-3e91-47fa-939f-7f2da6ac1133"}', '2026-11-09 20:29:59.748338+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('e3d30e02-6062-42b1-97b4-5efa0a4b5a2c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', 'b73207ab-580c-4077-b1f7-13b94a855ed2', '{"name": "Butter Extra 82%", "before": {"quantity": "28.000"}, "after": {"quantity": "24.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "e7b9f838-3e91-47fa-939f-7f2da6ac1133"}', '2026-11-09 20:29:59.74834+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('a52b6da0-3f8d-4d4c-8285-95985a4c4138', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '{"number": "OUT/2026/003", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-09 20:29:59.748341+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('ee00832a-dc94-4601-9d26-a15647df43ac', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', '{"name": "Gouda Cheese", "before": {"quantity": "60.000"}, "after": {"quantity": "50.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "8a59913a-b433-4654-8783-6a3e9994e96f"}', '2026-11-09 20:29:59.834134+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('154c7017-30c9-4fcc-84f3-4259bb3c60e1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', '{"name": "Sour Cream 18%", "before": {"quantity": "20.000"}, "after": {"quantity": "15.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "8a59913a-b433-4654-8783-6a3e9994e96f"}', '2026-11-09 20:29:59.834136+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('2def10b0-7a6b-4041-8e8a-a39a281f3534', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'document', '8a59913a-b433-4654-8783-6a3e9994e96f', '{"number": "OUT/2026/004", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-11-09 20:29:59.834136+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('18307c2b-c864-4f80-aea1-156f9e0d1134', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', '18d0f606-78b4-476f-8761-6e710672c3f3', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "sku": null, "quantity": "3.000", "storage_location_id": "9fc409ab-02e4-45f0-a6a8-55344aafe2e0", "storage_location_name": "Server Rack A", "category_id": "51f7e51a-6382-4973-99a9-5f9353991362", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-11-09 20:30:00.105063+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('03ea7cbf-5bf0-49a6-b506-1341d3ec4668', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'maker_production_order', '21ff6bdb-dd23-46c5-bab5-80df73db583b', '{"name": "PR/2026/0001", "status": "DRAFT", "output": "Plum Butter", "planned_qty": "12.000"}', NULL, 'null', '2026-11-09 20:30:00.312856+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('2417d031-3604-4874-9073-b5ade29ce5fc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', 'c82a3e23-85db-4275-b655-c89edaf839a5', '{"name": "Damson Plums", "before": {"quantity": "40.000"}, "after": {"quantity": "13.600"}}', 'production_run', '{"production_order_id": "21ff6bdb-dd23-46c5-bab5-80df73db583b", "production_order_number": "PR/2026/0001"}', '2026-11-09 20:30:00.371659+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f6118911-9561-4186-a912-d1d249263f1c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', 'ab2f3769-1eab-45fa-8139-325918662b24', '{"name": "White Sugar", "before": {"quantity": "25.000"}, "after": {"quantity": "21.220"}}', 'production_run', '{"production_order_id": "21ff6bdb-dd23-46c5-bab5-80df73db583b", "production_order_number": "PR/2026/0001"}', '2026-11-09 20:30:00.40242+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('81e3802c-59c3-4123-8b5e-dc095973a5b2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGE', 'item', '017b7fd5-a2f5-4460-b1a8-14693d388e98', '{"name": "Cassia Cinnamon", "before": {"quantity": "0.500"}, "after": {"quantity": "0.440"}}', 'production_run', '{"production_order_id": "21ff6bdb-dd23-46c5-bab5-80df73db583b", "production_order_number": "PR/2026/0001"}', '2026-11-09 20:30:00.421405+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('bb0623ff-829d-45c8-88a3-c1ef4492e128', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATE', 'item', 'd77771f8-a4d2-44da-bb70-e63cad25da78', '{"name": "Plum Butter", "brand": null, "barcode": null, "sku": "PLB-001", "quantity": "11.400", "storage_location_id": "85b351d5-711b-47d4-b174-83619236e876", "storage_location_name": "Shelf A - Bottom", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-11-09 20:30:00.446292+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('406e1a4c-2740-46ea-bff3-23ec21e90331', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'UPDATE', 'maker_production_order', '21ff6bdb-dd23-46c5-bab5-80df73db583b', '{"name": "PR/2026/0001", "old_status": "DRAFT", "new_status": "COMPLETED", "output": "Plum Butter", "quantity": "11.400", "total_cost": "95.36"}', NULL, 'null', '2026-11-09 20:30:00.456368+00');


--
-- Data for Name: audit_response_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('c6019817-b9a2-4deb-b9b7-03226641c060', 'e2700807-fa92-429d-95c4-5602e9be954e', 'd88a1be2-c697-4ea8-aa72-231786734362', '9560ba1a-aac2-40a8-bdec-31ed002aac92', 'iPhone 15 Pro', 'SN-100034', 'CONFIRMED', NULL, NULL, '2026-11-09 20:30:01.046215+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('852fe7c8-cda6-4661-972b-372b62879993', '2163460e-150b-43f6-b731-3383c581bd37', '1b960ca6-ebc0-4bb7-b03d-5f8611538c95', 'f209851d-1c68-4b70-938b-d2103b646e6f', 'Dell Latitude 5540', 'SN-100001', 'DISPUTED', 'DAMAGED', 'The hinge on the lid is cracked and the screen flickers.', '2026-11-09 20:30:01.046218+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('5a09fda8-184a-4895-a915-89c297322c05', '8a2ddff8-ec09-48d4-89a7-a0ce7fe77b2f', 'fa0ccc1a-4d60-4508-9e98-4955548de8f1', 'c1acf8bf-cf81-4a80-ae41-08d61a574810', 'ThinkPad T14s Gen 4', 'SN-100002', 'PENDING', NULL, NULL, '2026-11-09 20:30:01.046218+00', NULL);
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at, responded_at) VALUES ('4fdc796a-caea-4d4e-aea8-81522e2aa423', '7876b98a-4879-456d-8e1e-3d038957c82a', '1240e0ca-eaa8-41e6-b809-c297966446ab', 'bd563cb7-7dcc-479a-bbcc-cbe4d076d631', 'ThinkPad T14s Gen 4', 'SN-100003', 'PENDING', NULL, NULL, '2026-11-09 20:30:01.046219+00', NULL);


--
-- Data for Name: audit_responses; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('e2700807-fa92-429d-95c4-5602e9be954e', '78daf7f8-3a6a-4ddf-aa19-56d04010ce68', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'admin@example.com', 'Demo Administrator', 'AY-YJzC_7ppWCoYsISizB32C81X4A9l_L4Dh-gRDbZOE7M_bB811hY2bDyJFvF89m_-iDUOi52M77PSMtbRa8Q', '2026-11-26 23:59:00+00', 'CONFIRMED', '2026-11-06 20:30:01.041017+00', NULL, NULL, NULL, NULL, '2026-11-05 20:30:01.041017+00', NULL, '2026-11-09 20:30:01.043655+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('2163460e-150b-43f6-b731-3383c581bd37', '78daf7f8-3a6a-4ddf-aa19-56d04010ce68', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'priya.raman@example.com', 'Priya Raman', 'AHjhLGRXH7r_qEVQoMiRVaOrCO5HoGTDKNM2vpDIsyaCbI9aQWuXwcBy4topv3MqmXLovPcqYXlREkwl6AipBQ', '2026-11-26 23:59:00+00', 'DISPUTED', '2026-11-06 21:30:01.041017+00', 'The hinge on the lid is cracked and the screen flickers.', 'DAMAGED', NULL, NULL, '2026-11-05 20:30:01.041017+00', NULL, '2026-11-09 20:30:01.043657+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('8a2ddff8-ec09-48d4-89a7-a0ce7fe77b2f', '78daf7f8-3a6a-4ddf-aa19-56d04010ce68', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'marcus.webb@example.com', 'Marcus Webb', '3kavX3eF_JvQXzAhZiwWERpdCts2MUFeuiH4w5r-34v3Yy7MgLjE9bGR88XjF6LgcH9NQ2raS5MP1v2tqtn0vA', '2026-11-26 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-11-05 20:30:01.041017+00', NULL, '2026-11-09 20:30:01.043658+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('7876b98a-4879-456d-8e1e-3d038957c82a', '78daf7f8-3a6a-4ddf-aa19-56d04010ce68', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'ava.brennan@example.com', 'Ava Brennan', 'D-qv8-Kx4GvILVgF_eXrmycH2SYxJ2sRY_RCycPwcfFtHj7_YuZeBsD0dd6dnf7yuii1RmfsvR6AMmnkZ8NUCg', '2026-11-26 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-11-05 20:30:01.041017+00', NULL, '2026-11-09 20:30:01.043659+00');


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('51f7e51a-6382-4973-99a9-5f9353991362', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Laptop', 'LAPTOP', 'equipment', NULL, 'laptop', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "os", "type": "text", "label": "Operating System", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('cf2b82ae-57b3-4c73-95fa-b0145e6d995f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Desktop Computer', 'DESKTOP', 'equipment', NULL, 'monitor', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('3f6fa16a-9799-405c-9603-c256a30cee17', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Monitor / Display', 'MONITOR', 'equipment', NULL, 'monitor-smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "size_inches", "type": "number", "label": "Screen Size (inches)", "visible": true, "required": false, "is_system": true}, {"key": "resolution", "type": "text", "label": "Resolution", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 7, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('1319ddf0-e069-4343-b832-2889b3322ec8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Phone / Tablet', 'PHONE', 'equipment', NULL, 'smartphone', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "imei", "type": "text", "label": "IMEI", "visible": true, "required": false, "is_system": true}, {"key": "phone_number", "type": "text", "label": "Phone Number", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 3, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('70c15371-6ae6-4975-8ddd-83ca77960757', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fish', 'fish', 'cold_storage', 'FREEZER', 'Fish', NULL, NULL, 4, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('714ff621-ceb6-4d0b-ab14-66a7de646852', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Seafood', 'seafood', 'cold_storage', 'FREEZER', 'Shell', NULL, NULL, 5, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('93adc9f2-41e3-42b5-a954-7ce1e793ffef', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen meals', 'frozen_meals', 'cold_storage', 'FREEZER', 'Soup', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('7f00e767-edd4-4861-b55d-29af8ae4c39b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen vegetables', 'frozen_vegetables', 'cold_storage', 'FREEZER', 'LeafyGreen', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('f20e22f8-b5db-4ae9-926a-481f3388ddc6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Network Device', 'NETWORK_DEVICE', 'equipment', NULL, 'wifi', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "mac_address", "type": "text", "label": "MAC Address", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 8, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('515c8965-f761-41ab-8245-794bbee21ae8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Peripheral', 'PERIPHERAL', 'equipment', NULL, 'mouse', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 4, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('da084db8-fc4d-4799-8cd8-fe81280cd0e9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Server', 'SERVER', 'equipment', NULL, 'server', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "rack_position", "type": "text", "label": "Rack Position", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "cpu", "type": "text", "label": "CPU", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 10, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Other Equipment', 'OTHER_EQUIPMENT', 'equipment', NULL, 'package', NULL, NULL, 0, NULL, NULL, 'equipment', true, '[{"key": "category_id", "label": "Category", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('eca481a8-b5b8-46fe-9569-8e01b612d6ec', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Pork', 'pork', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d9de7fa5-ec47-4f7e-91a8-2d1f0134a15b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Beef', 'beef', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('85b942b2-1c25-4e94-99a5-61a4b7456850', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Poultry', 'poultry', 'cold_storage', 'FREEZER', 'Drumstick', NULL, NULL, 3, NULL, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('84297201-9cd0-404b-830b-35cbad7234ca', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen fruits', 'frozen_fruits', 'cold_storage', 'FREEZER', 'Apple', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('240cb293-0cdb-478a-856b-fc65ddd0251a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Ice cream and desserts', 'ice_cream', 'cold_storage', 'FREEZER', 'IceCream', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('d8199eed-ad2a-48b1-82b3-8a37cf8cc952', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen pizza', 'frozen_pizza', 'cold_storage', 'FREEZER', 'Pizza', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('7fccadf3-255b-49ce-99be-4073275efcec', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dairy', 'dairy', 'cold_storage', 'FRIDGE', 'Milk', NULL, NULL, 1, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('0389990b-d447-4ecd-ba0b-b4df565eee4e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cheese', 'cheese', 'cold_storage', 'FRIDGE', 'Cheese', NULL, NULL, 2, NULL, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('c4cd38a1-6af7-4a36-89fa-20046ee1f18a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Deli', 'deli', 'cold_storage', 'FRIDGE', 'Beef', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('73518e02-21fd-4b67-a6ed-404579320aa0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Eggs', 'eggs', 'cold_storage', 'FRIDGE', 'Egg', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('dd8e59c4-4e81-49aa-ba6a-3b3a1160a435', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fresh vegetables', 'fresh_vegetables', 'cold_storage', 'FRIDGE', 'LeafyGreen', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('5f2f245c-106f-442a-92a0-9cf0e1a2f6bb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fresh fruits', 'fresh_fruits', 'cold_storage', 'FRIDGE', 'Apple', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('3cbde1e1-8abc-4b1b-b879-178293517b1b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Drinks', 'drinks', 'cold_storage', 'FRIDGE', 'GlassWater', NULL, NULL, 7, NULL, NULL, NULL, true, '[{"key": "abv", "is_system": true, "label": "Alcohol content (ABV %)", "type": "number", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a388487e-6fee-4d33-a75f-24355acb29fd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Sauces and dips', 'sauces', 'cold_storage', 'FRIDGE', 'Pint', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('15da7ee7-e119-4611-a22e-d819a4385ca1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fresh meat', 'fresh_meat', 'cold_storage', 'FRIDGE', 'Drumstick', NULL, NULL, 9, NULL, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('835ca3b8-a69b-46b4-8c72-10af58d58492', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fresh meals', 'fresh_meals', 'cold_storage', 'FRIDGE', 'CookingPot', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b7c75a13-d533-4e6e-ad21-50e4814805ab', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dry products', 'dry_products', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 1, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('550deac4-1753-4e8b-ae11-bbd6ebf85c01', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Pasta', 'pasta', 'dry_goods', 'PANTRY', 'Utensils', NULL, NULL, 2, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('17de5e9f-e6b3-4102-bc4a-80bd57d75e8c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Rice and grains', 'rice_grains', 'dry_goods', 'PANTRY', 'Wheat', NULL, NULL, 3, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('6be70291-ea40-4c4c-803c-18d194e78a0e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Canned goods', 'canned_goods', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 4, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('9ccad7f3-47ad-445e-9b6e-b4510d4f38cb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Spices and herbs', 'spices_herbs', 'dry_goods', 'PANTRY', 'Leaf', NULL, NULL, 5, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('7b189ebd-ef33-427c-bf57-b584eefa435d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Oils and vinegars', 'oils_vinegars', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 6, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('edff8dc4-6474-49a7-8c0c-6feae4829aa3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Flours and sugars', 'flours_sugars', 'dry_goods', 'PANTRY', 'Box', NULL, NULL, 7, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a0705c5e-58fa-47fd-a513-54220fb00a28', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Snacks', 'snacks', 'dry_goods', 'PANTRY', 'Cookie', NULL, NULL, 8, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('32432b7d-e1fc-48b0-86db-a70bdf5631f6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Sweets', 'sweets', 'dry_goods', 'PANTRY', 'Candy', NULL, NULL, 9, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('b9486491-2c54-4d9f-b714-bd2225e109d2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Beverages (non-refrigerated)', 'beverages', 'dry_goods', 'PANTRY', 'GlassWater', NULL, NULL, 10, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('9c734dbe-321c-4517-83b2-6a733ac4497e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tea and coffee', 'tea_coffee', 'dry_goods', 'PANTRY', 'Coffee', NULL, NULL, 11, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('a4c9eb47-b9d0-41e7-a824-5cf1f28a2eb7', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cans and jars', 'cans_jars', 'dry_goods', 'PANTRY', 'Container', NULL, NULL, 12, NULL, NULL, NULL, true, '[]');
INSERT INTO public.categories (id, organization_id, name, code, context_tag, group_label, icon, emoji, color, sort_order, meta_data, default_removal_strategy, module_name, is_active, field_definitions) VALUES ('ed225fac-0507-451b-96e8-b9c7bf96940c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Other', 'other', NULL, NULL, 'Archive', NULL, NULL, 100, NULL, NULL, NULL, true, '[]');


--
-- Data for Name: cycle_count_schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_extra_costs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('ed774a5d-e924-42ab-b163-af116420540e', 'b7c59311-57b1-4b44-9bb7-0196118913d1', '6dd30970-c5e1-4fd5-b511-2a29845d62ac', 'c67f7840-e1c9-46e1-a074-6b940430e40e', 'Rice Cakes', 'Harvest Row', '2000000000701', 5.000, 5.000, 0.000, '917304cd-586e-45cc-9900-313855f42a9b', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 22.50, NULL, 22.50, 'USD', 1, NULL, '{"name": "Rice Cakes", "seed": "SEED-DOC", "brand": "Harvest Row"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('ab5639c5-3089-43f7-8bdc-f9fbe65ef3f5', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', '901a2389-0145-4457-90b7-d2b61cbc3abe', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 48.000, 48.000, 48.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 216.00, NULL, 216.00, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('3b0830da-a923-4dc9-b898-2a155a85bf63', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', 'dd07e024-7797-4e3e-b6da-85394471f19d', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 24.000, 24.000, 24.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, NULL, 124.80, NULL, 124.80, 'USD', 2, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('f27ef2ef-fba8-4da9-a207-d2f75217b67f', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', 'b73207ab-580c-4077-b1f7-13b94a855ed2', '80b42f49-4cde-42be-bb81-b4631caefbd5', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 36.000, 36.000, 36.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 320.40, NULL, 320.40, 'USD', 3, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('4ea88fff-1e07-4c1a-bdc6-69c38a45d23f', '64f48cb3-a184-4e39-a210-a533ab3598d3', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 'Gouda Cheese', 'Meadowlane', '2000000000046', 60.000, 60.000, 60.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 750.00, NULL, 750.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('bd17f841-0096-489c-8645-2f81e6ff4c6e', '64f48cb3-a184-4e39-a210-a533ab3598d3', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', 'fa748810-6265-493f-a360-df817a409794', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 20.000, 20.000, 20.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 82.00, NULL, 82.00, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('041e4017-71f6-4524-8732-42b36f2a2b54', 'a9f9e490-e1d9-4580-9d28-ce03dd1368a4', '5530d507-8782-45c5-bf59-4fa3e85eeb6a', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 'Dell Latitude 5540', 'Dell', '2000000010014', 5.000, 5.000, 5.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 4200.00, NULL, 21000.00, NULL, 21000.00, 'USD', 1, NULL, '{"name": "Dell Latitude 5540", "seed": "SEED-DOC", "brand": "Dell"}', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('31eb2a1e-3154-435d-a30b-580179bc9e7a', 'a9f9e490-e1d9-4580-9d28-ce03dd1368a4', '41043f6d-7863-49f4-ba89-f7c702978b9d', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'ThinkPad T14s Gen 4', 'Lenovo', '2000000010021', 3.000, 3.000, 3.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, NULL, 17400.00, NULL, 17400.00, 'USD', 2, NULL, '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC", "brand": "Lenovo"}', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('4982a2de-f822-484b-939d-4c18875fceac', 'ad73fd07-f37d-4e7e-9f1b-876850e847fe', '901a2389-0145-4457-90b7-d2b61cbc3abe', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 12.000, 12.000, 12.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, NULL, 54.00, NULL, 54.00, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('d2d0082d-fb17-4261-9e86-699d1232cf94', 'ad73fd07-f37d-4e7e-9f1b-876850e847fe', 'b73207ab-580c-4077-b1f7-13b94a855ed2', '80b42f49-4cde-42be-bb81-b4631caefbd5', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 8.000, 8.000, 8.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 71.20, NULL, 71.20, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('479572ab-8e0f-475b-8d71-c84c435589d7', '628ec398-1bcf-4792-be3f-ee3398c39d0f', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 0.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 125.00, NULL, 125.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('e598f9af-4b7c-4fe5-9517-d6ad98155c39', 'bfb27ef9-b911-4140-9f94-bce736fcc3dd', '18d0f606-78b4-476f-8761-6e710672c3f3', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'ThinkPad T14s Gen 4', NULL, NULL, 3.000, 3.000, 3.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, NULL, 17400.00, NULL, 17400.00, 'USD', 1, '5ffd280d-3d94-48a7-b1bb-649627aca117', '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC"}', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('33100d3c-ff80-4635-8b55-8c93a51a1e47', 'dd7d86fb-48bc-489a-8c5e-c5dc7c46e7cb', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 'Gouda Cheese', 'Meadowlane', '2000000000046', 8.000, 8.000, 0.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 100.00, NULL, 100.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('5ee4ebf4-cb1a-4c66-9c5e-5cc42dcb3997', 'dd7d86fb-48bc-489a-8c5e-c5dc7c46e7cb', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', 'fa748810-6265-493f-a360-df817a409794', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 4.000, 4.000, 0.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 16.40, NULL, 16.40, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('ed265a75-c86f-45fb-82d1-dbc7b3549223', '8a59913a-b433-4654-8783-6a3e9994e96f', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 10.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, NULL, 125.00, NULL, 125.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('c05d91a2-fe69-45a1-8635-ec888976803b', '8a59913a-b433-4654-8783-6a3e9994e96f', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', 'fa748810-6265-493f-a360-df817a409794', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 5.000, 5.000, 5.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, NULL, 20.50, NULL, 20.50, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('4398a1eb-755c-4e56-b2f6-dc5926ce714d', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 'dd07e024-7797-4e3e-b6da-85394471f19d', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 6.000, 6.000, 6.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, NULL, 31.20, NULL, 31.20, 'USD', 1, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 0.000, '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, false);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id, meta_data, expected_is_count) VALUES ('5c3043cc-5f88-4d07-8053-489b7d52a2b4', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 'b73207ab-580c-4077-b1f7-13b94a855ed2', '80b42f49-4cde-42be-bb81-b4631caefbd5', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 4.000, 4.000, 4.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, NULL, 35.60, NULL, 35.60, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 0.000, '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, false);


--
-- Data for Name: document_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_number_sequences (organization_id, prefix, next_value) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'PR/2026/', 2);


--
-- Data for Name: document_package_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('80f92b7b-6d80-4b2a-a517-21d09a65edc1', 'a6f3f117-f6e5-4144-9383-27b7dd53ed03', '4398a1eb-755c-4e56-b2f6-dc5926ce714d', 6.000, '2026-11-09 20:29:59.019664+00');
INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('6a4b5e39-b1c0-4f5e-954c-d8ca1365471a', 'db54490c-1180-4b1e-be90-89ee7eef3f53', '5c3043cc-5f88-4d07-8053-489b7d52a2b4', 4.000, '2026-11-09 20:29:59.019664+00');


--
-- Data for Name: document_packages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('a6f3f117-f6e5-4144-9383-27b7dd53ed03', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 1, NULL, '2026-11-09 20:29:59.019664+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('db54490c-1180-4b1e-be90-89ee7eef3f53', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 2, NULL, '2026-11-09 20:29:59.019664+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');


--
-- Data for Name: document_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_profiles (id, organization_id, name, value_tracking_enabled, tax_handling, default_tax_rate, require_partner_tax_id, numbering_format, type_labels, default_unit, visible_line_fields, print_template, default_currency, default_template_id, approval_threshold, approval_required_for_types, created_at, updated_at, number_padding, require_unit_price, confirm_shelf_by_scan, tracking_url_templates, quarantine_location_id, pick_order_strategy) VALUES ('e9c6c812-8917-41e0-881c-87a92ca8c479', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Full Value', true, 'SIMPLE_RATE', NULL, NULL, '{TYPE}/{YEAR}/{SEQ:03d}', 'null', 'pcs', '[]', 'auto', NULL, NULL, NULL, NULL, '2026-11-09 20:29:57.088064+00', '2026-11-09 20:29:57.107061+00', 3, false, false, NULL, 'c9f96697-3dc0-4d35-bb5f-66f5615a6725', NULL);


--
-- Data for Name: document_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_shipments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_shipments (id, organization_id, document_id, carrier, tracking_number, shipped_at, shipped_by, notes, created_at) VALUES ('84e09e9d-64f7-4555-a141-50a28178fd8a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 'InPost', '620012345678901234567890', '2026-11-09 20:29:59.643438+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', NULL, '2026-11-09 20:29:59.594834+00');


--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_type_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_warehouse_receiving; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_work_item_overlays; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('5d8b0554-af04-4d21-9239-aa6ed6aa2e52', '00e8db4f-deff-45c2-82ee-95c459b73161', 'IN', 'IN/2026/002', 'COMPLETED', 'd5624d47-95f8-4614-b1fd-b54126a2d6f7', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-10-31', NULL, 'Delivery note 7311', '{"code": "FFD-004", "name": "Freshfield Wholesale"}', NULL, NULL, 661.20, 0.00, 661.20, 'USD', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-10-31 08:10:00+00', '2026-11-09 20:30:00.995154+00', '2026-10-31 09:20:00+00', '2026-10-31 10:50:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('628ec398-1bcf-4792-be3f-ee3398c39d0f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'OUT', 'OUT/2026/002', 'CONFIRMED', '4b90b049-ab0c-484c-94cf-516153c7b811', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, '2026-11-07', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 125.00, 0.00, 125.00, 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', NULL, '2026-11-07 10:50:00+00', '2026-11-09 20:30:00.995571+00', '2026-11-07 12:00:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('64f48cb3-a184-4e39-a210-a533ab3598d3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'IN', 'IN/2026/003', 'COMPLETED', '7196aff0-d168-40d4-96c3-d48935de578a', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '2026-11-02', NULL, 'Delivery note 7312', '{"code": "MCC-005", "name": "Bulkline Cash & Carry"}', NULL, NULL, 832.00, 0.00, 832.00, 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-11-02 11:20:00+00', '2026-11-09 20:30:00.995915+00', '2026-11-02 12:30:00+00', '2026-11-02 14:00:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('8a59913a-b433-4654-8783-6a3e9994e96f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'OUT', 'OUT/2026/004', 'COMPLETED', '4b90b049-ab0c-484c-94cf-516153c7b811', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, '2026-11-08', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 145.50, 0.00, 145.50, 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-11-08 13:15:00+00', '2026-11-09 20:30:00.995917+00', '2026-11-08 14:25:00+00', '2026-11-08 15:55:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('a9f9e490-e1d9-4580-9d28-ce03dd1368a4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'IN', 'IN/2026/004', 'COMPLETED', '31869dee-d35c-401e-9a57-a5a63c1f75d3', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-07', NULL, 'Delivery note 7313', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 38400.00, 0.00, 38400.00, 'USD', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-07 11:20:00+00', '2026-11-09 20:30:00.995917+00', '2026-11-07 12:30:00+00', '2026-11-07 14:00:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('ad73fd07-f37d-4e7e-9f1b-876850e847fe', '00e8db4f-deff-45c2-82ee-95c459b73161', 'OUT', 'OUT/2026/001', 'COMPLETED', '674cf125-faba-4efc-bbff-8a9bd0ce70e5', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, '2026-11-05', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 125.20, 0.00, 125.20, 'USD', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-05 10:50:00+00', '2026-11-09 20:30:00.995917+00', '2026-11-05 12:00:00+00', '2026-11-05 13:30:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('b7c59311-57b1-4b44-9bb7-0196118913d1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'INT', 'INT/2026/001', 'DRAFT', NULL, '866b2db9-f86e-4955-8198-0d499f3e5025', '88658701-75a4-4a06-9d85-62f32417ca68', '2026-11-08', NULL, NULL, 'null', NULL, NULL, 22.50, 0.00, 22.50, 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', NULL, NULL, '2026-11-08 10:50:00+00', '2026-11-09 20:30:00.99711+00', NULL, NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('bfb27ef9-b911-4140-9f94-bce736fcc3dd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'IN', 'IN/2026/001', 'COMPLETED', '31869dee-d35c-401e-9a57-a5a63c1f75d3', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-10-23', NULL, 'PO/2026/003', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 17400.00, 0.00, 17400.00, 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-10-23 09:35:00+00', '2026-11-09 20:30:00.997332+00', '2026-10-23 10:45:00+00', '2026-10-23 12:15:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('dd7d86fb-48bc-489a-8c5e-c5dc7c46e7cb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'OUT', 'OUT/2026/005', 'CONFIRMED', '674cf125-faba-4efc-bbff-8a9bd0ce70e5', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, '2026-11-08', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 116.40, 0.00, 116.40, 'USD', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', NULL, '2026-11-08 14:05:00+00', '2026-11-09 20:30:00.997565+00', '2026-11-08 15:15:00+00', NULL, NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key, held_by, meta_data, print_snapshot) VALUES ('e7b9f838-3e91-47fa-939f-7f2da6ac1133', '00e8db4f-deff-45c2-82ee-95c459b73161', 'OUT', 'OUT/2026/003', 'COMPLETED', '674cf125-faba-4efc-bbff-8a9bd0ce70e5', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, '2026-11-08', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 66.80, 0.00, 66.80, 'USD', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-08 12:05:00+00', '2026-11-09 20:30:00.997756+00', '2026-11-08 13:15:00+00', '2026-11-08 14:45:00+00', NULL, false, false, NULL, NULL, false, NULL, NULL, NULL, NULL);


--
-- Data for Name: email_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('1240e0ca-eaa8-41e6-b809-c297966446ab', '00e8db4f-deff-45c2-82ee-95c459b73161', 'bd563cb7-7dcc-479a-bbcc-cbe4d076d631', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 'Ava Brennan', 'ava.brennan@example.com', '2026-10-26 20:30:00.206301+00', '2027-05-08 20:30:00.206306+00', NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-09 20:30:00.208839+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('fa0ccc1a-4d60-4508-9e98-4955548de8f1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c1acf8bf-cf81-4a80-ae41-08d61a574810', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 'Marcus Webb', 'marcus.webb@example.com', '2026-10-17 20:30:00.206384+00', '2027-05-08 20:30:00.206386+00', NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-09 20:30:00.208841+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('1b960ca6-ebc0-4bb7-b03d-5f8611538c95', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f209851d-1c68-4b70-938b-d2103b646e6f', NULL, '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 'Priya Raman', 'priya.raman@example.com', '2026-10-08 20:30:00.206413+00', '2027-05-08 20:30:00.206414+00', NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-11-09 20:30:00.208841+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('d88a1be2-c697-4ea8-aa72-231786734362', '00e8db4f-deff-45c2-82ee-95c459b73161', '9560ba1a-aac2-40a8-bdec-31ed002aac92', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 'Demo Administrator', 'admin@example.com', '2026-09-30 20:30:01.019597+00', NULL, NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', NULL, 'Work phone, with case and charger.', NULL, NULL, '2026-11-09 20:30:01.025518+00');


--
-- Data for Name: equipment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_maintenance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('e189298a-824d-403f-b55f-d979b22be434', '00e8db4f-deff-45c2-82ee-95c459b73161', '6674708c-ee7f-4a72-a8cd-c54966f2dcfc', 'REPAIR', 'Replace failed PSU', 'Redundant power supply 2 reported a fault; unit sent to the vendor.', NULL, 'USD', '2026-11-06', 'Northgate IT Distribution', NULL, NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.552483+00', '2026-11-09 20:30:00.552486+00');
INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('05c06005-a8f3-4777-a764-b0ec2b74cf88', '00e8db4f-deff-45c2-82ee-95c459b73161', '3069036f-d8a3-44b6-9d81-5704d6d2c6b3', 'INSPECTION', 'Battery self-test and runtime check', 'Runtime at full load 11 min, within spec. Batteries due next year.', 120.00, 'USD', '2026-09-30', 'Northgate IT Distribution', NULL, '2027-09-30', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.552488+00', '2026-11-09 20:30:00.552488+00');


--
-- Data for Name: event_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: event_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('3d2e0451-7e1f-46cd-8afa-0079d4864ee9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "901a2389-0145-4457-90b7-d2b61cbc3abe", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "48.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.645353+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.645355+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "8286bc5b-c3f3-4270-a38c-a753f5b8531b", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.680036+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('cf30cef5-6da8-49fd-b8d5-aeb63d20e84d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "dd07e024-7797-4e3e-b6da-85394471f19d", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.655293+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.655296+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "54e6d7a8-1d68-4c2b-a4e0-df49b00e2926", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.681661+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('b74791c0-3faa-494a-ae2c-e304107fd516', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "b73207ab-580c-4077-b1f7-13b94a855ed2", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.668450+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.668453+00:00", "category_id": "7fccadf3-255b-49ce-99be-4073275efcec", "description": null, "expiry_date": null, "module_name": null, "template_id": "80b42f49-4cde-42be-bb81-b4631caefbd5", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.681708+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('66242da4-3cb1-4387-a666-307cff1b08c1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "54f7f8f8-d787-4656-85a2-7c59662d2c4c", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "60.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.716625+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.716627+00:00", "category_id": "0389990b-d447-4ecd-ba0b-b4df565eee4e", "description": null, "expiry_date": null, "module_name": null, "template_id": "aeb331f9-551a-4794-801b-9d2fa6576ea8", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.725316+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('b3e8f5e0-9ec0-434b-94dd-8c8d2e619296', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "b6de84b0-c6ba-42d5-a875-e02d21715da3", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "20.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.722120+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.722122+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "fa748810-6265-493f-a360-df817a409794", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.725347+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('7ff19d15-b71d-4e8b-8d04-cec1979a458c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "5530d507-8782-45c5-bf59-4fa3e85eeb6a", "name": "Dell Latitude 5540", "brand": "Dell", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "5.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.747900+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.747902+00:00", "category_id": "51f7e51a-6382-4973-99a9-5f9353991362", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "d88c3c8f-3d12-443b-842e-17bc327f9fe6", "serial_number": null, "purchase_price": "4200.00", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "9fc409ab-02e4-45f0-a6a8-55344aafe2e0"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.756895+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('d03eb503-a81f-479d-8e44-239312a0fcd5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "41043f6d-7863-49f4-ba89-f7c702978b9d", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:29:58.753876+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.753877+00:00", "category_id": "51f7e51a-6382-4973-99a9-5f9353991362", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "4af7dd1e-9d07-47f8-b82a-13b52fb84728", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "9fc409ab-02e4-45f0-a6a8-55344aafe2e0"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.756925+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('8a01356f-fba3-4868-ad96-258c79b0cbe0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "901a2389-0145-4457-90b7-d2b61cbc3abe", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "meta_data": {}, "added_date": "2026-10-31", "created_at": "2026-10-31 10:50:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.695238+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "8286bc5b-c3f3-4270-a38c-a753f5b8531b", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "changes": {"quantity": 36.0}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.840147+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('9e437881-1da6-4da9-b8b2-07087f94b77e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "b73207ab-580c-4077-b1f7-13b94a855ed2", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "28.000", "image_key": null, "meta_data": {}, "added_date": "2026-10-31", "created_at": "2026-10-31 10:50:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.695238+00:00", "category_id": "7fccadf3-255b-49ce-99be-4073275efcec", "description": null, "expiry_date": null, "module_name": null, "template_id": "80b42f49-4cde-42be-bb81-b4631caefbd5", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "changes": {"quantity": 28.0}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:58.841055+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('6d476a9f-fd46-48d2-9012-6a35719118b3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "dd07e024-7797-4e3e-b6da-85394471f19d", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "18.000", "image_key": null, "meta_data": {}, "added_date": "2026-10-31", "created_at": "2026-10-31 10:50:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.695238+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "54e6d7a8-1d68-4c2b-a4e0-df49b00e2926", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "changes": {"quantity": 18.0}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:59.750223+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('7cf094d0-483c-463f-a927-1bca2ee0af5b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "b73207ab-580c-4077-b1f7-13b94a855ed2", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "meta_data": {}, "added_date": "2026-10-31", "created_at": "2026-10-31 10:50:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.834950+00:00", "category_id": "7fccadf3-255b-49ce-99be-4073275efcec", "description": null, "expiry_date": null, "module_name": null, "template_id": "80b42f49-4cde-42be-bb81-b4631caefbd5", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "changes": {"quantity": 24.0}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:59.750444+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('16013340-6145-4290-8e3e-7b33e12b2e44', '00e8db4f-deff-45c2-82ee-95c459b73161', 'document.completed', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "54e6d7a8-1d68-4c2b-a4e0-df49b00e2926", "product_code": null, "done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null, "source_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "target_location_id": null, "source_location_code": "SEED-U62H", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "80b42f49-4cde-42be-bb81-b4631caefbd5", "product_code": null, "done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null, "source_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "target_location_id": null, "source_location_code": "SEED-U62H", "target_location_code": null}], "document_id": "e7b9f838-3e91-47fa-939f-7f2da6ac1133", "document_type": "OUT", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:59.750476+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('7f63a1d2-16a2-4069-869a-8eaa6693d630', '00e8db4f-deff-45c2-82ee-95c459b73161', 'document.shipped', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "54e6d7a8-1d68-4c2b-a4e0-df49b00e2926", "product_code": null, "done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null, "source_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "target_location_id": null, "source_location_code": "SEED-U62H", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "80b42f49-4cde-42be-bb81-b4631caefbd5", "product_code": null, "done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null, "source_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf", "target_location_id": null, "source_location_code": "SEED-U62H", "target_location_code": null}], "carrier": "InPost", "shipped_at": "2026-11-09T20:29:59.643438+00:00", "document_id": "e7b9f838-3e91-47fa-939f-7f2da6ac1133", "tracking_url": "https://inpost.pl/sledzenie-przesylek?number=620012345678901234567890", "document_type": "OUT", "package_count": 2, "document_number": "OUT/2026/003", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "tracking_number": "620012345678901234567890"}', NULL, '2026-11-09 20:29:59.750507+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('1f2ee178-7328-4c09-a237-920aa70024b5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "54f7f8f8-d787-4656-85a2-7c59662d2c4c", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "50.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-02", "created_at": "2026-11-02 14:00:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.728569+00:00", "category_id": "0389990b-d447-4ecd-ba0b-b4df565eee4e", "description": null, "expiry_date": null, "module_name": null, "template_id": "aeb331f9-551a-4794-801b-9d2fa6576ea8", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1"}, "changes": {"quantity": 50.0}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:59.835727+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('f50f9aa6-69cc-4940-a9f8-dc634a913f42', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "b6de84b0-c6ba-42d5-a875-e02d21715da3", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "15.000", "image_key": null, "meta_data": {}, "added_date": "2026-11-02", "created_at": "2026-11-02 14:00:00+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:29:58.728569+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "fa748810-6265-493f-a360-df817a409794", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1"}, "changes": {"quantity": 15.0}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:59.835771+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('cb032a3f-be1e-4bf3-bec6-885bc2006419', '00e8db4f-deff-45c2-82ee-95c459b73161', 'document.completed', '{"lines": [{"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "aeb331f9-551a-4794-801b-9d2fa6576ea8", "product_code": null, "done_quantity": 10.0, "expected_quantity": 10.0, "source_po_line_id": null, "source_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1", "target_location_id": null, "source_location_code": "SEED-3OG7", "target_location_code": null}, {"unit": "pcs", "lot_id": null, "lot_number": null, "product_id": "fa748810-6265-493f-a360-df817a409794", "product_code": null, "done_quantity": 5.0, "expected_quantity": 5.0, "source_po_line_id": null, "source_location_id": "206de892-4ef6-49b3-b1bc-4d2d1dc779a1", "target_location_id": null, "source_location_code": "SEED-3OG7", "target_location_code": null}], "document_id": "8a59913a-b433-4654-8783-6a3e9994e96f", "document_type": "OUT", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:29:59.835984+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('19f8f72e-12f1-41b6-8e7e-ddf0434c673f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "18d0f606-78b4-476f-8761-6e710672c3f3", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "meta_data": {"equipment": {"equipment_status": "AVAILABLE"}}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:30:00.099156+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:30:00.099159+00:00", "category_id": "51f7e51a-6382-4973-99a9-5f9353991362", "description": null, "expiry_date": null, "module_name": "equipment", "template_id": "4af7dd1e-9d07-47f8-b82a-13b52fb84728", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "9fc409ab-02e4-45f0-a6a8-55344aafe2e0"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:30:00.108823+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('0e9f3351-fffd-4a17-8af7-91b5742755ea', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "c82a3e23-85db-4275-b655-c89edaf839a5", "name": "Damson Plums", "brand": "Green Acre", "lot_id": null, "uom_id": "fefa9928-2a16-4fa2-a52e-9cd9d3a18817", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "13.600", "image_key": null, "meta_data": null, "added_date": "2026-11-06", "created_at": "2026-11-09 20:29:57.643671+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:30:00.368392+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "063c1712-5f63-4a39-9de1-9bee2fcc5c21", "serial_number": null, "purchase_price": "3.40", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "4862b4f7-228f-43d4-b329-37de5b1813bf"}, "changes": {"quantity": 13.6}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:30:00.372846+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('0d365b9e-07d3-414c-8ac6-7af0749ffa0f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "ab2f3769-1eab-45fa-8139-325918662b24", "name": "White Sugar", "brand": "Harvest Row", "lot_id": null, "uom_id": "fefa9928-2a16-4fa2-a52e-9cd9d3a18817", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "21.220", "image_key": null, "meta_data": null, "added_date": "2026-10-20", "created_at": "2026-11-09 20:29:57.643675+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:30:00.401244+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "a7907bfa-51a5-4121-8ad2-91864a33b272", "serial_number": null, "purchase_price": "1.10", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "85b351d5-711b-47d4-b174-83619236e876"}, "changes": {"quantity": 21.22}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:30:00.403075+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('42ae85f6-29a1-4e60-96c8-cf3490b8f6bc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.updated', '{"item": {"id": "017b7fd5-a2f5-4460-b1a8-14693d388e98", "name": "Cassia Cinnamon", "brand": "Saltmill", "lot_id": null, "uom_id": "fefa9928-2a16-4fa2-a52e-9cd9d3a18817", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "0.440", "image_key": null, "meta_data": null, "added_date": "2026-10-06", "created_at": "2026-11-09 20:29:57.643675+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:30:00.419914+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "0ac86d54-9b7d-43be-a6de-b6db210e7c8f", "serial_number": null, "purchase_price": "24.00", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "85b351d5-711b-47d4-b174-83619236e876"}, "changes": {"quantity": 0.44}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:30:00.422239+00', NULL, 0);
INSERT INTO public.event_outbox (id, organization_id, event, payload, emitter_module, created_at, published_at, attempts) VALUES ('80df193d-07da-4b1d-801c-d8be7f07968b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'item.created', '{"item": {"id": "d77771f8-a4d2-44da-bb70-e63cad25da78", "name": "Plum Butter", "brand": null, "lot_id": null, "uom_id": "fefa9928-2a16-4fa2-a52e-9cd9d3a18817", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "11.400", "image_key": null, "meta_data": {}, "added_date": "2026-11-09", "created_at": "2026-11-09 20:30:00.443316+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-11-09 20:30:00.443318+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "42fb5efc-9a73-4801-989a-0182576ad930", "serial_number": null, "purchase_price": "8.36", "shelf_location": null, "deletion_reason": null, "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "85b351d5-711b-47d4-b174-83619236e876"}, "user_id": "d9f91cf7-ee26-4c70-836c-bff04b6bb484", "organization_id": "00e8db4f-deff-45c2-82ee-95c459b73161"}', NULL, '2026-11-09 20:30:00.447702+00', NULL, 0);


--
-- Data for Name: example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ingredient_nutrition_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_periods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('c04f0a37-9de8-402b-a497-5b8d505156d8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c82a3e23-85db-4275-b655-c89edaf839a5', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGED', '{"old": "40.000", "new": "13.600", "reason": "production_run", "production_order_id": "21ff6bdb-dd23-46c5-bab5-80df73db583b", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-09 20:30:00.370269+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1916b2fe-db1e-42b3-9449-fc240ff38af3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ab2f3769-1eab-45fa-8139-325918662b24', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGED', '{"old": "25.000", "new": "21.220", "reason": "production_run", "production_order_id": "21ff6bdb-dd23-46c5-bab5-80df73db583b", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-09 20:30:00.401904+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('fc328fd3-74aa-452b-b8f9-44a91b27545f', '00e8db4f-deff-45c2-82ee-95c459b73161', '017b7fd5-a2f5-4460-b1a8-14693d388e98', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'QUANTITY_CHANGED', '{"old": "0.500", "new": "0.440", "reason": "production_run", "production_order_id": "21ff6bdb-dd23-46c5-bab5-80df73db583b", "production_order_number": "PR/2026/0001"}', NULL, '2026-11-09 20:30:00.420731+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('6d53bc2e-4c46-44d6-92c3-ade10e8d1098', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd77771f8-a4d2-44da-bb70-e63cad25da78', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'CREATED', '{"created": true}', NULL, '2026-11-09 20:30:00.446845+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('69284112-2912-4c45-85c0-57ab580b6acb', '00e8db4f-deff-45c2-82ee-95c459b73161', '18d0f606-78b4-476f-8761-6e710672c3f3', '6e228bca-4488-4535-9fd3-0d4b0549bd49', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/004", "from_template": "4af7dd1e-9d07-47f8-b82a-13b52fb84728"}', 'bfb27ef9-b911-4140-9f94-bce736fcc3dd', '2026-11-09 20:30:00.106592+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('5ec6ec69-9059-493c-9614-0df1b04cf851', '00e8db4f-deff-45c2-82ee-95c459b73161', '901a2389-0145-4457-90b7-d2b61cbc3abe', 'f513905d-ce7d-43a4-a772-b43279005f82', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "8286bc5b-c3f3-4270-a38c-a753f5b8531b"}', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', '2026-11-09 20:29:58.675294+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('6a211c06-a3e4-4048-876e-e080435866c5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dd07e024-7797-4e3e-b6da-85394471f19d', 'f513905d-ce7d-43a4-a772-b43279005f82', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "54e6d7a8-1d68-4c2b-a4e0-df49b00e2926"}', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', '2026-11-09 20:29:58.675297+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('2218ce68-9183-44d1-8ca2-17bdacebabe0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b73207ab-580c-4077-b1f7-13b94a855ed2', 'f513905d-ce7d-43a4-a772-b43279005f82', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "80b42f49-4cde-42be-bb81-b4631caefbd5"}', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', '2026-11-09 20:29:58.675298+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('180f801f-865a-497e-926d-7002df9f4d38', '00e8db4f-deff-45c2-82ee-95c459b73161', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', '6e228bca-4488-4535-9fd3-0d4b0549bd49', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "aeb331f9-551a-4794-801b-9d2fa6576ea8"}', '64f48cb3-a184-4e39-a210-a533ab3598d3', '2026-11-09 20:29:58.724569+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('6d101f3b-ef5f-45e1-81f6-3f6c3f8a66a1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', '6e228bca-4488-4535-9fd3-0d4b0549bd49', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "fa748810-6265-493f-a360-df817a409794"}', '64f48cb3-a184-4e39-a210-a533ab3598d3', '2026-11-09 20:29:58.72457+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('7f1557fd-9f64-456b-9ab4-a5d5e29ae3b7', '00e8db4f-deff-45c2-82ee-95c459b73161', '901a2389-0145-4457-90b7-d2b61cbc3abe', 'f513905d-ce7d-43a4-a772-b43279005f82', 'QUANTITY_CHANGED', '{"old": "48.000", "new": "36.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', 'ad73fd07-f37d-4e7e-9f1b-876850e847fe', '2026-11-09 20:29:58.8387+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('ba32eae7-c01f-41a6-9817-d6bd81ea9b26', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b73207ab-580c-4077-b1f7-13b94a855ed2', 'f513905d-ce7d-43a4-a772-b43279005f82', 'QUANTITY_CHANGED', '{"old": "36.000", "new": "28.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', 'ad73fd07-f37d-4e7e-9f1b-876850e847fe', '2026-11-09 20:29:58.838702+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1b74de52-fea1-4e48-8d27-c35727ae7cb4', '00e8db4f-deff-45c2-82ee-95c459b73161', '5530d507-8782-45c5-bf59-4fa3e85eeb6a', 'f513905d-ce7d-43a4-a772-b43279005f82', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "d88c3c8f-3d12-443b-842e-17bc327f9fe6"}', 'a9f9e490-e1d9-4580-9d28-ce03dd1368a4', '2026-11-09 20:29:58.756229+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d9822091-0490-4c88-bee7-743417f2ca7b', '00e8db4f-deff-45c2-82ee-95c459b73161', '41043f6d-7863-49f4-ba89-f7c702978b9d', 'f513905d-ce7d-43a4-a772-b43279005f82', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "4af7dd1e-9d07-47f8-b82a-13b52fb84728"}', 'a9f9e490-e1d9-4580-9d28-ce03dd1368a4', '2026-11-09 20:29:58.756231+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('1f6f56a9-6be6-4140-ac35-5bb31eabb481', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dd07e024-7797-4e3e-b6da-85394471f19d', 'f513905d-ce7d-43a4-a772-b43279005f82', 'QUANTITY_CHANGED', '{"old": "24.000", "new": "18.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '2026-11-09 20:29:59.746472+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('ec37a5e0-d5cb-444e-a275-3663f6d791b8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b73207ab-580c-4077-b1f7-13b94a855ed2', 'f513905d-ce7d-43a4-a772-b43279005f82', 'QUANTITY_CHANGED', '{"old": "28.000", "new": "24.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', '2026-11-09 20:29:59.746475+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('308de5aa-b7ad-41d8-bc2b-99bc54372769', '00e8db4f-deff-45c2-82ee-95c459b73161', '54f7f8f8-d787-4656-85a2-7c59662d2c4c', '6e228bca-4488-4535-9fd3-0d4b0549bd49', 'QUANTITY_CHANGED', '{"old": "60.000", "new": "50.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', '8a59913a-b433-4654-8783-6a3e9994e96f', '2026-11-09 20:29:59.833255+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('28fdc00d-6cba-4c33-b725-077a1ef9f8fb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b6de84b0-c6ba-42d5-a875-e02d21715da3', '6e228bca-4488-4535-9fd3-0d4b0549bd49', 'QUANTITY_CHANGED', '{"old": "20.000", "new": "15.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', '8a59913a-b433-4654-8783-6a3e9994e96f', '2026-11-09 20:29:59.833257+00');


--
-- Data for Name: item_import_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('27599b96-532e-4b0a-afda-a84db42e3c1d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '9c734dbe-321c-4517-83b2-6a733ac4497e', NULL, 'Coffee Beans', 'Orchard & Oak', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '57e2ea5f-d739-4260-8c8b-8cdd0cd54dc1', 5.000, NULL, NULL, '2026-11-02', '2027-03-04', NULL, NULL, NULL, 5.70, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517105+00', '2026-11-09 20:29:57.517106+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d1f69a69-f2ba-41bf-ae34-8c8a1796892e', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', '5f2f245c-106f-442a-92a0-9cf0e1a2f6bb', NULL, 'Fuji Apples', 'Green Acre', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', 5.300, NULL, NULL, '2026-11-06', '2026-11-09', NULL, NULL, NULL, 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517107+00', '2026-11-09 20:29:57.517108+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6d570bbf-99bc-4cbf-8eff-9f1ab7015340', '00e8db4f-deff-45c2-82ee-95c459b73161', '8f446de5-a0e0-4514-832b-2d68c13476d6', 'a0705c5e-58fa-47fd-a513-54220fb00a28', NULL, 'Almonds', 'Green Acre', NULL, '917304cd-586e-45cc-9900-313855f42a9b', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', 5.000, NULL, NULL, '2026-10-11', NULL, NULL, NULL, NULL, 5.70, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517108+00', '2026-11-09 20:29:57.517109+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('af7aed07-4c92-466e-888b-28220c9caae4', '00e8db4f-deff-45c2-82ee-95c459b73161', '85b351d5-711b-47d4-b174-83619236e876', 'a0705c5e-58fa-47fd-a513-54220fb00a28', NULL, 'Almonds', 'Green Acre', NULL, '917304cd-586e-45cc-9900-313855f42a9b', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', 3.000, NULL, NULL, '2026-09-30', '2026-12-15', NULL, NULL, NULL, 4.81, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517109+00', '2026-11-09 20:29:57.517109+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('590d6574-c241-41cc-b235-f024204246f0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '9ccad7f3-47ad-445e-9b6e-b4510d4f38cb', NULL, 'Granulated Garlic', 'Saltmill', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '5e26266d-502e-4489-b09f-bf41874d8f83', 7.000, NULL, NULL, '2026-09-19', NULL, NULL, NULL, NULL, 5.52, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.51711+00', '2026-11-09 20:29:57.51711+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8e4b421b-8db9-47fe-95c2-298c20e26bef', '00e8db4f-deff-45c2-82ee-95c459b73161', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', '70c15371-6ae6-4975-8ddd-83ca77960757', NULL, 'Smoked Salmon', 'Bluewater', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'b60b93d0-b081-409f-a1df-80afe614f544', 7.000, NULL, NULL, '2026-11-03', '2026-11-12', NULL, NULL, NULL, 4.71, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517111+00', '2026-11-09 20:29:57.517111+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2142d4c5-c745-4da3-ba2b-522dea360662', '00e8db4f-deff-45c2-82ee-95c459b73161', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '5f2f245c-106f-442a-92a0-9cf0e1a2f6bb', NULL, 'Green Grapes', 'Green Acre', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '0bb26ced-1dd3-49a2-b332-55821cdf35d3', 7.400, NULL, NULL, '2026-11-08', '2027-03-11', NULL, NULL, NULL, 4.61, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517111+00', '2026-11-09 20:29:57.517111+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('82a14573-efea-4d8a-95a4-e28e1a52b3d9', '00e8db4f-deff-45c2-82ee-95c459b73161', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '5f2f245c-106f-442a-92a0-9cf0e1a2f6bb', NULL, 'Fuji Apples', 'Green Acre', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', 2.700, NULL, NULL, '2026-11-03', '2026-11-06', NULL, NULL, NULL, 5.64, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517112+00', '2026-11-09 20:29:57.517112+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a4a583f2-fc6e-4990-9299-4f46ef981147', '00e8db4f-deff-45c2-82ee-95c459b73161', '8f446de5-a0e0-4514-832b-2d68c13476d6', '32432b7d-e1fc-48b0-86db-a70bdf5631f6', NULL, 'Dark Chocolate 85%', 'Orchard & Oak', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9ee9b559-ea52-4db7-a2e4-28eaaf3d6b81', 1.000, NULL, NULL, '2026-10-09', '2027-05-03', NULL, NULL, NULL, 5.09, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517112+00', '2026-11-09 20:29:57.517113+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a7d22330-b3f3-4692-98d1-687b231d4034', '00e8db4f-deff-45c2-82ee-95c459b73161', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '6be70291-ea40-4c4c-803c-18d194e78a0e', NULL, 'Canned White Beans', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '2311d6c3-afc7-4dc8-9c71-5955220d6e31', 2.000, NULL, NULL, '2026-09-28', '2026-12-21', NULL, NULL, NULL, 4.65, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517113+00', '2026-11-09 20:29:57.517113+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9b04930c-a0ee-44dd-a50e-c079dd073a5d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '550deac4-1753-4e8b-ae11-bbd6ebf85c01', NULL, 'Penne Pasta', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'c3a351db-b74d-4190-a870-332727da317f', 7.000, NULL, NULL, '2026-09-17', '2027-03-08', NULL, NULL, NULL, 4.52, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517114+00', '2026-11-09 20:29:57.517114+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a01590cc-6be6-4608-9cbd-9e3958459560', '00e8db4f-deff-45c2-82ee-95c459b73161', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 'dd8e59c4-4e81-49aa-ba6a-3b3a1160a435', NULL, 'Carrots 1kg', 'Green Acre', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 'eb9b9ca0-46c5-4914-a914-c1dd7b1d6c0c', 8.200, NULL, NULL, '2026-11-03', '2026-11-10', NULL, NULL, NULL, 4.34, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517114+00', '2026-11-09 20:29:57.517115+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f1ede2b0-da84-44f2-8371-aed679b94426', '00e8db4f-deff-45c2-82ee-95c459b73161', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '17de5e9f-e6b3-4102-bc4a-80bd57d75e8c', NULL, 'Jasmine Rice 1kg', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'a288952d-aa29-4152-99bb-2eadf7b78e9d', 1.000, NULL, NULL, '2026-10-29', '2027-07-16', NULL, NULL, NULL, 5.31, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517115+00', '2026-11-09 20:29:57.517115+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('70b52e46-cddf-4527-a5ce-f8d1de53e3e0', '00e8db4f-deff-45c2-82ee-95c459b73161', '73869395-0caf-4783-a71d-e5ab311d279a', '0389990b-d447-4ecd-ba0b-b4df565eee4e', NULL, 'Gouda Cheese', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 9.000, NULL, NULL, '2026-11-04', '2026-11-07', NULL, NULL, NULL, 5.26, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517116+00', '2026-11-09 20:29:57.517116+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9100ddeb-e20b-40e1-8cad-31bf4dff3b34', '00e8db4f-deff-45c2-82ee-95c459b73161', '866b2db9-f86e-4955-8198-0d499f3e5025', '9ccad7f3-47ad-445e-9b6e-b4510d4f38cb', NULL, 'Ground Cinnamon', 'Saltmill', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '0624e122-2b53-43dc-9404-ac9614dd0b43', 9.000, NULL, NULL, '2026-10-07', NULL, NULL, NULL, NULL, 5.73, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517116+00', '2026-11-09 20:29:57.517116+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2489e68f-d8f9-4de3-a661-cce7220413f5', '00e8db4f-deff-45c2-82ee-95c459b73161', '8f446de5-a0e0-4514-832b-2d68c13476d6', 'b7c75a13-d533-4e6e-ad21-50e4814805ab', NULL, 'Fruit Muesli', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '349c83b7-b912-4814-8249-84962e8119fd', 3.000, NULL, NULL, '2026-09-26', '2027-07-21', NULL, NULL, NULL, 4.70, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517117+00', '2026-11-09 20:29:57.517117+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2a892d0e-bba1-487a-b61d-0af9b6435786', '00e8db4f-deff-45c2-82ee-95c459b73161', '471ef176-3922-44c1-9239-e42b8ca3f0ee', '3cbde1e1-8abc-4b1b-b879-178293517b1b', NULL, 'Orange Juice NFC', 'Orchard & Oak', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '6e1acfb0-89c6-47f3-89e9-5817114a77fe', 5.000, NULL, NULL, '2026-09-15', NULL, NULL, NULL, NULL, 5.11, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517117+00', '2026-11-09 20:29:57.517118+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9f888545-abf1-44c5-ae38-151c4522f0d2', '00e8db4f-deff-45c2-82ee-95c459b73161', '8f446de5-a0e0-4514-832b-2d68c13476d6', '9ccad7f3-47ad-445e-9b6e-b4510d4f38cb', NULL, 'Ground Ginger', 'Saltmill', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '685830c5-bf5f-4c1e-8eec-4fa61755aff9', 4.000, NULL, NULL, '2026-09-04', '2027-08-20', NULL, NULL, NULL, 5.74, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517118+00', '2026-11-09 20:29:57.517118+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a4d38a29-3a08-4915-b55c-33749b590c6f', '00e8db4f-deff-45c2-82ee-95c459b73161', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '550deac4-1753-4e8b-ae11-bbd6ebf85c01', NULL, 'Fusilli Pasta', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '516be891-373e-4e07-974c-bf2985e5f36d', 1.000, NULL, NULL, '2026-10-27', '2027-05-04', NULL, NULL, NULL, 5.27, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517118+00', '2026-11-09 20:29:57.517119+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('418a3d19-11bf-415e-87da-c67bead70780', '00e8db4f-deff-45c2-82ee-95c459b73161', '88658701-75a4-4a06-9d85-62f32417ca68', 'eca481a8-b5b8-46fe-9569-8e01b612d6ec', NULL, 'Smoked Bacon', 'Fellbrook Farms', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '342da948-8958-46c6-bc7b-d18965b7e227', 2.300, NULL, NULL, '2026-11-07', '2026-11-16', NULL, NULL, NULL, 5.02, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517119+00', '2026-11-09 20:29:57.517119+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('32346049-1904-4386-8864-c8c6e5d86e7f', '00e8db4f-deff-45c2-82ee-95c459b73161', '7c9ef099-d7e7-43b1-a405-3e3a232272b0', '550deac4-1753-4e8b-ae11-bbd6ebf85c01', NULL, 'Fusilli Pasta', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '516be891-373e-4e07-974c-bf2985e5f36d', 1.000, NULL, NULL, '2026-10-05', '2027-09-06', NULL, NULL, NULL, 5.69, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.51712+00', '2026-11-09 20:29:57.51712+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fdd5d3e6-d7a4-4e5a-b3d7-57bfca6ecab6', '00e8db4f-deff-45c2-82ee-95c459b73161', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 'a0705c5e-58fa-47fd-a513-54220fb00a28', NULL, 'Rice Cakes', 'Harvest Row', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 'c67f7840-e1c9-46e1-a074-6b940430e40e', 3.000, NULL, NULL, '2026-09-24', '2027-05-30', NULL, NULL, NULL, 4.80, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.51712+00', '2026-11-09 20:29:57.51712+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('13a10024-6548-43c5-92d5-6fb7ff338827', '00e8db4f-deff-45c2-82ee-95c459b73161', '0a2727e8-6c13-4603-93e7-89512c6d8941', '7f00e767-edd4-4861-b55d-29af8ae4c39b', NULL, 'Frozen Green Peas', 'Northwind Frozen', NULL, '917304cd-586e-45cc-9900-313855f42a9b', '787cd292-d3ef-4678-a6c8-91df9da2727e', 7.000, NULL, NULL, '2026-09-13', '2027-12-24', NULL, NULL, NULL, 4.92, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517121+00', '2026-11-09 20:29:57.517121+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5801179e-c321-4d5e-8635-db263cf85837', '00e8db4f-deff-45c2-82ee-95c459b73161', '66ee606c-e95d-4547-920f-fb79bb6d8759', '84297201-9cd0-404b-830b-35cbad7234ca', NULL, 'Frozen Blueberries', 'Northwind Frozen', NULL, '917304cd-586e-45cc-9900-313855f42a9b', '611cf45d-7d37-4357-9110-cd0a47a192e1', 2.000, NULL, NULL, '2026-09-02', '2027-11-17', NULL, NULL, NULL, 4.81, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517121+00', '2026-11-09 20:29:57.517122+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('eb6bce5a-d0d4-419a-bf14-12a4d288d20f', '00e8db4f-deff-45c2-82ee-95c459b73161', '73869395-0caf-4783-a71d-e5ab311d279a', '5f2f245c-106f-442a-92a0-9cf0e1a2f6bb', NULL, 'Strawberries', 'Green Acre', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '58353c4d-8e46-4c89-a1ff-cc78db74e5fc', 7.600, NULL, NULL, '2026-11-08', NULL, NULL, NULL, NULL, 5.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517122+00', '2026-11-09 20:29:57.517122+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('cf1f9f51-0562-40ab-ab8d-67ec2cc3a441', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', 'a388487e-6fee-4d33-a75f-24355acb29fd', NULL, 'Tomato Ketchup', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4dd93e53-5ef7-4aba-ad5d-f3ee76fe41a1', 10.000, NULL, NULL, '2026-11-06', '2026-11-09', NULL, NULL, NULL, 4.56, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517123+00', '2026-11-09 20:29:57.517123+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('97a7e448-cbe8-49cd-8d89-45b3e36ad7d0', '00e8db4f-deff-45c2-82ee-95c459b73161', '866b2db9-f86e-4955-8198-0d499f3e5025', '17de5e9f-e6b3-4102-bc4a-80bd57d75e8c', NULL, 'Buckwheat Groats', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'fbee3e5f-1150-494e-8a64-14f40fa58af2', 4.000, NULL, NULL, '2026-10-03', '2027-03-09', NULL, NULL, NULL, 4.60, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517123+00', '2026-11-09 20:29:57.517124+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f48fdf7b-9547-4bbe-b66c-7b933b5fb985', '00e8db4f-deff-45c2-82ee-95c459b73161', '7c9ef099-d7e7-43b1-a405-3e3a232272b0', 'edff8dc4-6474-49a7-8c0c-6feae4829aa3', NULL, 'Potato Starch', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'b90fae37-b088-49c0-b137-96e942d88441', 7.000, NULL, NULL, '2026-09-22', '2026-12-30', NULL, NULL, NULL, 5.67, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517124+00', '2026-11-09 20:29:57.517124+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0c4c5cc6-3318-427a-9e89-d24cd9d3475d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 'b7c75a13-d533-4e6e-ad21-50e4814805ab', NULL, 'Dry Yeast', 'Harvest Row', NULL, '917304cd-586e-45cc-9900-313855f42a9b', '84be7ee7-1046-4de1-a2b5-e9eac6542e8c', 1.000, NULL, NULL, '2026-09-11', NULL, NULL, NULL, NULL, 4.97, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517125+00', '2026-11-09 20:29:57.517125+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('11174d3c-0bcf-4bd0-ae2b-49b39ae77c14', '00e8db4f-deff-45c2-82ee-95c459b73161', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 'eca481a8-b5b8-46fe-9569-8e01b612d6ec', NULL, 'Smoked Bacon', 'Fellbrook Farms', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '342da948-8958-46c6-bc7b-d18965b7e227', 6.600, NULL, NULL, '2026-11-03', '2026-11-15', NULL, NULL, NULL, 4.64, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517125+00', '2026-11-09 20:29:57.517125+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('fc16bf83-ef39-465e-92c2-08602cc02c52', '00e8db4f-deff-45c2-82ee-95c459b73161', '73869395-0caf-4783-a71d-e5ab311d279a', '7fccadf3-255b-49ce-99be-4073275efcec', NULL, 'Butter Extra 82%', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '80b42f49-4cde-42be-bb81-b4631caefbd5', 7.000, NULL, NULL, '2026-11-08', '2026-11-13', NULL, NULL, NULL, 5.15, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517126+00', '2026-11-09 20:29:57.517126+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0e1aea87-9473-407c-9fa8-434b8dbbd04c', '00e8db4f-deff-45c2-82ee-95c459b73161', '8f446de5-a0e0-4514-832b-2d68c13476d6', 'a0705c5e-58fa-47fd-a513-54220fb00a28', NULL, 'Rice Cakes', 'Harvest Row', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 'c67f7840-e1c9-46e1-a074-6b940430e40e', 5.000, NULL, NULL, '2026-10-12', '2027-07-16', NULL, NULL, NULL, 4.80, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517126+00', '2026-11-09 20:29:57.517127+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6dd30970-c5e1-4fd5-b511-2a29845d62ac', '00e8db4f-deff-45c2-82ee-95c459b73161', '866b2db9-f86e-4955-8198-0d499f3e5025', 'a0705c5e-58fa-47fd-a513-54220fb00a28', NULL, 'Rice Cakes', 'Harvest Row', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 'c67f7840-e1c9-46e1-a074-6b940430e40e', 10.000, NULL, NULL, '2026-10-01', NULL, NULL, NULL, NULL, 5.39, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517127+00', '2026-11-09 20:29:57.517127+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e304bd93-ca18-4f72-b946-23d570b1fbd0', '00e8db4f-deff-45c2-82ee-95c459b73161', '66ee606c-e95d-4547-920f-fb79bb6d8759', '93adc9f2-41e3-42b5-a954-7ce1e793ffef', NULL, 'Potato and Cheese Dumplings', 'Northwind Frozen', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 'c7486598-4240-4979-bb9e-21e57b6effe8', 2.000, NULL, NULL, '2026-09-20', '2028-03-12', NULL, NULL, NULL, 4.96, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517128+00', '2026-11-09 20:29:57.517128+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3eb0a601-f188-45d9-bda6-ffe25bddd331', '00e8db4f-deff-45c2-82ee-95c459b73161', '8f446de5-a0e0-4514-832b-2d68c13476d6', '7b189ebd-ef33-427c-bf57-b584eefa435d', NULL, 'Extra Virgin Olive Oil', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', 3.000, NULL, NULL, '2026-09-09', '2027-10-03', NULL, NULL, NULL, 5.61, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517128+00', '2026-11-09 20:29:57.517128+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f61a7248-0e8d-4c7e-b23b-037031b0d4df', '00e8db4f-deff-45c2-82ee-95c459b73161', '866b2db9-f86e-4955-8198-0d499f3e5025', '9ccad7f3-47ad-445e-9b6e-b4510d4f38cb', NULL, 'Iodised Salt', 'Saltmill', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '7f65a62c-3ea1-4603-94f7-4d837d66dd43', 8.000, NULL, NULL, '2026-11-01', '2027-09-23', NULL, NULL, NULL, 5.55, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517129+00', '2026-11-09 20:29:57.517129+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('204cab04-4e3a-4e0a-9778-afb38fb32119', '00e8db4f-deff-45c2-82ee-95c459b73161', '73869395-0caf-4783-a71d-e5ab311d279a', '7fccadf3-255b-49ce-99be-4073275efcec', NULL, 'Cottage Cheese', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'beb604b5-970d-4898-a6fd-319fca3f44fb', 7.000, NULL, NULL, '2026-11-08', '2026-11-11', NULL, NULL, NULL, 5.19, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517129+00', '2026-11-09 20:29:57.51713+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8e6d929b-de81-43e5-8975-d77052e39655', '00e8db4f-deff-45c2-82ee-95c459b73161', '73869395-0caf-4783-a71d-e5ab311d279a', '0389990b-d447-4ecd-ba0b-b4df565eee4e', NULL, 'Gouda Cheese', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 6.000, NULL, NULL, '2026-11-07', '2026-11-14', NULL, NULL, NULL, 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.51713+00', '2026-11-09 20:29:57.51713+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1558d5e6-5200-4239-a65b-ce3beeee61c7', '00e8db4f-deff-45c2-82ee-95c459b73161', '866b2db9-f86e-4955-8198-0d499f3e5025', '9ccad7f3-47ad-445e-9b6e-b4510d4f38cb', NULL, 'Granulated Garlic', 'Saltmill', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '5e26266d-502e-4489-b09f-bf41874d8f83', 5.000, NULL, NULL, '2026-09-29', '2027-07-17', NULL, NULL, NULL, 4.83, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.51713+00', '2026-11-09 20:29:57.517131+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('730d0f53-f70d-4551-b127-cb0b61d8e4fa', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '7b189ebd-ef33-427c-bf57-b584eefa435d', NULL, 'Sunflower Oil', 'Harvest Row', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'bb856f1a-fcdb-4d29-b932-14925497488e', 5.000, NULL, NULL, '2026-09-18', NULL, NULL, NULL, NULL, 4.90, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.517131+00', '2026-11-09 20:29:57.517131+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('aff3912f-5db9-41e4-af46-dd0372079953', '00e8db4f-deff-45c2-82ee-95c459b73161', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 1.000, NULL, 'SN-100004', '2025-09-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-02", "warranty_until": "2028-09-01", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-02 09:00:00+00', '2026-11-09 20:29:57.604449+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c6df73d2-2857-47df-8f94-c5dde904f55d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 1.000, NULL, 'SN-100005', '2025-05-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-28", "warranty_until": "2028-05-27", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-28 09:00:00+00', '2026-11-09 20:29:57.604449+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9fb8e257-7362-4222-997f-0fc95090dcb4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'MacBook Pro 14 M3', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 1.000, NULL, 'SN-100006', '2025-02-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-20", "warranty_until": "2028-02-20", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-20 09:00:00+00', '2026-11-09 20:29:57.604449+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f7a9ce61-45d0-42ff-89da-0e4b45577575', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9a1bb369-c512-457e-ae53-78a72acc2219', 1.000, NULL, 'SN-100007', '2024-11-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-15", "warranty_until": "2027-11-15", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-15 09:00:00+00', '2026-11-09 20:29:57.60445+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d771a98b-99ee-4453-b88c-9efd33c8a944', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'HP EliteBook 840 G10', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9a1bb369-c512-457e-ae53-78a72acc2219', 1.000, NULL, 'SN-100008', '2024-08-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-10", "warranty_until": "2027-08-10", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-10 09:00:00+00', '2026-11-09 20:29:57.60445+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e9b95f9b-4a17-44a0-bc6b-29057b30aded', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 1.000, NULL, 'SN-100009', '2024-05-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-05", "warranty_until": "2027-05-05", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-05 09:00:00+00', '2026-11-09 20:29:57.604451+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d4073cdc-f3f7-4b1f-b5d5-43e7f485e5c5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 1.000, NULL, 'SN-100011', '2023-10-24', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-24", "warranty_until": "2026-10-23", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-24 09:00:00+00', '2026-11-09 20:29:57.604451+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('761da475-b617-4421-9005-cfc23d7e67c8', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 1.000, NULL, 'SN-100012', '2026-07-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-23", "warranty_until": "2029-07-22", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-23 09:00:00+00', '2026-11-09 20:29:57.604452+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ddc64060-32d3-4c0d-a479-ad7d7d22bfd2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'c061f145-3135-4b56-95ec-087889a26e8b', 1.000, NULL, 'SN-100013', '2026-04-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-17", "warranty_until": "2029-04-16", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-17 09:00:00+00', '2026-11-09 20:29:57.604452+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('67016547-c45a-40e1-947b-fd096f6181ad', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'c061f145-3135-4b56-95ec-087889a26e8b', 1.000, NULL, 'SN-100014', '2026-01-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-10", "warranty_until": "2029-01-09", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-10 09:00:00+00', '2026-11-09 20:29:57.604452+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('849644e5-32f2-46af-998f-ecfe23b4f828', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'c061f145-3135-4b56-95ec-087889a26e8b', 1.000, NULL, 'SN-100015', '2025-10-05', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-05", "warranty_until": "2028-10-04", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-05 09:00:00+00', '2026-11-09 20:29:57.604453+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a3ec8b27-9e92-4b14-95c6-56f2d6152b6a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'c061f145-3135-4b56-95ec-087889a26e8b', 1.000, NULL, 'SN-100016', '2025-06-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-30", "warranty_until": "2028-06-29", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-30 09:00:00+00', '2026-11-09 20:29:57.604453+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b2b64f94-50c4-4a0f-b3e4-2d16695ac6be', '00e8db4f-deff-45c2-82ee-95c459b73161', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'HP ProDesk 400 G9', 'HP', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'c061f145-3135-4b56-95ec-087889a26e8b', 1.000, NULL, 'SN-100017', '2025-03-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-25", "warranty_until": "2028-03-24", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-25 09:00:00+00', '2026-11-09 20:29:57.604454+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1a186a27-71c3-4c04-b816-8bcec8833feb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'dc652b43-dc3a-429f-bc55-63cadcd9f58f', 1.000, NULL, 'SN-100018', '2024-12-18', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-18", "warranty_until": "2027-12-18", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-18 09:00:00+00', '2026-11-09 20:29:57.604454+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c1fd02d3-898f-4f1f-8f4e-6efc127eefd6', '00e8db4f-deff-45c2-82ee-95c459b73161', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '54327d88-3d1a-470b-889d-459f5efa89be', 1.000, NULL, 'SN-100019', '2024-09-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-12", "warranty_until": "2027-09-12", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-12 09:00:00+00', '2026-11-09 20:29:57.604454+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('30a87ae0-c34e-4655-8d55-fb65adeb991c', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '54327d88-3d1a-470b-889d-459f5efa89be', 1.000, NULL, 'SN-100020', '2024-06-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-07", "warranty_until": "2027-06-07", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-07 09:00:00+00', '2026-11-09 20:29:57.604455+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('942e35ad-571a-4c9b-91f4-99ca1f520882', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '54327d88-3d1a-470b-889d-459f5efa89be', 1.000, NULL, 'SN-100021', '2024-03-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-02", "warranty_until": "2027-03-02", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-02 09:00:00+00', '2026-11-09 20:29:57.604455+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('0ad3caae-5199-4ca7-80db-86828d9928c6', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '54327d88-3d1a-470b-889d-459f5efa89be', 1.000, NULL, 'SN-100022', '2023-11-26', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-26", "warranty_until": "2026-11-25", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-26 09:00:00+00', '2026-11-09 20:29:57.604456+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('1c6b8373-bcb6-42ae-8b86-ad6397c6bf6c', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 'cf2b82ae-57b3-4c73-95fa-b0145e6d995f', 'equipment', 'Dell OptiPlex 7010', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 1.000, NULL, 'SN-100010', '2024-01-29', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-29", "warranty_until": "2027-01-28", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-29 09:00:00+00', '2026-11-09 20:30:01.061298+00', 'STM-Z4ZU', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('31cef3e2-6b3f-4cea-b6ed-8fd3cffcd664', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 1.000, NULL, 'SN-100000', '2026-09-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-25", "warranty_until": "2029-09-24", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-25 09:00:00+00', '2026-11-09 20:30:01.0613+00', 'STM-OY93', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e1c918ec-5b25-4818-a5cc-6d5f20bddf16', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Dell UltraSharp U2723QE', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '54327d88-3d1a-470b-889d-459f5efa89be', 1.000, NULL, 'SN-100023', '2026-08-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-25", "warranty_until": "2029-08-24", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-25 09:00:00+00', '2026-11-09 20:29:57.604456+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d7ea48e5-040d-490d-98bf-464ae6ffaf0a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'LG 27UK850-W', 'LG', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '6d40b416-5d46-4941-9081-e1dbd1eed786', 1.000, NULL, 'SN-100024', '2026-05-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-20", "warranty_until": "2029-05-19", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-20 09:00:00+00', '2026-11-09 20:29:57.604456+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('84135746-f479-4fdb-83d0-8aeea1e48f3c', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'LG 27UK850-W', 'LG', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '6d40b416-5d46-4941-9081-e1dbd1eed786', 1.000, NULL, 'SN-100025', '2026-02-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-12", "warranty_until": "2029-02-11", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-12 09:00:00+00', '2026-11-09 20:29:57.604457+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('92722a6f-84a6-4f15-a4ad-490c5281de17', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'LG 27UK850-W', 'LG', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '6d40b416-5d46-4941-9081-e1dbd1eed786', 1.000, NULL, 'SN-100026', '2025-11-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-07", "warranty_until": "2028-11-06", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-07 09:00:00+00', '2026-11-09 20:29:57.604457+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e2c336b3-2a37-48d2-9b42-41124eba8b82', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'LG 27UK850-W', 'LG', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '6d40b416-5d46-4941-9081-e1dbd1eed786', 1.000, NULL, 'SN-100027', '2025-08-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-02", "warranty_until": "2028-08-01", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-02 09:00:00+00', '2026-11-09 20:29:57.604458+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('55b58aad-3800-4b0a-abcd-ca28b4ad823e', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'LG 27UK850-W', 'LG', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '6d40b416-5d46-4941-9081-e1dbd1eed786', 1.000, NULL, 'SN-100028', '2025-04-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-27", "warranty_until": "2028-04-26", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-27 09:00:00+00', '2026-11-09 20:29:57.604458+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9b19623d-e563-438c-958d-a1eec11fd267', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 1.000, NULL, 'SN-100029', '2025-01-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-20", "warranty_until": "2028-01-20", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-20 09:00:00+00', '2026-11-09 20:29:57.604458+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('07761b98-e4d4-4e77-b078-c52f9656f039', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 1.000, NULL, 'SN-100030', '2024-10-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-15", "warranty_until": "2027-10-15", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-15 09:00:00+00', '2026-11-09 20:29:57.604459+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('4d5e0982-5d07-49c7-bcf3-d380b35f5345', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 1.000, NULL, 'SN-100031', '2024-07-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-10", "warranty_until": "2027-07-10", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-10 09:00:00+00', '2026-11-09 20:29:57.604459+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f8aa6bcb-17ff-4bfe-8f03-61778ceaf86a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', '3f6fa16a-9799-405c-9603-c256a30cee17', 'equipment', 'Samsung Odyssey G5', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 1.000, NULL, 'SN-100032', '2024-04-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-04", "warranty_until": "2027-04-04", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-04 09:00:00+00', '2026-11-09 20:29:57.604459+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5322a2c7-e466-4e95-bdb4-6c0261f5ef57', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '153e2c78-e030-4480-b56a-e0912b30632a', 1.000, NULL, 'SN-100033', '2023-12-29', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-29", "warranty_until": "2026-12-28", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-29 09:00:00+00', '2026-11-09 20:29:57.60446+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('a362692f-b98c-4242-bd1e-11a643b19c43', '00e8db4f-deff-45c2-82ee-95c459b73161', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '153e2c78-e030-4480-b56a-e0912b30632a', 1.000, NULL, 'SN-100035', '2026-06-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-22", "warranty_until": "2029-06-21", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-22 09:00:00+00', '2026-11-09 20:29:57.60446+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bf307f6c-4919-4497-8970-e4e55cc0d88a', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '153e2c78-e030-4480-b56a-e0912b30632a', 1.000, NULL, 'SN-100036', '2026-03-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-17", "warranty_until": "2029-03-16", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-17 09:00:00+00', '2026-11-09 20:29:57.604461+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6f502b40-a6ed-4098-ac5f-96e3f615af0b', '00e8db4f-deff-45c2-82ee-95c459b73161', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '153e2c78-e030-4480-b56a-e0912b30632a', 1.000, NULL, 'SN-100037', '2025-12-10', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-10", "warranty_until": "2028-12-09", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-10 09:00:00+00', '2026-11-09 20:29:57.604461+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('37f740b6-e4a3-43dc-b70d-2aea558cc3e4', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', 1.000, NULL, 'SN-100038', '2025-09-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-04", "warranty_until": "2028-09-03", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-04 09:00:00+00', '2026-11-09 20:29:57.604462+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('48241c33-1ae1-4823-903b-ad5a99364c18', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', 1.000, NULL, 'SN-100039', '2025-05-30', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-30", "warranty_until": "2028-05-29", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-30 09:00:00+00', '2026-11-09 20:29:57.604462+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('011d32dd-38a9-465f-9ba6-0fe342802bd0', '00e8db4f-deff-45c2-82ee-95c459b73161', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', 1.000, NULL, 'SN-100040', '2025-02-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-22", "warranty_until": "2028-02-22", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-22 09:00:00+00', '2026-11-09 20:29:57.604462+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('afa8df66-104b-4212-8a38-ea7a4d4b66c3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'Samsung Galaxy S24', 'Samsung', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', 1.000, NULL, 'SN-100041', '2024-11-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-17", "warranty_until": "2027-11-17", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-17 09:00:00+00', '2026-11-09 20:29:57.604463+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('386edf18-28e3-4599-8102-95e10f1b03e0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPad Air M2', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '610fdfe8-a330-4661-884e-3a0ee4127d92', 1.000, NULL, 'SN-100042', '2024-08-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-12", "warranty_until": "2027-08-12", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-12 09:00:00+00', '2026-11-09 20:29:57.604463+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d23dd38c-fbaf-468d-9f03-b005e82c0c57', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPad Air M2', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '610fdfe8-a330-4661-884e-3a0ee4127d92', 1.000, NULL, 'SN-100043', '2024-05-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-07", "warranty_until": "2027-05-07", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-07 09:00:00+00', '2026-11-09 20:29:57.604463+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e38df811-9a6d-4ff4-827e-e2496483b74e', '00e8db4f-deff-45c2-82ee-95c459b73161', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9025d321-5ecd-4d2b-939d-925f457f8b9e', 1.000, NULL, 'SN-100044', '2024-01-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-31", "warranty_until": "2027-01-30", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-31 09:00:00+00', '2026-11-09 20:29:57.604464+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('48465e17-0a15-4f8c-8dfa-cecdd9609e42', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 1.000, NULL, 'SN-100046', '2026-07-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-25", "warranty_until": "2029-07-24", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-25 09:00:00+00', '2026-11-09 20:29:57.604465+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9e0c155e-9d0f-4884-9ec3-ce8e4b14c519', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 1.000, NULL, 'SN-100047', '2026-04-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-19", "warranty_until": "2029-04-18", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-19 09:00:00+00', '2026-11-09 20:29:57.604465+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c31b5ec9-662f-45c4-83cc-586469efd1a3', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 1.000, NULL, 'SN-100048', '2026-01-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-12", "warranty_until": "2029-01-11", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-12 09:00:00+00', '2026-11-09 20:29:57.604465+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('087b5e83-5a7b-4c81-bffa-504fdbeeec54', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 1.000, NULL, 'SN-100049', '2025-10-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-07", "warranty_until": "2028-10-06", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-07 09:00:00+00', '2026-11-09 20:29:57.604466+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('087c7063-7b81-4f9b-8d30-d145dfb70ea7', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 1.000, NULL, 'SN-100050', '2025-07-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-02", "warranty_until": "2028-07-01", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-02 09:00:00+00', '2026-11-09 20:29:57.604466+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d49aa050-7a9b-4107-bf8d-d494ead846fd', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '8850e5a3-1986-4417-8a9f-f8f377957c3f', 1.000, NULL, 'SN-100051', '2025-03-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-27", "warranty_until": "2028-03-26", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-27 09:00:00+00', '2026-11-09 20:29:57.604466+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8d39ef1b-7999-449a-9bf2-2ae52b52c669', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '8850e5a3-1986-4417-8a9f-f8f377957c3f', 1.000, NULL, 'SN-100052', '2024-12-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-20", "warranty_until": "2027-12-20", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-20 09:00:00+00', '2026-11-09 20:29:57.604467+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c6746b2c-291d-46d0-82d1-3ae742828b7c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'TP-Link TL-SG3428', 'TP-Link', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '8850e5a3-1986-4417-8a9f-f8f377957c3f', 1.000, NULL, 'SN-100053', '2024-09-14', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-14", "warranty_until": "2027-09-14", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-14 09:00:00+00', '2026-11-09 20:29:57.604467+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e295992c-ea14-49e2-8aab-fed22d0655e0', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '217182bd-b208-424f-84c6-347898691e06', 1.000, NULL, 'SN-100054', '2024-06-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-09", "warranty_until": "2027-06-09", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-09 09:00:00+00', '2026-11-09 20:29:57.604467+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ebcb5606-40fd-4e50-aaab-7b9489cbd63c', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '217182bd-b208-424f-84c6-347898691e06', 1.000, NULL, 'SN-100055', '2024-03-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-04", "warranty_until": "2027-03-04", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-04 09:00:00+00', '2026-11-09 20:29:57.604468+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e18b612e-4f45-4e32-8ef7-e84b39af20be', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '217182bd-b208-424f-84c6-347898691e06', 1.000, NULL, 'SN-100056', '2023-11-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-28", "warranty_until": "2026-11-27", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-28 09:00:00+00', '2026-11-09 20:29:57.604468+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b45426c0-1f04-4ae4-9f35-bad0fa55e3ff', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '217182bd-b208-424f-84c6-347898691e06', 1.000, NULL, 'SN-100057', '2026-08-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-27", "warranty_until": "2029-08-26", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-27 09:00:00+00', '2026-11-09 20:29:57.604469+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ae2a6b53-eb54-4cac-86ad-df0144f376b2', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech MX Keys S', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'aa9e1eee-bcc1-4228-a898-3ebdb3f79732', 1.000, NULL, 'SN-100059', '2026-02-14', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-14", "warranty_until": "2029-02-13", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-14 09:00:00+00', '2026-11-09 20:29:57.604469+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5b552402-defb-4593-9817-ee940cf697db', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', 1.000, NULL, 'SN-100060', '2025-11-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-09", "warranty_until": "2028-11-08", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-09 09:00:00+00', '2026-11-09 20:29:57.60447+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('347c13ff-7d94-4a53-80ac-7b964e3be112', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', 1.000, NULL, 'SN-100061', '2025-08-04', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-04", "warranty_until": "2028-08-03", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-04 09:00:00+00', '2026-11-09 20:29:57.60447+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('eeed5c38-4c33-4027-b0fe-f243a74bd2ea', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech MX Master 3S', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', 1.000, NULL, 'SN-100062', '2025-04-29', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-29", "warranty_until": "2028-04-28", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-29 09:00:00+00', '2026-11-09 20:29:57.60447+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('34d02e01-2972-4ce2-addd-81a8ac11e8b8', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', 1.000, NULL, 'SN-100063', '2025-01-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-22", "warranty_until": "2028-01-22", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-22 09:00:00+00', '2026-11-09 20:29:57.604471+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('45917e2c-7746-4525-8c04-7abe599b6516', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', 1.000, NULL, 'SN-100064', '2024-10-17', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-17", "warranty_until": "2027-10-17", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-17 09:00:00+00', '2026-11-09 20:29:57.604471+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('2a03dd5b-1578-4e3f-a40e-263dc8221630', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Logitech C920 HD Pro', 'Logitech', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', 1.000, NULL, 'SN-100065', '2024-07-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-12", "warranty_until": "2027-07-12", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-12 09:00:00+00', '2026-11-09 20:29:57.604471+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('e71c43d3-78b3-4b88-9753-9592a50b8018', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', '515c8965-f761-41ab-8245-794bbee21ae8', 'equipment', 'Jabra Evolve2 65', 'Jabra', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'f95dddbd-0591-4827-b835-615fcddeb437', 1.000, NULL, 'SN-100066', '2024-04-06', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-06", "warranty_until": "2027-04-06", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-06 09:00:00+00', '2026-11-09 20:29:57.604472+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('aed95fa2-cc7d-413f-a427-fd0c8c237974', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ca19ba2-326d-4463-8779-d52cac2c2dad', 1.000, NULL, 'SN-100069', '2026-06-24', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-24", "warranty_until": "2029-06-23", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-24 09:00:00+00', '2026-11-09 20:29:57.604473+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5fbc74f1-7785-40e0-aa0b-81138e457d79', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9415af05-c7ea-4044-a47c-73918712aca5', 1.000, NULL, 'SN-100068', '2023-09-25', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-09-25", "warranty_until": "2026-09-24", "equipment_status": "AVAILABLE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2023-09-25 09:00:00+00', '2026-11-09 20:30:01.0613+00', 'STM-RTAJ', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c0be7cca-7cd4-4b44-a7ee-953e2261c9ae', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ca19ba2-326d-4463-8779-d52cac2c2dad', 1.000, NULL, 'SN-100070', '2026-03-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-19", "warranty_until": "2029-03-18", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-19 09:00:00+00', '2026-11-09 20:29:57.604473+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8ed4a10a-7a2b-4393-9ad2-1706e99e2bec', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ca19ba2-326d-4463-8779-d52cac2c2dad', 1.000, NULL, 'SN-100071', '2025-12-12', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-12", "warranty_until": "2028-12-11", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-12 09:00:00+00', '2026-11-09 20:29:57.604473+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('78d9e7b3-980a-4ae2-a8cb-f6980183282f', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4ca19ba2-326d-4463-8779-d52cac2c2dad', 1.000, NULL, 'SN-100072', '2025-09-06', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-06", "warranty_until": "2028-09-05", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-06 09:00:00+00', '2026-11-09 20:29:57.604474+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('318e127f-c854-457b-bc88-feda72c18dff', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', 1.000, NULL, 'SN-100073', '2025-06-01', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-01", "warranty_until": "2028-05-31", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-01 09:00:00+00', '2026-11-09 20:29:57.604474+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bd0741bd-810e-41cd-ad45-7762c91d2fd4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'Supermicro SYS-1029U', 'Supermicro', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', 1.000, NULL, 'SN-100074', '2025-02-24', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-24", "warranty_until": "2028-02-24", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-24 09:00:00+00', '2026-11-09 20:29:57.604475+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('52b58422-6b52-4161-98d0-6009b4db1fd2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '420a7571-bdc7-46b5-8a94-a7a87845194f', 1.000, NULL, 'SN-100076', '2024-08-14', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-14", "warranty_until": "2027-08-14", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-14 09:00:00+00', '2026-11-09 20:29:57.604476+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('022f59c5-a682-462c-b57a-34b217de93fe', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '1a98a752-a9d5-405b-8811-3539b8170bea', 1.000, NULL, 'SN-100077', '2024-05-09', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-09", "warranty_until": "2027-05-09", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-09 09:00:00+00', '2026-11-09 20:29:57.604476+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('db8410d0-7156-4270-8d8b-51dd33d6d007', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c2c2653b-c961-4e10-93e6-665780ad0903', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '1a98a752-a9d5-405b-8811-3539b8170bea', 1.000, NULL, 'SN-100078', '2024-02-02', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-02", "warranty_until": "2027-02-01", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-02 09:00:00+00', '2026-11-09 20:29:57.604476+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('8bd7506a-d7c8-4743-bad6-4265987d9529', '00e8db4f-deff-45c2-82ee-95c459b73161', '66eea498-a873-404c-9657-e5c94d678571', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '1a98a752-a9d5-405b-8811-3539b8170bea', 1.000, NULL, 'SN-100079', '2023-10-28', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-28", "warranty_until": "2026-10-27", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-28 09:00:00+00', '2026-11-09 20:29:57.604477+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6923a9ed-5b2b-4c80-b3cd-0fce93df9fda', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '1a98a752-a9d5-405b-8811-3539b8170bea', 1.000, NULL, 'SN-100080', '2026-07-27', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-27", "warranty_until": "2029-07-26", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-27 09:00:00+00', '2026-11-09 20:29:57.604477+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6948263c-e76b-4cb4-a785-690378e874bd', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'Rack 42U Open Frame', 'Rittal', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '1a98a752-a9d5-405b-8811-3539b8170bea', 1.000, NULL, 'SN-100081', '2026-04-21', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-21", "warranty_until": "2029-04-20", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-21 09:00:00+00', '2026-11-09 20:29:57.604478+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('41043f6d-7863-49f4-ba89-f7c702978b9d', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 3.000, NULL, NULL, '2026-11-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-07", "warranty_until": "2029-11-06", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-07 14:00:00+00', '2026-11-09 20:29:58.769315+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('dd07e024-7797-4e3e-b6da-85394471f19d', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 'Natural Yoghurt 400g', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', 18.000, NULL, NULL, '2026-10-31', NULL, NULL, NULL, '{}', 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-10-31 10:50:00+00', '2026-11-09 20:29:59.706702+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('54f7f8f8-d787-4656-85a2-7c59662d2c4c', '00e8db4f-deff-45c2-82ee-95c459b73161', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '0389990b-d447-4ecd-ba0b-b4df565eee4e', NULL, 'Gouda Cheese', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 50.000, NULL, NULL, '2026-11-02', NULL, NULL, NULL, '{}', 12.50, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 14:00:00+00', '2026-11-09 20:29:59.81429+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b6de84b0-c6ba-42d5-a875-e02d21715da3', '00e8db4f-deff-45c2-82ee-95c459b73161', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, NULL, 'Sour Cream 18%', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'fa748810-6265-493f-a360-df817a409794', 15.000, NULL, NULL, '2026-11-02', NULL, NULL, NULL, '{}', 4.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-02 14:00:00+00', '2026-11-09 20:29:59.826603+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('bd563cb7-7dcc-479a-bbcc-cbe4d076d631', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 1.000, NULL, 'SN-100003', '2025-12-08', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-08", "warranty_until": "2028-12-07", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-08 09:00:00+00', '2026-11-09 20:30:00.207023+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c1acf8bf-cf81-4a80-ae41-08d61a574810', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 1.000, NULL, 'SN-100002', '2026-03-15', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-15", "warranty_until": "2029-03-14", "equipment_status": "DEPLOYED"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-15 09:00:00+00', '2026-11-09 20:30:00.207024+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('f209851d-1c68-4b70-938b-d2103b646e6f', '00e8db4f-deff-45c2-82ee-95c459b73161', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 1.000, NULL, 'SN-100001', '2026-06-20', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-20", "warranty_until": "2029-06-19", "equipment_status": "DEPLOYED"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-20 09:00:00+00', '2026-11-09 20:30:00.207025+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('c82a3e23-85db-4275-b655-c89edaf839a5', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 'Damson Plums', 'Green Acre', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', 13.600, NULL, NULL, '2026-11-06', NULL, NULL, NULL, NULL, 3.40, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.643671+00', '2026-11-09 20:30:00.368392+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('ab2f3769-1eab-45fa-8139-325918662b24', '00e8db4f-deff-45c2-82ee-95c459b73161', '85b351d5-711b-47d4-b174-83619236e876', NULL, NULL, 'White Sugar', 'Harvest Row', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 'a7907bfa-51a5-4121-8ad2-91864a33b272', 21.220, NULL, NULL, '2026-10-20', NULL, NULL, NULL, NULL, 1.10, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.643675+00', '2026-11-09 20:30:00.401244+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('017b7fd5-a2f5-4460-b1a8-14693d388e98', '00e8db4f-deff-45c2-82ee-95c459b73161', '85b351d5-711b-47d4-b174-83619236e876', NULL, NULL, 'Cassia Cinnamon', 'Saltmill', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', 0.440, NULL, NULL, '2026-10-06', NULL, NULL, NULL, NULL, 24.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:29:57.643675+00', '2026-11-09 20:30:00.419914+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('6674708c-ee7f-4a72-a8cd-c54966f2dcfc', '00e8db4f-deff-45c2-82ee-95c459b73161', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 'da084db8-fc4d-4799-8cd8-fe81280cd0e9', 'equipment', 'Dell PowerEdge R750', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9415af05-c7ea-4044-a47c-73918712aca5', 1.000, NULL, 'SN-100067', '2023-12-31', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-31", "warranty_until": "2026-12-30", "equipment_status": "MAINTENANCE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-31 09:00:00+00', '2026-11-09 20:30:00.551205+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9560ba1a-aac2-40a8-bdec-31ed002aac92', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b94369de-1676-42e5-998c-4be2391acbf9', '1319ddf0-e069-4343-b832-2889b3322ec8', 'equipment', 'iPhone 15 Pro', 'Apple', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '153e2c78-e030-4480-b56a-e0912b30632a', 1.000, NULL, 'SN-100034', '2023-09-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-09-23", "warranty_until": "2026-09-22", "equipment_status": "DEPLOYED"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2023-09-23 09:00:00+00', '2026-11-09 20:30:01.024714+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3069036f-d8a3-44b6-9d81-5704d6d2c6b3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '3a3630fb-a3eb-4b5f-bb29-c21ebb54e8c7', 'equipment', 'APC Smart-UPS 3000VA', 'APC', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '420a7571-bdc7-46b5-8a94-a7a87845194f', 1.000, NULL, 'SN-100075', '2024-11-19', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-11-19", "warranty_until": "2027-11-19", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2024-11-19 09:00:00+00', '2026-11-09 20:30:01.061299+00', 'STM-CC0G', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('3b90be3f-1690-4596-a418-a37bd71e01c4', '00e8db4f-deff-45c2-82ee-95c459b73161', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Catalyst 9200L', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '9025d321-5ecd-4d2b-939d-925f457f8b9e', 1.000, NULL, 'SN-100045', '2023-10-26', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-26", "warranty_until": "2026-10-25", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-26 09:00:00+00', '2026-11-09 20:30:01.0613+00', 'STM-VUD1', NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('5530d507-8782-45c5-bf59-4fa3e85eeb6a', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'Dell Latitude 5540', 'Dell', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 5.000, NULL, NULL, '2026-11-07', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-11-07", "warranty_until": "2029-11-06", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-11-07 14:00:00+00', '2026-11-09 20:29:58.769319+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('901a2389-0145-4457-90b7-d2b61cbc3abe', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, NULL, 'UHT Milk 3.2%', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', 36.000, NULL, NULL, '2026-10-31', NULL, NULL, NULL, '{}', 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-10-31 10:50:00+00', '2026-11-09 20:29:58.8158+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('b73207ab-580c-4077-b1f7-13b94a855ed2', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', '7fccadf3-255b-49ce-99be-4073275efcec', NULL, 'Butter Extra 82%', 'Meadowlane', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '80b42f49-4cde-42be-bb81-b4631caefbd5', 24.000, NULL, NULL, '2026-10-31', NULL, NULL, NULL, '{}', 8.90, 'USD', false, false, NULL, NULL, NULL, '2026-10-31 10:50:00+00', '2026-11-09 20:29:59.728522+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('18d0f606-78b4-476f-8761-6e710672c3f3', '00e8db4f-deff-45c2-82ee-95c459b73161', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '51f7e51a-6382-4973-99a9-5f9353991362', 'equipment', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 3.000, NULL, NULL, '2026-10-23', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-10-23", "warranty_until": "2029-10-22", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 12:15:00+00', '2026-11-09 20:30:00.125617+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('d77771f8-a4d2-44da-bb70-e63cad25da78', '00e8db4f-deff-45c2-82ee-95c459b73161', '85b351d5-711b-47d4-b174-83619236e876', NULL, NULL, 'Plum Butter', NULL, NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', '42fb5efc-9a73-4801-989a-0182576ad930', 11.400, NULL, NULL, '2026-11-09', NULL, NULL, NULL, '{}', 8.36, 'USD', false, false, NULL, NULL, NULL, '2026-11-09 20:30:00.443316+00', '2026-11-09 20:30:00.443318+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, module_name, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, lot_id, owner_id, source_document_id) VALUES ('9985b1fe-f85b-4d99-a355-1119714698cf', '00e8db4f-deff-45c2-82ee-95c459b73161', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 'f20e22f8-b5db-4ae9-926a-481f3388ddc6', 'equipment', 'Cisco Meraki MR46', 'Cisco', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', '217182bd-b208-424f-84c6-347898691e06', 1.000, NULL, 'SN-100058', '2026-05-22', NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-22", "warranty_until": "2029-05-21", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-22 09:00:00+00', '2026-11-09 20:30:01.061301+00', 'STM-ODRH', NULL, NULL, NULL, NULL);


--
-- Data for Name: label_pool; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('87fe67f1-d75e-486c-92c2-9853b6544350', 'STM-CC0G', true, '2026-10-29 20:30:01.060207+00', '3069036f-d8a3-44b6-9d81-5704d6d2c6b3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('d23a413f-aefd-4d6b-b2d5-72b5e2579eaa', 'STM-VUD1', true, '2026-10-29 20:30:01.060207+00', '3b90be3f-1690-4596-a418-a37bd71e01c4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('a96f223b-9c0e-4bd7-b627-d0cd1ad2053f', 'STM-ODRH', true, '2026-10-29 20:30:01.060207+00', '9985b1fe-f85b-4d99-a355-1119714698cf', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('c7de529b-2a53-4dae-90c7-327427a38eb9', 'STM-OY93', true, '2026-10-29 20:30:01.060207+00', '31cef3e2-6b3f-4cea-b6ed-8fd3cffcd664', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('0917b55b-c08f-40ba-8903-995f5611a9e5', 'STM-Z4ZU', true, '2026-10-29 20:30:01.060207+00', '1c6b8373-bcb6-42ae-8b86-ad6397c6bf6c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('8de856b5-49a3-4523-9494-f326b6611391', 'STM-RTAJ', true, '2026-10-29 20:30:01.060207+00', '5fbc74f1-7785-40e0-aa0b-81138e457d79', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('7444ac78-3285-4185-ac87-d964e30437a5', 'STM-NS4S', false, NULL, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('17e4fd12-5fd5-4a75-aff9-205f73a0947f', 'STM-W790', false, NULL, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('9f87efe9-2376-45d9-93fa-660cd9acbf7d', 'STM-JQYB', false, NULL, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('e9068661-6484-44e4-b418-b2d28f1f8b66', 'STM-MSJV', false, NULL, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('442fe950-6968-42f5-a42d-d0aaf1b20e8e', 'STM-VG03', false, NULL, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('b8e79516-2e14-4fd5-ac94-b7c47979546a', 'STM-UKIW', false, NULL, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'GENERIC', NULL, NULL, NULL, '2026-10-28 20:30:01.060207+00', '2026-10-28 20:30:01.060207+00', 0, NULL);


--
-- Data for Name: location_relocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_bom_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('fb8cc21e-2b73-410d-8ff4-256cdc5df8d5', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', 'kg', 10.00, 'stone fruit', '2026-11-09 20:29:57.416688+00', '2026-11-09 20:29:57.416691+00', 'bc3c10ec-bf13-4118-83ec-d2763d85203a', 2.0000, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817');
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('ae971e7d-d8e8-4603-a99a-01e8a5ad9917', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', 'a7907bfa-51a5-4121-8ad2-91864a33b272', 'kg', 5.00, 'sweetener', '2026-11-09 20:29:57.416693+00', '2026-11-09 20:29:57.416693+00', 'bc3c10ec-bf13-4118-83ec-d2763d85203a', 0.3000, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817');
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('f046ac3e-1807-4ca9-ab00-07bc5d37cf38', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', 'kg', 0.00, 'spice', '2026-11-09 20:29:57.416694+00', '2026-11-09 20:29:57.416695+00', 'bc3c10ec-bf13-4118-83ec-d2763d85203a', 0.0050, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817');


--
-- Data for Name: maker_module_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_module_settings (organization_id, reference_direction, created_at, updated_at, allow_overproduction, availability_check_scope, create_on_shortage_strategy) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'MARGIN', '2026-11-09 20:30:00.262382+00', '2026-11-09 20:30:00.262385+00', true, 'GLOBAL', 'WARN');


--
-- Data for Name: maker_production_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('414833eb-7c71-406b-a460-98398be2ab6d', '21ff6bdb-dd23-46c5-bab5-80df73db583b', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', 26.4000, 'kg', '4862b4f7-228f-43d4-b329-37de5b1813bf', 3.4000, 'fifo', NULL);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('54cea544-a799-438b-becf-236b37095f8c', '21ff6bdb-dd23-46c5-bab5-80df73db583b', 'a7907bfa-51a5-4121-8ad2-91864a33b272', 3.7800, 'kg', '85b351d5-711b-47d4-b174-83619236e876', 1.1000, 'fifo', NULL);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('d168b626-c93d-4b94-aa61-99e5fcc1a268', '21ff6bdb-dd23-46c5-bab5-80df73db583b', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', 0.0600, 'kg', '85b351d5-711b-47d4-b174-83619236e876', 24.0000, 'fifo', NULL);


--
-- Data for Name: maker_production_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_orders (id, organization_id, output_template_id, planned_qty, output_storage_location_id, status, total_cost, production_date, notes, created_by, completed_by, created_at, completed_at, cancel_reason, produced_item_id, recipe_id, actual_qty, overproduced, scrap_qty, unit_cost_snapshot, reference_price_snapshot, result_per_unit, result_per_batch, number, short_at_create) VALUES ('21ff6bdb-dd23-46c5-bab5-80df73db583b', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', 12.000, '85b351d5-711b-47d4-b174-83619236e876', 'COMPLETED', 95.36, '2026-11-09', 'Autumn batch, first of the season.', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.307975+00', '2026-11-09 20:30:00.455784+00', NULL, 'd77771f8-a4d2-44da-bb70-e63cad25da78', 'bc3c10ec-bf13-4118-83ec-d2763d85203a', 11.400, false, 0.600, 8.3647, 18.00, 9.64, 9.64, 'PR/2026/0001', false);


--
-- Data for Name: maker_recipe_cost_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_recipes (id, organization_id, output_template_id, name, batch_yield_qty, batch_yield_uom_id, process_steps, reference_price, is_default, source_recipe_id, source_snapshot_at, created_at, updated_at) VALUES ('bc3c10ec-bf13-4118-83ec-d2763d85203a', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', 'Plum Butter', 1.0000, NULL, NULL, 18.00, true, NULL, NULL, '2026-11-09 20:29:57.40567+00', '2026-11-09 20:29:57.405672+00');


--
-- Data for Name: meal_plan_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('9fd5a8b8-812f-4dda-816b-fac3e1cb5306', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-09', 'BREAKFAST', '91ba51d7-1965-48c4-b13c-fd03037d3d64', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('66f440b1-2433-4a81-ba43-810303642531', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-09', 'DINNER', 'aad70a26-5044-45c1-8baa-a540ce1df5b6', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('457a129d-58a4-4f9d-b6fe-0c1a4a8facd3', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-10', 'DINNER', 'c699bb02-2134-4881-be65-3ae1cd1ba45d', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('d8116793-e76a-4d9d-a62e-6dd952bf0743', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-11', 'BREAKFAST', '91ba51d7-1965-48c4-b13c-fd03037d3d64', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('25377b99-3560-4cc2-a0b6-10bba32ca4fd', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-11', 'DINNER', '7ac44cc1-5492-4eb9-a14a-89191b1bc896', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('ccba83d9-4b58-4ba3-8621-81a3ed5417ad', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-12', 'DINNER', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('f2ddff7e-0d65-4acd-9f1b-bab1a49860ea', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-13', 'DINNER', 'aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('3279c71d-64a2-46c2-9989-3dffbe9c1c18', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-14', 'BREAKFAST', 'ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('e6a0a6c3-c29d-46a1-8433-e5c7dc656898', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-14', 'DINNER', '5cd1f034-5031-49a4-8139-5f3497e91d9c', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('20c06c37-113f-4fec-87aa-73bc063c871b', '7adce4c2-4df6-4a19-8352-50dda6cf98cf', '2026-11-15', 'BREAKFAST', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', NULL, NULL, 0);


--
-- Data for Name: meal_plans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plans (id, organization_id, name, start_date, end_date, enabled_slots, default_servings, shopping_list_id, notes, created_by, created_at, updated_at, listed_meals) VALUES ('7adce4c2-4df6-4a19-8352-50dda6cf98cf', '00e8db4f-deff-45c2-82ee-95c459b73161', 'This week', '2026-11-09', '2026-11-15', '["BREAKFAST", "DINNER"]', NULL, '8b08458b-920d-49fb-afb9-92544ed13579', NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.527815+00', '2026-11-09 20:30:00.527817+00', NULL);


--
-- Data for Name: module_installations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.organizations (id, name, created_at, created_by, enabled_modules, allowed_modules, settings, short_id, active_profile_id, onboarding_completed, focus_module, pre_focus_enabled_modules, pre_onboarding_manual_modules, currency, timezone, tax_id, country, print_page_size, address, logo_url) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'Larkspur Trading Co.', '2026-11-09 20:29:56.953319+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '["approvals", "recipes", "stats", "partners", "stock_takes", "purchase_orders", "categories", "warehouse", "shopping_lists", "maker", "core", "printing", "items", "announcements", "locations", "equipment", "nutrition"]', NULL, '{"module:equipment": {"warranty_warning_days": 60, "maintenance_warning_days": 14, "__schema_version": 1}, "module:stats": {"enable_analytics": true, "show_inventory_value": true, "__schema_version": 1}, "show_module_data": true, "module:approvals": {"allow_admin_self_approve": true}, "demo_last_reset_at": "2026-11-09T20:30:01.270204+00:00"}', NULL, 'equipment_wms', true, NULL, NULL, NULL, 'USD', 'UTC', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('31869dee-d35c-401e-9a57-a5a63c1f75d3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Eurodata Systems', 'SUP-001', 'SUPPLIER', NULL, false, 'orders@eurodata.example.com', '+44 20 7946 0101', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424649+00', '2026-11-09 20:29:57.424652+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('a89fd506-ce44-426f-a6aa-afe3d0bb336a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Northgate IT Distribution', 'ITD-002', 'SUPPLIER', NULL, false, 'sales@northgate-it.example.com', '+44 20 7946 0102', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424653+00', '2026-11-09 20:29:57.424653+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('d70fbd13-1c81-454e-8ac8-327031a0e0a9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'TechSupply Europe', 'TSE-003', 'SUPPLIER', NULL, false, 'orders@techsupply.example.net', '+44 20 7946 0103', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424654+00', '2026-11-09 20:29:57.424654+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('d5624d47-95f8-4614-b1fd-b54126a2d6f7', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Freshfield Wholesale', 'FFD-004', 'SUPPLIER', NULL, false, 'orders@freshfield.example.com', '+44 20 7946 0104', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424655+00', '2026-11-09 20:29:57.424655+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('7196aff0-d168-40d4-96c3-d48935de578a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Bulkline Cash & Carry', 'MCC-005', 'SUPPLIER', NULL, false, 'b2b@bulkline.example.com', '+44 20 7946 0105', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424655+00', '2026-11-09 20:29:57.424655+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('a31e40b8-b52f-432b-9e5c-a5f6280ca34c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cornerstore Deliveries', 'ZAB-006', 'SUPPLIER', NULL, false, 'deliveries@cornerstore.example.com', '+44 20 7946 0106', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424656+00', '2026-11-09 20:29:57.424656+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('19fd7922-0a92-447f-97fa-cbab7a413ac2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cisco Systems', 'CSC-007', 'MANUFACTURER', NULL, false, 'enterprise@cisco.example.com', '+44 20 7946 0107', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424656+00', '2026-11-09 20:29:57.424657+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('aeee3728-a7fb-4f0f-b01d-dc3a4cbbd71f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dell Technologies', 'DLL-008', 'MANUFACTURER', NULL, false, 'enterprise@dell.example.com', '+44 20 7946 0108', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424657+00', '2026-11-09 20:29:57.424657+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('87d40306-abf2-4cbe-b5c8-eea2fb4bf50c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Hewlett Packard Enterprise', 'HPE-009', 'MANUFACTURER', NULL, false, 'sales@hpe.example.com', '+44 20 7946 0109', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424658+00', '2026-11-09 20:29:57.424658+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('4a2c8aec-0187-4afb-8ff7-191672c028d2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Apple', 'APL-010', 'MANUFACTURER', NULL, false, 'business@apple.example.com', '+44 20 7946 0110', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424659+00', '2026-11-09 20:29:57.424659+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('674cf125-faba-4efc-bbff-8a9bd0ce70e5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Harper Catering', 'CUS-011', 'CUSTOMER', NULL, false, 'orders@harpercatering.example.com', '+44 20 7946 0111', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.424659+00', '2026-11-09 20:29:57.42466+00');
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, is_consumer, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at) VALUES ('4b90b049-ab0c-484c-94cf-516153c7b811', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Officeworks Services', 'CUS-012', 'CUSTOMER', NULL, false, 'office@officeworks.example.net', '+44 20 7946 0112', NULL, NULL, NULL, NULL, true, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:29:57.42466+00', '2026-11-09 20:29:57.42466+00');


--
-- Data for Name: picking_session_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: picking_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: po_partner_pricelist; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('08dbd5c6-96bc-47c9-a40a-3de7649da0b5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd5624d47-95f8-4614-b1fd-b54126a2d6f7', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', 3.2000, 'USD', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', NULL, '2026-09-10', NULL, NULL, '2026-11-09 20:30:01.096146+00', '2026-11-09 20:30:01.096148+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('dd2b732d-893f-47be-84b9-254acb5d3cf0', '00e8db4f-deff-45c2-82ee-95c459b73161', '7196aff0-d168-40d4-96c3-d48935de578a', 'a7907bfa-51a5-4121-8ad2-91864a33b272', 1.0500, 'USD', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', NULL, '2026-09-10', NULL, NULL, '2026-11-09 20:30:01.096149+00', '2026-11-09 20:30:01.096149+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('841c0970-2a8e-48a8-b61d-fbd65cfb01ea', '00e8db4f-deff-45c2-82ee-95c459b73161', '7196aff0-d168-40d4-96c3-d48935de578a', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', 22.5000, 'USD', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', NULL, '2026-09-10', NULL, NULL, '2026-11-09 20:30:01.096149+00', '2026-11-09 20:30:01.09615+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('98e3642a-d588-460e-88a5-5f1a98b40a02', '00e8db4f-deff-45c2-82ee-95c459b73161', '31869dee-d35c-401e-9a57-a5a63c1f75d3', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 4100.0000, 'USD', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, '2026-09-10', NULL, NULL, '2026-11-09 20:30:01.09615+00', '2026-11-09 20:30:01.09615+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('2db7ad54-7b46-4db4-a41e-0effda0500d8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a89fd506-ce44-426f-a6aa-afe3d0bb336a', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 4180.0000, 'USD', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, '2026-09-10', NULL, NULL, '2026-11-09 20:30:01.096151+00', '2026-11-09 20:30:01.096151+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('55c7b848-b42f-4310-b5c5-77ed68561509', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a89fd506-ce44-426f-a6aa-afe3d0bb336a', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 5650.0000, 'USD', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, '2026-09-10', NULL, NULL, '2026-11-09 20:30:01.096151+00', '2026-11-09 20:30:01.096152+00');


--
-- Data for Name: po_reorder_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('7073b478-28d3-4d82-aa0e-c10ccba559ad', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', '4862b4f7-228f-43d4-b329-37de5b1813bf', 20.000, 40.000, 10.000, 'd5624d47-95f8-4614-b1fd-b54126a2d6f7', NULL, '2026-11-09 20:30:01.085929+00', '2026-11-09 20:30:01.085932+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('468c8795-9d98-4fc0-9afb-58bdf9b92e31', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', '85b351d5-711b-47d4-b174-83619236e876', 5.000, 25.000, 2.000, '7196aff0-d168-40d4-96c3-d48935de578a', NULL, '2026-11-09 20:30:01.085933+00', '2026-11-09 20:30:01.085933+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('8b21cb56-10b3-40e9-8fc7-6afdc475f36a', '00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', '85b351d5-711b-47d4-b174-83619236e876', 0.100, 0.500, 0.100, '7196aff0-d168-40d4-96c3-d48935de578a', NULL, '2026-11-09 20:30:01.085933+00', '2026-11-09 20:30:01.085934+00');


--
-- Data for Name: po_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_settings (id, organization_id, approval_threshold, approval_required, created_at, updated_at) VALUES ('cf3d38d8-46df-49af-bfca-79a7bbbac83f', '00e8db4f-deff-45c2-82ee-95c459b73161', 10000.00, false, '2026-11-09 20:30:01.008855+00', '2026-11-09 20:30:01.008858+00');


--
-- Data for Name: print_agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: print_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8286bc5b-c3f3-4270-a38c-a753f5b8531b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.2, "carbs_g": 4.8, "protein_g": 3.2, "calories_kcal": 62}}', '2026-11-09 20:29:57.381615+00', '2026-11-09 20:29:57.381619+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 7.5, "protein_g": 4.0, "calories_kcal": 67}}', '2026-11-09 20:29:57.38162+00', '2026-11-09 20:29:57.38162+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('80b42f49-4cde-42be-bb81-b4631caefbd5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Butter Extra 82%', 'Meadowlane', '2000000000039', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 200.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 82.0, "carbs_g": 0.8, "protein_g": 0.5, "calories_kcal": 748}}', '2026-11-09 20:29:57.381621+00', '2026-11-09 20:29:57.381621+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('aeb331f9-551a-4794-801b-9d2fa6576ea8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Gouda Cheese', 'Meadowlane', '2000000000046', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 300.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 1.3, "protein_g": 24.0, "calories_kcal": 356}}', '2026-11-09 20:29:57.381621+00', '2026-11-09 20:29:57.381622+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fa748810-6265-493f-a360-df817a409794', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Sour Cream 18%', 'Meadowlane', '2000000000053', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 300.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 18.0, "carbs_g": 3.4, "protein_g": 2.5, "calories_kcal": 182}}', '2026-11-09 20:29:57.381622+00', '2026-11-09 20:29:57.381622+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('beb604b5-970d-4898-a6fd-319fca3f44fb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cottage Cheese', 'Meadowlane', '2000000000060', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 200.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 5.0, "protein_g": 9.0, "calories_kcal": 125}}', '2026-11-09 20:29:57.381623+00', '2026-11-09 20:29:57.381623+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0809a309-300c-4839-b4b8-d9cc6dfc2d3c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Lean Quark', 'Meadowlane', '2000000000077', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 250.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 3.5, "protein_g": 18.0, "calories_kcal": 85}}', '2026-11-09 20:29:57.381623+00', '2026-11-09 20:29:57.381624+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('3d1b782b-9970-4eb8-aca8-c36ac62e204e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Eggs Medium 10pk', 'Fellbrook Farms', '2000000000084', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 600.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 1.1, "protein_g": 13.0, "calories_kcal": 155}}', '2026-11-09 20:29:57.381624+00', '2026-11-09 20:29:57.381625+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7bd9b9c7-1d9a-447b-87eb-8669d6c5d4cf', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Chicken Ham', 'Fellbrook Farms', '2000000000091', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 4.5, "carbs_g": 1.0, "protein_g": 16.0, "calories_kcal": 110}}', '2026-11-09 20:29:57.381625+00', '2026-11-09 20:29:57.381625+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('30508eb8-e747-4099-b689-e4bb5ecb72d1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Pork Frankfurters', 'Fellbrook Farms', '2000000000107', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 22.0, "carbs_g": 2.0, "protein_g": 12.0, "calories_kcal": 253}}', '2026-11-09 20:29:57.381625+00', '2026-11-09 20:29:57.381626+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1b2d2248-37a0-423d-90bc-de53376d875e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Smoked Sausage', 'Fellbrook Farms', '2000000000114', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 27.0, "carbs_g": 3.0, "protein_g": 12.0, "calories_kcal": 301}}', '2026-11-09 20:29:57.381626+00', '2026-11-09 20:29:57.381626+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('342da948-8958-46c6-bc7b-d18965b7e227', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Smoked Bacon', 'Fellbrook Farms', '2000000000121', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 38.0, "carbs_g": 1.0, "protein_g": 12.0, "calories_kcal": 393}}', '2026-11-09 20:29:57.381627+00', '2026-11-09 20:29:57.381627+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('cab52259-e9cc-4641-9617-8a9188b49e20', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Chicken Breast Fillet', 'Fellbrook Farms', '2000000000138', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 600.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.2, "carbs_g": 0.0, "protein_g": 23.0, "calories_kcal": 110}}', '2026-11-09 20:29:57.381627+00', '2026-11-09 20:29:57.381628+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b60b93d0-b081-409f-a1df-80afe614f544', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Smoked Salmon', 'Bluewater', '2000000000145', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 150.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 13.0, "carbs_g": 0.0, "protein_g": 20.0, "calories_kcal": 196}}', '2026-11-09 20:29:57.381628+00', '2026-11-09 20:29:57.381628+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0d0c149b-9aa5-4f28-9f87-911b04b11df4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Mayonnaise', 'Harvest Row', '2000000000152', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 300.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 79.0, "carbs_g": 1.0, "protein_g": 1.0, "calories_kcal": 714}}', '2026-11-09 20:29:57.381629+00', '2026-11-09 20:29:57.381629+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4dd93e53-5ef7-4aba-ad5d-f3ee76fe41a1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tomato Ketchup', 'Harvest Row', '2000000000169', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 26.0, "protein_g": 1.0, "calories_kcal": 112}}', '2026-11-09 20:29:57.381629+00', '2026-11-09 20:29:57.381629+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6e1acfb0-89c6-47f3-89e9-5817114a77fe', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Orange Juice NFC', 'Orchard & Oak', '2000000000176', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.7, "calories_kcal": 45}}', '2026-11-09 20:29:57.38163+00', '2026-11-09 20:29:57.38163+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ab273307-799a-4fdb-9d7e-f6ced41bd0ff', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Chocolate Milk Drink', 'Meadowlane', '2000000000183', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 14.0, "protein_g": 3.2, "calories_kcal": 84}}', '2026-11-09 20:29:57.38163+00', '2026-11-09 20:29:57.381631+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5e535f00-2412-4cba-bb11-5791e4a77e84', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Classic Hummus', 'Green Acre', '2000000000190', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 200.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 14.0, "carbs_g": 14.0, "protein_g": 7.0, "calories_kcal": 215}}', '2026-11-09 20:29:57.381631+00', '2026-11-09 20:29:57.381631+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f155fe7d-cd3f-469e-8d1c-f90cbd525528', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Red Pesto', 'Harvest Row', '2000000000206', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 190.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 25.0, "carbs_g": 5.0, "protein_g": 3.0, "calories_kcal": 267}}', '2026-11-09 20:29:57.381632+00', '2026-11-09 20:29:57.381632+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('eb9b9ca0-46c5-4914-a914-c1dd7b1d6c0c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Carrots 1kg', 'Green Acre', '4651922764332', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.9, "calories_kcal": 41}}', '2026-11-09 20:29:57.381632+00', '2026-11-09 20:29:57.381632+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7013a917-ad3b-4edc-a037-169808558193', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Broccoli', 'Green Acre', '7671591271129', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 7.0, "protein_g": 2.8, "calories_kcal": 34}}', '2026-11-09 20:29:57.381633+00', '2026-11-09 20:29:57.381633+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('e4a1ab60-42e5-4774-816b-99fb47659e10', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cherry Tomatoes', 'Green Acre', '1461382306422', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 3.9, "protein_g": 0.9, "calories_kcal": 18}}', '2026-11-09 20:29:57.381633+00', '2026-11-09 20:29:57.381634+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a4f0e475-32bc-4013-ac14-3c2aedce8de3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cucumber', 'Green Acre', '3824875293377', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 300.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 3.6, "protein_g": 0.7, "calories_kcal": 16}}', '2026-11-09 20:29:57.381634+00', '2026-11-09 20:29:57.381634+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('50e20ec2-822e-412f-9f47-0f5fa4e200bd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fuji Apples', 'Green Acre', '0774915747311', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 14.0, "protein_g": 0.3, "calories_kcal": 52}}', '2026-11-09 20:29:57.381635+00', '2026-11-09 20:29:57.381635+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0bb26ced-1dd3-49a2-b332-55821cdf35d3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Green Grapes', 'Green Acre', '2178682164889', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 18.0, "protein_g": 0.7, "calories_kcal": 69}}', '2026-11-09 20:29:57.381635+00', '2026-11-09 20:29:57.381635+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('58353c4d-8e46-4c89-a1ff-cc78db74e5fc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Strawberries', 'Green Acre', '9922816702736', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 7.7, "protein_g": 0.7, "calories_kcal": 32}}', '2026-11-09 20:29:57.381636+00', '2026-11-09 20:29:57.381636+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b2a37968-27e2-4568-9083-20e9ab079a64', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Bananas', 'Green Acre', '6348208271001', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 23.0, "protein_g": 1.1, "calories_kcal": 89}}', '2026-11-09 20:29:57.381636+00', '2026-11-09 20:29:57.381637+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('34a0b2fb-cf8e-4fb2-9c6c-9ec60197f606', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Vanilla Ice Cream', 'Northwind Frozen', '2000000000299', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 11.0, "carbs_g": 24.0, "protein_g": 3.5, "calories_kcal": 207}}', '2026-11-09 20:29:57.381637+00', '2026-11-09 20:29:57.381637+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('56a688a0-ba15-4830-a631-bfe5794a8eca', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen Pepperoni Pizza', 'Northwind Frozen', '2000000000305', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 350.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 12.0, "carbs_g": 28.0, "protein_g": 11.0, "calories_kcal": 266}}', '2026-11-09 20:29:57.381638+00', '2026-11-09 20:29:57.381638+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c7486598-4240-4979-bb9e-21e57b6effe8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Potato and Cheese Dumplings', 'Northwind Frozen', '2000000000312', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 600.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 28.0, "protein_g": 5.0, "calories_kcal": 196}}', '2026-11-09 20:29:57.381639+00', '2026-11-09 20:29:57.381639+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d4cac971-e8fa-48f6-95b8-0e34ead33420', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fish Fingers', 'Bluewater', '2000000000329', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 10.0, "carbs_g": 22.0, "protein_g": 10.0, "calories_kcal": 215}}', '2026-11-09 20:29:57.381639+00', '2026-11-09 20:29:57.381639+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4ef274a2-b6fe-4ef0-b4ff-c9fdcd50ae64', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen Mixed Vegetables', 'Northwind Frozen', '2000000000336', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 750.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 5.0, "protein_g": 2.0, "calories_kcal": 35}}', '2026-11-09 20:29:57.38164+00', '2026-11-09 20:29:57.38164+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('787cd292-d3ef-4678-a6c8-91df9da2727e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen Green Peas', 'Northwind Frozen', '2000000000343', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 450.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.4, "carbs_g": 14.0, "protein_g": 5.0, "calories_kcal": 81}}', '2026-11-09 20:29:57.38164+00', '2026-11-09 20:29:57.381641+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0385fbac-ae28-4680-9c45-2e8bb3612b2c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen Chips', 'Northwind Frozen', '2000000000350', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 750.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 5.0, "carbs_g": 24.0, "protein_g": 2.5, "calories_kcal": 152}}', '2026-11-09 20:29:57.381641+00', '2026-11-09 20:29:57.381641+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('611cf45d-7d37-4357-9110-cd0a47a192e1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen Blueberries', 'Northwind Frozen', '2000000000367', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 14.0, "protein_g": 0.7, "calories_kcal": 57}}', '2026-11-09 20:29:57.381641+00', '2026-11-09 20:29:57.381642+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b08458c8-d015-485a-b9e7-f99680d1aad3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Frozen Sour Cherries', 'Northwind Frozen', '2000000000374', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 12.0, "protein_g": 1.0, "calories_kcal": 50}}', '2026-11-09 20:29:57.381642+00', '2026-11-09 20:29:57.381643+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b3e38373-39df-499a-b13a-a2766b209b10', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Minced Pork', 'Fellbrook Farms', '2000000000381', NULL, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 19.0, "carbs_g": 0.0, "protein_g": 15.0, "calories_kcal": 242}}', '2026-11-09 20:29:57.381643+00', '2026-11-09 20:29:57.381643+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('71017bd0-7db1-4df5-aaea-5a6e3b59ce15', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Spaghetti 500g', 'Harvest Row', '2000000000398', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-09 20:29:57.381644+00', '2026-11-09 20:29:57.381644+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c3a351db-b74d-4190-a870-332727da317f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Penne Pasta', 'Harvest Row', '2000000000404', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-09 20:29:57.381644+00', '2026-11-09 20:29:57.381644+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('516be891-373e-4e07-974c-bf2985e5f36d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fusilli Pasta', 'Harvest Row', '2000000000411', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-11-09 20:29:57.381645+00', '2026-11-09 20:29:57.381645+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('fbee3e5f-1150-494e-8a64-14f40fa58af2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Buckwheat Groats', 'Harvest Row', '2000000000435', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 3.0, "carbs_g": 62.0, "protein_g": 12.0, "calories_kcal": 343}}', '2026-11-09 20:29:57.381646+00', '2026-11-09 20:29:57.381646+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8ca982aa-57eb-4a30-9d75-265c347b28d8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Rolled Oats', 'Harvest Row', '2000000000442', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 7.0, "carbs_g": 68.0, "protein_g": 13.0, "calories_kcal": 379}}', '2026-11-09 20:29:57.381646+00', '2026-11-09 20:29:57.381647+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('349c83b7-b912-4814-8249-84962e8119fd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fruit Muesli', 'Harvest Row', '2000000000459', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 67.0, "protein_g": 9.0, "calories_kcal": 398}}', '2026-11-09 20:29:57.381647+00', '2026-11-09 20:29:57.381647+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c0d7c8b8-0a50-4630-b3ac-083909ecf946', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Corn Flakes', 'Harvest Row', '2000000000466', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 375.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 84.0, "protein_g": 6.0, "calories_kcal": 361}}', '2026-11-09 20:29:57.381648+00', '2026-11-09 20:29:57.381648+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('337711ed-2878-4163-9c87-8717a1371768', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Wheat Flour Type 550', 'Harvest Row', '2000000000473', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.0, "carbs_g": 72.0, "protein_g": 10.0, "calories_kcal": 341}}', '2026-11-09 20:29:57.381648+00', '2026-11-09 20:29:57.381648+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8e729252-6b73-4ad1-a945-f62c1086a00a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'White Sugar 1kg', 'Harvest Row', '2000000000480', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 100.0, "protein_g": 0.0, "calories_kcal": 387}}', '2026-11-09 20:29:57.381649+00', '2026-11-09 20:29:57.381649+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('7f65a62c-3ea1-4603-94f7-4d837d66dd43', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Iodised Salt', 'Saltmill', '2000000000497', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381649+00', '2026-11-09 20:29:57.381649+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d6ae3a3b-dbaa-4ccb-9933-2d9d7e753b6f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Ground Black Pepper', 'Saltmill', '2000000000503', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 40.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.38165+00', '2026-11-09 20:29:57.38165+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f4d82862-a08a-4eef-9a78-4c8ffefaed0e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dried Oregano', 'Saltmill', '2000000000510', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 15.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.38165+00', '2026-11-09 20:29:57.381651+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5a728e80-1517-4a51-bafe-bc242d8dea42', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dried Basil', 'Saltmill', '2000000000527', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 10.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381651+00', '2026-11-09 20:29:57.381651+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('5e26266d-502e-4489-b09f-bf41874d8f83', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Granulated Garlic', 'Saltmill', '2000000000534', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 25.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381652+00', '2026-11-09 20:29:57.381652+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0984ac47-8b8c-490f-9a09-d7eb6d3cd264', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Extra Virgin Olive Oil', 'Harvest Row', '2000000000541', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 750.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-09 20:29:57.381652+00', '2026-11-09 20:29:57.381652+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('bb856f1a-fcdb-4d29-b932-14925497488e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Sunflower Oil', 'Harvest Row', '2000000000558', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-11-09 20:29:57.381653+00', '2026-11-09 20:29:57.381653+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('06b25639-9c62-4c4a-9e82-7da3cdb48727', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tomato Passata', 'Harvest Row', '2000000000565', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 700.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 5.5, "protein_g": 1.5, "calories_kcal": 32}}', '2026-11-09 20:29:57.381653+00', '2026-11-09 20:29:57.381654+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('deae4716-149b-4cbb-ba33-75b217122513', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Peeled Tomatoes 400g', 'Harvest Row', '2000000000572', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.2, "carbs_g": 4.0, "protein_g": 1.2, "calories_kcal": 26}}', '2026-11-09 20:29:57.381654+00', '2026-11-09 20:29:57.381654+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f1f91d41-5fb9-4ab5-a6e5-21988074debf', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Canned Chickpeas', 'Harvest Row', '2000000000589', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.6, "carbs_g": 27.0, "protein_g": 9.0, "calories_kcal": 164}}', '2026-11-09 20:29:57.381655+00', '2026-11-09 20:29:57.381655+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f5a47832-23b5-455b-aac7-48a4d3684225', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Canned Sweetcorn', 'Harvest Row', '2000000000602', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 340.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 1.5, "carbs_g": 19.0, "protein_g": 3.0, "calories_kcal": 96}}', '2026-11-09 20:29:57.381656+00', '2026-11-09 20:29:57.381656+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('873cba06-505e-494c-ba2e-f8e678ee832b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tuna in Oil', 'Bluewater', '2000000000619', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 160.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 9.0, "carbs_g": 0.0, "protein_g": 26.0, "calories_kcal": 198}}', '2026-11-09 20:29:57.381656+00', '2026-11-09 20:29:57.381657+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b93f7f58-e0b4-445f-9f1b-bc1c7021c828', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Chicken Stock', 'Harvest Row', '2000000000626', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 120.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381657+00', '2026-11-09 20:29:57.381657+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('150a9d23-fc3e-4cde-b4a6-f812c8a92da3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Earl Grey Tea', 'Orchard & Oak', '2000000000633', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 50.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381657+00', '2026-11-09 20:29:57.381658+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f204cd1b-9010-4312-95b6-e86d24e2643e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Ground Coffee', 'Orchard & Oak', '2000000000640', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 250.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381658+00', '2026-11-09 20:29:57.381658+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('57e2ea5f-d739-4260-8c8b-8cdd0cd54dc1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Coffee Beans', 'Orchard & Oak', '2000000000657', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381659+00', '2026-11-09 20:29:57.381659+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a1df5871-001e-45a6-9da8-bf510c33b177', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Strawberry Jam', 'Orchard & Oak', '2000000000664', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 350.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.1, "carbs_g": 65.0, "protein_g": 0.5, "calories_kcal": 264}}', '2026-11-09 20:29:57.381659+00', '2026-11-09 20:29:57.381659+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('96c91f8c-8465-4d05-8061-5d1751288718', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Peanut Butter', 'Orchard & Oak', '2000000000671', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 250.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 20.0, "protein_g": 25.0, "calories_kcal": 588}}', '2026-11-09 20:29:57.38166+00', '2026-11-09 20:29:57.38166+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9ee9b559-ea52-4db7-a2e4-28eaaf3d6b81', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dark Chocolate 85%', 'Orchard & Oak', '2000000000688', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 100.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 44.0, "carbs_g": 39.0, "protein_g": 8.0, "calories_kcal": 598}}', '2026-11-09 20:29:57.38166+00', '2026-11-09 20:29:57.38166+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2e20fa11-f190-4e5e-924d-41a720dd5e8d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Salted Potato Crisps', 'Orchard & Oak', '2000000000695', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 165.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 35.0, "carbs_g": 53.0, "protein_g": 4.0, "calories_kcal": 536}}', '2026-11-09 20:29:57.381661+00', '2026-11-09 20:29:57.381661+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c67f7840-e1c9-46e1-a074-6b940430e40e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Rice Cakes', 'Harvest Row', '2000000000701', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 120.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 2.0, "carbs_g": 82.0, "protein_g": 7.0, "calories_kcal": 387}}', '2026-11-09 20:29:57.381661+00', '2026-11-09 20:29:57.381662+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('78ec019c-050b-452c-bac5-58e8d9977879', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Butter Biscuits', 'Orchard & Oak', '2000000000718', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 200.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 17.0, "carbs_g": 71.0, "protein_g": 6.0, "calories_kcal": 454}}', '2026-11-09 20:29:57.381662+00', '2026-11-09 20:29:57.381662+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('37e35a1d-44cf-459c-a58a-6786cc1c59f3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Soy Sauce', 'Harvest Row', '2000000000725', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 250.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 5.0, "protein_g": 8.0, "calories_kcal": 53}}', '2026-11-09 20:29:57.381662+00', '2026-11-09 20:29:57.381663+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('136ba022-e7d5-496b-b4a1-a3625321e24c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tomato Paste', 'Harvest Row', '2000000000732', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 170.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.3, "carbs_g": 9.0, "protein_g": 3.0, "calories_kcal": 55}}', '2026-11-09 20:29:57.381663+00', '2026-11-09 20:29:57.381663+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b90fae37-b088-49c0-b137-96e942d88441', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Potato Starch', 'Harvest Row', '2000000000749', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 500.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 85.0, "protein_g": 0.5, "calories_kcal": 341}}', '2026-11-09 20:29:57.381664+00', '2026-11-09 20:29:57.381664+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c15965cb-7201-4c66-9680-af49f6637a17', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Baking Powder', 'Harvest Row', '2000000000756', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 50.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381664+00', '2026-11-09 20:29:57.381664+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('84be7ee7-1046-4de1-a2b5-e9eac6542e8c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dry Yeast', 'Harvest Row', '2000000000763', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 14.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381665+00', '2026-11-09 20:29:57.381665+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1b1ada48-5fee-4941-a765-450e7d55d182', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Vanilla Sugar', 'Harvest Row', '2000000000770', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 32.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381665+00', '2026-11-09 20:29:57.381666+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('77c08e1d-cacc-40f2-98cc-f3718e2a3182', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Sweet Paprika', 'Saltmill', '2000000000794', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 30.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381666+00', '2026-11-09 20:29:57.381667+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d7ca0b58-9330-47b9-90b9-ff5a777e50d9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Curry Powder', 'Saltmill', '2000000000800', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 25.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381667+00', '2026-11-09 20:29:57.381667+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('685830c5-bf5f-4c1e-8eec-4fa61755aff9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Ground Ginger', 'Saltmill', '2000000000817', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 20.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.381668+00', '2026-11-09 20:29:57.381668+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4fb79eb5-2b87-46b1-b0b7-6310cbb851cf', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Wildflower Honey', 'Orchard & Oak', '2000000000824', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 0.0, "carbs_g": 82.0, "protein_g": 0.3, "calories_kcal": 304}}', '2026-11-09 20:29:57.381668+00', '2026-11-09 20:29:57.381668+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6bf2d993-0d6e-4975-8d91-b31fdd7bac20', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Walnuts', 'Green Acre', '2000000000831', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 200.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 65.0, "carbs_g": 14.0, "protein_g": 15.0, "calories_kcal": 654}}', '2026-11-09 20:29:57.381669+00', '2026-11-09 20:29:57.381669+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('90d23976-c086-4242-8bc1-8c2cdbea1a4c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Almonds', 'Green Acre', '2000000000848', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 200.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 50.0, "carbs_g": 22.0, "protein_g": 21.0, "calories_kcal": 579}}', '2026-11-09 20:29:57.381669+00', '2026-11-09 20:29:57.38167+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('077dbf4f-0bff-4911-9ad4-39b492dda441', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Instant Tomato Soup', 'Harvest Row', '2000000000855', NULL, '917304cd-586e-45cc-9900-313855f42a9b', 85.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, 'null', '2026-11-09 20:29:57.38167+00', '2026-11-09 20:29:57.38167+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('21f5acbc-eff5-451b-8ca9-4b27e9c616aa', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cocoa Powder', 'Orchard & Oak', '2000000000862', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 100.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, NULL, '{"nutrition": {"fat_g": 15.0, "carbs_g": 36.0, "protein_g": 24.0, "calories_kcal": 348}}', '2026-11-09 20:29:57.381671+00', '2026-11-09 20:29:57.381671+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d88c3c8f-3d12-443b-842e-17bc327f9fe6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dell Latitude 5540', 'Dell', '2000000010014', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-1345U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-09 20:29:57.395856+00', '2026-11-09 20:29:57.39586+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4af7dd1e-9d07-47f8-b82a-13b52fb84728', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ThinkPad T14s Gen 4', 'Lenovo', '2000000010021', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "AMD Ryzen 7 PRO", "ram": "32GB", "storage": "1TB SSD"}}', '2026-11-09 20:29:57.395861+00', '2026-11-09 20:29:57.395861+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d97eb9d7-4797-4ccd-9695-8f3c9aa6edab', '00e8db4f-deff-45c2-82ee-95c459b73161', 'MacBook Pro 14 M3', 'Apple', '2000000010038', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Apple M3 Pro", "ram": "18GB", "storage": "512GB SSD"}}', '2026-11-09 20:29:57.395861+00', '2026-11-09 20:29:57.395862+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9a1bb369-c512-457e-ae53-78a72acc2219', '00e8db4f-deff-45c2-82ee-95c459b73161', 'HP EliteBook 840 G10', 'HP', '2000000010045', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-1365U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-09 20:29:57.395862+00', '2026-11-09 20:29:57.395862+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f3f6277b-cfea-489b-8fc9-02487454dadf', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dell OptiPlex 7010', 'Dell', '2000000010052', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-13500", "ram": "16GB", "storage": "512GB SSD"}}', '2026-11-09 20:29:57.395863+00', '2026-11-09 20:29:57.395863+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('c061f145-3135-4b56-95ec-087889a26e8b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'HP ProDesk 400 G9', 'HP', '2000000010069', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i5-12500", "ram": "8GB", "storage": "256GB SSD"}}', '2026-11-09 20:29:57.395863+00', '2026-11-09 20:29:57.395863+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('dc652b43-dc3a-429f-bc55-63cadcd9f58f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Lenovo ThinkCentre M90q', 'Lenovo', '2000000010076', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel i7-13700", "ram": "16GB", "storage": "1TB SSD"}}', '2026-11-09 20:29:57.395864+00', '2026-11-09 20:29:57.395864+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('54327d88-3d1a-470b-889d-459f5efa89be', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dell UltraSharp U2723QE', 'Dell', '2000000010083', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-09 20:29:57.395865+00', '2026-11-09 20:29:57.395865+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('6d40b416-5d46-4941-9081-e1dbd1eed786', '00e8db4f-deff-45c2-82ee-95c459b73161', 'LG 27UK850-W', 'LG', '2000000010090', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-11-09 20:29:57.395865+00', '2026-11-09 20:29:57.395866+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Samsung Odyssey G5', 'Samsung', '2000000010106', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "32\"", "panel": "VA", "resolution": "2560x1440"}}', '2026-11-09 20:29:57.395866+00', '2026-11-09 20:29:57.395866+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('153e2c78-e030-4480-b56a-e0912b30632a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'iPhone 15 Pro', 'Apple', '2000000010113', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Natural Titanium", "storage": "256GB"}}', '2026-11-09 20:29:57.395867+00', '2026-11-09 20:29:57.395867+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4ecc7f87-37ca-4418-950a-d19abcc50f2a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Samsung Galaxy S24', 'Samsung', '2000000010120', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Phantom Black", "storage": "128GB"}}', '2026-11-09 20:29:57.395867+00', '2026-11-09 20:29:57.395867+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('610fdfe8-a330-4661-884e-3a0ee4127d92', '00e8db4f-deff-45c2-82ee-95c459b73161', 'iPad Air M2', 'Apple', '2000000010137', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"color": "Space Gray", "storage": "128GB"}}', '2026-11-09 20:29:57.395868+00', '2026-11-09 20:29:57.395868+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9025d321-5ecd-4d2b-939d-925f457f8b9e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cisco Catalyst 9200L', 'Cisco', '2000000010144', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE", "management": "DNA Center"}}', '2026-11-09 20:29:57.395868+00', '2026-11-09 20:29:57.395869+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', '2000000010151', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "48x 1GbE + 4x 10GbE"}}', '2026-11-09 20:29:57.395869+00', '2026-11-09 20:29:57.395869+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('8850e5a3-1986-4417-8a9f-f8f377957c3f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'TP-Link TL-SG3428', 'TP-Link', '2000000010168', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"ports": "24x 1GbE + 4x SFP"}}', '2026-11-09 20:29:57.395869+00', '2026-11-09 20:29:57.39587+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('217182bd-b208-424f-84c6-347898691e06', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cisco Meraki MR46', 'Cisco', '2000000010175', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"speed": "AX5400", "standard": "Wi-Fi 6"}}', '2026-11-09 20:29:57.39587+00', '2026-11-09 20:29:57.39587+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('aa9e1eee-bcc1-4228-a898-3ebdb3f79732', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Logitech MX Keys S', 'Logitech', '2000000010182', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Mechanical", "layout": "US"}}', '2026-11-09 20:29:57.395871+00', '2026-11-09 20:29:57.395871+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('d51ae20b-7e11-4f6a-b07a-651430aff68e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Logitech MX Master 3S', 'Logitech', '2000000010199', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"dpi": 8000, "buttons": 7}}', '2026-11-09 20:29:57.395871+00', '2026-11-09 20:29:57.395871+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f8b5105f-bec6-4c53-b399-0940ea8dcf57', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Logitech C920 HD Pro', 'Logitech', '2000000010205', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"fps": 30, "resolution": "1080p"}}', '2026-11-09 20:29:57.395872+00', '2026-11-09 20:29:57.395872+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('f95dddbd-0591-4827-b835-615fcddeb437', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Jabra Evolve2 65', 'Jabra', '2000000010212', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"type": "Headset", "connection": "Bluetooth"}}', '2026-11-09 20:29:57.395872+00', '2026-11-09 20:29:57.395873+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('9415af05-c7ea-4044-a47c-73918712aca5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Dell PowerEdge R750', 'Dell', '2000000010229', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4314", "ram": "64GB", "storage": "2x 480GB SSD"}}', '2026-11-09 20:29:57.395873+00', '2026-11-09 20:29:57.395873+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('4ca19ba2-326d-4463-8779-d52cac2c2dad', '00e8db4f-deff-45c2-82ee-95c459b73161', 'HPE ProLiant DL380 Gen10', 'HPE', '2000000010236', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Gold 5318Y", "ram": "128GB", "storage": "4x 960GB SSD"}}', '2026-11-09 20:29:57.395874+00', '2026-11-09 20:29:57.395874+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('34d27d14-ab66-4b09-8ffa-f135f94f93d1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Supermicro SYS-1029U', 'Supermicro', '2000000010243', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"cpu": "Intel Xeon Silver 4214", "ram": "96GB", "storage": "2x 1TB SSD"}}', '2026-11-09 20:29:57.395874+00', '2026-11-09 20:29:57.395874+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('420a7571-bdc7-46b5-8a94-a7a87845194f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'APC Smart-UPS 3000VA', 'APC', '2000000010250', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"runtime": "~15min at full load", "capacity": "3000VA/2700W"}}', '2026-11-09 20:29:57.395875+00', '2026-11-09 20:29:57.395875+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('1a98a752-a9d5-405b-8811-3539b8170bea', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Rack 42U Open Frame', 'Rittal', '2000000010267', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '{"equipment": {"size": "42U", "width": "19 inch"}}', '2026-11-09 20:29:57.395875+00', '2026-11-09 20:29:57.395876+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('42fb5efc-9a73-4801-989a-0182576ad930', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Plum Butter', 'Hollow Lane Orchard', '2000000009018', 'PLB-001', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-09 20:29:57.402573+00', '2026-11-09 20:29:57.402575+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('063c1712-5f63-4a39-9de1-9bee2fcc5c21', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Damson Plums', 'Green Acre', '2000000009025', 'PLM-001', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-09 20:29:57.402576+00', '2026-11-09 20:29:57.402576+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a7907bfa-51a5-4121-8ad2-91864a33b272', '00e8db4f-deff-45c2-82ee-95c459b73161', 'White Sugar', 'Harvest Row', '2000000009032', 'SUG-001', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-09 20:29:57.402576+00', '2026-11-09 20:29:57.402576+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0ac86d54-9b7d-43be-a6de-b6db210e7c8f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Cassia Cinnamon', 'Saltmill', '2000000009049', 'CIN-001', 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 0, 'FIFO', '{"maker_demo": true}', '2026-11-09 20:29:57.402577+00', '2026-11-09 20:29:57.402577+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('0624e122-2b53-43dc-9404-ac9614dd0b43', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Ground Cinnamon', 'Saltmill', '2000000000787', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 20.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 9, NULL, 'null', '2026-11-09 20:29:57.381666+00', '2026-11-09 20:29:57.514952+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('2311d6c3-afc7-4dc8-9c71-5955220d6e31', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Canned White Beans', 'Harvest Row', '2000000000596', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 400.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 2, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 25.0, "protein_g": 9.0, "calories_kcal": 139}}', '2026-11-09 20:29:57.381655+00', '2026-11-09 20:29:57.514956+00');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, removal_strategy, meta_data, created_at, updated_at) VALUES ('a288952d-aa29-4152-99bb-2eadf7b78e9d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Jasmine Rice 1kg', 'Harvest Row', '2000000000428', NULL, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 1000.000000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, NULL, NULL, 1, NULL, '{"nutrition": {"fat_g": 0.5, "carbs_g": 78.0, "protein_g": 7.0, "calories_kcal": 348}}', '2026-11-09 20:29:57.381645+00', '2026-11-09 20:29:57.514956+00');


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('b69a06f3-9247-4573-a5b1-48c4d483d524', '4c455c38-8700-4b97-987a-e402b3fd551d', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 'Dell Latitude 5540', 4.000, 0.000, 4200.00, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('ee6d72f2-1034-4172-9a84-3cc3b22812ea', 'd3779d22-c7c7-47ec-88b4-b4c7fe450482', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 'Dell Latitude 5540', 6.000, 0.000, 4200.00, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('54880cd7-b53e-4ebe-b236-f83950b58f28', 'd3779d22-c7c7-47ec-88b4-b4c7fe450482', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'ThinkPad T14s Gen 4', 2.000, 0.000, 5800.00, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, 2, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('5ffd280d-3d94-48a7-b1bb-649627aca117', 'aad72d21-ff44-42ea-92a6-13ceff6b0eb5', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'ThinkPad T14s Gen 4', 5.000, 3.000, 5800.00, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, 1, NULL, NULL);


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('aad72d21-ff44-42ea-92a6-13ceff6b0eb5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'PO/2026/003', 'CONFIRMED', '31869dee-d35c-401e-9a57-a5a63c1f75d3', '2026-10-27', 'Partly delivered; the rest is on back order with the supplier.', 'USD', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-20 20:29:59.862538+00', NULL, NULL, '2026-10-20 20:29:59.862538+00', '2026-11-09 20:30:00.610745+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('4c455c38-8700-4b97-987a-e402b3fd551d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'PO/2026/001', 'PENDING_APPROVAL', 'a89fd506-ce44-426f-a6aa-afe3d0bb336a', '2026-11-13', 'Laptops for the two November starters and two for the loan pool.', 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', NULL, NULL, NULL, NULL, '2026-11-06 20:29:59.862538+00', '2026-11-09 20:30:01.015033+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('d3779d22-c7c7-47ec-88b4-b4c7fe450482', '00e8db4f-deff-45c2-82ee-95c459b73161', 'PO/2026/002', 'CONFIRMED', 'a89fd506-ce44-426f-a6aa-afe3d0bb336a', '2026-11-06', 'Quarterly refresh of the support desk.', 'USD', '6e228bca-4488-4535-9fd3-0d4b0549bd49', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-31 04:29:59.862538+00', NULL, NULL, '2026-10-30 20:29:59.862538+00', '2026-11-09 20:30:01.015531+00');


--
-- Data for Name: putaway_capacity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_home_silenced; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_location_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_rule_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('e355be77-7b57-4f33-aeb0-c6a5e29d9ce5', '00e8db4f-deff-45c2-82ee-95c459b73161', '898fe9de-47d6-447f-a6c0-d80c1cb8752c', '4862b4f7-228f-43d4-b329-37de5b1813bf', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('18ad3f2b-6548-4317-8826-65e41983e1df', '00e8db4f-deff-45c2-82ee-95c459b73161', '898fe9de-47d6-447f-a6c0-d80c1cb8752c', '47b747a8-0340-493b-845a-8d3d906d17ff', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('7ef59055-9601-46bc-81d3-0d97d4db953c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c11e951b-ed08-474e-a73e-46c713b09750', '66ee606c-e95d-4547-920f-fb79bb6d8759', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('cfef49c2-acb2-4423-929b-aa0dd4841336', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c11e951b-ed08-474e-a73e-46c713b09750', '0609450b-99c5-4863-a285-183519183528', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('2d7b2b66-de11-4d52-b50e-bd591df73f0c', '00e8db4f-deff-45c2-82ee-95c459b73161', '942bd2be-713a-44dc-a2e8-1de3e31af33d', '4862b4f7-228f-43d4-b329-37de5b1813bf', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('328dfe1d-36f6-487d-83c9-179c6d660a4e', '00e8db4f-deff-45c2-82ee-95c459b73161', '942bd2be-713a-44dc-a2e8-1de3e31af33d', '47b747a8-0340-493b-845a-8d3d906d17ff', 1);


--
-- Data for Name: putaway_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('898fe9de-47d6-447f-a6c0-d80c1cb8752c', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, '7fccadf3-255b-49ce-99be-4073275efcec', NULL, NULL, 50, true, '2026-11-09 20:30:00.558739+00', '2026-11-09 20:30:00.558739+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('c11e951b-ed08-474e-a73e-46c713b09750', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, '93adc9f2-41e3-42b5-a954-7ce1e793ffef', NULL, NULL, 50, true, '2026-11-09 20:30:00.558739+00', '2026-11-09 20:30:00.558739+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('942bd2be-713a-44dc-a2e8-1de3e31af33d', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', NULL, NULL, NULL, 10, true, '2026-11-09 20:30:00.558739+00', '2026-11-09 20:30:00.558739+00');


--
-- Data for Name: recipe_collection_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('63831fc9-ef8d-4eef-87dd-7402048611cc', 'aad70a26-5044-45c1-8baa-a540ce1df5b6', 'f1f91d41-5fb9-4ab5-a6e5-21988074debf', 'Canned Chickpeas', NULL, NULL, 2.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('4feaa7aa-83c0-4b38-b9db-849e310b0a85', 'aad70a26-5044-45c1-8baa-a540ce1df5b6', '06b25639-9c62-4c4a-9e82-7da3cdb48727', 'Tomato Passata', NULL, NULL, 500.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('678d5a6b-78e5-45b7-acde-7a5e37e858c5', 'aad70a26-5044-45c1-8baa-a540ce1df5b6', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('81e43598-4f40-469b-858f-7830edb358a3', 'aad70a26-5044-45c1-8baa-a540ce1df5b6', '77c08e1d-cacc-40f2-98cc-f3718e2a3182', 'Sweet Paprika', NULL, NULL, 3.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d5fc5942-b303-406e-a19f-e49e77e71f05', 'c699bb02-2134-4881-be65-3ae1cd1ba45d', '71017bd0-7db1-4df5-aaea-5a6e3b59ce15', 'Spaghetti 500g', NULL, NULL, 200.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('56cb94fd-86f7-42b7-8363-7203eba78843', 'c699bb02-2134-4881-be65-3ae1cd1ba45d', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', 'Extra Virgin Olive Oil', NULL, NULL, 40.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('84e4a35e-968b-47f1-9820-d47aa2f1d09a', 'c699bb02-2134-4881-be65-3ae1cd1ba45d', '5e26266d-502e-4489-b09f-bf41874d8f83', 'Granulated Garlic', NULL, NULL, 3.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('de6209f6-cc2a-45a8-b802-fdd72f6ce15c', 'c699bb02-2134-4881-be65-3ae1cd1ba45d', '7f65a62c-3ea1-4603-94f7-4d837d66dd43', 'Iodised Salt', NULL, NULL, 10.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('806f202c-eb1f-4a7e-ac9f-237d702542d7', '7ac44cc1-5492-4eb9-a14a-89191b1bc896', 'cab52259-e9cc-4641-9617-8a9188b49e20', 'Chicken Breast Fillet', NULL, NULL, 600.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('cfceab89-af5f-4787-abe0-9e820da6320c', '7ac44cc1-5492-4eb9-a14a-89191b1bc896', 'a288952d-aa29-4152-99bb-2eadf7b78e9d', 'Jasmine Rice 1kg', NULL, NULL, 300.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('117d5731-ae9c-418a-bf78-68fe2fec5df9', '7ac44cc1-5492-4eb9-a14a-89191b1bc896', 'd7ca0b58-9330-47b9-90b9-ff5a777e50d9', 'Curry Powder', NULL, NULL, 10.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('e9b3022f-d2a9-4238-9d27-f96ecd2dad9c', '7ac44cc1-5492-4eb9-a14a-89191b1bc896', 'deae4716-149b-4cbb-ba33-75b217122513', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3c899518-840f-42c6-bc68-167482005d83', '7ac44cc1-5492-4eb9-a14a-89191b1bc896', NULL, 'Coconut Milk', NULL, NULL, 400.000, 'b83a5e3d-374a-4a36-9640-990e1e3ee484', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('9754a54b-7781-4953-9021-43d6e36e2b89', 'aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74', 'c3a351db-b74d-4190-a870-332727da317f', 'Penne Pasta', NULL, NULL, 200.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('d2ab9924-d2cd-4a83-a50e-53b3ad8031b1', 'aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74', 'f155fe7d-cd3f-469e-8d1c-f90cbd525528', 'Red Pesto', NULL, NULL, 90.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0159b2b1-eedf-483e-9b03-6caadb3e8640', 'aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74', 'e4a1ab60-42e5-4774-816b-99fb47659e10', 'Cherry Tomatoes', NULL, NULL, 250.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1a4f0ec3-e4d2-49d7-b536-2af95b86f96b', 'aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74', NULL, 'Parmesan', NULL, NULL, 40.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1ba8960c-0665-492c-9e8e-c5441a27294a', '91ba51d7-1965-48c4-b13c-fd03037d3d64', '8ca982aa-57eb-4a30-9d75-265c347b28d8', 'Rolled Oats', NULL, NULL, 100.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('269093b6-de8a-4ec5-8417-04af9c472f1c', '91ba51d7-1965-48c4-b13c-fd03037d3d64', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', 'Natural Yoghurt 400g', NULL, NULL, 300.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('7ea006c7-a595-46e9-bb6b-cffa1c7072c9', '91ba51d7-1965-48c4-b13c-fd03037d3d64', '611cf45d-7d37-4357-9110-cd0a47a192e1', 'Frozen Blueberries', NULL, NULL, 120.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1189e5b6-9d50-4916-a268-82c3671d3670', '91ba51d7-1965-48c4-b13c-fd03037d3d64', '4fb79eb5-2b87-46b1-b0b7-6310cbb851cf', 'Wildflower Honey', NULL, NULL, 20.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('cf4d7cfe-7f34-49cc-b705-3176cfae9884', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', 'b2a37968-27e2-4568-9083-20e9ab079a64', 'Bananas', NULL, NULL, 500.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f234cb31-19a1-40f4-b9c4-ef2cf9c9a35a', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', '337711ed-2878-4163-9c87-8717a1371768', 'Wheat Flour Type 550', NULL, NULL, 250.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('aaf20d76-4991-4b65-b827-19cfa1f102fc', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', '8e729252-6b73-4ad1-a945-f62c1086a00a', 'White Sugar 1kg', NULL, NULL, 150.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c1ee073f-f205-4e07-b551-90281b94a132', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', '3d1b782b-9970-4eb8-aca8-c36ac62e204e', 'Eggs Medium 10pk', NULL, NULL, 1.000, '917304cd-586e-45cc-9900-313855f42a9b', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('41ba08ad-87c5-484a-a504-e48f64381a25', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', '80b42f49-4cde-42be-bb81-b4631caefbd5', 'Butter Extra 82%', NULL, NULL, 100.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('e660b755-84af-4751-8272-e4097ec3a136', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', 'c15965cb-7201-4c66-9680-af49f6637a17', 'Baking Powder', NULL, NULL, 8.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('722b1646-f168-435d-970d-2ba93b339a25', '6d7ec52a-07af-4f1a-a37b-82f109d341b2', '6bf2d993-0d6e-4975-8d91-b31fdd7bac20', 'Walnuts', NULL, NULL, 100.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 6, NULL, NULL, NULL, NULL, '["nuts"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('fe592152-78df-4007-ac80-fe14626bcaff', '5cd1f034-5031-49a4-8139-5f3497e91d9c', '3d1b782b-9970-4eb8-aca8-c36ac62e204e', 'Eggs Medium 10pk', NULL, NULL, 1.000, '917304cd-586e-45cc-9900-313855f42a9b', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1f38ec01-17c3-4c64-b689-abf725b2cd62', '5cd1f034-5031-49a4-8139-5f3497e91d9c', 'deae4716-149b-4cbb-ba33-75b217122513', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3cb9afbb-1562-487d-b276-cfaa037efd89', '5cd1f034-5031-49a4-8139-5f3497e91d9c', '77c08e1d-cacc-40f2-98cc-f3718e2a3182', 'Sweet Paprika', NULL, NULL, 3.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('32c40b35-586e-4baf-80d1-a305cb34bd9f', '5cd1f034-5031-49a4-8139-5f3497e91d9c', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c07437d7-004b-4385-9e51-993e70ab3c67', '5cd1f034-5031-49a4-8139-5f3497e91d9c', NULL, 'Onion', NULL, NULL, 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('380893b0-7b82-42d6-b724-295848885e9d', 'ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', '337711ed-2878-4163-9c87-8717a1371768', 'Wheat Flour Type 550', NULL, NULL, 250.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('72b6721f-4cac-46f7-b398-c0de32f9c7ee', 'ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', 'UHT Milk 3.2%', NULL, NULL, 500.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["milk"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('10ffc6c7-7681-4661-9a10-3f25a233e607', 'ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', '3d1b782b-9970-4eb8-aca8-c36ac62e204e', 'Eggs Medium 10pk', NULL, NULL, 1.000, '917304cd-586e-45cc-9900-313855f42a9b', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('9c47fe40-36e7-4f45-aefb-5a291d6f9e33', 'ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', '58353c4d-8e46-4c89-a1ff-cc78db74e5fc', 'Strawberries', NULL, NULL, 300.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('3d64e7c5-5702-427d-9095-086c21b81dca', 'ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', 'bb856f1a-fcdb-4d29-b932-14925497488e', 'Sunflower Oil', NULL, NULL, 25.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('7c74a263-027d-4229-8e81-b1fa61796034', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', '516be891-373e-4e07-974c-bf2985e5f36d', 'Fusilli Pasta', NULL, NULL, 300.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '["gluten"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6b69c854-00f7-4c5e-8370-6f9c75170506', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', '873cba06-505e-494c-ba2e-f8e678ee832b', 'Tuna in Oil', NULL, NULL, 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '["fish"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('cad872b0-31ea-4f98-9b33-e4244447fcfe', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', 'f5a47832-23b5-455b-aac7-48a4d3684225', 'Canned Sweetcorn', NULL, NULL, 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('165e52a8-776e-4ef6-9bba-9011af9f8e47', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', '0d0c149b-9aa5-4f28-9f87-911b04b11df4', 'Mayonnaise', NULL, NULL, 75.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '["eggs"]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6705e5ae-e1d8-4eef-96fc-1a2bf3a4cf63', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', 'a4f0e475-32bc-4013-ac14-3c2aedce8de3', 'Cucumber', NULL, NULL, 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('5badf574-edfa-4a42-92fb-82ce29d1000b', 'f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', NULL, 'Fresh Basil', NULL, NULL, 10.000, 'd17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);


--
-- Data for Name: recipe_tag_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('5cd1f034-5031-49a4-8139-5f3497e91d9c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Shakshuka', 'Eggs poached in a spiced tomato sauce, straight from the pan.', '1. Soften the sliced onion in the oil with the paprika.
2. Add the tomatoes and simmer until thick.
3. Make four wells, crack in the eggs, cover and cook until set.', 2, 25, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/5cd1f034-5031-49a4-8139-5f3497e91d9c/cover.f495462017a6.jpg', NULL, '["breakfast", "vegetarian"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.512796+00', '2026-11-09 20:30:01.238834+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('6d7ec52a-07af-4f1a-a37b-82f109d341b2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Banana Bread', 'What the bananas going brown on the counter are for.', '1. Mash the bananas and beat in the melted butter, sugar and eggs.
2. Fold in the flour, baking powder and chopped walnuts.
3. Bake in a lined loaf tin at 175 C for about an hour.', 8, 70, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/6d7ec52a-07af-4f1a-a37b-82f109d341b2/cover.3af478a733d8.jpg', NULL, '["baking"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.511125+00', '2026-11-09 20:30:01.238838+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('7ac44cc1-5492-4eb9-a14a-89191b1bc896', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Chicken Curry with Jasmine Rice', 'A weeknight curry from the freezer and the spice drawer.', '1. Brown the diced chicken, then stir in the curry powder.
2. Add the tomatoes and coconut milk; simmer for twenty minutes.
3. Serve over the rice.', 4, 40, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/7ac44cc1-5492-4eb9-a14a-89191b1bc896/cover.7dc6671c2bc9.jpg', NULL, '["dinner"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.50537+00', '2026-11-09 20:30:01.238838+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('91ba51d7-1965-48c4-b13c-fd03037d3d64', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Overnight Oats with Blueberries', 'Made the evening before, eaten on the way out.', '1. Stir the oats into the yoghurt with a spoon of honey.
2. Fold in the blueberries straight from the freezer.
3. Cover and leave in the fridge overnight.', 2, 10, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/91ba51d7-1965-48c4-b13c-fd03037d3d64/cover.dfc3aa2068eb.jpg', NULL, '["breakfast", "vegetarian"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.509441+00', '2026-11-09 20:30:01.238839+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Penne with Red Pesto', 'Fifteen minutes, one pan, no chopping board.', '1. Cook the penne.
2. Halve the tomatoes and warm them in the pesto.
3. Toss with the pasta and finish with grated parmesan.', 2, 15, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/aa4fabab-e4e9-4d4b-b315-ce3dcfe49f74/cover.a2c6108f9a7c.jpg', NULL, '["quick", "pasta", "vegetarian"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.507114+00', '2026-11-09 20:30:01.238839+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('aad70a26-5044-45c1-8baa-a540ce1df5b6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tomato and Chickpea Stew', 'One pot, thirty minutes, everything from the pantry shelf.', '1. Warm the oil and toast the paprika for thirty seconds.
2. Add the passata and the drained chickpeas.
3. Simmer for twenty minutes, season and serve with bread.', 4, 30, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/aad70a26-5044-45c1-8baa-a540ce1df5b6/cover.a73330974669.jpg', NULL, '["quick", "vegetarian"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.499214+00', '2026-11-09 20:30:01.238839+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('c699bb02-2134-4881-be65-3ae1cd1ba45d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Spaghetti with Garlic and Oil', 'The five-ingredient supper worth knowing by heart.', '1. Cook the spaghetti in well-salted water.
2. Warm the oil gently with the garlic; do not let it brown.
3. Toss the drained pasta in the oil with a splash of cooking water.', 2, 20, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/c699bb02-2134-4881-be65-3ae1cd1ba45d/cover.02cc9ab66567.jpg', NULL, '["quick", "pasta"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.501252+00', '2026-11-09 20:30:01.23884+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Pancakes with Strawberries', 'Saturday breakfast, twelve thin pancakes.', '1. Whisk the flour, milk and eggs into a thin batter; rest it ten minutes.
2. Fry in a lightly oiled pan, a ladle at a time.
3. Serve with sliced strawberries.', 4, 30, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/ccd00f5c-dcd5-4dae-9e5a-7cdf4abc1137/cover.3882e8b3d23f.jpg', NULL, '["breakfast"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.514561+00', '2026-11-09 20:30:01.23884+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tuna Pasta Salad', 'A lunchbox that keeps until Wednesday.', '1. Cook the fusilli and cool it under running water.
2. Mix with the tuna, sweetcorn, diced cucumber and mayonnaise.
3. Tear the basil over the top before serving.', 3, 20, '00e8db4f-deff-45c2-82ee-95c459b73161/recipes/f0eef44f-477f-45f4-bbea-8ea2f4dbfb1a/cover.f2cb55c523ee.jpg', NULL, '["quick", "pasta"]', false, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.516056+00', '2026-11-09 20:30:01.23884+00');


--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_exclusions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('d8547ca5-be1a-4cf5-affd-e0e496d4fe5e', '8b08458b-920d-49fb-afb9-92544ed13579', NULL, NULL, 'Coconut Milk', 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'For the curry on Wednesday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-09 20:30:00.529749+00', '2026-11-09 20:30:00.529751+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('3423a598-f56c-4314-84d1-da867385676f', '8b08458b-920d-49fb-afb9-92544ed13579', NULL, NULL, 'Parmesan', 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'For the penne on Friday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-09 20:30:00.529753+00', '2026-11-09 20:30:00.529753+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('fabb3f79-8ff8-4385-8130-cfedff2900e2', '8b08458b-920d-49fb-afb9-92544ed13579', NULL, NULL, 'Onion', 3.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'Shakshuka on Saturday', NULL, false, NULL, NULL, 'manual', 0, '2026-11-09 20:30:00.529754+00', '2026-11-09 20:30:00.529755+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('95fe8357-5913-4ef8-804e-5b33c359b0c5', '8b08458b-920d-49fb-afb9-92544ed13579', NULL, NULL, 'Fresh Basil', 1.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', 'Tuna pasta salad', NULL, false, NULL, NULL, 'manual', 0, '2026-11-09 20:30:00.529755+00', '2026-11-09 20:30:00.529756+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('164f922d-cc7c-4b3b-be57-363f229f3254', '8b08458b-920d-49fb-afb9-92544ed13579', NULL, NULL, 'UHT Milk 3.2%', 2.000, '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-09 20:30:00.529756+00', '2026-11-09 20:30:00.529757+00', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('361a2456-7ea6-4d8a-8811-c1e79b8bccab', '8b08458b-920d-49fb-afb9-92544ed13579', NULL, NULL, 'Bananas', 1.000, 'fefa9928-2a16-4fa2-a52e-9cd9d3a18817', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-11-09 20:30:00.529757+00', '2026-11-09 20:30:00.529758+00', 'b2a37968-27e2-4568-9083-20e9ab079a64', NULL);


--
-- Data for Name: shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_lists (id, organization_id, name, status, completed_at, archived_at, created_by, created_at, updated_at) VALUES ('8b08458b-920d-49fb-afb9-92544ed13579', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Weekly shop', 'active', NULL, NULL, 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.524949+00', '2026-11-09 20:30:00.524953+00');


--
-- Data for Name: stock_anchors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('917bc085-c7fb-4e65-a748-fa3d7f7c68ed', '00e8db4f-deff-45c2-82ee-95c459b73161', '57e2ea5f-d739-4260-8c8b-8cdd0cd54dc1', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5743ed88-8c3f-4df8-8bb4-8300cd38830b', '00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('245e6971-86a9-437b-8e75-9ce3b9be2b44', '00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', '8f446de5-a0e0-4514-832b-2d68c13476d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1e48f06f-8714-4e35-adc4-e69d632e725a', '00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', '85b351d5-711b-47d4-b174-83619236e876', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('42d204dd-6030-461f-a928-8d017272414f', '00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9b0040f2-c593-4053-af97-31639b2fc0da', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b60b93d0-b081-409f-a1df-80afe614f544', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a7d7d811-03b9-4764-8cc3-6c17ebe47006', '00e8db4f-deff-45c2-82ee-95c459b73161', '0bb26ced-1dd3-49a2-b332-55821cdf35d3', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6b4b73d6-5079-4bdd-aa54-a48dd65ff2a4', '00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('efe30391-026f-4d1d-ae49-6cbd258bca51', '00e8db4f-deff-45c2-82ee-95c459b73161', '9ee9b559-ea52-4db7-a2e4-28eaaf3d6b81', '8f446de5-a0e0-4514-832b-2d68c13476d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('11223bac-cff7-4299-a3b0-d58992629984', '00e8db4f-deff-45c2-82ee-95c459b73161', '2311d6c3-afc7-4dc8-9c71-5955220d6e31', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e588f9fa-4f3d-4d0f-8f14-7e5a2960c617', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c3a351db-b74d-4190-a870-332727da317f', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7642a330-aec4-4ba9-8406-5d0da8c09217', '00e8db4f-deff-45c2-82ee-95c459b73161', 'eb9b9ca0-46c5-4914-a914-c1dd7b1d6c0c', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('15d72be0-2200-4ab5-88f2-7cdc5ae4d4e6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a288952d-aa29-4152-99bb-2eadf7b78e9d', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('76b1eeeb-bb98-42b6-a188-4183b0e20a20', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', '73869395-0caf-4783-a71d-e5ab311d279a', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('31ea96d8-803b-40a4-8efd-9f437bafce71', '00e8db4f-deff-45c2-82ee-95c459b73161', '0624e122-2b53-43dc-9404-ac9614dd0b43', '866b2db9-f86e-4955-8198-0d499f3e5025', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('dbdaa759-2291-4af9-906a-61f1b890b287', '00e8db4f-deff-45c2-82ee-95c459b73161', '349c83b7-b912-4814-8249-84962e8119fd', '8f446de5-a0e0-4514-832b-2d68c13476d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ec83c68a-8d59-4691-a64b-6f90ace349e0', '00e8db4f-deff-45c2-82ee-95c459b73161', '6e1acfb0-89c6-47f3-89e9-5817114a77fe', '471ef176-3922-44c1-9239-e42b8ca3f0ee', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7fae22ed-756a-421f-8f6d-7a56253f5aae', '00e8db4f-deff-45c2-82ee-95c459b73161', '685830c5-bf5f-4c1e-8eec-4fa61755aff9', '8f446de5-a0e0-4514-832b-2d68c13476d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('937c94ca-3689-4cb6-a9d8-77d88c8b3ad0', '00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8387fa88-9d54-4a53-b22a-226b1162e352', '00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', '88658701-75a4-4a06-9d85-62f32417ca68', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c03640f4-1eb0-4140-83a2-da628eab1982', '00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', '7c9ef099-d7e7-43b1-a405-3e3a232272b0', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1f15f3b2-925e-40c4-a0a9-50d36d9a7df3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0352ef98-4545-4570-9413-90565ee2abde', '00e8db4f-deff-45c2-82ee-95c459b73161', '787cd292-d3ef-4678-a6c8-91df9da2727e', '0a2727e8-6c13-4603-93e7-89512c6d8941', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ae9579e3-0c63-4bc0-ba12-04ec1a887bc9', '00e8db4f-deff-45c2-82ee-95c459b73161', '611cf45d-7d37-4357-9110-cd0a47a192e1', '66ee606c-e95d-4547-920f-fb79bb6d8759', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9a9b8c9c-a56a-4176-84af-f8ccd23c0db7', '00e8db4f-deff-45c2-82ee-95c459b73161', '58353c4d-8e46-4c89-a1ff-cc78db74e5fc', '73869395-0caf-4783-a71d-e5ab311d279a', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5dccdbed-0a26-4cf0-8d77-37c1c4cc2b80', '00e8db4f-deff-45c2-82ee-95c459b73161', '4dd93e53-5ef7-4aba-ad5d-f3ee76fe41a1', '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b13d7460-fb63-4512-b32e-ed35aa1ca09a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fbee3e5f-1150-494e-8a64-14f40fa58af2', '866b2db9-f86e-4955-8198-0d499f3e5025', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('dce157ca-051f-4484-982a-7371ad0d9528', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b90fae37-b088-49c0-b137-96e942d88441', '7c9ef099-d7e7-43b1-a405-3e3a232272b0', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3c8aba41-9303-4f7c-a288-ffba23a283e9', '00e8db4f-deff-45c2-82ee-95c459b73161', '84be7ee7-1046-4de1-a2b5-e9eac6542e8c', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3b8504a4-b9fc-429a-9658-5edc9ee1c12e', '00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('32758d56-b2c6-4262-a5a8-80b7c25a7e19', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '73869395-0caf-4783-a71d-e5ab311d279a', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('df4776ac-f58f-4c59-88c3-b0f6ba87ac83', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', '8f446de5-a0e0-4514-832b-2d68c13476d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('223d7952-113f-4558-b81a-9d558b3fd2ea', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', '866b2db9-f86e-4955-8198-0d499f3e5025', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a71b3e18-bd80-4290-9a93-24500afdc79d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c7486598-4240-4979-bb9e-21e57b6effe8', '66ee606c-e95d-4547-920f-fb79bb6d8759', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e8ec10a1-4eba-40fd-a134-24e152013578', '00e8db4f-deff-45c2-82ee-95c459b73161', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', '8f446de5-a0e0-4514-832b-2d68c13476d6', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2103c8c3-204d-4483-a0e9-3a4180382435', '00e8db4f-deff-45c2-82ee-95c459b73161', '7f65a62c-3ea1-4603-94f7-4d837d66dd43', '866b2db9-f86e-4955-8198-0d499f3e5025', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d9d39833-bcee-4621-87ed-20ea4339ca70', '00e8db4f-deff-45c2-82ee-95c459b73161', 'beb604b5-970d-4898-a6fd-319fca3f44fb', '73869395-0caf-4783-a71d-e5ab311d279a', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8d4492a5-b61d-4f68-b7c0-684392193ce0', '00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', '866b2db9-f86e-4955-8198-0d499f3e5025', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6dd61940-d8e2-4cdc-adba-240532434471', '00e8db4f-deff-45c2-82ee-95c459b73161', 'bb856f1a-fcdb-4d29-b932-14925497488e', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', '2026-11-09 20:29:57.431674+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('84a5ec9f-dfc2-4ba0-987d-015f1eb44efb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0cfc5b7b-d3b7-45fa-9948-ff3e1556502c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fcec5faf-378e-4df8-a25a-c349bb0af31f', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1c6a2027-a99e-41de-bcc5-a92dc3d91d30', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6e8bf156-51ce-4e07-9362-8232871442f2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e37a0f72-0e92-45b5-991d-44705d188d25', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('90ff8d58-40cb-4721-84f3-3f0dd9cfe977', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e3aa3057-3f00-492b-8f33-97410b1efd6a', '00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2ad9ce1a-bcd3-4304-94e7-68b3e9263831', '00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b2fcf888-e70b-4621-8ec0-9bf1d38371ae', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ec1d37e2-ee5e-4d89-8d86-1aa196fedb3a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f3bfb5dd-f115-43c1-925b-980712770de4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4d65b232-ab72-45cb-a452-59f2e7827860', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9fe035d2-8712-4564-9ec8-ef325ad5366d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('011f0f55-4b47-46cf-ada6-7343b910f502', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', 'c2c2653b-c961-4e10-93e6-665780ad0903', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('58cfedbb-cc7b-4170-b39a-66ffcf3fcd21', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a0b11238-f0e4-43b2-9b43-cc5764fd0cf4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dc652b43-dc3a-429f-bc55-63cadcd9f58f', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b38049df-72a1-48d6-a15a-73ac1eea19bf', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fd80687e-ecae-4b72-8120-ba7cd59bdf96', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ec1f3ba1-6b43-4329-b055-fb14a623ee4e', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('871bc290-fb61-40a8-9c34-6e9018185363', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d419894c-4ac6-4cee-817a-586244d3d926', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e82acdce-5f65-4940-b8c8-5b4a690fa662', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8d6b9f65-e3bd-42fe-824f-79fdc4a8c17d', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('43aa820f-1a1a-495b-bae0-a8b760a3b54e', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('17c06d0b-77bb-4f5a-a2bf-0d9efb0da53d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ca86e569-f0b8-479a-baec-5c4817e00015', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('355e9c43-2813-49b1-b306-bc942ddbec4e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('781a269e-17a6-40f4-96c6-3e84e7fc935e', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3a45f2e5-2421-430f-8547-b0b21605abb4', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('34c5ac28-6b9f-4e6b-af0b-fa56b26b4924', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('86e70f75-c382-497f-bfdf-2dfea1eabd2a', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f120e1df-9061-47df-bda5-46acd75a8a93', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cabb0843-09b3-4818-a7b3-5415c13aea09', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('12c0820e-da7d-4f38-bdb1-61089d83c17f', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('44b6ad6c-f65d-42a7-ae4d-6466e7d32a4d', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5a9eef1b-f4e7-413c-a057-3fb03646cea0', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e3b19791-45a1-4a1d-bd51-ed546c1320f3', '00e8db4f-deff-45c2-82ee-95c459b73161', '610fdfe8-a330-4661-884e-3a0ee4127d92', 'c2c2653b-c961-4e10-93e6-665780ad0903', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d0a8df2a-bb37-4426-8cef-8a06ba433618', '00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('19d642d4-6d3c-43d0-8ae2-1b8a7b5f1fa4', '00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d4678cee-01e7-42f6-8831-08014e2cc64b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9b98d554-8d85-48fb-8bd3-975e6ddf190d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('464f620e-85af-41a6-b941-0122a684d5ba', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 'c2c2653b-c961-4e10-93e6-665780ad0903', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('056efeca-c458-4eaf-b390-90fb16e31591', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('934cfa5c-39cd-436f-91ea-6e9835b07261', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3dc8e9b0-183c-4db7-b49f-9b6cc276cde8', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', 'c2c2653b-c961-4e10-93e6-665780ad0903', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e0dfaa07-cc08-40ca-a905-29143611a079', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7b796e5c-6f94-4bdf-9563-82f46ace12c8', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('990bffe4-3de9-49c2-98ee-4a0064e0a108', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('22e58b88-dace-45d1-9a98-457517f42319', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aa9e1eee-bcc1-4228-a898-3ebdb3f79732', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('96ae170c-1618-4a0a-ac3e-45b83e1b3c3c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c51b80d5-c121-4b82-84a1-ed378357024c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', 'c2c2653b-c961-4e10-93e6-665780ad0903', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a44106ad-2711-4262-ab16-d55207e57c0c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5a288fcb-a519-4e24-8f46-5bfb007787b8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('06565f7e-5123-4e63-92c9-57732a91edc6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d2a0c204-5f4c-45de-ae62-9aa00ea575e4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f95dddbd-0591-4827-b835-615fcddeb437', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bab33cf8-d988-4460-b90b-067988163404', '00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e8f50ed1-b372-4c8f-a5e5-b722b4c90aff', '00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fd5a8789-413c-4182-b715-b33688e70d22', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b2f102cc-f3a0-46e0-96fb-6b69eac11a06', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('667887c3-9ca3-471d-989e-59c380b1fc9b', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4a23637e-fd25-4233-982b-4bd586eb4725', '00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('10de7468-3ba2-4796-a974-525579b452ca', '00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5aa3538a-d0c6-4447-b244-8040225df3af', '00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8118dfe4-b6ca-4b96-93bd-9216b6a7bd65', '00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', 'b94369de-1676-42e5-998c-4be2391acbf9', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('64c85885-f91a-4999-aa8b-0df037d2667f', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('679c3da7-583f-46e2-9286-a1a5c8c317fb', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', 'c2c2653b-c961-4e10-93e6-665780ad0903', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('579ed470-4382-42dc-b764-5eb54cdcb7fa', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', '66eea498-a873-404c-9657-e5c94d678571', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ea4e5002-be36-49d6-bbcb-a7dbdcdd8532', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '2026-11-09 20:29:57.53307+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('31a9cd63-3665-4389-8cf3-8ad5f5b16597', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-11-09 20:29:57.626148+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9c8e7315-51fe-407b-8a85-53ff33cc5bea', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', '85b351d5-711b-47d4-b174-83619236e876', '2026-11-09 20:29:57.626148+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3e751e64-356a-4080-ac1d-33acd5100a6d', '00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', '85b351d5-711b-47d4-b174-83619236e876', '2026-11-09 20:29:57.626148+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d16af418-4172-4e00-a492-4a27575fca00', '00e8db4f-deff-45c2-82ee-95c459b73161', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('59d09b58-1c63-4802-88a2-49952dfab373', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e532473d-6b09-4b98-90ec-534bafd53ce4', '00e8db4f-deff-45c2-82ee-95c459b73161', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', '4862b4f7-228f-43d4-b329-37de5b1813bf', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cf909942-3c32-45ca-841d-bcfc2f53efb3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('12ea29f6-57cb-4063-b024-f65a8b5279a3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fa748810-6265-493f-a360-df817a409794', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1dd5b43c-5e29-4830-990f-e28bbae31904', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c567a8c9-57ff-4d45-b1c0-8d19ee6e5546', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '2026-11-09 20:29:58.449103+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3b410ab2-3d7e-416f-9081-381fe0586ce4', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', '85b351d5-711b-47d4-b174-83619236e876', '2026-11-09 20:30:00.242127+00');


--
-- Data for Name: stock_ledger_totals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f95dddbd-0591-4827-b835-615fcddeb437', 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '610fdfe8-a330-4661-884e-3a0ee4127d92', 'c2c2653b-c961-4e10-93e6-665780ad0903', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'dc652b43-dc3a-429f-bc55-63cadcd9f58f', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 'c2c2653b-c961-4e10-93e6-665780ad0903', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'aa9e1eee-bcc1-4228-a898-3ebdb3f79732', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', 'b94369de-1676-42e5-998c-4be2391acbf9', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', '66eea498-a873-404c-9657-e5c94d678571', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '57e2ea5f-d739-4260-8c8b-8cdd0cd54dc1', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', '4862b4f7-228f-43d4-b329-37de5b1813bf', 5.300);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', '8f446de5-a0e0-4514-832b-2d68c13476d6', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', '85b351d5-711b-47d4-b174-83619236e876', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '0bb26ced-1dd3-49a2-b332-55821cdf35d3', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 7.400);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'b60b93d0-b081-409f-a1df-80afe614f544', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 2.700);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '9ee9b559-ea52-4db7-a2e4-28eaaf3d6b81', '8f446de5-a0e0-4514-832b-2d68c13476d6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '2311d6c3-afc7-4dc8-9c71-5955220d6e31', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c3a351db-b74d-4190-a870-332727da317f', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'eb9b9ca0-46c5-4914-a914-c1dd7b1d6c0c', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 8.200);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'a288952d-aa29-4152-99bb-2eadf7b78e9d', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '0624e122-2b53-43dc-9404-ac9614dd0b43', '866b2db9-f86e-4955-8198-0d499f3e5025', 9.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '349c83b7-b912-4814-8249-84962e8119fd', '8f446de5-a0e0-4514-832b-2d68c13476d6', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', '4862b4f7-228f-43d4-b329-37de5b1813bf', 36.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '6e1acfb0-89c6-47f3-89e9-5817114a77fe', '471ef176-3922-44c1-9239-e42b8ca3f0ee', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '685830c5-bf5f-4c1e-8eec-4fa61755aff9', '8f446de5-a0e0-4514-832b-2d68c13476d6', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', '88658701-75a4-4a06-9d85-62f32417ca68', 2.300);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', '7c9ef099-d7e7-43b1-a405-3e3a232272b0', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 6.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '787cd292-d3ef-4678-a6c8-91df9da2727e', '0a2727e8-6c13-4603-93e7-89512c6d8941', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '611cf45d-7d37-4357-9110-cd0a47a192e1', '66ee606c-e95d-4547-920f-fb79bb6d8759', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '58353c4d-8e46-4c89-a1ff-cc78db74e5fc', '73869395-0caf-4783-a71d-e5ab311d279a', 7.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'fbee3e5f-1150-494e-8a64-14f40fa58af2', '866b2db9-f86e-4955-8198-0d499f3e5025', 4.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '4dd93e53-5ef7-4aba-ad5d-f3ee76fe41a1', '4862b4f7-228f-43d4-b329-37de5b1813bf', 10.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', '4862b4f7-228f-43d4-b329-37de5b1813bf', 18.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'b90fae37-b088-49c0-b137-96e942d88441', '7c9ef099-d7e7-43b1-a405-3e3a232272b0', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '4862b4f7-228f-43d4-b329-37de5b1813bf', 24.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '84be7ee7-1046-4de1-a2b5-e9eac6542e8c', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 1.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 6.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', '8f446de5-a0e0-4514-832b-2d68c13476d6', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '73869395-0caf-4783-a71d-e5ab311d279a', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 50.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', '866b2db9-f86e-4955-8198-0d499f3e5025', 10.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'fa748810-6265-493f-a360-df817a409794', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 15.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', '8f446de5-a0e0-4514-832b-2d68c13476d6', 3.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'c7486598-4240-4979-bb9e-21e57b6effe8', '66ee606c-e95d-4547-920f-fb79bb6d8759', 2.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'beb604b5-970d-4898-a6fd-319fca3f44fb', '73869395-0caf-4783-a71d-e5ab311d279a', 7.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '7f65a62c-3ea1-4603-94f7-4d837d66dd43', '866b2db9-f86e-4955-8198-0d499f3e5025', 8.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', '866b2db9-f86e-4955-8198-0d499f3e5025', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', '73869395-0caf-4783-a71d-e5ab311d279a', 15.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'bb856f1a-fcdb-4d29-b932-14925497488e', 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 5.000);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', '4862b4f7-228f-43d4-b329-37de5b1813bf', 13.600);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', '85b351d5-711b-47d4-b174-83619236e876', 21.220);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', '85b351d5-711b-47d4-b174-83619236e876', 0.440);
INSERT INTO public.stock_ledger_totals (organization_id, product_template_id, storage_location_id, quantity) VALUES ('00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', '85b351d5-711b-47d4-b174-83619236e876', 11.400);


--
-- Data for Name: stock_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_moves; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a1480cc8-5820-40d5-86a2-e29df8881883', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9560ba1a-aac2-40a8-bdec-31ed002aac92', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-09-23 07:00:00+00', '2026-11-09 20:29:57.691077+00', '2023-09-23 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b9b27688-b4f3-4bea-8917-a7d270ad422f', '00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5fbc74f1-7785-40e0-aa0b-81138e457d79', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-09-25 08:07:00+00', '2026-11-09 20:29:57.705677+00', '2023-09-25 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dd87b700-0ff7-4f09-8236-7a8f2c1841d9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd4073cdc-f3f7-4b1f-b5d5-43e7f485e5c5', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-10-24 09:14:00+00', '2026-11-09 20:29:57.711465+00', '2023-10-24 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('33c05680-c35b-444e-88f4-3ad665a83491', '00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', NULL, '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3b90be3f-1690-4596-a418-a37bd71e01c4', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-10-26 10:21:00+00', '2026-11-09 20:29:57.716469+00', '2023-10-26 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('098cf97e-65a4-482d-a603-da4ff29b9637', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8bd7506a-d7c8-4743-bad6-4265987d9529', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-10-28 11:28:00+00', '2026-11-09 20:29:57.720741+00', '2023-10-28 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b696bf77-1158-4717-a188-c1f346208651', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0ad3caae-5199-4ca7-80db-86828d9928c6', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-11-26 12:35:00+00', '2026-11-09 20:29:57.725054+00', '2023-11-26 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6ea00d69-1f0b-4b0a-9c38-75bfa2476c34', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e18b612e-4f45-4e32-8ef7-e84b39af20be', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-11-28 13:42:00+00', '2026-11-09 20:29:57.729262+00', '2023-11-28 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e7f188d9-2e79-45ef-9ec5-956d65dc6d24', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5322a2c7-e466-4e95-bdb4-6c0261f5ef57', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-12-29 14:49:00+00', '2026-11-09 20:29:57.73292+00', '2023-12-29 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('caccbba6-bb32-4104-9b2c-6e1b36c18d62', '00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6674708c-ee7f-4a72-a8cd-c54966f2dcfc', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2023-12-31 15:56:00+00', '2026-11-09 20:29:57.736288+00', '2023-12-31 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('80fef303-0552-43f6-b562-64879ad7e1aa', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1c6b8373-bcb6-42ae-8b86-ad6397c6bf6c', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-01-29 16:03:00+00', '2026-11-09 20:29:57.740159+00', '2024-01-29 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('57703af4-2be6-4664-aebb-e36273d590aa', '00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', NULL, '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e38df811-9a6d-4ff4-827e-e2496483b74e', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-01-31 07:10:00+00', '2026-11-09 20:29:57.744066+00', '2024-01-31 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1ff11133-05ff-4b0a-903e-8e02d794479d', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'db8410d0-7156-4270-8d8b-51dd33d6d007', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-02-02 08:17:00+00', '2026-11-09 20:29:57.747969+00', '2024-02-02 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('694d51f0-c69e-4765-b1e0-b38beb3bb0f6', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '942e35ad-571a-4c9b-91f4-99ca1f520882', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-03-02 09:24:00+00', '2026-11-09 20:29:57.751896+00', '2024-03-02 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('04e21747-3ca9-437b-b7f9-9db5b555ef5c', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ebcb5606-40fd-4e50-aaab-7b9489cbd63c', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-03-04 10:31:00+00', '2026-11-09 20:29:57.755786+00', '2024-03-04 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7e303255-f43b-4def-8e80-12d1103c0629', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f8aa6bcb-17ff-4bfe-8f03-61778ceaf86a', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-04-04 11:38:00+00', '2026-11-09 20:29:57.760634+00', '2024-04-04 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b5b218e9-b234-40e0-bd69-b7659e93af5d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f95dddbd-0591-4827-b835-615fcddeb437', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e71c43d3-78b3-4b88-9753-9592a50b8018', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-04-06 12:45:00+00', '2026-11-09 20:29:57.764859+00', '2024-04-06 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('98c2e6f3-0ca4-4c87-bd73-f523cbf36bdd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e9b95f9b-4a17-44a0-bc6b-29057b30aded', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-05-05 13:52:00+00', '2026-11-09 20:29:57.769386+00', '2024-05-05 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('26875822-d6cc-4e9c-aa91-c00bf88cc352', '00e8db4f-deff-45c2-82ee-95c459b73161', '610fdfe8-a330-4661-884e-3a0ee4127d92', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd23dd38c-fbaf-468d-9f03-b005e82c0c57', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-05-07 14:59:00+00', '2026-11-09 20:29:57.773804+00', '2024-05-07 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5dfa36d8-a859-4418-9db4-27d89dd6713c', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '022f59c5-a682-462c-b57a-34b217de93fe', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-05-09 15:06:00+00', '2026-11-09 20:29:57.777829+00', '2024-05-09 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cf4d49e3-f5f4-4fc4-bc2b-264105f4092e', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '30a87ae0-c34e-4655-8d55-fb65adeb991c', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-06-07 16:13:00+00', '2026-11-09 20:29:57.780883+00', '2024-06-07 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8446ec62-f3a7-4b5f-8bb9-8dc829223e3c', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e295992c-ea14-49e2-8aab-fed22d0655e0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-06-09 07:20:00+00', '2026-11-09 20:29:57.784219+00', '2024-06-09 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cf6662c1-1a97-4440-b618-9c9579f19eb1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '4d5e0982-5d07-49c7-bcf3-d380b35f5345', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-07-10 08:27:00+00', '2026-11-09 20:29:57.788357+00', '2024-07-10 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b2d7dc41-68cb-46b5-850c-6116827f0614', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '2a03dd5b-1578-4e3f-a40e-263dc8221630', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-07-12 09:34:00+00', '2026-11-09 20:29:57.798931+00', '2024-07-12 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('54fed287-01ff-4244-b7aa-6478dc9ec4a2', '00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd771a98b-99ee-4453-b88c-9efd33c8a944', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-08-10 10:41:00+00', '2026-11-09 20:29:57.804801+00', '2024-08-10 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('32437d14-8777-4f50-8392-057cee396a37', '00e8db4f-deff-45c2-82ee-95c459b73161', '610fdfe8-a330-4661-884e-3a0ee4127d92', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '386edf18-28e3-4599-8102-95e10f1b03e0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-08-12 11:48:00+00', '2026-11-09 20:29:57.809344+00', '2024-08-12 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e197297e-205b-46d2-9e7d-13b456d2a3e9', '00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '52b58422-6b52-4161-98d0-6009b4db1fd2', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-08-14 12:55:00+00', '2026-11-09 20:29:57.814997+00', '2024-08-14 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9f65fc49-fd29-4c3d-b767-f1e7a0739904', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c1fd02d3-898f-4f1f-8f4e-6efc127eefd6', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-09-12 13:02:00+00', '2026-11-09 20:29:57.820841+00', '2024-09-12 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('22106b74-0268-47ef-9f51-7f9e1b0c1b1e', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c6746b2c-291d-46d0-82d1-3ae742828b7c', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-09-14 14:09:00+00', '2026-11-09 20:29:57.825798+00', '2024-09-14 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bfd78c2e-6cbe-416b-b5ae-1c4b446c2d3f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '07761b98-e4d4-4e77-b078-c52f9656f039', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-10-15 15:16:00+00', '2026-11-09 20:29:57.829996+00', '2024-10-15 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cb750b4e-59ee-4462-b62d-48703f54fafc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '45917e2c-7746-4525-8c04-7abe599b6516', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-10-17 16:23:00+00', '2026-11-09 20:29:57.834206+00', '2024-10-17 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('495e3f6a-b8c6-467f-b0c8-32c8987a14f1', '00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f7a9ce61-45d0-42ff-89da-0e4b45577575', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-11-15 07:30:00+00', '2026-11-09 20:29:57.839255+00', '2024-11-15 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f10ef136-2bec-4ffb-8973-c7d3d4363a0c', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'afa8df66-104b-4212-8a38-ea7a4d4b66c3', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-11-17 08:37:00+00', '2026-11-09 20:29:57.84443+00', '2024-11-17 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1366e497-45f0-4c11-8ffd-9ce1ca72a125', '00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '3069036f-d8a3-44b6-9d81-5704d6d2c6b3', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-11-19 09:44:00+00', '2026-11-09 20:29:57.849799+00', '2024-11-19 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c4247a2c-0759-4dc2-a25c-b2a24393dd5d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dc652b43-dc3a-429f-bc55-63cadcd9f58f', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '1a186a27-71c3-4c04-b816-8bcec8833feb', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-12-18 10:51:00+00', '2026-11-09 20:29:57.85426+00', '2024-12-18 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7f50c792-72db-41b6-abfd-eaa4520690d0', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8d39ef1b-7999-449a-9bf2-2ae52b52c669', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2024-12-20 11:58:00+00', '2026-11-09 20:29:57.858572+00', '2024-12-20 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('65e94095-ff38-4971-989c-552179295d1a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9b19623d-e563-438c-958d-a1eec11fd267', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-01-20 12:05:00+00', '2026-11-09 20:29:57.862583+00', '2025-01-20 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('22b43036-6cec-4505-9c4c-dbdf8e73fc47', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '34d02e01-2972-4ce2-addd-81a8ac11e8b8', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-01-22 13:12:00+00', '2026-11-09 20:29:57.865913+00', '2025-01-22 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e725267e-0f0d-4ff7-9152-5e38f50aa17c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9fb8e257-7362-4222-997f-0fc95090dcb4', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-02-20 14:19:00+00', '2026-11-09 20:29:57.870099+00', '2025-02-20 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('25e131ad-9e76-4ea3-9932-ce440e7890fe', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '011d32dd-38a9-465f-9ba6-0fe342802bd0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-02-22 15:26:00+00', '2026-11-09 20:29:57.874569+00', '2025-02-22 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3ae27784-0ee6-4906-a453-ccdc93d293f3', '00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bd0741bd-810e-41cd-ad45-7762c91d2fd4', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-02-24 16:33:00+00', '2026-11-09 20:29:57.880078+00', '2025-02-24 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('16c912d5-3e73-47b3-a4fd-5dc4621fc83d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b2b64f94-50c4-4a0f-b3e4-2d16695ac6be', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-03-25 07:40:00+00', '2026-11-09 20:29:57.885326+00', '2025-03-25 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('6cd6244e-cf0c-4a26-97d0-06052cf2d852', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd49aa050-7a9b-4107-bf8d-d494ead846fd', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-03-27 08:47:00+00', '2026-11-09 20:29:57.890986+00', '2025-03-27 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2b891c06-2180-4957-9890-25818c89a46b', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '55b58aad-3800-4b0a-abcd-ca28b4ad823e', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-04-27 09:54:00+00', '2026-11-09 20:29:57.897546+00', '2025-04-27 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('28e8e448-f240-4f1d-9565-43362c685ada', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'eeed5c38-4c33-4027-b0fe-f243a74bd2ea', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-04-29 10:01:00+00', '2026-11-09 20:29:57.902141+00', '2025-04-29 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('59f049c6-9450-4336-b31c-951cc4aecc2c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c6df73d2-2857-47df-8f94-c5dde904f55d', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-05-28 11:08:00+00', '2026-11-09 20:29:57.906313+00', '2025-05-28 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('29c473b2-dfee-4cbe-9d85-2f685d4d52a0', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '48241c33-1ae1-4823-903b-ad5a99364c18', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-05-30 12:15:00+00', '2026-11-09 20:29:57.910447+00', '2025-05-30 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d2ddbee8-9e26-4c72-858b-aa4f029faa3a', '00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '318e127f-c854-457b-bc88-feda72c18dff', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-06-01 13:22:00+00', '2026-11-09 20:29:57.914622+00', '2025-06-01 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e70e0fea-12d8-4ef7-bdf5-9d2c78122916', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a3ec8b27-9e92-4b14-95c6-56f2d6152b6a', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-06-30 14:29:00+00', '2026-11-09 20:29:57.919789+00', '2025-06-30 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('67d9a37c-cd93-423f-8461-01def620a446', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '087c7063-7b81-4f9b-8d30-d145dfb70ea7', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-07-02 15:36:00+00', '2026-11-09 20:29:57.925224+00', '2025-07-02 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('31fd30e7-ba14-4ac6-869f-ce7adaa8e532', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e2c336b3-2a37-48d2-9b42-41124eba8b82', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-08-02 16:43:00+00', '2026-11-09 20:29:57.930132+00', '2025-08-02 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f912c31b-3c8e-4575-9dda-2d11261cb498', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '347c13ff-7d94-4a53-80ac-7b964e3be112', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-08-04 07:50:00+00', '2026-11-09 20:29:57.935147+00', '2025-08-04 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4137e814-6ace-4075-96d3-0e16d5f7c6ad', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', NULL, '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'aff3912f-5db9-41e4-af46-dd0372079953', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-09-02 08:57:00+00', '2026-11-09 20:29:57.939657+00', '2025-09-02 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cfa40ffe-5bff-4f5a-aef4-c2c71e2cfbd0', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '37f740b6-e4a3-43dc-b70d-2aea558cc3e4', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-09-04 09:04:00+00', '2026-11-09 20:29:57.944043+00', '2025-09-04 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('77b5dd47-92f3-4992-a0ac-39836fba67e1', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '78d9e7b3-980a-4ae2-a8cb-f6980183282f', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-09-06 10:11:00+00', '2026-11-09 20:29:57.948574+00', '2025-09-06 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('102a9a02-4c37-48a0-adc2-e292a707eecc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '849644e5-32f2-46af-998f-ecfe23b4f828', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-10-05 11:18:00+00', '2026-11-09 20:29:57.952642+00', '2025-10-05 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('13337fe1-6b09-424f-88ca-08557b0b74f4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '087b5e83-5a7b-4c81-bffa-504fdbeeec54', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-10-07 12:25:00+00', '2026-11-09 20:29:57.956885+00', '2025-10-07 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c3e6dc9e-5e98-4382-b624-db7321bdd61b', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '92722a6f-84a6-4f15-a4ad-490c5281de17', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-11-07 13:32:00+00', '2026-11-09 20:29:57.961826+00', '2025-11-07 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('482138b2-1d6c-43d2-8a22-b46ae28cc496', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '5b552402-defb-4593-9817-ee940cf697db', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-11-09 14:39:00+00', '2026-11-09 20:29:57.965708+00', '2025-11-09 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('17d99510-7c3a-4def-b2e0-cbd2f6ccc9c2', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', NULL, 'f8ae04f7-198a-43c9-b801-a3d211d9800a', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bd563cb7-7dcc-479a-bbcc-cbe4d076d631', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-12-08 15:46:00+00', '2026-11-09 20:29:57.969171+00', '2025-12-08 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('83d55463-04a0-4b3d-8f5a-b1cd0b4f7383', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, '01db1d75-57a3-4cd9-b50c-dbb6b662fb12', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6f502b40-a6ed-4098-ac5f-96e3f615af0b', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-12-10 16:53:00+00', '2026-11-09 20:29:57.974179+00', '2025-12-10 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('96c8efa3-4609-42de-a84a-187975bae6ff', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '8ed4a10a-7a2b-4393-9ad2-1706e99e2bec', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2025-12-12 07:00:00+00', '2026-11-09 20:29:57.978642+00', '2025-12-12 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('077f42b1-64a5-4a64-8cdb-bded24d52d49', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 'c2c2653b-c961-4e10-93e6-665780ad0903', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '67016547-c45a-40e1-947b-fd096f6181ad', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-01-10 08:07:00+00', '2026-11-09 20:29:57.982856+00', '2026-01-10 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('97a1758e-92f7-4a6c-8059-f3137b5a4c59', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c31b5ec9-662f-45c4-83cc-586469efd1a3', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-01-12 09:14:00+00', '2026-11-09 20:29:57.986915+00', '2026-01-12 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('31535a80-3e12-40ce-83a1-9c6e91d0b1c6', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '84135746-f479-4fdb-83d0-8aeea1e48f3c', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-02-12 10:21:00+00', '2026-11-09 20:29:57.9908+00', '2026-02-12 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fbd51ca7-ad01-487a-b24d-03570c9b499d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aa9e1eee-bcc1-4228-a898-3ebdb3f79732', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ae2a6b53-eb54-4cac-86ad-df0144f376b2', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-02-14 11:28:00+00', '2026-11-09 20:29:57.995056+00', '2026-02-14 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('44364804-1ea8-4cc7-82fd-32addb6b659a', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c1acf8bf-cf81-4a80-ae41-08d61a574810', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-03-15 12:35:00+00', '2026-11-09 20:29:58.000785+00', '2026-03-15 12:35:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cc38c666-b1ff-4918-b69a-8634998eaa80', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'bf307f6c-4919-4497-8970-e4e55cc0d88a', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-03-17 13:42:00+00', '2026-11-09 20:29:58.00749+00', '2026-03-17 13:42:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a10b9a2a-05c4-4689-a5cf-d66d9ebd0be2', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c0be7cca-7cd4-4b44-a7ee-953e2261c9ae', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-03-19 14:49:00+00', '2026-11-09 20:29:58.013601+00', '2026-03-19 14:49:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9faeb075-bf8d-4287-a0b2-31d9e461833a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ddc64060-32d3-4c0d-a479-ad7d7d22bfd2', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-04-17 15:56:00+00', '2026-11-09 20:29:58.018558+00', '2026-04-17 15:56:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e928a6a4-1804-4ba8-9096-3ab3494701e3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9e0c155e-9d0f-4884-9ec3-ce8e4b14c519', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-04-19 16:03:00+00', '2026-11-09 20:29:58.024433+00', '2026-04-19 16:03:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c3018c53-fe6f-43e5-aa68-1dae0046acf7', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, '6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6948263c-e76b-4cb4-a785-690378e874bd', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-04-21 07:10:00+00', '2026-11-09 20:29:58.028621+00', '2026-04-21 07:10:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cd8387b7-0ee3-469b-990c-635264a3d0c7', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'd7ea48e5-040d-490d-98bf-464ae6ffaf0a', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-05-20 08:17:00+00', '2026-11-09 20:29:58.031843+00', '2026-05-20 08:17:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('582c0ac0-06b2-444a-b75b-dc7910a567a7', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '9985b1fe-f85b-4d99-a355-1119714698cf', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-05-22 09:24:00+00', '2026-11-09 20:29:58.036259+00', '2026-05-22 09:24:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('9f63e79b-8169-4ccd-a0ff-38f0e285cc95', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', NULL, '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f209851d-1c68-4b70-938b-d2103b646e6f', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-06-20 10:31:00+00', '2026-11-09 20:29:58.041044+00', '2026-06-20 10:31:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a52968b1-ad4c-4d36-898a-2bf0a5b1f080', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, '3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a362692f-b98c-4242-bd1e-11a643b19c43', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-06-22 11:38:00+00', '2026-11-09 20:29:58.045282+00', '2026-06-22 11:38:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('009acd9e-d39d-49b2-95af-77ae3c226d2c', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'aed95fa2-cc7d-413f-a427-fd0c8c237974', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-06-24 12:45:00+00', '2026-11-09 20:29:58.04908+00', '2026-06-24 12:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('613508ff-80f2-45e6-a5ad-b191b84f75ea', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, '3f490bb0-1c52-477c-8892-8f2d1d274ee9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '761da475-b617-4421-9005-cfc23d7e67c8', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-07-23 13:52:00+00', '2026-11-09 20:29:58.053633+00', '2026-07-23 13:52:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('810d6b26-b26d-4466-bfc3-2b63adb30c2c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 'b94369de-1676-42e5-998c-4be2391acbf9', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '48465e17-0a15-4f8c-8dfa-cecdd9609e42', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-07-25 14:59:00+00', '2026-11-09 20:29:58.057733+00', '2026-07-25 14:59:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('7c1da0a5-2017-49b3-a400-2a4db02d3169', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 'd07c10ee-54d0-48aa-b18b-f2d51881e219', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '6923a9ed-5b2b-4c80-b3cd-0fce93df9fda', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-07-27 15:06:00+00', '2026-11-09 20:29:58.062048+00', '2026-07-27 15:06:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('02e4e657-7759-4ea2-b229-769a6d4814db', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, '66eea498-a873-404c-9657-e5c94d678571', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e1c918ec-5b25-4818-a5cc-6d5f20bddf16', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-08-25 16:13:00+00', '2026-11-09 20:29:58.067438+00', '2026-08-25 16:13:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3e67a065-6e8a-46fa-a9c6-12b6c779ef44', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'b45426c0-1f04-4ae4-9f35-bad0fa55e3ff', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-08-27 07:20:00+00', '2026-11-09 20:29:58.071009+00', '2026-08-27 07:20:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0788a014-3051-4e1e-b9f8-6d7e482cd6f0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', NULL, 'e7ed7113-f029-424f-94b8-a98a1d53f7a1', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '31cef3e2-6b3f-4cea-b6ed-8fd3cffcd664', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-25 08:27:00+00', '2026-11-09 20:29:58.075515+00', '2026-09-25 08:27:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('28c0e139-4451-46f0-a5b5-bec0ef7a4c5b', '00e8db4f-deff-45c2-82ee-95c459b73161', '57e2ea5f-d739-4260-8c8b-8cdd0cd54dc1', NULL, 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '27599b96-532e-4b0a-afda-a84db42e3c1d', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-02 09:34:00+00', '2026-11-09 20:29:58.080533+00', '2026-11-02 09:34:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2e9c79fc-02bd-4377-93a2-387dd4a448af', '00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', 5.300, NULL, NULL, NULL, 'done', 'opening_balance', 'd1f69a69-f2ba-41bf-ae34-8c8a1796892e', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-06 10:41:00+00', '2026-11-09 20:29:58.086796+00', '2026-11-06 10:41:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('bed8125b-0ee7-4a6e-91a6-1a8952c55e99', '00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', NULL, '8f446de5-a0e0-4514-832b-2d68c13476d6', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '6d570bbf-99bc-4cbf-8eff-9f1ab7015340', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-11 11:48:00+00', '2026-11-09 20:29:58.093969+00', '2026-10-11 11:48:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2f89de73-1aa1-488c-9d84-3e7ca171f652', '00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', NULL, '85b351d5-711b-47d4-b174-83619236e876', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'af7aed07-4c92-466e-888b-28220c9caae4', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-30 12:55:00+00', '2026-11-09 20:29:58.100371+00', '2026-09-30 12:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('29b57062-ee7a-415f-919f-0e67b8859bd6', '00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', NULL, 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '590d6574-c241-41cc-b235-f024204246f0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-19 13:02:00+00', '2026-11-09 20:29:58.107546+00', '2026-09-19 13:02:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ac49496c-f229-467a-860d-ec9a18ec7195', '00e8db4f-deff-45c2-82ee-95c459b73161', '0bb26ced-1dd3-49a2-b332-55821cdf35d3', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 7.400, NULL, NULL, NULL, 'done', 'opening_balance', '2142d4c5-c745-4da3-ba2b-522dea360662', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-08 14:09:00+00', '2026-11-09 20:29:58.114078+00', '2026-11-08 14:09:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c200bc2c-dd20-4cff-9cf2-446df6de87a4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b60b93d0-b081-409f-a1df-80afe614f544', NULL, '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '8e4b421b-8db9-47fe-95c2-298c20e26bef', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-03 15:16:00+00', '2026-11-09 20:29:58.118855+00', '2026-11-03 15:16:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('902cdd3b-1bbd-4d0b-b4b2-b974c3c063ea', '00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 2.700, NULL, NULL, NULL, 'done', 'opening_balance', '82a14573-efea-4d8a-95a4-e28e1a52b3d9', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-03 16:23:00+00', '2026-11-09 20:29:58.123404+00', '2026-11-03 16:23:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e349434e-701f-4fe7-afc5-1b0c80272dca', '00e8db4f-deff-45c2-82ee-95c459b73161', '9ee9b559-ea52-4db7-a2e4-28eaaf3d6b81', NULL, '8f446de5-a0e0-4514-832b-2d68c13476d6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a4a583f2-fc6e-4990-9299-4f46ef981147', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-09 07:30:00+00', '2026-11-09 20:29:58.127894+00', '2026-10-09 07:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('48d2bea1-9bd8-4d09-abe0-a34e849a6820', '00e8db4f-deff-45c2-82ee-95c459b73161', '2311d6c3-afc7-4dc8-9c71-5955220d6e31', NULL, '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a7d22330-b3f3-4692-98d1-687b231d4034', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-28 08:37:00+00', '2026-11-09 20:29:58.13269+00', '2026-09-28 08:37:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('a0573dec-cb3b-4725-a607-499138c00974', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c3a351db-b74d-4190-a870-332727da317f', NULL, 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '9b04930c-a0ee-44dd-a50e-c079dd073a5d', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-17 09:44:00+00', '2026-11-09 20:29:58.13757+00', '2026-09-17 09:44:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cc24a9ba-adfa-418a-880d-6a698c53a41b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'eb9b9ca0-46c5-4914-a914-c1dd7b1d6c0c', NULL, '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 8.200, NULL, NULL, NULL, 'done', 'opening_balance', 'a01590cc-6be6-4608-9cbd-9e3958459560', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-03 10:51:00+00', '2026-11-09 20:29:58.141972+00', '2026-11-03 10:51:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('5b7a6e53-04a9-4b4d-8674-e9578369f46b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a288952d-aa29-4152-99bb-2eadf7b78e9d', NULL, '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f1ede2b0-da84-44f2-8371-aed679b94426', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-29 11:58:00+00', '2026-11-09 20:29:58.146537+00', '2026-10-29 11:58:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d0020da5-ae8d-4052-b39a-5192f6ec58ed', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', NULL, '73869395-0caf-4783-a71d-e5ab311d279a', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '70b52e46-cddf-4527-a5ce-f8d1de53e3e0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-04 12:05:00+00', '2026-11-09 20:29:58.15167+00', '2026-11-04 12:05:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e647ac51-ace9-4037-8f55-3de61e80c377', '00e8db4f-deff-45c2-82ee-95c459b73161', '0624e122-2b53-43dc-9404-ac9614dd0b43', NULL, '866b2db9-f86e-4955-8198-0d499f3e5025', 9.000, NULL, NULL, NULL, 'done', 'opening_balance', '9100ddeb-e20b-40e1-8cad-31bf4dff3b34', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-07 13:12:00+00', '2026-11-09 20:29:58.156516+00', '2026-10-07 13:12:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f9a8f268-52f8-4d34-a06f-6ca582d5d565', '00e8db4f-deff-45c2-82ee-95c459b73161', '349c83b7-b912-4814-8249-84962e8119fd', NULL, '8f446de5-a0e0-4514-832b-2d68c13476d6', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '2489e68f-d8f9-4de3-a661-cce7220413f5', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-26 14:19:00+00', '2026-11-09 20:29:58.161727+00', '2026-09-26 14:19:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('dfd5d305-d4ee-4065-a094-c8459661f26a', '00e8db4f-deff-45c2-82ee-95c459b73161', '6e1acfb0-89c6-47f3-89e9-5817114a77fe', NULL, '471ef176-3922-44c1-9239-e42b8ca3f0ee', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '2a892d0e-bba1-487a-b61d-0af9b6435786', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-15 15:26:00+00', '2026-11-09 20:29:58.166251+00', '2026-09-15 15:26:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('afe676e6-67d8-46d8-bcc3-9dca843f5b90', '00e8db4f-deff-45c2-82ee-95c459b73161', '685830c5-bf5f-4c1e-8eec-4fa61755aff9', NULL, '8f446de5-a0e0-4514-832b-2d68c13476d6', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '9f888545-abf1-44c5-ae38-151c4522f0d2', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-04 16:33:00+00', '2026-11-09 20:29:58.170607+00', '2026-09-04 16:33:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c301aefd-e603-4857-8949-5bc8d8200321', '00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', NULL, '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', 'a4d38a29-3a08-4915-b55c-33749b590c6f', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-27 07:40:00+00', '2026-11-09 20:29:58.17476+00', '2026-10-27 07:40:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('603fd533-2c7f-426b-9eda-b669398f4810', '00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', NULL, '88658701-75a4-4a06-9d85-62f32417ca68', 2.300, NULL, NULL, NULL, 'done', 'opening_balance', '418a3d19-11bf-415e-87da-c67bead70780', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-07 08:47:00+00', '2026-11-09 20:29:58.180262+00', '2026-11-07 08:47:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('8161de9d-310d-4f80-baa8-5d4d30ffaba9', '00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', NULL, '7c9ef099-d7e7-43b1-a405-3e3a232272b0', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '32346049-1904-4386-8864-c8c6e5d86e7f', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-05 09:54:00+00', '2026-11-09 20:29:58.186499+00', '2026-10-05 09:54:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('544be808-6cca-4e3a-b9ad-6c6f5a449259', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', NULL, '2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fdd5d3e6-d7a4-4e5a-b3d7-57bfca6ecab6', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-24 10:01:00+00', '2026-11-09 20:29:58.191511+00', '2026-09-24 10:01:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('02b08329-57ef-4784-8643-382a93b602a6', '00e8db4f-deff-45c2-82ee-95c459b73161', '787cd292-d3ef-4678-a6c8-91df9da2727e', NULL, '0a2727e8-6c13-4603-93e7-89512c6d8941', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '13a10024-6548-43c5-92d5-6fb7ff338827', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-13 11:08:00+00', '2026-11-09 20:29:58.197019+00', '2026-09-13 11:08:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('2ab3c65d-58f5-45bf-b0d6-30cc88beee96', '00e8db4f-deff-45c2-82ee-95c459b73161', '611cf45d-7d37-4357-9110-cd0a47a192e1', NULL, '66ee606c-e95d-4547-920f-fb79bb6d8759', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', '5801179e-c321-4d5e-8635-db263cf85837', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-02 12:15:00+00', '2026-11-09 20:29:58.202273+00', '2026-09-02 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('37cdab35-7f95-4da5-8e09-3c0e0fe1361c', '00e8db4f-deff-45c2-82ee-95c459b73161', '58353c4d-8e46-4c89-a1ff-cc78db74e5fc', NULL, '73869395-0caf-4783-a71d-e5ab311d279a', 7.600, NULL, NULL, NULL, 'done', 'opening_balance', 'eb6bce5a-d0d4-419a-bf14-12a4d288d20f', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-08 13:22:00+00', '2026-11-09 20:29:58.207094+00', '2026-11-08 13:22:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('0d39d90b-ee2d-419a-8194-a85d33a71443', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fbee3e5f-1150-494e-8a64-14f40fa58af2', NULL, '866b2db9-f86e-4955-8198-0d499f3e5025', 4.000, NULL, NULL, NULL, 'done', 'opening_balance', '97a7e448-cbe8-49cd-8d89-45b3e36ad7d0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-03 14:29:00+00', '2026-11-09 20:29:58.211595+00', '2026-10-03 14:29:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('cadcbe91-1140-41eb-b46d-702ef0c97ac1', '00e8db4f-deff-45c2-82ee-95c459b73161', '4dd93e53-5ef7-4aba-ad5d-f3ee76fe41a1', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', 10.000, NULL, NULL, NULL, 'done', 'opening_balance', 'cf1f9f51-0562-40ab-ab8d-67ec2cc3a441', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-06 15:36:00+00', '2026-11-09 20:29:58.215907+00', '2026-11-06 15:36:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f471672b-641b-48a8-8a14-b88bcd107c24', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b90fae37-b088-49c0-b137-96e942d88441', NULL, '7c9ef099-d7e7-43b1-a405-3e3a232272b0', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f48fdf7b-9547-4bbe-b66c-7b933b5fb985', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-22 16:43:00+00', '2026-11-09 20:29:58.219984+00', '2026-09-22 16:43:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e8aa78a2-68c9-4db8-b7dc-a497d4e74b71', '00e8db4f-deff-45c2-82ee-95c459b73161', '84be7ee7-1046-4de1-a2b5-e9eac6542e8c', NULL, 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 1.000, NULL, NULL, NULL, 'done', 'opening_balance', '0c4c5cc6-3318-427a-9e89-d24cd9d3475d', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-11 07:50:00+00', '2026-11-09 20:29:58.224014+00', '2026-09-11 07:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3d900ff3-21a0-4931-8526-8e3bd2ce17bb', '00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', NULL, '9ed5fc92-ea45-4e8b-9b56-9d54a2659112', 6.600, NULL, NULL, NULL, 'done', 'opening_balance', '11174d3c-0bcf-4bd0-ae2b-49b39ae77c14', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-03 08:57:00+00', '2026-11-09 20:29:58.230973+00', '2026-11-03 08:57:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('24a9fc10-ae60-4710-a171-5ffb6dec9f58', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', NULL, '8f446de5-a0e0-4514-832b-2d68c13476d6', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '0e1aea87-9473-407c-9fa8-434b8dbbd04c', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-12 09:04:00+00', '2026-11-09 20:29:58.237298+00', '2026-10-12 09:04:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f03d17a4-cff1-43de-a225-e116118d23aa', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', NULL, '73869395-0caf-4783-a71d-e5ab311d279a', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', 'fc16bf83-ef39-465e-92c2-08602cc02c52', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-08 10:11:00+00', '2026-11-09 20:29:58.243066+00', '2026-11-08 10:11:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('4ffd75ff-210c-441f-b067-6f1723d70f04', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', NULL, '866b2db9-f86e-4955-8198-0d499f3e5025', 10.000, NULL, NULL, NULL, 'done', 'opening_balance', '6dd30970-c5e1-4fd5-b511-2a29845d62ac', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-01 11:18:00+00', '2026-11-09 20:29:58.247801+00', '2026-10-01 11:18:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('59e8b6f2-7234-41f1-9e4b-48fc8a9b0f3c', '00e8db4f-deff-45c2-82ee-95c459b73161', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', NULL, '8f446de5-a0e0-4514-832b-2d68c13476d6', 3.000, NULL, NULL, NULL, 'done', 'opening_balance', '3eb0a601-f188-45d9-bda6-ffe25bddd331', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-09 12:25:00+00', '2026-11-09 20:29:58.255123+00', '2026-09-09 12:25:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('84e37058-1a90-41ef-bb4b-9810842124f2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c7486598-4240-4979-bb9e-21e57b6effe8', NULL, '66ee606c-e95d-4547-920f-fb79bb6d8759', 2.000, NULL, NULL, NULL, 'done', 'opening_balance', 'e304bd93-ca18-4f72-b946-23d570b1fbd0', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-20 13:32:00+00', '2026-11-09 20:29:58.260901+00', '2026-09-20 13:32:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('64f20454-9e4b-45ac-a7ba-56fa037f0024', '00e8db4f-deff-45c2-82ee-95c459b73161', 'beb604b5-970d-4898-a6fd-319fca3f44fb', NULL, '73869395-0caf-4783-a71d-e5ab311d279a', 7.000, NULL, NULL, NULL, 'done', 'opening_balance', '204cab04-4e3a-4e0a-9778-afb38fb32119', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-08 14:39:00+00', '2026-11-09 20:29:58.266702+00', '2026-11-08 14:39:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('724fe93d-a374-4cca-b042-75b57319f9d0', '00e8db4f-deff-45c2-82ee-95c459b73161', '7f65a62c-3ea1-4603-94f7-4d837d66dd43', NULL, '866b2db9-f86e-4955-8198-0d499f3e5025', 8.000, NULL, NULL, NULL, 'done', 'opening_balance', 'f61a7248-0e8d-4c7e-b23b-037031b0d4df', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-01 15:46:00+00', '2026-11-09 20:29:58.271358+00', '2026-11-01 15:46:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('59b90e04-0978-454a-92a8-4c1281c6b53a', '00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', NULL, '866b2db9-f86e-4955-8198-0d499f3e5025', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '1558d5e6-5200-4239-a65b-ce3beeee61c7', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-29 16:53:00+00', '2026-11-09 20:29:58.275822+00', '2026-09-29 16:53:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('e780b6d9-dece-4f5d-a334-524dfe20c191', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', NULL, '73869395-0caf-4783-a71d-e5ab311d279a', 6.000, NULL, NULL, NULL, 'done', 'opening_balance', '8e6d929b-de81-43e5-8975-d77052e39655', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-07 07:00:00+00', '2026-11-09 20:29:58.279779+00', '2026-11-07 07:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('3dfe436d-ab59-4bd1-b74c-900033195f13', '00e8db4f-deff-45c2-82ee-95c459b73161', 'bb856f1a-fcdb-4d29-b932-14925497488e', NULL, 'e03fe983-c49d-4d62-8a19-19fddaecdd89', 5.000, NULL, NULL, NULL, 'done', 'opening_balance', '730d0f53-f70d-4551-b127-cb0b61d8e4fa', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-09-18 08:07:00+00', '2026-11-09 20:29:58.284251+00', '2026-09-18 08:07:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('142780ad-7dc4-43cd-9ab1-6c6c095bbde2', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', 40.000, NULL, NULL, NULL, 'done', 'opening_balance', 'c82a3e23-85db-4275-b655-c89edaf839a5', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-06 09:14:00+00', '2026-11-09 20:29:58.288661+00', '2026-11-06 09:14:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('fe4d392a-f863-48e5-9ab5-2da8871f05f0', '00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', NULL, '85b351d5-711b-47d4-b174-83619236e876', 0.500, NULL, NULL, NULL, 'done', 'opening_balance', '017b7fd5-a2f5-4460-b1a8-14693d388e98', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-06 10:21:00+00', '2026-11-09 20:29:58.292891+00', '2026-10-06 10:21:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('c4b07cd8-2e2d-4fa3-8654-0b1dad5c2c7b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', NULL, '85b351d5-711b-47d4-b174-83619236e876', 25.000, NULL, NULL, NULL, 'done', 'opening_balance', 'ab2f3769-1eab-45fa-8139-325918662b24', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-10-20 11:28:00+00', '2026-11-09 20:29:58.299128+00', '2026-10-20 11:28:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b016a2ef-9b66-4a20-a347-87192e6aa5cc', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, 26.400, NULL, NULL, NULL, 'done', 'maker_production', '21ff6bdb-dd23-46c5-bab5-80df73db583b', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.374491+00', '2026-11-09 20:30:00.374493+00', '2026-11-09 20:30:00.374008+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b6880c8b-3dc7-4ff6-b993-8890863a9207', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', '85b351d5-711b-47d4-b174-83619236e876', NULL, 3.780, NULL, NULL, NULL, 'done', 'maker_production', '21ff6bdb-dd23-46c5-bab5-80df73db583b', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.40382+00', '2026-11-09 20:30:00.403822+00', '2026-11-09 20:30:00.403691+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('f7ddaf0d-d542-4e86-8272-0e081f1b98de', '00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', '85b351d5-711b-47d4-b174-83619236e876', NULL, 0.060, NULL, NULL, NULL, 'done', 'maker_production', '21ff6bdb-dd23-46c5-bab5-80df73db583b', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.423228+00', '2026-11-09 20:30:00.423229+00', '2026-11-09 20:30:00.42305+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('accfd433-95d1-4b5e-82c9-9ac1c68f9cb6', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', NULL, '85b351d5-711b-47d4-b174-83619236e876', 11.400, NULL, NULL, NULL, 'done', 'maker_production', '21ff6bdb-dd23-46c5-bab5-80df73db583b', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '2026-11-09 20:30:00.449287+00', '2026-11-09 20:30:00.449289+00', '2026-11-09 20:30:00.448743+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1aa03b31-05c3-4bd9-926c-88c24293fd03', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 3.000, NULL, NULL, NULL, 'done', 'document', 'bfb27ef9-b911-4140-9f94-bce736fcc3dd', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-10-23 12:15:00+00', '2026-11-09 20:30:00.973758+00', '2026-10-23 12:15:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('00d3f08c-43ad-49eb-822e-f3cfaa1adfad', '00e8db4f-deff-45c2-82ee-95c459b73161', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', 48.000, NULL, NULL, NULL, 'done', 'document', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-10-31 10:50:00+00', '2026-11-09 20:30:00.980951+00', '2026-10-31 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('063d6707-dc98-4138-ba5d-d7536e7dbc78', '00e8db4f-deff-45c2-82ee-95c459b73161', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', 24.000, NULL, NULL, NULL, 'done', 'document', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-10-31 10:50:00+00', '2026-11-09 20:30:00.980951+00', '2026-10-31 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d35d17e5-e25f-4bd3-8b57-3ec5b8f806c4', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', 36.000, NULL, NULL, NULL, 'done', 'document', '5d8b0554-af04-4d21-9239-aa6ed6aa2e52', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-10-31 10:50:00+00', '2026-11-09 20:30:00.980951+00', '2026-10-31 10:50:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('99674cb2-46b6-4b8a-83af-68f8007633b3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 60.000, NULL, NULL, NULL, 'done', 'document', '64f48cb3-a184-4e39-a210-a533ab3598d3', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-11-02 14:00:00+00', '2026-11-09 20:30:00.983016+00', '2026-11-02 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('d2097ab2-4c8c-4a8f-851b-5bb2e9e3309d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fa748810-6265-493f-a360-df817a409794', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', 20.000, NULL, NULL, NULL, 'done', 'document', '64f48cb3-a184-4e39-a210-a533ab3598d3', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-11-02 14:00:00+00', '2026-11-09 20:30:00.983016+00', '2026-11-02 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('033a9d6c-0259-4de8-b331-5def18a239ff', '00e8db4f-deff-45c2-82ee-95c459b73161', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, 12.000, NULL, NULL, NULL, 'done', 'document', 'ad73fd07-f37d-4e7e-9f1b-876850e847fe', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-05 13:30:00+00', '2026-11-09 20:30:00.984673+00', '2026-11-05 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('287b8add-ec90-49e7-bb07-39048e517504', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, 8.000, NULL, NULL, NULL, 'done', 'document', 'ad73fd07-f37d-4e7e-9f1b-876850e847fe', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-05 13:30:00+00', '2026-11-09 20:30:00.984673+00', '2026-11-05 13:30:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('ba159764-5b91-4c14-9b9f-af12e92f66fd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 5.000, NULL, NULL, NULL, 'done', 'document', 'a9f9e490-e1d9-4580-9d28-ce03dd1368a4', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-07 14:00:00+00', '2026-11-09 20:30:00.987445+00', '2026-11-07 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('95e03bc6-918a-43f4-a6c6-cecf2a0a149d', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', NULL, '9fc409ab-02e4-45f0-a6a8-55344aafe2e0', 3.000, NULL, NULL, NULL, 'done', 'document', 'a9f9e490-e1d9-4580-9d28-ce03dd1368a4', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-07 14:00:00+00', '2026-11-09 20:30:00.987445+00', '2026-11-07 14:00:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b1a7b3e9-5bce-46e7-86f0-ef3b4af0ec33', '00e8db4f-deff-45c2-82ee-95c459b73161', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, 6.000, NULL, NULL, NULL, 'done', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-08 14:45:00+00', '2026-11-09 20:30:00.98972+00', '2026-11-08 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('b88b8ef1-a734-49ad-9343-830bb1e17022', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL, 4.000, NULL, NULL, NULL, 'done', 'document', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 'f513905d-ce7d-43a4-a772-b43279005f82', '2026-11-08 14:45:00+00', '2026-11-09 20:30:00.98972+00', '2026-11-08 14:45:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('91b40fe7-99ce-43aa-8140-538928a0b8e4', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, 10.000, NULL, NULL, NULL, 'done', 'document', '8a59913a-b433-4654-8783-6a3e9994e96f', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-11-08 15:55:00+00', '2026-11-09 20:30:00.991952+00', '2026-11-08 15:55:00+00');
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, owner_id, expiry_date, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at) VALUES ('1917c3a9-ed28-4f08-9f41-9141bac4ecfa', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fa748810-6265-493f-a360-df817a409794', '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL, 5.000, NULL, NULL, NULL, 'done', 'document', '8a59913a-b433-4654-8783-6a3e9994e96f', '6e228bca-4488-4535-9fd3-0d4b0549bd49', '2026-11-08 15:55:00+00', '2026-11-09 20:30:00.991952+00', '2026-11-08 15:55:00+00');


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('612df169-535f-477e-a332-33e8e96300c6', '00e8db4f-deff-45c2-82ee-95c459b73161', '628ec398-1bcf-4792-be3f-ee3398c39d0f', '479572ab-8e0f-475b-8d71-c84c435589d7', 'cf909942-3c32-45ca-841d-bcfc2f53efb3', NULL, NULL, 10.000, '2026-11-09 20:29:58.869659+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('e6cd6c71-a98b-4c3e-b004-92f37b95462e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dd7d86fb-48bc-489a-8c5e-c5dc7c46e7cb', '33100d3c-ff80-4635-8b55-8c93a51a1e47', 'cf909942-3c32-45ca-841d-bcfc2f53efb3', NULL, NULL, 8.000, '2026-11-09 20:29:58.971363+00');
INSERT INTO public.stock_reservations (id, organization_id, document_id, document_line_id, anchor_id, lot_id, owner_id, quantity, created_at) VALUES ('d037ba49-157b-49a5-865d-5fad5aa34cae', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dd7d86fb-48bc-489a-8c5e-c5dc7c46e7cb', '5ee4ebf4-cb1a-4c66-9c5e-5cc42dcb3997', '12ea29f6-57cb-4063-b024-f65a8b5279a3', NULL, NULL, 4.000, '2026-11-09 20:29:58.980429+00');


--
-- Data for Name: stock_take_closed_locations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_counts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('cb46fc05-e286-42d9-8c1b-1bb5e2a6cb0a', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', '27599b96-532e-4b0a-afda-a84db42e3c1d', 'Coffee Beans', 'Orchard & Oak', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, 5.000, 4.000, NULL, NULL, NULL, 1, '2026-11-09 20:30:00.487425+00', '2026-11-09 20:30:00.487427+00', 'MISCOUNT', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('ac561105-98af-4d25-8da0-8b9329995b40', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', '6d570bbf-99bc-4cbf-8eff-9f1ab7015340', 'Almonds', 'Green Acre', '917304cd-586e-45cc-9900-313855f42a9b', NULL, NULL, 5.000, 5.000, NULL, NULL, NULL, 0, '2026-11-09 20:30:00.487429+00', '2026-11-09 20:30:00.48743+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('f4f61fd2-44db-47e3-b99c-813f14ac8e58', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', 'af7aed07-4c92-466e-888b-28220c9caae4', 'Almonds', 'Green Acre', '917304cd-586e-45cc-9900-313855f42a9b', NULL, NULL, 3.000, 3.000, NULL, NULL, NULL, 0, '2026-11-09 20:30:00.48743+00', '2026-11-09 20:30:00.487431+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('e9879989-c549-4b54-95a9-b5c3e712a801', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', '590d6574-c241-41cc-b235-f024204246f0', 'Granulated Garlic', 'Saltmill', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, 7.000, 5.000, NULL, NULL, NULL, 1, '2026-11-09 20:30:00.487432+00', '2026-11-09 20:30:00.487432+00', 'DAMAGE', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('7ec3a3fc-d3fc-475f-baf7-bd2c8de23418', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', 'a4a583f2-fc6e-4990-9299-4f46ef981147', 'Dark Chocolate 85%', 'Orchard & Oak', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, 1.000, 1.000, NULL, NULL, NULL, 0, '2026-11-09 20:30:00.487433+00', '2026-11-09 20:30:00.487434+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('f27e5788-7cef-4d36-93fb-0f0f080d7d61', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', 'a7d22330-b3f3-4692-98d1-687b231d4034', 'Canned White Beans', 'Harvest Row', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, 2.000, 3.000, NULL, NULL, NULL, 1, '2026-11-09 20:30:00.487435+00', '2026-11-09 20:30:00.487435+00', 'WRONG_LOCATION', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('900aaa72-4977-41d4-be37-414d303fb943', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', '9b04930c-a0ee-44dd-a50e-c079dd073a5d', 'Penne Pasta', 'Harvest Row', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, 7.000, 7.000, NULL, NULL, NULL, 0, '2026-11-09 20:30:00.487436+00', '2026-11-09 20:30:00.487437+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('28346a57-592a-4d3d-b481-713ec0200d06', 'f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', 'f1ede2b0-da84-44f2-8371-aed679b94426', 'Jasmine Rice 1kg', 'Harvest Row', '6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, NULL, 1.000, 1.000, NULL, NULL, NULL, 0, '2026-11-09 20:30:00.487437+00', '2026-11-09 20:30:00.487438+00', NULL, false, NULL, NULL);


--
-- Data for Name: stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_takes (id, user_id, organization_id, storage_location_id, name, description, status, started_at, completed_at, notes, blind_mode, require_full_count, tolerance_percent, deleted_at, created_at, updated_at, schedule_id, adjustment_document_id) VALUES ('f6bc8c84-9d9d-47a1-8071-4b3ee0c29588', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'Dry Goods count', 'Quarterly count of the dry goods shelves.', 'completed', '2026-11-06 18:30:00.484087+00', '2026-11-06 20:30:00.484096+00', NULL, false, true, 2.00, NULL, '2026-11-09 20:30:00.48493+00', '2026-11-09 20:30:00.611501+00', NULL, NULL);


--
-- Data for Name: stock_valuation_layers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('138c788f-0c92-4743-a493-9c58f7a4f1d8', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2023-09-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.70059+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d773a85e-e743-4189-9ed7-bdc8db36c897', '00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2023-09-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.708429+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2ae3bf6c-2dbb-48b1-b1f3-9da107146bad', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2023-10-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.71432+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('32b6c1ee-9d3f-48db-b72d-256484fcbab8', '00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2023-10-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.718711+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aee4ab87-19b3-4b85-b0fc-87a743967950', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2023-10-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.723188+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('76da649f-d2b3-4cc9-bb14-f8f5879d34e6', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2023-11-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.727351+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('54872787-b1df-4074-8a09-328f309c2710', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2023-11-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.731292+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('a544b115-9165-4306-b050-c6975c4997ad', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2023-12-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.734718+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8c845dc6-ee2c-4f01-b1b3-496444225f64', '00e8db4f-deff-45c2-82ee-95c459b73161', '9415af05-c7ea-4044-a47c-73918712aca5', NULL, 1.000, 1.000, 28000.0000, 28000.00, '2023-12-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.738312+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('10fee0a8-a019-47cb-91da-4f03414680aa', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2024-01-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.742211+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3a09ff8f-5c15-4e16-a2e4-479dcc26849e', '00e8db4f-deff-45c2-82ee-95c459b73161', '9025d321-5ecd-4d2b-939d-925f457f8b9e', NULL, 1.000, 1.000, 8500.0000, 8500.00, '2024-01-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.746149+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('73452fc8-fe9c-4bae-bc66-ef52d16a5330', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-02-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.750084+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('608c0b72-9e87-4b61-b35b-ec75f5ea6db6', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2024-03-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.75395+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('50d6054a-1c90-40f7-833f-7d94ee952dfb', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-03-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.758479+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d6c599cd-e238-48fe-b3c5-160cd839353e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2024-04-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.762916+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('17b09e5b-578b-4e7e-9669-2057f00e4fc1', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f95dddbd-0591-4827-b835-615fcddeb437', NULL, 1.000, 1.000, 650.0000, 650.00, '2024-04-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.767179+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e8f6d005-84ba-423f-8230-2a0db83332c8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2024-05-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.771809+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7cc80088-afeb-4e81-89b7-3928d45fb119', '00e8db4f-deff-45c2-82ee-95c459b73161', '610fdfe8-a330-4661-884e-3a0ee4127d92', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2024-05-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.775959+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c42f3860-8d95-462b-ade6-4bf3968183e0', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-05-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.779815+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ba0e55d9-cda5-44b0-9c17-510da91781c4', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2024-06-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.78311+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('16e40ccd-b12c-47aa-9a83-064a863f3061', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2024-06-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.787009+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('06674cd6-56f0-4f10-8cac-f891e1877dcb', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2024-07-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.796061+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9f9c3269-4d96-403d-b61d-f592b5ac6b49', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', NULL, 1.000, 1.000, 350.0000, 350.00, '2024-07-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.802129+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3c9f1bd7-0737-4593-8088-e0b14bc2753b', '00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-08-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.807857+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('70b116de-df3a-4040-b4b9-eef4a0245069', '00e8db4f-deff-45c2-82ee-95c459b73161', '610fdfe8-a330-4661-884e-3a0ee4127d92', NULL, 1.000, 1.000, 3400.0000, 3400.00, '2024-08-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.812137+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9832f6aa-2fd2-455b-9971-7c6a00a49172', '00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2024-08-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.818046+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b7cc78e0-3c0c-4a5b-ae8c-7e63da418138', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2024-09-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.823671+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('78152fee-62b2-480b-a59c-ea0803236fe2', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', NULL, 1.000, 1.000, 950.0000, 950.00, '2024-09-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.828036+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('bbd72135-bc1e-45fd-a8f3-acf42b9a4c9b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2024-10-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.8322+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1efe6442-4e36-4f40-8da7-e85f634d200c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', NULL, 1.000, 1.000, 350.0000, 350.00, '2024-10-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.836817+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4d007f38-7184-4ceb-a2fa-b9303427e4ab', '00e8db4f-deff-45c2-82ee-95c459b73161', '9a1bb369-c512-457e-ae53-78a72acc2219', NULL, 1.000, 1.000, 4600.0000, 4600.00, '2024-11-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.841926+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1dcb91a4-e080-4252-b1b8-b3b544035793', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2024-11-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.847429+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d0122c47-db1a-4bb0-8b87-8793974dabd4', '00e8db4f-deff-45c2-82ee-95c459b73161', '420a7571-bdc7-46b5-8a94-a7a87845194f', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2024-11-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.852366+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f706d749-d1a6-42b9-ae8b-c670807cfe36', '00e8db4f-deff-45c2-82ee-95c459b73161', 'dc652b43-dc3a-429f-bc55-63cadcd9f58f', NULL, 1.000, 1.000, 3600.0000, 3600.00, '2024-12-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.856603+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6a8dd909-e04b-43ab-808b-cdc495cd9c8f', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', NULL, 1.000, 1.000, 950.0000, 950.00, '2024-12-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.860732+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f586b12d-60cb-4c90-8453-68ce5effb187', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b2e434e4-8ca3-40a0-a15a-3a1e8ca99b78', NULL, 1.000, 1.000, 1400.0000, 1400.00, '2025-01-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.864664+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('dc2e6a37-4270-45e7-aec8-875a969bd892', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f8b5105f-bec6-4c53-b399-0940ea8dcf57', NULL, 1.000, 1.000, 350.0000, 350.00, '2025-01-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.868132+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('df577e71-ebd8-429c-8b2a-96a5c7dc97bd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2025-02-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.872319+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('71d19e0c-69e0-4310-8865-ea72da97472d', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-02-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.877477+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aa012cbc-a379-4e9a-a754-59c4bca096ac', '00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2025-02-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.882975+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c17ace78-0b96-499d-be0d-c15f2ed8d247', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-03-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.887949+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d86ce998-2c5a-403e-b942-6b5d31141ae6', '00e8db4f-deff-45c2-82ee-95c459b73161', '8850e5a3-1986-4417-8a9f-f8f377957c3f', NULL, 1.000, 1.000, 950.0000, 950.00, '2025-03-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.894242+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5abbd026-33df-4525-ab07-fa5dce7efe5a', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2025-04-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.899995+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('567addaa-684c-4b85-9f70-b16b73bf292d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', NULL, 1.000, 1.000, 400.0000, 400.00, '2025-04-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.904304+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5f8e1b01-f100-4098-a0c8-3aeb206c5dc5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2025-05-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.908505+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('80cb3af0-f699-4794-84c4-f1eaf156c92a', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-05-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.912452+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4ca2b85b-96c6-4f5d-85cd-132ea2b38018', '00e8db4f-deff-45c2-82ee-95c459b73161', '34d27d14-ab66-4b09-8ffa-f135f94f93d1', NULL, 1.000, 1.000, 18000.0000, 18000.00, '2025-06-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.917276+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4f7a5436-d175-48b4-8e8c-56e7ada1c2f9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-06-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.922686+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5b88a4a0-f8c3-4ba4-9327-28a1734db408', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-07-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.927804+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('bd79f23a-1c72-46cf-a9ae-54f049f2b669', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2025-08-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.932736+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('203b9caf-adaf-48fb-a00d-c3f6249a671c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', NULL, 1.000, 1.000, 400.0000, 400.00, '2025-08-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.937558+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('52d9062f-21c3-47bc-90d6-9b2ef470d566', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd97eb9d7-4797-4ccd-9695-8f3c9aa6edab', NULL, 1.000, 1.000, 9500.0000, 9500.00, '2025-09-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.94195+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('fadb013d-9552-4ac0-925d-0a295a4ab9f8', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ecc7f87-37ca-4418-950a-d19abcc50f2a', NULL, 1.000, 1.000, 3800.0000, 3800.00, '2025-09-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.946418+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('532bba4b-03d4-41de-ab8b-8d636a03f599', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2025-09-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.951152+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4fb19188-258d-43ff-adca-bc35046768bc', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2025-10-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.955447+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7b824237-d024-41ed-8537-2a5548d87d99', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2025-10-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.959477+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('6a415bc4-c05c-46ad-921d-ed469ef6f7e4', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2025-11-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.963911+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('77724fca-e7d1-4f96-9931-3eac6cf870e6', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd51ae20b-7e11-4f6a-b07a-651430aff68e', NULL, 1.000, 1.000, 400.0000, 400.00, '2025-11-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.967534+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('de61d94f-53d0-4256-bae6-7cceb98ecb69', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2025-12-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.971785+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('dba6b64a-7084-477a-92f0-eb2bbc78da2c', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2025-12-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.976534+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1aab37fe-fe36-4834-bc30-a3a715f562e0', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2025-12-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.980946+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('9f44a561-24b6-431d-a117-df21e3583f69', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-01-10', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.984963+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d15a4c25-f64a-4e90-9a0c-c01f7d2a9948', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-01-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.988972+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4b2c5f7b-1b13-428f-9645-2cc76390d892', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2026-02-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.992905+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('edffefce-2c71-4440-9629-87a38e3d51a7', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aa9e1eee-bcc1-4228-a898-3ebdb3f79732', NULL, 1.000, 1.000, 450.0000, 450.00, '2026-02-14', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:57.997922+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('20a85743-c043-4c36-b845-b36c88b56a41', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', NULL, 1.000, 1.000, 5800.0000, 5800.00, '2026-03-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.004506+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('699b2962-063e-4aca-9f25-1d28f2164c66', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2026-03-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.010704+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f18be0ba-b039-4764-a2ee-8c8d5b5d1d6f', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2026-03-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.0168+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('539806da-d6a3-44ab-b168-ec64c9460236', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c061f145-3135-4b56-95ec-087889a26e8b', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-04-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.021967+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7e640b63-29af-48e7-8212-40fd2b049b53', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-04-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.026807+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d13453bd-728b-424f-a743-fec36267e07f', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-04-21', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.030697+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('385fa4b6-1169-48d2-acfa-9a055f826e30', '00e8db4f-deff-45c2-82ee-95c459b73161', '6d40b416-5d46-4941-9081-e1dbd1eed786', NULL, 1.000, 1.000, 1600.0000, 1600.00, '2026-05-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.034017+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f6dcce64-3030-495f-b3fb-a2647d458848', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-05-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.038851+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('57904629-0cbc-47c0-a33d-75d5dda70366', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-06-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.043294+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aca4e755-4624-4b23-891e-833e96a28705', '00e8db4f-deff-45c2-82ee-95c459b73161', '153e2c78-e030-4480-b56a-e0912b30632a', NULL, 1.000, 1.000, 5200.0000, 5200.00, '2026-06-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.047827+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('42f423b6-0f17-4f5c-95aa-d8116d35956c', '00e8db4f-deff-45c2-82ee-95c459b73161', '4ca19ba2-326d-4463-8779-d52cac2c2dad', NULL, 1.000, 1.000, 32000.0000, 32000.00, '2026-06-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.051564+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('37c1c328-a78a-4e57-b59b-48ed5971dce3', '00e8db4f-deff-45c2-82ee-95c459b73161', 'f3f6277b-cfea-489b-8fc9-02487454dadf', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-07-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.056299+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('11c368df-45ce-4a71-ad07-88cf13b5abb2', '00e8db4f-deff-45c2-82ee-95c459b73161', 'ac4a1537-c9e2-4989-a56f-21b94ec8e3ea', NULL, 1.000, 1.000, 3200.0000, 3200.00, '2026-07-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.06006+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1109b7c5-12fe-4242-8b85-e04da4a5afe4', '00e8db4f-deff-45c2-82ee-95c459b73161', '1a98a752-a9d5-405b-8811-3539b8170bea', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-07-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.065258+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5dcfae2b-7aa1-4e14-8817-d1a87e5ee415', '00e8db4f-deff-45c2-82ee-95c459b73161', '54327d88-3d1a-470b-889d-459f5efa89be', NULL, 1.000, 1.000, 2100.0000, 2100.00, '2026-08-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.069841+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('59379fd5-bdbf-40e4-93c2-1a53a25ab8cb', '00e8db4f-deff-45c2-82ee-95c459b73161', '217182bd-b208-424f-84c6-347898691e06', NULL, 1.000, 1.000, 2800.0000, 2800.00, '2026-08-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.073425+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f4178bbd-3039-429c-b680-455e41d5e039', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', NULL, 1.000, 1.000, 4200.0000, 4200.00, '2026-09-25', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.07821+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ab245303-0795-4cb2-9a3f-ce506dcba146', '00e8db4f-deff-45c2-82ee-95c459b73161', '57e2ea5f-d739-4260-8c8b-8cdd0cd54dc1', NULL, 5.000, 5.000, 5.7000, 28.50, '2026-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.084416+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1b425b01-8328-4dac-abf7-7d240c00660b', '00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', NULL, 5.300, 5.300, 4.5000, 23.85, '2026-11-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.091264+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('2228e868-64e6-4433-8a97-3c54db226452', '00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', NULL, 5.000, 5.000, 5.7000, 28.50, '2026-10-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.097508+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3b9b276f-efdd-492a-85d6-0b3e98fabe16', '00e8db4f-deff-45c2-82ee-95c459b73161', '90d23976-c086-4242-8bc1-8c2cdbea1a4c', NULL, 3.000, 3.000, 4.8100, 14.43, '2026-09-30', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.104979+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e753d55d-ccdf-4d60-abde-af184df59376', '00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', NULL, 7.000, 7.000, 5.5200, 38.64, '2026-09-19', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.111656+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1700ea60-13ea-4638-8bd2-efb5baf64a8a', '00e8db4f-deff-45c2-82ee-95c459b73161', '0bb26ced-1dd3-49a2-b332-55821cdf35d3', NULL, 7.400, 7.400, 4.6100, 34.11, '2026-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.116861+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d58ecaf0-e00a-44cd-9e42-01d4c05cf5e0', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b60b93d0-b081-409f-a1df-80afe614f544', NULL, 7.000, 7.000, 4.7100, 32.97, '2026-11-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.121502+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('360acfb2-fad8-424c-9cce-2445894ae74a', '00e8db4f-deff-45c2-82ee-95c459b73161', '50e20ec2-822e-412f-9f47-0f5fa4e200bd', NULL, 2.700, 2.700, 5.6400, 15.23, '2026-11-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.125978+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b70e1d39-b244-47de-a533-605dc5a8a041', '00e8db4f-deff-45c2-82ee-95c459b73161', '9ee9b559-ea52-4db7-a2e4-28eaaf3d6b81', NULL, 1.000, 1.000, 5.0900, 5.09, '2026-10-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.130774+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8e3fbc88-da55-4114-93e6-85b30b7ef482', '00e8db4f-deff-45c2-82ee-95c459b73161', '2311d6c3-afc7-4dc8-9c71-5955220d6e31', NULL, 2.000, 2.000, 4.6500, 9.30, '2026-09-28', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.135687+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('5d876a3d-27a4-4c27-83b9-963405e3d83d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c3a351db-b74d-4190-a870-332727da317f', NULL, 7.000, 7.000, 4.5200, 31.64, '2026-09-17', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.140232+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c662188b-ae04-421e-be4f-02416777556d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'eb9b9ca0-46c5-4914-a914-c1dd7b1d6c0c', NULL, 8.200, 8.200, 4.3400, 35.59, '2026-11-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.144578+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('57b84d7c-b778-47cc-98db-2fb9c58ef4ee', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a288952d-aa29-4152-99bb-2eadf7b78e9d', NULL, 1.000, 1.000, 5.3100, 5.31, '2026-10-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.149596+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('91ce36c5-e83e-4e99-a006-bd8f9d43272f', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', NULL, 9.000, 9.000, 5.2600, 47.34, '2026-11-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.154474+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('0a97d3ae-9db2-4027-90db-3445c20587a0', '00e8db4f-deff-45c2-82ee-95c459b73161', '0624e122-2b53-43dc-9404-ac9614dd0b43', NULL, 9.000, 9.000, 5.7300, 51.57, '2026-10-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.159458+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('605f98cd-a160-4dfa-93bc-e6023515880e', '00e8db4f-deff-45c2-82ee-95c459b73161', '349c83b7-b912-4814-8249-84962e8119fd', NULL, 3.000, 3.000, 4.7000, 14.10, '2026-09-26', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.164533+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('88369263-01c3-4971-b22a-15bfae5e2669', '00e8db4f-deff-45c2-82ee-95c459b73161', '6e1acfb0-89c6-47f3-89e9-5817114a77fe', NULL, 5.000, 5.000, 5.1100, 25.55, '2026-09-15', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.1689+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('dee9915c-3f4e-4dc6-8bd9-eaaeb3f19d58', '00e8db4f-deff-45c2-82ee-95c459b73161', '685830c5-bf5f-4c1e-8eec-4fa61755aff9', NULL, 4.000, 4.000, 5.7400, 22.96, '2026-09-04', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.17304+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('e7e947be-5634-4d14-9c6c-c42841fe7279', '00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', NULL, 1.000, 1.000, 5.2700, 5.27, '2026-10-27', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.177657+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('eb991205-e503-4d4f-a588-66d2dadc16b8', '00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', NULL, 2.300, 2.300, 5.0200, 11.55, '2026-11-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.184056+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1b988da8-e49d-4ad8-8463-3107b06f1ba1', '00e8db4f-deff-45c2-82ee-95c459b73161', '516be891-373e-4e07-974c-bf2985e5f36d', NULL, 1.000, 1.000, 5.6900, 5.69, '2026-10-05', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.189486+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('35c8b519-85a0-40ac-a52d-5d7ce901142c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', NULL, 3.000, 3.000, 4.8000, 14.40, '2026-09-24', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.194792+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ecea7380-f05e-404a-ba46-1b8d67df35c5', '00e8db4f-deff-45c2-82ee-95c459b73161', '787cd292-d3ef-4678-a6c8-91df9da2727e', NULL, 7.000, 7.000, 4.9200, 34.44, '2026-09-13', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.199841+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('48acb01e-84b8-4f06-9d92-3fdc8d17f06a', '00e8db4f-deff-45c2-82ee-95c459b73161', '611cf45d-7d37-4357-9110-cd0a47a192e1', NULL, 2.000, 2.000, 4.8100, 9.62, '2026-09-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.205145+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7249ad43-0aa8-41a7-a62d-df154f36a6b5', '00e8db4f-deff-45c2-82ee-95c459b73161', '58353c4d-8e46-4c89-a1ff-cc78db74e5fc', NULL, 7.600, 7.600, 5.5000, 41.80, '2026-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.209864+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('fa1f3b07-03fb-437c-bbfc-5bcd225956af', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fbee3e5f-1150-494e-8a64-14f40fa58af2', NULL, 4.000, 4.000, 4.6000, 18.40, '2026-10-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.214236+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('a1c24005-aab4-4688-9c8b-4a68c31261b3', '00e8db4f-deff-45c2-82ee-95c459b73161', '4dd93e53-5ef7-4aba-ad5d-f3ee76fe41a1', NULL, 10.000, 10.000, 4.5600, 45.60, '2026-11-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.218311+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8858e7d5-d8db-4b2b-865f-9a2451b96f7c', '00e8db4f-deff-45c2-82ee-95c459b73161', 'b90fae37-b088-49c0-b137-96e942d88441', NULL, 7.000, 7.000, 5.6700, 39.69, '2026-09-22', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.222377+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b59a55fe-f564-4842-a643-711f6017ba40', '00e8db4f-deff-45c2-82ee-95c459b73161', '84be7ee7-1046-4de1-a2b5-e9eac6542e8c', NULL, 1.000, 1.000, 4.9700, 4.97, '2026-09-11', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.228058+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d9ec984c-9131-4f64-8cb7-f766a170bf54', '00e8db4f-deff-45c2-82ee-95c459b73161', '342da948-8958-46c6-bc7b-d18965b7e227', NULL, 6.600, 6.600, 4.6400, 30.62, '2026-11-03', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.234633+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('4baf9afe-c84d-476a-8fc1-24e903b7fc05', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', NULL, 5.000, 5.000, 4.8000, 24.00, '2026-10-12', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.241049+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7ae9a29b-0329-4d32-86bd-6e51b4ad8749', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', NULL, 7.000, 7.000, 5.1500, 36.05, '2026-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.246002+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('1ec56a8c-54b1-4614-bbed-9e5ce5f3050d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c67f7840-e1c9-46e1-a074-6b940430e40e', NULL, 10.000, 10.000, 5.3900, 53.90, '2026-10-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.252376+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('423138e7-c31b-4fce-80fa-8a9eacea5dd9', '00e8db4f-deff-45c2-82ee-95c459b73161', '0984ac47-8b8c-490f-9a09-d7eb6d3cd264', NULL, 3.000, 3.000, 5.6100, 16.83, '2026-09-09', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.258479+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('ff4b02d5-24e5-4a72-8761-74f4c67b6cbe', '00e8db4f-deff-45c2-82ee-95c459b73161', 'c7486598-4240-4979-bb9e-21e57b6effe8', NULL, 2.000, 2.000, 4.9600, 9.92, '2026-09-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.264586+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('161d2d48-afcd-4e5b-9c27-42ee0412e156', '00e8db4f-deff-45c2-82ee-95c459b73161', 'beb604b5-970d-4898-a6fd-319fca3f44fb', NULL, 7.000, 7.000, 5.1900, 36.33, '2026-11-08', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.269579+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('a4c0ce28-270a-4438-9297-6cbfadef649c', '00e8db4f-deff-45c2-82ee-95c459b73161', '7f65a62c-3ea1-4603-94f7-4d837d66dd43', NULL, 8.000, 8.000, 5.5500, 44.40, '2026-11-01', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.273978+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d639f537-bec3-47a2-a3de-ea3877df4908', '00e8db4f-deff-45c2-82ee-95c459b73161', '5e26266d-502e-4489-b09f-bf41874d8f83', NULL, 5.000, 5.000, 4.8300, 24.15, '2026-09-29', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.278765+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('962b979d-91d0-4259-bbf5-d77d84e0d6fd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', NULL, 6.000, 6.000, 5.2000, 31.20, '2026-11-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.282231+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('46d55e25-b194-4f94-baa1-383e3ee6ac93', '00e8db4f-deff-45c2-82ee-95c459b73161', 'bb856f1a-fcdb-4d29-b932-14925497488e', NULL, 5.000, 5.000, 4.9000, 24.50, '2026-09-18', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.286847+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('51cc376c-dfea-4e28-89ba-9f7dc179235b', '00e8db4f-deff-45c2-82ee-95c459b73161', 'd88c3c8f-3d12-443b-842e-17bc327f9fe6', '041e4017-71f6-4524-8732-42b36f2a2b54', 5.000, 5.000, 4200.0000, 21000.00, '2026-11-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.757802+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('91ebbf7c-2a52-4884-a0b4-dd2164c19f20', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', '31eb2a1e-3154-435d-a30b-580179bc9e7a', 3.000, 3.000, 5800.0000, 17400.00, '2026-11-07', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.757803+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7c835d9f-315f-4727-b6c3-21be18f707cc', '00e8db4f-deff-45c2-82ee-95c459b73161', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', 'ab5639c5-3089-43f7-8bdc-f9fbe65ef3f5', 48.000, 36.000, 4.5000, 216.00, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.687674+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('aae94b8e-1d89-4ce8-afb0-00ef56fdf335', '00e8db4f-deff-45c2-82ee-95c459b73161', '8286bc5b-c3f3-4270-a38c-a753f5b8531b', '4982a2de-f822-484b-939d-4c18875fceac', 12.000, 0.000, 4.5000, 54.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-09 20:29:58.841501+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('c2f88886-5eba-4a3c-834d-b822f3a138a2', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', 'd2d0082d-fb17-4261-9e86-699d1232cf94', 8.000, 0.000, 8.9000, 71.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-09 20:29:58.841503+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('3bae7315-0ac0-4588-a79b-b15f1c720893', '00e8db4f-deff-45c2-82ee-95c459b73161', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', '3b0830da-a923-4dc9-b898-2a155a85bf63', 24.000, 18.000, 5.2000, 124.80, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.687677+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('a34fe137-f9ca-4be2-b423-c3ae6ceea900', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', 'f27ef2ef-fba8-4da9-a207-d2f75217b67f', 36.000, 24.000, 8.9000, 320.40, '2026-10-31', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.687678+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b109d69f-c473-48cf-b058-fc853a5eeb35', '00e8db4f-deff-45c2-82ee-95c459b73161', '54e6d7a8-1d68-4c2b-a4e0-df49b00e2926', '4398a1eb-755c-4e56-b2f6-dc5926ce714d', 6.000, 0.000, 5.2000, 31.20, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-09 20:29:59.750909+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('414f1957-8111-41ab-ac02-2eed7c2acd54', '00e8db4f-deff-45c2-82ee-95c459b73161', '80b42f49-4cde-42be-bb81-b4631caefbd5', '5c3043cc-5f88-4d07-8053-489b7d52a2b4', 4.000, 0.000, 8.9000, 35.60, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-09 20:29:59.750911+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8c552013-a213-4d60-93ac-529d32e5d419', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', '4ea88fff-1e07-4c1a-bdc6-69c38a45d23f', 60.000, 50.000, 12.5000, 750.00, '2026-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.726368+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8ea845c9-3149-47fd-b4b9-e73875dfb891', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fa748810-6265-493f-a360-df817a409794', 'bd17f841-0096-489c-8645-2f81e6ff4c6e', 20.000, 15.000, 4.1000, 82.00, '2026-11-02', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.72637+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b1acccf1-eb43-4d04-8446-9500c3a5a3d5', '00e8db4f-deff-45c2-82ee-95c459b73161', 'aeb331f9-551a-4794-801b-9d2fa6576ea8', 'ed265a75-c86f-45fb-82d1-dbc7b3549223', 10.000, 0.000, 12.5000, 125.00, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-09 20:29:59.83623+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f0b8ba08-eddb-4f9e-ab29-0a63374c95dd', '00e8db4f-deff-45c2-82ee-95c459b73161', 'fa748810-6265-493f-a360-df817a409794', 'c05d91a2-fe69-45a1-8635-ec888976803b', 5.000, 0.000, 4.1000, 20.50, NULL, 'USD', 'OUT', 'fifo', NULL, NULL, '2026-11-09 20:29:59.836232+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('b36d5aac-0c34-4697-b0c0-7a5e10d01eb7', '00e8db4f-deff-45c2-82ee-95c459b73161', '4af7dd1e-9d07-47f8-b82a-13b52fb84728', 'e598f9af-4b7c-4fe5-9517-d6ad98155c39', 3.000, 3.000, 5800.0000, 17400.00, '2026-10-23', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:30:00.111807+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('8ab2b6ee-1c8e-409a-a6f7-09628ac43cf9', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', NULL, 40.000, 13.600, 3.4000, 136.00, '2026-11-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.291144+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('d6de9f89-1326-48a7-a31a-d9bb3f7cb359', '00e8db4f-deff-45c2-82ee-95c459b73161', '063c1712-5f63-4a39-9de1-9bee2fcc5c21', NULL, 26.400, 0.000, 3.4000, 89.76, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-09 20:30:00.386207+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('82cda4fb-fb82-4fc4-b10e-cbe1e722e2af', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', NULL, 25.000, 21.220, 1.1000, 27.50, '2026-10-20', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.302809+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('fb4730b4-c144-47ae-8fdd-eeb340bfe86d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'a7907bfa-51a5-4121-8ad2-91864a33b272', NULL, 3.780, 0.000, 1.1000, 4.16, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-09 20:30:00.409019+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('f944928d-b734-47fb-9e7c-3f3bc80f67c3', '00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', NULL, 0.500, 0.440, 24.0000, 12.00, '2026-10-06', 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:29:58.295658+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('57b97f1b-ece7-4742-9ecb-ed64e52d6618', '00e8db4f-deff-45c2-82ee-95c459b73161', '0ac86d54-9b7d-43be-a6de-b6db210e7c8f', NULL, 0.060, 0.000, 24.0000, 1.44, NULL, 'USD', 'OUT', 'fifo', 'USED', NULL, '2026-11-09 20:30:00.428938+00');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, document_date, currency, direction, cost_basis, reason, item_id, created_at) VALUES ('7f813b8d-40f7-425f-9d5b-7c609df489db', '00e8db4f-deff-45c2-82ee-95c459b73161', '42fb5efc-9a73-4801-989a-0182576ad930', NULL, 11.400, 11.400, 8.3647, 95.36, NULL, 'USD', 'IN', 'stated', NULL, NULL, '2026-11-09 20:30:00.455056+00');


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('50a21b85-ae1f-4691-b229-fb88eede2bac', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, NULL, '[]', 'STOCK', '[]', 'Main Warehouse', 'Receiving and dispatch — shared by every module', NULL, NULL, 1, 'internal', NULL, '{"seed": {"code": "MAIN_WAREHOUSE", "name": "Main Warehouse"}}', NULL, '2026-11-09 20:29:57.071818+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('06001ddb-2806-4340-8266-66c924901fd1', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'cb1f377a-ee55-453c-bf47-aa387e26bb1e', '[]', 'STOCK', '[]', 'Consumed (Virtual)', NULL, 'System location', NULL, 39, 'customer', NULL, '{"seed": {"code": "CONSUMED_VIRTUAL", "name": "Consumed (Virtual)"}}', NULL, '2026-11-09 20:29:57.096685+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('5639b14d-4b2a-4853-aa07-5338574f0a85', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, NULL, '[]', 'NONE', '[]', 'Server Room', 'Primary server room / data center', NULL, NULL, 44, 'internal', 'equipment', '{"seed": {"code": "SERVER_ROOM", "name": "Server Room"}}', NULL, '2026-11-09 20:29:57.071824+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c1c2741e-ea60-4ba5-8937-9a940600abdf', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'cb1f377a-ee55-453c-bf47-aa387e26bb1e', '[]', 'STOCK', '[]', 'Production (Virtual)', NULL, 'System location', NULL, 42, 'production', NULL, '{"seed": {"code": "PRODUCTION_VIRTUAL", "name": "Production (Virtual)"}}', NULL, '2026-11-09 20:29:57.100046+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('01db1d75-57a3-4cd9-b50c-dbb6b662fb12', '00e8db4f-deff-45c2-82ee-95c459b73161', '647a0855-0bcb-480c-be05-b73a37759d74', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Floor 1 - Row B', NULL, NULL, 'E-02', 36, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.360884+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c9f96697-3dc0-4d35-bb5f-66f5615a6725', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, '54ffd022-8fa1-4517-bf25-14ef4b52e50d', '[]', 'STOCK', '[]', 'Quarantine', NULL, NULL, NULL, 43, 'internal', NULL, '{"seed": {"code": "QUARANTINE", "name": "Quarantine"}}', NULL, '2026-11-09 20:29:57.103613+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ed476482-e137-41fc-b94a-ff23280cfb87', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, NULL, '[]', 'NONE', '[]', 'IT Storage', 'IT equipment storage and logistics warehouse', NULL, NULL, 40, 'internal', 'equipment', '{"seed": {"code": "IT_STORAGE", "name": "IT Storage"}}', NULL, '2026-11-09 20:29:57.071826+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('ff6cf4cc-d8f2-4279-8730-3ddfa5c42e21', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, 'cb1f377a-ee55-453c-bf47-aa387e26bb1e', '[]', 'STOCK', '[]', 'Inventory Loss (Virtual)', NULL, 'System location', NULL, 41, 'inventory', NULL, '{"seed": {"code": "LOSS_VIRTUAL", "name": "Inventory Loss (Virtual)"}}', NULL, '2026-11-09 20:29:57.098487+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0609450b-99c5-4863-a285-183519183528', '00e8db4f-deff-45c2-82ee-95c459b73161', '99da11e2-74a7-4cba-bd8a-bf55f56e4f2a', 'a3f3fe3d-1dbc-4a52-8c0f-19fc3848c964', '[]', 'FREEZING', '[]', 'Freezer 1', NULL, NULL, 'B-01', 10, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.335278+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('0a2727e8-6c13-4603-93e7-89512c6d8941', '00e8db4f-deff-45c2-82ee-95c459b73161', '99da11e2-74a7-4cba-bd8a-bf55f56e4f2a', 'a3f3fe3d-1dbc-4a52-8c0f-19fc3848c964', '[]', 'FREEZING', '[]', 'Freezer 2', NULL, NULL, 'B-02', 11, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.336253+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('206de892-4ef6-49b3-b1bc-4d2d1dc779a1', '00e8db4f-deff-45c2-82ee-95c459b73161', '93c63305-643a-489f-b0ee-9f0b3118dd13', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Fridge B', NULL, NULL, 'A-02', 6, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.330681+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('2989daf7-0905-4ff9-9a1e-9e9cf912a5d6', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Shelf A - Middle', NULL, NULL, 'F-02', 16, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.341081+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('3a7f3dc8-d5e2-4654-a1d5-1ea6da5735cd', '00e8db4f-deff-45c2-82ee-95c459b73161', '40a7492d-9679-4e85-9c2f-e0f2993ee170', '8e117dd5-e601-42e7-8391-3a5d3da6314d', '[]', 'STOCK', '[]', 'Patch Panel', NULL, NULL, 'C-04', 29, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.353829+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('3f490bb0-1c52-477c-8892-8f2d1d274ee9', '00e8db4f-deff-45c2-82ee-95c459b73161', '647a0855-0bcb-480c-be05-b73a37759d74', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Floor 2 - Row A', NULL, NULL, 'E-03', 37, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.361636+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('40a7492d-9679-4e85-9c2f-e0f2993ee170', '00e8db4f-deff-45c2-82ee-95c459b73161', '160194cb-5901-4edd-841f-cf7e80f688ad', '8e117dd5-e601-42e7-8391-3a5d3da6314d', '[]', 'STOCK', '[]', 'Server Room', NULL, NULL, 'C', 25, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.350048+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('45a04792-f2a1-4f36-9061-a0eb201f2f70', '00e8db4f-deff-45c2-82ee-95c459b73161', '5fb0c92a-9f68-47e5-8508-8afeed91fb8d', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Dry Goods', NULL, NULL, 'F', 14, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.339189+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('471ef176-3922-44c1-9239-e42b8ca3f0ee', '00e8db4f-deff-45c2-82ee-95c459b73161', '69a0826a-1508-4333-a615-69a4da548683', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'STOCK', '[]', 'Beverage Rack 2', NULL, NULL, 'G-02', 23, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.347796+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('47b747a8-0340-493b-845a-8d3d906d17ff', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Fridge A - Door', NULL, NULL, 'A-01-02', 5, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.329827+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('4862b4f7-228f-43d4-b329-37de5b1813bf', '00e8db4f-deff-45c2-82ee-95c459b73161', '93c63305-643a-489f-b0ee-9f0b3118dd13', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Fridge A', NULL, NULL, 'A-01', 3, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.3279+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('5425cd68-9981-415b-bcbe-27410a2fa10d', '00e8db4f-deff-45c2-82ee-95c459b73161', '160194cb-5901-4edd-841f-cf7e80f688ad', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'IT Workshop', NULL, NULL, 'D', 30, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.35539+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('647a0855-0bcb-480c-be05-b73a37759d74', '00e8db4f-deff-45c2-82ee-95c459b73161', '160194cb-5901-4edd-841f-cf7e80f688ad', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Workstations', NULL, NULL, 'E', 34, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.359286+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('66ee606c-e95d-4547-920f-fb79bb6d8759', '00e8db4f-deff-45c2-82ee-95c459b73161', '99da11e2-74a7-4cba-bd8a-bf55f56e4f2a', 'a3f3fe3d-1dbc-4a52-8c0f-19fc3848c964', '[]', 'FREEZING', '[]', 'Chest Freezer', NULL, NULL, 'B-03', 12, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.337146+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('66eea498-a873-404c-9657-e5c94d678571', '00e8db4f-deff-45c2-82ee-95c459b73161', '647a0855-0bcb-480c-be05-b73a37759d74', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Floor 2 - Row B', NULL, NULL, 'E-04', 38, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.362379+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('69a0826a-1508-4333-a615-69a4da548683', '00e8db4f-deff-45c2-82ee-95c459b73161', '5fb0c92a-9f68-47e5-8508-8afeed91fb8d', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'STOCK', '[]', 'Beverages', NULL, NULL, 'G', 21, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.345963+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('6ffc1d0b-85e1-4a7b-8d1b-8986f7ba84b6', '00e8db4f-deff-45c2-82ee-95c459b73161', '40a7492d-9679-4e85-9c2f-e0f2993ee170', '8e117dd5-e601-42e7-8391-3a5d3da6314d', '[]', 'STOCK', '[]', 'UPS Bay', NULL, NULL, 'C-03', 28, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.352763+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('73869395-0caf-4783-a71d-e5ab311d279a', '00e8db4f-deff-45c2-82ee-95c459b73161', '93c63305-643a-489f-b0ee-9f0b3118dd13', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Walk-in Cooler', NULL, NULL, 'A-04', 8, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.332455+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('7c9ef099-d7e7-43b1-a405-3e3a232272b0', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Shelf B - Bottom', NULL, NULL, 'F-06', 20, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.345082+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('85b351d5-711b-47d4-b174-83619236e876', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Shelf A - Bottom', NULL, NULL, 'F-03', 17, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.342156+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('866b2db9-f86e-4955-8198-0d499f3e5025', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Shelf A - Top', NULL, NULL, 'F-01', 15, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.340203+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('88658701-75a4-4a06-9d85-62f32417ca68', '00e8db4f-deff-45c2-82ee-95c459b73161', '4862b4f7-228f-43d4-b329-37de5b1813bf', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Fridge A - Top Shelf', NULL, NULL, 'A-01-01', 4, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.328932+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('8f446de5-a0e0-4514-832b-2d68c13476d6', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Shelf B - Top', NULL, NULL, 'F-04', 18, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.343144+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('93c63305-643a-489f-b0ee-9f0b3118dd13', '00e8db4f-deff-45c2-82ee-95c459b73161', '50a21b85-ae1f-4691-b229-fb88eede2bac', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Cold Storage', NULL, NULL, 'A', 2, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.326192+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('99da11e2-74a7-4cba-bd8a-bf55f56e4f2a', '00e8db4f-deff-45c2-82ee-95c459b73161', '50a21b85-ae1f-4691-b229-fb88eede2bac', 'a3f3fe3d-1dbc-4a52-8c0f-19fc3848c964', '[]', 'FREEZING', '[]', 'Freezer Zone', NULL, NULL, 'B', 9, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.333866+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('9ed5fc92-ea45-4e8b-9b56-9d54a2659112', '00e8db4f-deff-45c2-82ee-95c459b73161', '93c63305-643a-489f-b0ee-9f0b3118dd13', '65bf61fe-1073-477d-8b99-30e2dbf79cb9', '[]', 'EXPIRY', '[]', 'Fridge C', NULL, NULL, 'A-03', 7, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.331529+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('9fc409ab-02e4-45f0-a6a8-55344aafe2e0', '00e8db4f-deff-45c2-82ee-95c459b73161', '40a7492d-9679-4e85-9c2f-e0f2993ee170', '8e117dd5-e601-42e7-8391-3a5d3da6314d', '[]', 'STOCK', '[]', 'Server Rack A', NULL, NULL, 'C-01', 26, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.350872+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('b1095706-0888-46c1-8d90-04174899f254', '00e8db4f-deff-45c2-82ee-95c459b73161', '69a0826a-1508-4333-a615-69a4da548683', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'STOCK', '[]', 'Beverage Rack 1', NULL, NULL, 'G-01', 22, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.346809+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('b94369de-1676-42e5-998c-4be2391acbf9', '00e8db4f-deff-45c2-82ee-95c459b73161', '647a0855-0bcb-480c-be05-b73a37759d74', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Floor 1 - Row A', NULL, NULL, 'E-01', 35, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.360116+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('c2c2653b-c961-4e10-93e6-665780ad0903', '00e8db4f-deff-45c2-82ee-95c459b73161', '5425cd68-9981-415b-bcbe-27410a2fa10d', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Spare Parts Bin', NULL, NULL, 'D-03', 33, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.358387+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('d07c10ee-54d0-48aa-b18b-f2d51881e219', '00e8db4f-deff-45c2-82ee-95c459b73161', '5425cd68-9981-415b-bcbe-27410a2fa10d', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Workshop Shelf 1', NULL, NULL, 'D-01', 31, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.356328+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('e03fe983-c49d-4d62-8a19-19fddaecdd89', '00e8db4f-deff-45c2-82ee-95c459b73161', '45a04792-f2a1-4f36-9061-a0eb201f2f70', 'df93090d-04aa-40df-87d3-506dd0359ab8', '[]', 'EXPIRY', '[]', 'Shelf B - Middle', NULL, NULL, 'F-05', 19, 'internal', 'food', NULL, NULL, '2026-11-09 20:29:57.344106+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('e7ed7113-f029-424f-94b8-a98a1d53f7a1', '00e8db4f-deff-45c2-82ee-95c459b73161', '5425cd68-9981-415b-bcbe-27410a2fa10d', '5e924382-e775-4e4d-b33a-819d52b9955a', '[]', 'STOCK', '[]', 'Workshop Shelf 2', NULL, NULL, 'D-02', 32, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.357374+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('f8ae04f7-198a-43c9-b801-a3d211d9800a', '00e8db4f-deff-45c2-82ee-95c459b73161', '40a7492d-9679-4e85-9c2f-e0f2993ee170', '8e117dd5-e601-42e7-8391-3a5d3da6314d', '[]', 'STOCK', '[]', 'Server Rack B', NULL, NULL, 'C-02', 27, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.351757+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('160194cb-5901-4edd-841f-cf7e80f688ad', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, '54ffd022-8fa1-4517-bf25-14ef4b52e50d', '[]', 'STOCK', '[]', 'Office Building', NULL, NULL, 'LOC-WSZ2', 24, 'internal', 'equipment', NULL, NULL, '2026-11-09 20:29:57.349198+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, sequence, usage, context_tag, settings, warehouse_config, created_at, created_by) VALUES ('5fb0c92a-9f68-47e5-8508-8afeed91fb8d', '00e8db4f-deff-45c2-82ee-95c459b73161', NULL, '54ffd022-8fa1-4517-bf25-14ef4b52e50d', '[]', 'STOCK', '[]', 'Pantry Building', NULL, NULL, 'LOC-YCSC', 13, 'internal', NULL, NULL, NULL, '2026-11-09 20:29:57.338253+00', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484');


--
-- Data for Name: storage_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('55201e62-5c03-48ff-8566-4de33d34ee6a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Shelf / Cabinet', 'SHELF', 'STOCK', '["quantity", "unit"]', '[]', 'BookOpen', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('54ffd022-8fa1-4517-bf25-14ef4b52e50d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Storage Room', 'STORAGE_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Warehouse', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('cb1f377a-ee55-453c-bf47-aa387e26bb1e', '00e8db4f-deff-45c2-82ee-95c459b73161', 'System', 'SYSTEM', 'NONE', '[]', '[]', 'Settings', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('6b1de239-9d89-462d-87e7-9b608d4e7b54', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Tool Room', 'TOOL_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Wrench', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('35050275-d2f1-4715-b4af-f5e2ac19c2fa', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Maintenance Bay', 'MAINTENANCE_BAY', 'NONE', '["quantity", "unit"]', '[]', 'Hammer', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('8e117dd5-e601-42e7-8391-3a5d3da6314d', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Server Room', 'SERVER_ROOM', 'NONE', '["serial_number", "manufacturer", "model", "ip_address", "equipment_status"]', '[]', 'server', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('5e924382-e775-4e4d-b33a-819d52b9955a', '00e8db4f-deff-45c2-82ee-95c459b73161', 'IT Storage / Warehouse', 'IT_STORAGE', 'NONE', '["serial_number", "manufacturer", "model", "equipment_status"]', '[]', 'warehouse', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('a3f3fe3d-1dbc-4a52-8c0f-19fc3848c964', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Freezer', 'FREEZER', 'FREEZING', '[]', '[]', 'Snowflake', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('65bf61fe-1073-477d-8b99-30e2dbf79cb9', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Fridge', 'FRIDGE', 'EXPIRY', '[]', '[]', 'Refrigerator', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('df93090d-04aa-40df-87d3-506dd0359ab8', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Pantry', 'PANTRY', 'EXPIRY', '[]', '[]', 'ShoppingBasket', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('38141e5f-63b2-4674-ae59-345c383f6475', '00e8db4f-deff-45c2-82ee-95c459b73161', 'Medicine Cabinet', 'MEDICINE_CABINET', 'EXPIRY', '[]', '[]', 'Cross', true, NULL, '{"check_expiry": true}');


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_settings (key, value, updated_at, updated_by) VALUES ('default_org_limits', '{"max_members": null, "max_products": null, "ai_scans_monthly": null, "ai_requests_monthly": 20}', '2026-11-09 20:30:01.265698+00', NULL);


--
-- Data for Name: tax_rate_assignments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unit_conversions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: uom_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('ee6c64f2-bbfc-448c-88d6-f320d8ff028d', NULL, 'Weight');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('5601b48c-63a4-40a3-82b2-78c915b56edd', NULL, 'Volume');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('4fdd8e02-19d3-4bff-95d8-40f375d98509', NULL, 'Unit');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('712cecae-beb8-4b7c-8bfe-b02b3b1ed6c3', NULL, 'Length');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('bfee44bd-cf5a-416c-a3bc-4ad372af1803', NULL, 'Pack');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('b2b44535-d6b6-4b2a-8a39-127b6d58ba8b', NULL, 'Can');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('4c72b19f-7b86-4782-9e43-d1c0b4abae99', NULL, 'Bottle');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('6b5bf68d-84a6-48d4-998a-c76808a24fd8', NULL, 'Box');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('8daa7ad0-74a1-4dd7-87a6-675232ef86a0', NULL, 'Bag');


--
-- Data for Name: uoms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('d17a4bea-b58f-4c2e-853d-abe294cd8acc', NULL, 'ee6c64f2-bbfc-448c-88d6-f320d8ff028d', 'Gram', 'g', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('fefa9928-2a16-4fa2-a52e-9cd9d3a18817', NULL, 'ee6c64f2-bbfc-448c-88d6-f320d8ff028d', 'Kilogram', 'kg', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('38630464-ed9a-45e9-a712-3f9d58f03319', NULL, 'ee6c64f2-bbfc-448c-88d6-f320d8ff028d', 'Milligram', 'mg', 0.001000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('5eb406e7-932d-4dd4-aca7-0c1829546016', NULL, 'ee6c64f2-bbfc-448c-88d6-f320d8ff028d', 'Ounce', 'oz', 28.349500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('03ac0a9f-f139-4c4d-b8fd-fdfd170f1345', NULL, 'ee6c64f2-bbfc-448c-88d6-f320d8ff028d', 'Pound', 'lb', 453.592000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('b83a5e3d-374a-4a36-9640-990e1e3ee484', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Milliliter', 'ml', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('d32114df-753c-4dad-baf8-dacf993c5a2e', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Liter', 'l', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('6bc1b8da-dbcc-4064-a73e-cea6ecb1e73c', NULL, '4fdd8e02-19d3-4bff-95d8-40f375d98509', 'Piece', 'pcs', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('917304cd-586e-45cc-9900-313855f42a9b', NULL, 'bfee44bd-cf5a-416c-a3bc-4ad372af1803', 'Pack', 'pack', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('c29e7275-ddc8-4200-9b48-39d74ac0672e', NULL, 'b2b44535-d6b6-4b2a-8a39-127b6d58ba8b', 'Can', 'can', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('13db6baf-0796-4f70-88e6-ded5fd17e389', NULL, '4c72b19f-7b86-4782-9e43-d1c0b4abae99', 'Bottle', 'bottle', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('18fda315-50e5-4f98-bda5-953e5a2a6434', NULL, '6b5bf68d-84a6-48d4-998a-c76808a24fd8', 'Box', 'box', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8504337a-c843-44f9-bf62-8ee4c7db49a1', NULL, '8daa7ad0-74a1-4dd7-87a6-675232ef86a0', 'Bag', 'bag', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('6a13b6a1-96b5-4581-b85d-d23c85f47615', NULL, '712cecae-beb8-4b7c-8bfe-b02b3b1ed6c3', 'Centimeter', 'cm', 1.000000000, true, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('84a414e3-1eba-41f0-b089-58dc21e74ab0', NULL, '712cecae-beb8-4b7c-8bfe-b02b3b1ed6c3', 'Meter', 'm', 100.000000000, false, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('b843e689-3bac-49b0-86f7-5d148c74e7c9', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Fluid Ounce', 'fl oz', 29.573500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8277204e-b11b-4550-85e5-a7d68abb5048', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Cup (US)', 'cup', 236.588000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('eb5c2124-be5c-4039-92cb-ee298b4280d5', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Pint (US)', 'pt', 473.176000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f56366f8-d12a-4374-a6b3-2059025281a1', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Quart (US)', 'qt', 946.353000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f5aa18e4-b8c3-42d6-9c2f-79967b466eb3', NULL, '5601b48c-63a4-40a3-82b2-78c915b56edd', 'Gallon (US)', 'gal', 3785.410000000, false, true, 0.001000);


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('d9f91cf7-ee26-4c70-836c-bff04b6bb484', 'admin@example.com', '$2b$12$Wi25qjBP3NHQydMf4m4mcOVbymRPsbPnJC7T27yQOmv6XK/SM58oa', 'Demo Administrator', '2026-11-09 20:29:56.950429+00', '2026-11-09 20:29:56.961512+00', 'en', 'admin', true, false, false, NULL, NULL, 0, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('6e228bca-4488-4535-9fd3-0d4b0549bd49', 'ava.brennan@example.com', '$2b$12$2KcJaCuYnC820L0Lw1rIUezk33e7SZeEJwLTEYM8boJODEzCEjRLq', 'Ava Brennan', '2026-11-09 20:30:00.952099+00', '2026-11-09 20:30:00.952103+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('f513905d-ce7d-43a4-a772-b43279005f82', 'marcus.webb@example.com', '$2b$12$UR7NU7D/FPs8.qTFxJ2r3epyW6g6ISjiZxHk3hV0E1mBa2d33F1Um', 'Marcus Webb', '2026-11-09 20:30:00.952105+00', '2026-11-09 20:30:00.952106+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, '00e8db4f-deff-45c2-82ee-95c459b73161');


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_line_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('3c98d4f4-a294-4aeb-8300-4413c41c69f8', 'a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', '5c3043cc-5f88-4d07-8053-489b7d52a2b4', 1, 'picked', 4.000, 'A-01 · Fridge A', 'Butter Extra 82%', NULL, 4.000, 'pcs', '59d09b58-1c63-4802-88a2-49952dfab373', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('b74dfcf4-1c38-490f-82c1-d3afd1d6db4d', 'a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', 'c05d91a2-fe69-45a1-8635-ec888976803b', 3, 'picked', 5.000, 'A-02 · Fridge B', 'Sour Cream 18%', NULL, 5.000, 'pcs', '12ea29f6-57cb-4063-b024-f65a8b5279a3', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('bedf71c4-90f9-484b-8212-e3cf894a9bcf', 'a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', 'ed265a75-c86f-45fb-82d1-dbc7b3549223', 2, 'picked', 10.000, 'A-02 · Fridge B', 'Gouda Cheese', NULL, 10.000, 'pcs', 'cf909942-3c32-45ca-841d-bcfc2f53efb3', NULL, '206de892-4ef6-49b3-b1bc-4d2d1dc779a1', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('d3d0ce97-a9f7-4313-9f0e-1785bf1d0661', 'a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', '4398a1eb-755c-4e56-b2f6-dc5926ce714d', 0, 'picked', 6.000, 'A-01 · Fridge A', 'Natural Yoghurt 400g', NULL, 6.000, 'pcs', 'd16af418-4172-4e00-a492-4a27575fca00', NULL, '4862b4f7-228f-43d4-b329-37de5b1813bf', NULL);


--
-- Data for Name: wms_pick_session_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 0);
INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', '8a59913a-b433-4654-8783-6a3e9994e96f', 1);


--
-- Data for Name: wms_pick_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_sessions (id, organization_id, document_id, assigned_to, status, started_at, completed_at, meta_data, last_activity_at) VALUES ('a1f94b9c-b7fc-4ce5-ab36-f0fb16b87e86', '00e8db4f-deff-45c2-82ee-95c459b73161', 'e7b9f838-3e91-47fa-939f-7f2da6ac1133', 'd9f91cf7-ee26-4c70-836c-bff04b6bb484', 'completed', '2026-11-09 20:29:59.290523+00', '2026-11-09 20:29:59.506135+00', 'null', '2026-11-09 20:29:59.482734+00');


--
-- Name: ai_connections ai_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version_api_keys alembic_version_api_keys_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_api_keys
    ADD CONSTRAINT alembic_version_api_keys_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_approvals alembic_version_approvals_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_approvals
    ADD CONSTRAINT alembic_version_approvals_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_equipment alembic_version_equipment_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_equipment
    ADD CONSTRAINT alembic_version_equipment_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_example_widgets alembic_version_example_widgets_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_example_widgets
    ADD CONSTRAINT alembic_version_example_widgets_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_maker alembic_version_maker_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_maker
    ADD CONSTRAINT alembic_version_maker_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_printing alembic_version_printing_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_printing
    ADD CONSTRAINT alembic_version_printing_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_purchase_orders alembic_version_purchase_orders_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_purchase_orders
    ADD CONSTRAINT alembic_version_purchase_orders_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_recipes alembic_version_recipes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_recipes
    ADD CONSTRAINT alembic_version_recipes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_shopping_lists alembic_version_shopping_lists_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_shopping_lists
    ADD CONSTRAINT alembic_version_shopping_lists_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_stock_takes alembic_version_stock_takes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_stock_takes
    ADD CONSTRAINT alembic_version_stock_takes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_warehouse alembic_version_warehouse_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_warehouse
    ADD CONSTRAINT alembic_version_warehouse_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_webhooks alembic_version_webhooks_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_webhooks
    ADD CONSTRAINT alembic_version_webhooks_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approval_decisions approval_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: approval_workflows approval_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);


--
-- Name: audit_campaigns audit_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_response_items audit_response_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_pkey PRIMARY KEY (id);


--
-- Name: audit_responses audit_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cycle_count_schedules cycle_count_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_pkey PRIMARY KEY (id);


--
-- Name: document_extra_costs document_extra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_pkey PRIMARY KEY (id);


--
-- Name: document_lines document_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_pkey PRIMARY KEY (id);


--
-- Name: document_number_sequences document_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_pkey PRIMARY KEY (organization_id, prefix);


--
-- Name: document_package_lines document_package_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_pkey PRIMARY KEY (id);


--
-- Name: document_packages document_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_pkey PRIMARY KEY (id);


--
-- Name: document_profiles document_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_pkey PRIMARY KEY (id);


--
-- Name: document_relations document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_pkey PRIMARY KEY (id);


--
-- Name: document_shipments document_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: document_type_configs document_type_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_pkey PRIMARY KEY (id);


--
-- Name: document_warehouse_receiving document_warehouse_receiving_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_pkey PRIMARY KEY (id);


--
-- Name: document_work_item_overlays document_work_item_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_jobs email_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_jobs
    ADD CONSTRAINT email_jobs_pkey PRIMARY KEY (id);


--
-- Name: equipment_assignments equipment_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_pkey PRIMARY KEY (id);


--
-- Name: equipment_attachments equipment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_pkey PRIMARY KEY (id);


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: event_deliveries event_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT event_deliveries_pkey PRIMARY KEY (id);


--
-- Name: event_outbox event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox
    ADD CONSTRAINT event_outbox_pkey PRIMARY KEY (id);


--
-- Name: example_widgets example_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_pkey PRIMARY KEY (id);


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_pkey PRIMARY KEY (id);


--
-- Name: inventory_periods inventory_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_pkey PRIMARY KEY (id);


--
-- Name: item_attachments item_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_pkey PRIMARY KEY (id);


--
-- Name: item_history item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_pkey PRIMARY KEY (id);


--
-- Name: item_import_jobs item_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: label_pool label_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_pkey PRIMARY KEY (id);


--
-- Name: location_relocations location_relocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_pkey PRIMARY KEY (id);


--
-- Name: maker_bom_lines maker_bom_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_module_settings maker_module_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: maker_production_order_lines maker_production_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_production_orders maker_production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_pkey PRIMARY KEY (id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_recipes maker_recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_entries meal_plan_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_pkey PRIMARY KEY (id);


--
-- Name: meal_plans meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_pkey PRIMARY KEY (id);


--
-- Name: module_installations module_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_installations
    ADD CONSTRAINT module_installations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: picking_session_items picking_session_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_pkey PRIMARY KEY (id);


--
-- Name: picking_sessions picking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_pkey PRIMARY KEY (id);


--
-- Name: po_partner_pricelist po_partner_pricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_pkey PRIMARY KEY (id);


--
-- Name: po_reorder_rules po_reorder_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_pkey PRIMARY KEY (id);


--
-- Name: po_settings po_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_pkey PRIMARY KEY (id);


--
-- Name: print_agents print_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_pkey PRIMARY KEY (id);


--
-- Name: print_jobs print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_pkey PRIMARY KEY (id);


--
-- Name: product_templates product_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: putaway_capacity putaway_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_pkey PRIMARY KEY (id);


--
-- Name: putaway_home_silenced putaway_home_silenced_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_pkey PRIMARY KEY (id);


--
-- Name: putaway_location_settings putaway_location_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_pkey PRIMARY KEY (id);


--
-- Name: putaway_rule_locations putaway_rule_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_pkey PRIMARY KEY (id);


--
-- Name: putaway_rules putaway_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_pkey PRIMARY KEY (id);


--
-- Name: recipe_collection_members recipe_collection_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_pkey PRIMARY KEY (id);


--
-- Name: recipe_collections recipe_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipe_tag_configs recipe_tag_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shopping_exclusions shopping_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_history shopping_list_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_items shopping_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_pkey PRIMARY KEY (id);


--
-- Name: shopping_lists shopping_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_pkey PRIMARY KEY (id);


--
-- Name: stock_anchors stock_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger_totals stock_ledger_totals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_pkey PRIMARY KEY (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_lots stock_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_pkey PRIMARY KEY (id);


--
-- Name: stock_moves stock_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_closed_locations stock_take_closed_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_counts stock_take_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_take_items stock_take_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);


--
-- Name: stock_takes stock_takes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);


--
-- Name: stock_valuation_layers stock_valuation_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: storage_types storage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tax_rate_assignments tax_rate_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_pkey PRIMARY KEY (id);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: unit_conversions unit_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom_categories uom_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_pkey PRIMARY KEY (id);


--
-- Name: uoms uoms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_pkey PRIMARY KEY (id);


--
-- Name: ai_connections uq_ai_connections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT uq_ai_connections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_bom_lines uq_bom_recipe_child; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT uq_bom_recipe_child UNIQUE (recipe_id, child_template_id);


--
-- Name: document_type_configs uq_doctype_config_org_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT uq_doctype_config_org_type UNIQUE (organization_id, document_type);


--
-- Name: documents uq_document_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT uq_document_org_number UNIQUE (organization_id, number);


--
-- Name: document_package_lines uq_document_package_lines_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT uq_document_package_lines_line UNIQUE (document_package_id, document_line_id);


--
-- Name: document_packages uq_document_packages_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT uq_document_packages_number UNIQUE (document_id, number);


--
-- Name: document_profiles uq_document_profile_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT uq_document_profile_org UNIQUE (organization_id);


--
-- Name: document_shipments uq_document_shipments_document; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT uq_document_shipments_document UNIQUE (document_id);


--
-- Name: document_warehouse_receiving uq_document_warehouse_receiving_org_warehouse; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT uq_document_warehouse_receiving_org_warehouse UNIQUE (organization_id, warehouse_id);


--
-- Name: event_deliveries uq_event_deliveries_event_handler; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT uq_event_deliveries_event_handler UNIQUE (event_id, handler);


--
-- Name: ingredient_nutrition_defaults uq_ingredient_defaults_org_lang_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT uq_ingredient_defaults_org_lang_name UNIQUE (organization_id, lang, name_normalized);


--
-- Name: inventory_periods uq_inventory_period_org_year_month; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT uq_inventory_period_org_year_month UNIQUE (organization_id, year, month);


--
-- Name: label_pool uq_label_pool_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT uq_label_pool_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: stock_lots uq_lot_org_product_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT uq_lot_org_product_name UNIQUE (organization_id, product_template_id, name);


--
-- Name: meal_plan_entries uq_meal_plan_entries_plan_date_slot_order; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT uq_meal_plan_entries_plan_date_slot_order UNIQUE (meal_plan_id, date, slot, "order");


--
-- Name: partners uq_partner_org_name_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT uq_partner_org_name_type UNIQUE (organization_id, name, type);


--
-- Name: po_reorder_rules uq_po_reorder_rules_org_product_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT uq_po_reorder_rules_org_product_loc UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: po_settings uq_po_settings_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT uq_po_settings_org UNIQUE (organization_id);


--
-- Name: print_agents uq_print_agents_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT uq_print_agents_org_name UNIQUE (organization_id, name);


--
-- Name: purchase_orders uq_purchase_orders_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT uq_purchase_orders_org_number UNIQUE (organization_id, number);


--
-- Name: putaway_capacity uq_putaway_capacity_org_loc_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT uq_putaway_capacity_org_loc_product UNIQUE (organization_id, location_id, product_template_id);


--
-- Name: putaway_home_silenced uq_putaway_home_silenced_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT uq_putaway_home_silenced_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: putaway_location_settings uq_putaway_location_settings_org_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT uq_putaway_location_settings_org_loc UNIQUE (organization_id, location_id);


--
-- Name: putaway_rule_locations uq_putaway_rule_locations_rule_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT uq_putaway_rule_locations_rule_loc UNIQUE (rule_id, location_id);


--
-- Name: recipe_collection_members uq_recipe_collection_members; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT uq_recipe_collection_members UNIQUE (collection_id, recipe_id);


--
-- Name: recipe_collections uq_recipe_collections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT uq_recipe_collections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_recipes uq_recipe_org_template_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT uq_recipe_org_template_name UNIQUE (organization_id, output_template_id, name);


--
-- Name: recipe_tag_configs uq_recipe_tag_configs_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT uq_recipe_tag_configs_org_name UNIQUE (organization_id, name);


--
-- Name: shopping_exclusions uq_shopping_exclusions_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT uq_shopping_exclusions_org_name UNIQUE (organization_id, name_normalized);


--
-- Name: stock_anchors uq_stock_anchor_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT uq_stock_anchor_group UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_take_closed_locations uq_stock_take_closed_locations_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT uq_stock_take_closed_locations_location UNIQUE (stock_take_id, storage_location_id);


--
-- Name: storage_locations uq_storage_locations_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT uq_storage_locations_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_category; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_category UNIQUE (organization_id, category_id);


--
-- Name: tax_rate_assignments uq_tax_rate_assignments_org_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT uq_tax_rate_assignments_org_product UNIQUE (organization_id, product_template_id);


--
-- Name: unit_conversions uq_unit_conv_org_ingredient_unit_lang; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT uq_unit_conv_org_ingredient_unit_lang UNIQUE (organization_id, ingredient_key, source_unit, lang);


--
-- Name: uom_categories uq_uom_category_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uq_uom_category_org_name UNIQUE (organization_id, name);


--
-- Name: uoms uq_uom_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uq_uom_org_name UNIQUE (organization_id, name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pkey PRIMARY KEY (pick_line_id, lot_id);


--
-- Name: wms_pick_lines wms_pick_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_session_documents wms_pick_session_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_pkey PRIMARY KEY (session_id, document_id);


--
-- Name: wms_pick_sessions wms_pick_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_connections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_connections_organization_id ON public.ai_connections USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_created_at ON public.ai_usage_logs USING btree (created_at);


--
-- Name: ix_ai_usage_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_organization_id ON public.ai_usage_logs USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_user_id ON public.ai_usage_logs USING btree (user_id);


--
-- Name: ix_api_keys_hashed_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_api_keys_hashed_key ON public.api_keys USING btree (hashed_key);


--
-- Name: ix_api_keys_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_organization_id ON public.api_keys USING btree (organization_id);


--
-- Name: ix_approval_decisions_approval_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_decisions_approval_request_id ON public.approval_decisions USING btree (approval_request_id);


--
-- Name: ix_approval_requests_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_organization_id ON public.approval_requests USING btree (organization_id);


--
-- Name: ix_approval_requests_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_target ON public.approval_requests USING btree (target_type, target_id, organization_id);


--
-- Name: ix_approval_workflows_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_workflows_organization_id ON public.approval_workflows USING btree (organization_id);


--
-- Name: ix_audit_campaigns_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_org ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_campaigns_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_organization_id ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_log_org_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_created_at_id ON public.audit_log USING btree (organization_id, created_at DESC, id);


--
-- Name: ix_audit_log_org_type_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_type_created_at ON public.audit_log USING btree (organization_id, target_type, created_at DESC, id);


--
-- Name: ix_audit_log_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_target ON public.audit_log USING btree (target_type, target_id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_audit_response_items_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_assignment_id ON public.audit_response_items USING btree (assignment_id);


--
-- Name: ix_audit_response_items_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_item_id ON public.audit_response_items USING btree (item_id);


--
-- Name: ix_audit_response_items_response_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_response_id ON public.audit_response_items USING btree (response_id);


--
-- Name: ix_audit_responses_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_assignment_id ON public.audit_responses USING btree (assignment_id);


--
-- Name: ix_audit_responses_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_id ON public.audit_responses USING btree (campaign_id);


--
-- Name: ix_audit_responses_campaign_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_status ON public.audit_responses USING btree (campaign_id, status);


--
-- Name: ix_audit_responses_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_organization_id ON public.audit_responses USING btree (organization_id);


--
-- Name: ix_audit_responses_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_responses_token ON public.audit_responses USING btree (token);


--
-- Name: ix_bom_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_org ON public.maker_bom_lines USING btree (organization_id);


--
-- Name: ix_bom_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_parent ON public.maker_bom_lines USING btree (parent_template_id);


--
-- Name: ix_bom_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_recipe ON public.maker_bom_lines USING btree (recipe_id);


--
-- Name: ix_categories_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_code ON public.categories USING btree (code);


--
-- Name: ix_categories_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_context_tag ON public.categories USING btree (context_tag);


--
-- Name: ix_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_is_active ON public.categories USING btree (is_active);


--
-- Name: ix_categories_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_module_name ON public.categories USING btree (module_name);


--
-- Name: ix_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_organization_id ON public.categories USING btree (organization_id);


--
-- Name: ix_cycle_count_schedules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cycle_count_schedules_organization_id ON public.cycle_count_schedules USING btree (organization_id);


--
-- Name: ix_doc_relation_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_source ON public.document_relations USING btree (source_document_id);


--
-- Name: ix_doc_relation_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_target ON public.document_relations USING btree (target_document_id);


--
-- Name: ix_doc_templates_org_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_templates_org_module ON public.document_templates USING btree (organization_id, module);


--
-- Name: ix_document_extra_costs_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_document ON public.document_extra_costs USING btree (document_id);


--
-- Name: ix_document_extra_costs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_organization_id ON public.document_extra_costs USING btree (organization_id);


--
-- Name: ix_document_lines_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_brand_trgm ON public.document_lines USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_document_lines_corrects_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_corrects_line_id ON public.document_lines USING btree (corrects_line_id);


--
-- Name: ix_document_lines_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_document_id ON public.document_lines USING btree (document_id);


--
-- Name: ix_document_lines_held; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_held ON public.document_lines USING btree (document_id) WHERE (held_quantity > (0)::numeric);


--
-- Name: ix_document_lines_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_name_trgm ON public.document_lines USING gin (name public.gin_trgm_ops);


--
-- Name: ix_document_lines_puts_away_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_puts_away_line_id ON public.document_lines USING btree (puts_away_line_id);


--
-- Name: ix_document_lines_source_po_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_source_po_line_id ON public.document_lines USING btree (source_po_line_id);


--
-- Name: ix_document_org_partner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_partner ON public.documents USING btree (organization_id, partner_id);


--
-- Name: ix_document_org_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_status_created_at ON public.documents USING btree (organization_id, status, created_at);


--
-- Name: ix_document_org_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_type_status ON public.documents USING btree (organization_id, type, status);


--
-- Name: ix_document_package_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_line_id ON public.document_package_lines USING btree (document_line_id);


--
-- Name: ix_document_package_lines_document_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_package_id ON public.document_package_lines USING btree (document_package_id);


--
-- Name: ix_document_packages_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_document_id ON public.document_packages USING btree (document_id);


--
-- Name: ix_document_packages_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_organization_id ON public.document_packages USING btree (organization_id);


--
-- Name: ix_document_profiles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_profiles_organization_id ON public.document_profiles USING btree (organization_id);


--
-- Name: ix_document_shipments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shipments_organization_id ON public.document_shipments USING btree (organization_id);


--
-- Name: ix_document_templates_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_module ON public.document_templates USING btree (module);


--
-- Name: ix_document_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_organization_id ON public.document_templates USING btree (organization_id);


--
-- Name: ix_document_type_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_type_configs_organization_id ON public.document_type_configs USING btree (organization_id);


--
-- Name: ix_document_warehouse_receiving_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_warehouse_receiving_organization_id ON public.document_warehouse_receiving USING btree (organization_id);


--
-- Name: ix_document_work_item_overlays_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_work_item_overlays_organization_id ON public.document_work_item_overlays USING btree (organization_id);


--
-- Name: ix_documents_backorder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_backorder_id ON public.documents USING btree (backorder_id);


--
-- Name: ix_documents_corrects_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_corrects_document_id ON public.documents USING btree (corrects_document_id);


--
-- Name: ix_documents_external_reference_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_external_reference_trgm ON public.documents USING gin (external_reference public.gin_trgm_ops);


--
-- Name: ix_documents_notes_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_notes_trgm ON public.documents USING gin (notes public.gin_trgm_ops);


--
-- Name: ix_documents_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_number_trgm ON public.documents USING gin (number public.gin_trgm_ops);


--
-- Name: ix_documents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_organization_id ON public.documents USING btree (organization_id);


--
-- Name: ix_documents_partner_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_partner_name_trgm ON public.documents USING gin (((partner_snapshot ->> 'name'::text)) public.gin_trgm_ops);


--
-- Name: ix_email_jobs_next_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_next_attempt_at ON public.email_jobs USING btree (next_attempt_at);


--
-- Name: ix_email_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_organization_id ON public.email_jobs USING btree (organization_id);


--
-- Name: ix_email_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_status ON public.email_jobs USING btree (status);


--
-- Name: ix_eq_assignments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_assignments_org_item ON public.equipment_assignments USING btree (organization_id, item_id);


--
-- Name: ix_eq_attachments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_attachments_org_item ON public.equipment_attachments USING btree (organization_id, item_id);


--
-- Name: ix_eq_maintenance_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_maintenance_org_item ON public.equipment_maintenance_logs USING btree (organization_id, item_id);


--
-- Name: ix_equipment_assignments_assignee_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_assignee_partner_id ON public.equipment_assignments USING btree (assignee_partner_id);


--
-- Name: ix_equipment_assignments_checkout_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_checkout_location_id ON public.equipment_assignments USING btree (checkout_location_id);


--
-- Name: ix_equipment_assignments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_item_id ON public.equipment_assignments USING btree (item_id);


--
-- Name: ix_equipment_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_organization_id ON public.equipment_assignments USING btree (organization_id);


--
-- Name: ix_equipment_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_item_id ON public.equipment_attachments USING btree (item_id);


--
-- Name: ix_equipment_attachments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_organization_id ON public.equipment_attachments USING btree (organization_id);


--
-- Name: ix_equipment_maintenance_logs_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_item_id ON public.equipment_maintenance_logs USING btree (item_id);


--
-- Name: ix_equipment_maintenance_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_organization_id ON public.equipment_maintenance_logs USING btree (organization_id);


--
-- Name: ix_event_deliveries_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_organization_id ON public.event_deliveries USING btree (organization_id);


--
-- Name: ix_event_deliveries_status_next_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_status_next_attempt ON public.event_deliveries USING btree (status, next_attempt_at);


--
-- Name: ix_event_outbox_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_organization_id ON public.event_outbox USING btree (organization_id);


--
-- Name: ix_event_outbox_unpublished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_unpublished ON public.event_outbox USING btree (created_at) WHERE (published_at IS NULL);


--
-- Name: ix_example_widgets_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_example_widgets_organization_id ON public.example_widgets USING btree (organization_id);


--
-- Name: ix_ingredient_defaults_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_defaults_lookup ON public.ingredient_nutrition_defaults USING btree (name_normalized, lang, organization_id);


--
-- Name: ix_ingredient_nutrition_defaults_name_normalized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_name_normalized ON public.ingredient_nutrition_defaults USING btree (name_normalized);


--
-- Name: ix_ingredient_nutrition_defaults_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_organization_id ON public.ingredient_nutrition_defaults USING btree (organization_id);


--
-- Name: ix_item_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_attachments_item_id ON public.item_attachments USING btree (item_id);


--
-- Name: ix_item_history_item_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_item_created ON public.item_history USING btree (item_id, created_at);


--
-- Name: ix_item_history_org_action_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_org_action_created ON public.item_history USING btree (organization_id, action, created_at);


--
-- Name: ix_item_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_organization_id ON public.item_history USING btree (organization_id);


--
-- Name: ix_item_history_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_source_document_id ON public.item_history USING btree (source_document_id);


--
-- Name: ix_item_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_user_id ON public.item_history USING btree (user_id);


--
-- Name: ix_item_import_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_import_jobs_organization_id ON public.item_import_jobs USING btree (organization_id);


--
-- Name: ix_items_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode ON public.items USING btree (barcode);


--
-- Name: ix_items_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode_trgm ON public.items USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_items_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_brand_trgm ON public.items USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_items_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_created_at ON public.items USING btree (created_at);


--
-- Name: ix_items_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_expiry_date ON public.items USING btree (expiry_date);


--
-- Name: ix_items_is_catalog_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_catalog_entry ON public.items USING btree (is_catalog_entry);


--
-- Name: ix_items_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_deleted ON public.items USING btree (is_deleted);


--
-- Name: ix_items_label_code_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_label_code_trgm ON public.items USING gin (label_code public.gin_trgm_ops);


--
-- Name: ix_items_meta_data_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_meta_data_gin ON public.items USING gin (meta_data);


--
-- Name: ix_items_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_module_name ON public.items USING btree (module_name);


--
-- Name: ix_items_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_name_trgm ON public.items USING gin (name public.gin_trgm_ops);


--
-- Name: ix_items_org_archived_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_archived_at ON public.items USING btree (organization_id, is_deleted, COALESCE(deleted_at, created_at) DESC, id);


--
-- Name: ix_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_barcode_active ON public.items USING btree (organization_id, barcode, is_deleted);


--
-- Name: ix_items_org_category_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_category_active ON public.items USING btree (organization_id, category_id, is_deleted);


--
-- Name: ix_items_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_created ON public.items USING btree (organization_id, is_deleted, created_at DESC);


--
-- Name: ix_items_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_name ON public.items USING btree (organization_id, is_deleted, name);


--
-- Name: ix_items_org_not_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_not_deleted ON public.items USING btree (organization_id, is_deleted);


--
-- Name: ix_items_org_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_template_active ON public.items USING btree (organization_id, template_id, is_deleted);


--
-- Name: ix_items_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_organization_id ON public.items USING btree (organization_id);


--
-- Name: ix_items_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_partner_id ON public.items USING btree (partner_id);


--
-- Name: ix_items_quantity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_quantity ON public.items USING btree (quantity);


--
-- Name: ix_items_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number ON public.items USING btree (serial_number);


--
-- Name: ix_items_serial_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number_trgm ON public.items USING gin (serial_number public.gin_trgm_ops);


--
-- Name: ix_items_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_source_document_id ON public.items USING btree (source_document_id);


--
-- Name: ix_items_stock_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_stock_group ON public.items USING btree (organization_id, template_id, storage_location_id, lot_id, owner_id) INCLUDE (quantity, is_deleted);


--
-- Name: ix_items_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_storage_location_id ON public.items USING btree (storage_location_id);


--
-- Name: ix_label_pool_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_context_tag ON public.label_pool USING btree (context_tag);


--
-- Name: ix_label_pool_is_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_is_assigned ON public.label_pool USING btree (is_assigned);


--
-- Name: ix_location_relocations_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_relocations_org_moved_at ON public.location_relocations USING btree (organization_id, moved_at);


--
-- Name: ix_lot_org_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_org_expiry ON public.stock_lots USING btree (organization_id, expiry_date);


--
-- Name: ix_meal_plan_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_date ON public.meal_plan_entries USING btree (date);


--
-- Name: ix_meal_plan_entries_meal_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_meal_plan_id ON public.meal_plan_entries USING btree (meal_plan_id);


--
-- Name: ix_meal_plan_entries_plan_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_plan_date ON public.meal_plan_entries USING btree (meal_plan_id, date);


--
-- Name: ix_meal_plan_entries_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_recipe ON public.meal_plan_entries USING btree (recipe_id);


--
-- Name: ix_meal_plans_org_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_end ON public.meal_plans USING btree (organization_id, end_date);


--
-- Name: ix_meal_plans_org_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_start ON public.meal_plans USING btree (organization_id, start_date);


--
-- Name: ix_meal_plans_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_organization_id ON public.meal_plans USING btree (organization_id);


--
-- Name: ix_module_installations_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_module_installations_module_name ON public.module_installations USING btree (module_name);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_organization_invitations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organization_invitations_code ON public.organization_invitations USING btree (code);


--
-- Name: ix_organizations_short_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_short_id ON public.organizations USING btree (short_id);


--
-- Name: ix_partners_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_code ON public.partners USING btree (code);


--
-- Name: ix_partners_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_is_active ON public.partners USING btree (is_active);


--
-- Name: ix_partners_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_name_trgm ON public.partners USING gin (name public.gin_trgm_ops);


--
-- Name: ix_partners_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_organization_id ON public.partners USING btree (organization_id);


--
-- Name: ix_picking_session_items_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_session_items_session_id ON public.picking_session_items USING btree (session_id);


--
-- Name: ix_picking_sessions_meal_plan_entry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_meal_plan_entry_id ON public.picking_sessions USING btree (meal_plan_entry_id);


--
-- Name: ix_picking_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_organization_id ON public.picking_sessions USING btree (organization_id);


--
-- Name: ix_picking_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_user_id ON public.picking_sessions USING btree (user_id);


--
-- Name: ix_po_partner_pricelist_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_organization_id ON public.po_partner_pricelist USING btree (organization_id);


--
-- Name: ix_po_partner_pricelist_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_partner_id ON public.po_partner_pricelist USING btree (partner_id);


--
-- Name: ix_po_partner_pricelist_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_product_template_id ON public.po_partner_pricelist USING btree (product_template_id);


--
-- Name: ix_po_partner_pricelist_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_template_active ON public.po_partner_pricelist USING btree (product_template_id, valid_from, valid_to);


--
-- Name: ix_po_reorder_rules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_organization_id ON public.po_reorder_rules USING btree (organization_id);


--
-- Name: ix_po_reorder_rules_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_product_template_id ON public.po_reorder_rules USING btree (product_template_id);


--
-- Name: ix_po_reorder_rules_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_storage_location_id ON public.po_reorder_rules USING btree (storage_location_id);


--
-- Name: ix_po_settings_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_settings_organization_id ON public.po_settings USING btree (organization_id);


--
-- Name: ix_print_agents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_agents_organization_id ON public.print_agents USING btree (organization_id);


--
-- Name: ix_print_jobs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_agent_id ON public.print_jobs USING btree (agent_id);


--
-- Name: ix_print_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_organization_id ON public.print_jobs USING btree (organization_id);


--
-- Name: ix_print_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_status ON public.print_jobs USING btree (status);


--
-- Name: ix_prod_line_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_line_order ON public.maker_production_order_lines USING btree (production_order_id);


--
-- Name: ix_prod_org_output; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_output ON public.maker_production_orders USING btree (organization_id, output_template_id);


--
-- Name: ix_prod_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_status ON public.maker_production_orders USING btree (organization_id, status);


--
-- Name: ix_product_templates_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode ON public.product_templates USING btree (barcode);


--
-- Name: ix_product_templates_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode_trgm ON public.product_templates USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_product_templates_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_name_trgm ON public.product_templates USING gin (name public.gin_trgm_ops);


--
-- Name: ix_product_templates_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_org_name ON public.product_templates USING btree (organization_id, name);


--
-- Name: ix_product_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_organization_id ON public.product_templates USING btree (organization_id);


--
-- Name: ix_product_templates_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku ON public.product_templates USING btree (sku);


--
-- Name: ix_product_templates_sku_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku_trgm ON public.product_templates USING gin (sku public.gin_trgm_ops);


--
-- Name: ix_purchase_order_lines_purchase_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_purchase_order_id ON public.purchase_order_lines USING btree (purchase_order_id);


--
-- Name: ix_purchase_order_lines_source_reorder_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_source_reorder_rule_id ON public.purchase_order_lines USING btree (source_reorder_rule_id);


--
-- Name: ix_purchase_orders_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_number ON public.purchase_orders USING btree (number);


--
-- Name: ix_purchase_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_organization_id ON public.purchase_orders USING btree (organization_id);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_putaway_capacity_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_capacity_org ON public.putaway_capacity USING btree (organization_id);


--
-- Name: ix_putaway_home_silenced_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_home_silenced_organization_id ON public.putaway_home_silenced USING btree (organization_id);


--
-- Name: ix_putaway_rule_locations_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rule_locations_rule ON public.putaway_rule_locations USING btree (rule_id);


--
-- Name: ix_putaway_rules_org_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_category ON public.putaway_rules USING btree (organization_id, category_id);


--
-- Name: ix_putaway_rules_org_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_priority ON public.putaway_rules USING btree (organization_id, priority);


--
-- Name: ix_putaway_rules_org_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_product ON public.putaway_rules USING btree (organization_id, product_template_id);


--
-- Name: ix_recipe_collection_members_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_collection_id ON public.recipe_collection_members USING btree (collection_id);


--
-- Name: ix_recipe_collection_members_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_recipe_id ON public.recipe_collection_members USING btree (recipe_id);


--
-- Name: ix_recipe_collections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_organization_id ON public.recipe_collections USING btree (organization_id);


--
-- Name: ix_recipe_collections_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_parent_id ON public.recipe_collections USING btree (parent_id);


--
-- Name: ix_recipe_cost_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_org ON public.maker_recipe_cost_lines USING btree (organization_id);


--
-- Name: ix_recipe_cost_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_recipe ON public.maker_recipe_cost_lines USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_ingredient_group_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_ingredient_group_name ON public.recipe_ingredients USING btree (ingredient_group_name);


--
-- Name: ix_recipe_ingredients_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_recipe_id ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_template_id ON public.recipe_ingredients USING btree (template_id);


--
-- Name: ix_recipe_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_org_template ON public.maker_recipes USING btree (organization_id, output_template_id);


--
-- Name: ix_recipe_tag_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_tag_configs_organization_id ON public.recipe_tag_configs USING btree (organization_id);


--
-- Name: ix_recipes_is_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_is_favorite ON public.recipes USING btree (is_favorite);


--
-- Name: ix_recipes_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_organization_id ON public.recipes USING btree (organization_id);


--
-- Name: ix_registration_requests_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);


--
-- Name: ix_registration_requests_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_token ON public.registration_requests USING btree (token);


--
-- Name: ix_reservation_anchor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_anchor ON public.stock_reservations USING btree (anchor_id);


--
-- Name: ix_reservation_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_document ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_reservation_org_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_org_doc ON public.stock_reservations USING btree (organization_id, document_id);


--
-- Name: ix_roles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_organization_id ON public.roles USING btree (organization_id);


--
-- Name: ix_shopping_exclusions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_exclusions_organization_id ON public.shopping_exclusions USING btree (organization_id);


--
-- Name: ix_shopping_list_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_organization_id ON public.shopping_list_history USING btree (organization_id);


--
-- Name: ix_shopping_list_history_original_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_original_list_id ON public.shopping_list_history USING btree (original_list_id);


--
-- Name: ix_shopping_list_items_is_purchased; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_items_is_purchased ON public.shopping_list_items USING btree (is_purchased);


--
-- Name: ix_shopping_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_lists_status ON public.shopping_lists USING btree (status);


--
-- Name: ix_stock_anchors_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_product_template_id ON public.stock_anchors USING btree (product_template_id);


--
-- Name: ix_stock_anchors_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_storage_location_id ON public.stock_anchors USING btree (storage_location_id);


--
-- Name: ix_stock_ledger_totals_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_product_template_id ON public.stock_ledger_totals USING btree (product_template_id);


--
-- Name: ix_stock_ledger_totals_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_totals_storage_location_id ON public.stock_ledger_totals USING btree (storage_location_id);


--
-- Name: ix_stock_lots_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_expiry_date ON public.stock_lots USING btree (expiry_date);


--
-- Name: ix_stock_lots_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_organization_id ON public.stock_lots USING btree (organization_id);


--
-- Name: ix_stock_lots_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_product_template_id ON public.stock_lots USING btree (product_template_id);


--
-- Name: ix_stock_moves_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_completed_at ON public.stock_moves USING btree (completed_at);


--
-- Name: ix_stock_moves_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_at ON public.stock_moves USING btree (created_at);


--
-- Name: ix_stock_moves_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_by ON public.stock_moves USING btree (created_by);


--
-- Name: ix_stock_moves_from_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_from_loc ON public.stock_moves USING btree (from_location_id);


--
-- Name: ix_stock_moves_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_lot_id ON public.stock_moves USING btree (lot_id);


--
-- Name: ix_stock_moves_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_moved_at ON public.stock_moves USING btree (organization_id, COALESCE(completed_at, created_at) DESC, id);


--
-- Name: ix_stock_moves_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_template ON public.stock_moves USING btree (organization_id, product_template_id);


--
-- Name: ix_stock_moves_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_organization_id ON public.stock_moves USING btree (organization_id);


--
-- Name: ix_stock_moves_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_owner_id ON public.stock_moves USING btree (owner_id);


--
-- Name: ix_stock_moves_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_product_template_id ON public.stock_moves USING btree (product_template_id);


--
-- Name: ix_stock_moves_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_reference ON public.stock_moves USING btree (reference_type, reference_id);


--
-- Name: ix_stock_moves_to_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_to_loc ON public.stock_moves USING btree (to_location_id);


--
-- Name: ix_stock_reservations_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_document_id ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_stock_reservations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_organization_id ON public.stock_reservations USING btree (organization_id);


--
-- Name: ix_stock_take_closed_locations_stock_take_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_closed_locations_stock_take_id ON public.stock_take_closed_locations USING btree (stock_take_id);


--
-- Name: ix_stock_take_counts_stock_take_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_counts_stock_take_item_id ON public.stock_take_counts USING btree (stock_take_item_id);


--
-- Name: ix_stock_takes_schedule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_takes_schedule_id ON public.stock_takes USING btree (schedule_id);


--
-- Name: ix_stock_valuation_layers_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_organization_id ON public.stock_valuation_layers USING btree (organization_id);


--
-- Name: ix_stock_valuation_layers_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_product_template_id ON public.stock_valuation_layers USING btree (product_template_id);


--
-- Name: ix_storage_locations_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_context_tag ON public.storage_locations USING btree (context_tag);


--
-- Name: ix_storage_locations_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_org_name ON public.storage_locations USING btree (organization_id, name);


--
-- Name: ix_storage_locations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_organization_id ON public.storage_locations USING btree (organization_id);


--
-- Name: ix_storage_locations_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_parent_id ON public.storage_locations USING btree (parent_id);


--
-- Name: ix_svl_org_direction_dated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_dated_at ON public.stock_valuation_layers USING btree (organization_id, direction, COALESCE(document_date, ((created_at AT TIME ZONE 'UTC'::text))::date), created_at, id);


--
-- Name: ix_svl_org_direction_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_reason ON public.stock_valuation_layers USING btree (organization_id, direction, reason);


--
-- Name: ix_svl_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_template ON public.stock_valuation_layers USING btree (organization_id, product_template_id);


--
-- Name: ix_svl_template_remaining; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_template_remaining ON public.stock_valuation_layers USING btree (organization_id, product_template_id, remaining_qty);


--
-- Name: ix_tax_rate_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_organization_id ON public.tax_rate_assignments USING btree (organization_id);


--
-- Name: ix_tax_rate_assignments_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_assignments_tax_rate_id ON public.tax_rate_assignments USING btree (tax_rate_id);


--
-- Name: ix_tax_rates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rates_organization_id ON public.tax_rates USING btree (organization_id);


--
-- Name: ix_unit_conv_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conv_lookup ON public.unit_conversions USING btree (ingredient_key, source_unit, lang, organization_id);


--
-- Name: ix_unit_conversions_ingredient_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_ingredient_key ON public.unit_conversions USING btree (ingredient_key);


--
-- Name: ix_unit_conversions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_organization_id ON public.unit_conversions USING btree (organization_id);


--
-- Name: ix_uom_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uom_categories_organization_id ON public.uom_categories USING btree (organization_id);


--
-- Name: ix_uoms_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uoms_organization_id ON public.uoms USING btree (organization_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_is_superuser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_is_superuser ON public.users USING btree (is_superuser);


--
-- Name: ix_users_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_organization_id ON public.users USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_organization_id ON public.webhook_delivery_logs USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_webhook_endpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_webhook_endpoint_id ON public.webhook_delivery_logs USING btree (webhook_endpoint_id);


--
-- Name: ix_webhook_endpoints_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_endpoints_organization_id ON public.webhook_endpoints USING btree (organization_id);


--
-- Name: ix_wms_pick_line_lots_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_line_lots_lot_id ON public.wms_pick_line_lots USING btree (lot_id);


--
-- Name: ix_wms_pick_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_document_line_id ON public.wms_pick_lines USING btree (document_line_id);


--
-- Name: ix_wms_pick_lines_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_session_id ON public.wms_pick_lines USING btree (session_id);


--
-- Name: ix_wms_pick_session_documents_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_session_documents_document_id ON public.wms_pick_session_documents USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_document_id ON public.wms_pick_sessions USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_organization_id ON public.wms_pick_sessions USING btree (organization_id);


--
-- Name: uq_document_org_post_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_org_post_key ON public.documents USING btree (organization_id, post_key) WHERE (post_key IS NOT NULL);


--
-- Name: uq_document_work_item_overlays_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_work_item_overlays_source ON public.document_work_item_overlays USING btree (organization_id, source_kind, source_id) WHERE (source_id IS NOT NULL);


--
-- Name: uq_eq_assignments_active_per_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_eq_assignments_active_per_item ON public.equipment_assignments USING btree (item_id) WHERE (checked_in_at IS NULL);


--
-- Name: uq_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_barcode_active ON public.items USING btree (organization_id, barcode) WHERE ((barcode IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_items_org_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_serial ON public.items USING btree (organization_id, serial_number) WHERE ((serial_number IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_partner_org_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_partner_org_code ON public.partners USING btree (organization_id, code) WHERE (code IS NOT NULL);


--
-- Name: uq_pending_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pending_request ON public.approval_requests USING btree (organization_id, target_type, target_id) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying])::text[]));


--
-- Name: uq_prod_org_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_prod_org_number ON public.maker_production_orders USING btree (organization_id, number) WHERE (number IS NOT NULL);


--
-- Name: uq_recipe_default_per_template; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_recipe_default_per_template ON public.maker_recipes USING btree (organization_id, output_template_id) WHERE (is_default = true);


--
-- Name: uq_stock_moves_backfill_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_stock_moves_backfill_ref ON public.stock_moves USING btree (reference_type, reference_id) WHERE ((reference_type)::text = 'item_history'::text);


--
-- Name: uq_storage_locations_org_parent_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_storage_locations_org_parent_name ON public.storage_locations USING btree (organization_id, parent_id, name) WHERE (parent_id IS NOT NULL);


--
-- Name: uq_storage_locations_org_root_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_storage_locations_org_root_name ON public.storage_locations USING btree (organization_id, name) WHERE (parent_id IS NULL);


--
-- Name: uq_templates_org_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_barcode ON public.product_templates USING btree (organization_id, barcode) WHERE (barcode IS NOT NULL);


--
-- Name: uq_templates_org_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_sku ON public.product_templates USING btree (organization_id, sku) WHERE (sku IS NOT NULL);


--
-- Name: uq_uom_category_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uom_category_reference ON public.uoms USING btree (category_id) WHERE (is_reference = true);


--
-- Name: uq_workflow_org_target; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_workflow_org_target ON public.approval_workflows USING btree (organization_id, target_type) WHERE (archived_at IS NULL);


--
-- Name: audit_log audit_log_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_log_immutable BEFORE DELETE OR UPDATE ON public.audit_log FOR EACH ROW EXECUTE FUNCTION public.audit_log_immutable();


--
-- Name: items ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER UPDATE OF quantity, lot_id, owner_id, storage_location_id, template_id, is_deleted ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL) AND ((new.is_deleted IS NOT FALSE) OR (new.template_id IS DISTINCT FROM old.template_id) OR (new.storage_location_id IS DISTINCT FROM old.storage_location_id) OR (new.lot_id IS DISTINCT FROM old.lot_id) OR (new.owner_id IS DISTINCT FROM old.owner_id) OR (new.quantity IS NULL) OR (new.quantity = 'NaN'::numeric) OR (new.quantity < old.quantity)))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_reservations ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER INSERT OR UPDATE OF quantity, anchor_id, lot_id, owner_id ON public.stock_reservations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: items ck_stock_holds_within_stock_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock_on_delete AFTER DELETE ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_moves stock_ledger_totals_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_delete AFTER DELETE ON public.stock_moves REFERENCING OLD TABLE AS old_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_insert AFTER INSERT ON public.stock_moves REFERENCING NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: stock_moves stock_ledger_totals_on_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_ledger_totals_on_update AFTER UPDATE ON public.stock_moves REFERENCING OLD TABLE AS old_moves NEW TABLE AS new_moves FOR EACH STATEMENT EXECUTE FUNCTION public.stock_ledger_totals_follow_moves();


--
-- Name: ai_connections ai_connections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approval_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approval_request_id_fkey FOREIGN KEY (approval_request_id) REFERENCES public.approval_requests(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.approval_workflows(id) ON DELETE RESTRICT;


--
-- Name: approval_workflows approval_workflows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_campaigns audit_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_campaigns audit_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_response_items audit_response_items_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_response_id_fkey FOREIGN KEY (response_id) REFERENCES public.audit_responses(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.audit_campaigns(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: categories categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_extra_costs document_extra_costs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_corrects_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_corrects_line_id_fkey FOREIGN KEY (corrects_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_executed_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_executed_location_id_fkey FOREIGN KEY (executed_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_puts_away_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_puts_away_line_id_fkey FOREIGN KEY (puts_away_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: document_number_sequences document_number_sequences_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_package_id_fkey FOREIGN KEY (document_package_id) REFERENCES public.document_packages(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_packages document_packages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_default_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_default_template_id_fkey FOREIGN KEY (default_template_id) REFERENCES public.document_templates(id) ON DELETE SET NULL;


--
-- Name: document_profiles document_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_quarantine_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_quarantine_location_id_fkey FOREIGN KEY (quarantine_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_relations document_relations_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_relations document_relations_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_shipped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_shipped_by_fkey FOREIGN KEY (shipped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates document_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_type_configs document_type_configs_default_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_source_location_id_fkey FOREIGN KEY (default_source_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_default_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_target_location_id_fkey FOREIGN KEY (default_target_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_receiving_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_receiving_location_id_fkey FOREIGN KEY (receiving_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: document_work_item_overlays document_work_item_overlays_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_backorder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_backorder_id_fkey FOREIGN KEY (backorder_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: documents documents_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_corrects_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_corrects_document_id_fkey FOREIGN KEY (corrects_document_id) REFERENCES public.documents(id) ON DELETE RESTRICT;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: documents documents_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: documents documents_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_assignee_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_assignee_partner_id_fkey FOREIGN KEY (assignee_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_in_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_in_by_fkey FOREIGN KEY (checked_in_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_out_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_out_by_fkey FOREIGN KEY (checked_out_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checkout_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checkout_location_id_fkey FOREIGN KEY (checkout_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_assignments equipment_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_service_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_service_partner_id_fkey FOREIGN KEY (service_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: example_widgets example_widgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests fk_approval_requests_consumed_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_approval_requests_consumed_by_users FOREIGN KEY (consumed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_history fk_item_history_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_stock_anchor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_stock_anchor FOREIGN KEY (organization_id, template_id, storage_location_id) REFERENCES public.stock_anchors(organization_id, product_template_id, storage_location_id);


--
-- Name: label_pool fk_label_pool_item_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_item_id FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: organizations fk_organizations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT fk_organizations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: picking_sessions fk_picking_sessions_meal_plan_entry_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT fk_picking_sessions_meal_plan_entry_id FOREIGN KEY (meal_plan_entry_id) REFERENCES public.meal_plan_entries(id) ON DELETE SET NULL;


--
-- Name: stock_reservations fk_stock_reservations_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT fk_stock_reservations_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_expected_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_expected_location_id FOREIGN KEY (expected_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_storage_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_storage_location_id FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: users fk_users_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wms_pick_lines fk_wms_pick_lines_anchor_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_anchor_id FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines fk_wms_pick_lines_lot_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_lot_id FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_periods inventory_periods_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_reopened_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_reopened_by_fkey FOREIGN KEY (reopened_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_attachments item_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_history item_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_import_jobs item_import_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_import_jobs item_import_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_import_jobs
    ADD CONSTRAINT item_import_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: items items_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: items items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: items items_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: items items_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: items items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id);


--
-- Name: items items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: label_pool label_pool_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: label_pool label_pool_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: label_pool label_pool_target_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_target_storage_location_id_fkey FOREIGN KEY (target_storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_from_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_from_parent_id_fkey FOREIGN KEY (from_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: location_relocations location_relocations_to_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_to_parent_id_fkey FOREIGN KEY (to_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: maker_bom_lines maker_bom_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_parent_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_parent_template_id_fkey FOREIGN KEY (parent_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_module_settings maker_module_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_order_lines maker_production_order_lines_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_source_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_source_storage_location_id_fkey FOREIGN KEY (source_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_orders maker_production_orders_output_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_storage_location_id_fkey FOREIGN KEY (output_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_orders maker_production_orders_produced_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_produced_item_id_fkey FOREIGN KEY (produced_item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_batch_yield_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_batch_yield_uom_id_fkey FOREIGN KEY (batch_yield_uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_recipes maker_recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_meal_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_meal_plan_id_fkey FOREIGN KEY (meal_plan_id) REFERENCES public.meal_plans(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: meal_plans meal_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: meal_plans meal_plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: organization_invitations organization_invitations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: organization_invitations organization_invitations_used_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_used_by_user_id_fkey FOREIGN KEY (used_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners partners_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_session_items picking_session_items_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.recipe_ingredients(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.picking_sessions(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: po_partner_pricelist po_partner_pricelist_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_preferred_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_preferred_partner_id_fkey FOREIGN KEY (preferred_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: po_settings po_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_agents print_agents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.print_agents(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_jobs print_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates product_templates_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_volume_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_volume_uom_id_fkey FOREIGN KEY (volume_uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates product_templates_weight_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_weight_uom_id_fkey FOREIGN KEY (weight_uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_order_lines purchase_order_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines purchase_order_lines_source_reorder_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_source_reorder_rule_id_fkey FOREIGN KEY (source_reorder_rule_id) REFERENCES public.po_reorder_rules(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_orders purchase_orders_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: putaway_capacity putaway_capacity_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_home_silenced putaway_home_silenced_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_home_silenced
    ADD CONSTRAINT putaway_home_silenced_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.putaway_rules(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipe_collections recipe_collections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_price_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_price_uom_id_fkey FOREIGN KEY (price_uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_tag_configs recipe_tag_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipes recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: registration_requests registration_requests_approved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_approved_by_id_fkey FOREIGN KEY (approved_by_id) REFERENCES public.users(id);


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: shopping_exclusions shopping_exclusions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_exclusions shopping_exclusions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_history shopping_list_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_list_history shopping_list_history_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: shopping_list_items shopping_list_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_shopping_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_shopping_list_id_fkey FOREIGN KEY (shopping_list_id) REFERENCES public.shopping_lists(id) ON DELETE CASCADE;


--
-- Name: shopping_list_items shopping_list_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: shopping_lists shopping_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shopping_lists shopping_lists_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_ledger_totals stock_ledger_totals_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger_totals
    ADD CONSTRAINT stock_ledger_totals_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_lots stock_lots_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_anchor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_anchor_id_fkey FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_counted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_counted_by_fkey FOREIGN KEY (counted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_stock_take_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_stock_take_item_id_fkey FOREIGN KEY (stock_take_item_id) REFERENCES public.stock_take_items(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: stock_take_items stock_take_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_take_items stock_take_items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id);


--
-- Name: stock_take_items stock_take_items_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: stock_takes stock_takes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.cycle_count_schedules(id) ON DELETE SET NULL;


--
-- Name: stock_takes stock_takes_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers stock_valuation_layers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_locations storage_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: storage_locations storage_locations_storage_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_storage_type_id_fkey FOREIGN KEY (storage_type_id) REFERENCES public.storage_types(id);


--
-- Name: storage_types storage_types_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_types storage_types_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tax_rate_assignments tax_rate_assignments_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: tax_rate_assignments tax_rate_assignments_tax_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_assignments
    ADD CONSTRAINT tax_rate_assignments_tax_rate_id_fkey FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rates(id) ON DELETE CASCADE;


--
-- Name: tax_rates tax_rates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: unit_conversions unit_conversions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uom_categories uom_categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uoms uoms_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.uom_categories(id);


--
-- Name: uoms uoms_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_webhook_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_webhook_endpoint_id_fkey FOREIGN KEY (webhook_endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pick_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pick_line_id_fkey FOREIGN KEY (pick_line_id) REFERENCES public.wms_pick_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines wms_pick_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: wms_pick_sessions wms_pick_sessions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


