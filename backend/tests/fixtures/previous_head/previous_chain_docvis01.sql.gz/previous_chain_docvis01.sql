-- The database the pre-0.11.0 core chain left at its last revision (docvis01).
-- Cut from the development line at 3db341e78 with the demo reset and dump
-- procedure of scripts/release-db-snapshot.sh.
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: audit_log_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_log_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_log rows are immutable: % operation not allowed', TG_OP;
    RETURN NULL;
END;
$$;


--
-- Name: stock_holds_within_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_holds_within_stock() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
DECLARE
    g_anchor uuid;
    g_lot uuid;
    g_owner uuid;
    anchor stock_anchors%ROWTYPE;
    held numeric;
    on_hand numeric;
BEGIN
    IF TG_TABLE_NAME = 'stock_reservations' THEN
        g_anchor := NEW.anchor_id;
        g_lot := NEW.lot_id;
        g_owner := NEW.owner_id;
    ELSE
        SELECT id INTO g_anchor FROM stock_anchors
         WHERE organization_id = OLD.organization_id
           AND product_template_id = OLD.template_id
           AND storage_location_id = OLD.storage_location_id;
        g_lot := OLD.lot_id;
        g_owner := OLD.owner_id;
    END IF;
    -- A group with no anchor has no reservation rows to hold it.
    IF g_anchor IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT coalesce(sum(quantity), 0) INTO held
      FROM stock_reservations
     WHERE anchor_id = g_anchor
       AND lot_id IS NOT DISTINCT FROM g_lot
       AND owner_id IS NOT DISTINCT FROM g_owner;
    IF held = 0 THEN
        RETURN NULL;
    END IF;

    SELECT * INTO anchor FROM stock_anchors WHERE id = g_anchor;
    SELECT coalesce(sum(nullif(quantity, 'NaN'::numeric)), 0) INTO on_hand
      FROM items
     WHERE organization_id = anchor.organization_id
       AND template_id = anchor.product_template_id
       AND storage_location_id = anchor.storage_location_id
       AND lot_id IS NOT DISTINCT FROM g_lot
       AND owner_id IS NOT DISTINCT FROM g_owner
       AND is_deleted IS FALSE;

    IF held > on_hand THEN
        RAISE EXCEPTION
            'ck_stock_holds_within_stock: % reserved of a grain holding %',
            held, on_hand
        USING ERRCODE = 'check_violation',
              CONSTRAINT = 'ck_stock_holds_within_stock',
              DETAIL = format(
                  'product %s, shelf %s, batch %s, owner %s',
                  anchor.product_template_id,
                  anchor.storage_location_id,
                  coalesce(g_lot::text, '-'),
                  coalesce(g_owner::text, '-')
              );
    END IF;
    RETURN NULL;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_connections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    api_key_enc character varying DEFAULT ''::character varying NOT NULL,
    api_base_url character varying(512) DEFAULT ''::character varying NOT NULL,
    model_name character varying(255) DEFAULT ''::character varying NOT NULL,
    temperature double precision,
    max_tokens integer,
    top_p double precision,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    capability_checks jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage_logs (
    id uuid NOT NULL,
    user_id uuid,
    organization_id uuid NOT NULL,
    model_name character varying(255) NOT NULL,
    provider character varying(100),
    prompt_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    total_tokens integer NOT NULL,
    estimated_cost_usd double precision,
    cost_is_estimated boolean DEFAULT false NOT NULL,
    action_type character varying(100),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_api_keys (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_approvals (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_equipment (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_example_widgets (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_maker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_maker (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_printing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_printing (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_purchase_orders (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_recipes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_shopping_lists (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_stock_takes (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_warehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_warehouse (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version_webhooks (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) NOT NULL,
    active_from timestamp with time zone NOT NULL,
    active_until timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    hashed_key character varying(64) NOT NULL,
    key_prefix character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    scope character varying(32)
);


--
-- Name: approval_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_decisions (
    id uuid NOT NULL,
    approval_request_id uuid NOT NULL,
    stage_order integer NOT NULL,
    approver_id uuid,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    notes text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    current_stage integer DEFAULT 1 NOT NULL,
    total_stages integer NOT NULL,
    created_by uuid NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    consumed_by uuid
);


--
-- Name: approval_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_workflows (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    stages json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    archived_at timestamp with time zone,
    requester_scope jsonb DEFAULT '{"everyone": true}'::jsonb NOT NULL
);


--
-- Name: audit_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_campaigns (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    scope_type character varying(20) NOT NULL,
    scope_filter_id uuid,
    launched_at timestamp with time zone,
    deadline timestamp with time zone NOT NULL,
    reminder_days_before integer NOT NULL,
    last_reminder_sent_at timestamp with time zone,
    status character varying(20) NOT NULL,
    email_subject character varying(255),
    email_body text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    snapshot json,
    reason character varying(500),
    meta_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_response_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_response_items (
    id uuid NOT NULL,
    response_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    item_id uuid NOT NULL,
    item_name character varying(255) NOT NULL,
    serial_number character varying(100),
    status character varying(20) NOT NULL,
    dispute_type character varying(30),
    dispute_reason text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: audit_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_responses (
    id uuid NOT NULL,
    campaign_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    assignment_id uuid,
    assignee_email character varying(255) NOT NULL,
    assignee_name character varying(255) NOT NULL,
    token character varying(86) NOT NULL,
    token_expires_at timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    responded_at timestamp with time zone,
    dispute_reason text,
    dispute_type character varying(30),
    response_ip character varying(45),
    response_user_agent character varying(500),
    email_sent_at timestamp with time zone,
    reminder_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    code character varying(100),
    context_tag character varying(100),
    icon character varying(100),
    sort_order integer NOT NULL,
    meta_data jsonb,
    module_name character varying(50),
    is_active boolean NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    emoji character varying(32),
    color character varying(16),
    group_label character varying(50),
    default_removal_strategy character varying(10)
);


--
-- Name: cycle_count_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cycle_count_schedules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    frequency character varying(20) NOT NULL,
    scope character varying(20) NOT NULL,
    scope_filter json,
    sample_size integer,
    tolerance_percent numeric(5,2),
    is_active boolean NOT NULL,
    last_run_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_cycle_count_schedules_frequency CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying])::text[]))),
    CONSTRAINT ck_cycle_count_schedules_scope CHECK (((scope)::text = ANY ((ARRAY['all'::character varying, 'zone'::character varying, 'category'::character varying])::text[])))
);


--
-- Name: document_extra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extra_costs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(3),
    allocation_method character varying(10) DEFAULT 'value'::character varying NOT NULL,
    note character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_extra_costs_amount CHECK ((amount > (0)::numeric))
);


--
-- Name: document_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_lines (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    item_id uuid,
    product_template_id uuid,
    name character varying(255),
    brand character varying(255),
    barcode character varying(50),
    quantity numeric(12,3) NOT NULL,
    expected_quantity numeric(12,3) NOT NULL,
    done_quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    batch_number character varying(100),
    serial_number character varying(100),
    expiry_date date,
    notes text,
    discrepancy_code character varying(50),
    discrepancy_reason text,
    unit_price numeric(12,2),
    tax_rate numeric(5,2),
    line_value numeric(14,2),
    line_tax numeric(14,2),
    line_gross numeric(14,2),
    currency character varying(3),
    line_number integer NOT NULL,
    source_po_line_id uuid,
    product_snapshot jsonb,
    executed_location_id uuid,
    corrects_line_id uuid,
    target_location_id uuid,
    held_quantity numeric(12,3) DEFAULT 0 NOT NULL,
    source_location_id uuid,
    puts_away_line_id uuid
);


--
-- Name: document_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_number_sequences (
    organization_id uuid NOT NULL,
    prefix character varying(120) NOT NULL,
    next_value integer DEFAULT 1 NOT NULL
);


--
-- Name: document_package_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_package_lines (
    id uuid NOT NULL,
    document_package_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_document_package_lines_quantity CHECK ((quantity > (0)::numeric))
);


--
-- Name: document_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_packages (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    number integer NOT NULL,
    weight_kg numeric(10,3),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ck_document_packages_weight CHECK ((weight_kg > (0)::numeric))
);


--
-- Name: document_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    value_tracking_enabled boolean NOT NULL,
    tax_handling character varying(20) NOT NULL,
    default_tax_rate numeric(5,2),
    require_partner_tax_id boolean,
    numbering_format character varying(100) NOT NULL,
    type_labels json,
    default_unit character varying(20) NOT NULL,
    visible_line_fields json,
    print_template character varying(50) NOT NULL,
    default_currency character varying(3),
    default_template_id uuid,
    approval_threshold numeric(14,2),
    approval_required_for_types json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    number_padding smallint NOT NULL,
    require_unit_price boolean DEFAULT false NOT NULL,
    confirm_shelf_by_scan boolean DEFAULT false NOT NULL,
    tracking_url_templates json,
    quarantine_location_id uuid
);


--
-- Name: document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_relations (
    id uuid NOT NULL,
    source_document_id uuid NOT NULL,
    target_document_id uuid NOT NULL,
    relation_type character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_shipments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    carrier character varying(100) NOT NULL,
    tracking_number character varying(100),
    shipped_at timestamp with time zone NOT NULL,
    shipped_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    module character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(50) NOT NULL,
    body_html text NOT NULL,
    version integer NOT NULL,
    is_default boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    source_builtin character varying(255),
    source_checksum character varying(64)
);


--
-- Name: document_type_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_type_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_type character varying(15) NOT NULL,
    default_source_location_id uuid,
    default_target_location_id uuid,
    sequence_format character varying(50) NOT NULL,
    require_partner boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_warehouse_receiving; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_warehouse_receiving (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    two_step boolean DEFAULT false NOT NULL,
    receiving_location_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_work_item_overlays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_work_item_overlays (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    source_kind character varying(48) NOT NULL,
    source_id uuid,
    assignee_id uuid,
    title character varying(200),
    due_date date,
    done_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    type character varying(15) NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    source_location_id uuid,
    target_location_id uuid,
    scheduled_date date,
    notes text,
    external_reference character varying(100),
    partner_snapshot jsonb,
    corrects_document_id uuid,
    backorder_id uuid,
    total_net numeric(14,2),
    total_tax numeric(14,2),
    total_gross numeric(14,2),
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    completed_at timestamp with time zone,
    reason_code character varying(50),
    is_opening boolean DEFAULT false NOT NULL,
    stock_already_applied boolean DEFAULT false NOT NULL,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    complete_on_approval boolean DEFAULT false NOT NULL,
    post_key character varying(64)
);


--
-- Name: email_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_jobs (
    id uuid NOT NULL,
    organization_id uuid,
    to_email character varying(320) NOT NULL,
    subject character varying(500) NOT NULL,
    html_content text NOT NULL,
    attachment_bytes bytea,
    attachment_filename character varying(255),
    smtp_config_enc text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    failure_notice_enc text
);


--
-- Name: equipment_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_assignments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    assignee_partner_id uuid,
    checkout_location_id uuid,
    assigned_to_name character varying(255) NOT NULL,
    assigned_to_email character varying(255),
    checked_out_at timestamp with time zone NOT NULL,
    expected_return_at timestamp with time zone,
    checked_in_at timestamp with time zone,
    checked_out_by uuid NOT NULL,
    checked_in_by uuid,
    checkout_notes text,
    checkin_notes text,
    checkin_condition character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_type character varying(30) NOT NULL,
    content_type character varying(100) NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: equipment_maintenance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_maintenance_logs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    item_id uuid NOT NULL,
    maintenance_type character varying(30) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    cost numeric(10,2),
    currency character varying(3),
    performed_at date NOT NULL,
    performed_by character varying(255),
    service_partner_id uuid,
    next_maintenance_at date,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_deliveries (
    id uuid NOT NULL,
    event_id character varying(64) NOT NULL,
    event character varying(100) NOT NULL,
    handler character varying(255) NOT NULL,
    organization_id uuid,
    payload jsonb NOT NULL,
    status character varying(16) NOT NULL,
    attempts integer NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_outbox (
    id uuid NOT NULL,
    organization_id uuid,
    event character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    published_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    emitter_module character varying(64)
);


--
-- Name: example_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.example_widgets (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(30) DEFAULT 'blue'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ingredient_nutrition_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_nutrition_defaults (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    calories_kcal numeric(8,2) NOT NULL,
    protein_g numeric(8,2),
    fat_g numeric(8,2),
    carbs_g numeric(8,2),
    fiber_g numeric(8,2),
    sugar_g numeric(8,2),
    salt_g numeric(8,2),
    source character varying(50) NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_periods (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    reopened_at timestamp with time zone,
    reopened_by uuid,
    notes text
);


--
-- Name: item_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_attachments (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_history (
    id uuid NOT NULL,
    organization_id uuid,
    item_id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    changes json,
    source_document_id uuid,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: item_type_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_type_definitions (
    code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    organization_id uuid,
    module_name character varying(50),
    is_system boolean NOT NULL,
    is_active boolean NOT NULL,
    allowed_system_fields json DEFAULT '["brand", "barcode", "quantity", "unit"]'::json NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    category_id uuid,
    name character varying(255) NOT NULL,
    brand character varying(255),
    description character varying(500),
    uom_id uuid,
    template_id uuid,
    quantity numeric(12,3) NOT NULL,
    barcode character varying(50),
    serial_number character varying(100),
    added_date date NOT NULL,
    expiry_date date,
    shelf_location character varying(255),
    item_type character varying(100),
    image_url character varying(500),
    meta_data jsonb,
    purchase_price numeric(10,2),
    currency character varying(3),
    is_deleted boolean NOT NULL,
    is_catalog_entry boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    label_code character varying(20),
    partner_id uuid,
    source_document_id uuid,
    module_name character varying(50),
    lot_id uuid,
    owner_id uuid,
    CONSTRAINT ck_items_quantity_nonneg CHECK ((quantity >= (0)::numeric))
);


--
-- Name: label_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_pool (
    id uuid NOT NULL,
    short_code character varying(100) NOT NULL,
    is_assigned boolean NOT NULL,
    assigned_at timestamp with time zone,
    item_id uuid,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    label_type character varying(50) NOT NULL,
    description character varying(255),
    target_storage_location_id uuid,
    context_tag character varying(50),
    created_at timestamp with time zone NOT NULL,
    printed_at timestamp with time zone,
    scan_count integer NOT NULL,
    last_scanned_at timestamp with time zone
);


--
-- Name: location_relocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_relocations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid,
    location_name character varying(255) NOT NULL,
    from_parent_id uuid,
    to_parent_id uuid,
    from_path text,
    to_path text,
    moved_at timestamp with time zone NOT NULL,
    created_by uuid
);


--
-- Name: maker_bom_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_bom_lines (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_template_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    unit character varying(8) NOT NULL,
    yield_loss_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    recipe_id uuid NOT NULL,
    qty_per_batch numeric(12,4) NOT NULL,
    uom_id uuid,
    CONSTRAINT ck_bom_no_self CHECK ((parent_template_id <> child_template_id)),
    CONSTRAINT ck_bom_qty CHECK ((qty_per_batch > (0)::numeric)),
    CONSTRAINT ck_bom_yield_range CHECK (((yield_loss_pct >= (0)::numeric) AND (yield_loss_pct <= (100)::numeric)))
);


--
-- Name: maker_module_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_module_settings (
    organization_id uuid NOT NULL,
    reference_direction character varying(10) DEFAULT 'MARGIN'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    allow_overproduction boolean DEFAULT true NOT NULL,
    availability_check_scope character varying(15) DEFAULT 'GLOBAL'::character varying NOT NULL,
    create_on_shortage_strategy character varying(10) DEFAULT 'WARN'::character varying NOT NULL
);


--
-- Name: maker_production_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_order_lines (
    id uuid NOT NULL,
    production_order_id uuid NOT NULL,
    child_template_id uuid NOT NULL,
    consumed_qty numeric(12,4) NOT NULL,
    unit character varying(8) NOT NULL,
    source_storage_location_id uuid,
    unit_cost_snapshot numeric(12,4),
    cost_source character varying(16),
    shortfall_qty numeric(12,4)
);


--
-- Name: maker_production_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_production_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    planned_qty numeric(12,3) NOT NULL,
    output_storage_location_id uuid NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    total_cost numeric(12,2),
    production_date date,
    notes character varying(500),
    created_by uuid,
    completed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    cancel_reason character varying(500),
    produced_item_id uuid,
    recipe_id uuid,
    actual_qty numeric(12,3),
    overproduced boolean DEFAULT false NOT NULL,
    scrap_qty numeric(12,3),
    unit_cost_snapshot numeric(12,4),
    reference_price_snapshot numeric(12,2),
    result_per_unit numeric(12,2),
    result_per_batch numeric(12,2),
    number character varying(32),
    short_at_create boolean DEFAULT false NOT NULL
);


--
-- Name: maker_recipe_cost_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipe_cost_lines (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    label character varying(120) NOT NULL,
    amount numeric(12,2) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: maker_recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maker_recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    output_template_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    batch_yield_qty numeric(12,4) DEFAULT '1'::numeric NOT NULL,
    batch_yield_uom_id uuid,
    process_steps jsonb,
    reference_price numeric(12,2),
    is_default boolean DEFAULT false NOT NULL,
    source_recipe_id uuid,
    source_snapshot_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: meal_plan_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_entries (
    id uuid NOT NULL,
    meal_plan_id uuid NOT NULL,
    date date NOT NULL,
    slot character varying(20) NOT NULL,
    recipe_id uuid NOT NULL,
    servings integer,
    notes text,
    "order" integer NOT NULL,
    CONSTRAINT ck_meal_plan_entries_slot CHECK (((slot)::text = ANY ((ARRAY['LUNCH'::character varying, 'BREAKFAST'::character varying, 'DINNER'::character varying, 'SNACK'::character varying])::text[])))
);


--
-- Name: meal_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plans (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255),
    start_date date NOT NULL,
    end_date date NOT NULL,
    enabled_slots jsonb NOT NULL,
    default_servings integer,
    shopping_list_id uuid,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: module_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_installations (
    id uuid NOT NULL,
    module_name character varying(100) NOT NULL,
    installed_version character varying(50) NOT NULL,
    installed_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(1000) NOT NULL,
    type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    link character varying(255),
    meta_data jsonb
);


--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_invitations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    code character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    is_used boolean NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    role_id uuid,
    invited_email character varying(255),
    used_by_user_id uuid,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid,
    enabled_modules json NOT NULL,
    allowed_modules json,
    settings json NOT NULL,
    short_id character varying(20),
    active_profile_id character varying(50),
    onboarding_completed boolean DEFAULT false,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'UTC'::character varying NOT NULL,
    tax_id character varying(50),
    country character varying(2),
    address json,
    logo_url character varying(500),
    focus_module character varying(50),
    pre_focus_enabled_modules json,
    print_page_size character varying(10),
    pre_onboarding_manual_modules json
);


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    type character varying(30) NOT NULL,
    tax_id character varying(50),
    email character varying(255),
    phone character varying(50),
    website character varying(500),
    contact_person character varying(255),
    address jsonb,
    notes text,
    is_active boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_consumer boolean DEFAULT false NOT NULL
);


--
-- Name: picking_session_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_session_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    ingredient_id uuid,
    item_id uuid,
    quantity_consumed numeric(10,3),
    picked_items jsonb,
    consumed_valuation_rate numeric(12,2),
    status character varying(20) NOT NULL,
    ingredient_name character varying(255),
    required_quantity numeric(10,3),
    required_uom_symbol character varying(10)
);


--
-- Name: picking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.picking_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    user_id uuid NOT NULL,
    servings integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    rating integer,
    scale numeric(10,3)
);


--
-- Name: po_partner_pricelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_partner_pricelist (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    partner_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    uom_id uuid,
    min_quantity numeric(12,3),
    valid_from date NOT NULL,
    valid_to date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_partner_pricelist_min_qty_positive CHECK (((min_quantity IS NULL) OR (min_quantity > (0)::numeric))),
    CONSTRAINT ck_po_partner_pricelist_unit_price_positive CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT ck_po_partner_pricelist_valid_range CHECK (((valid_to IS NULL) OR (valid_to >= valid_from)))
);


--
-- Name: po_reorder_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_reorder_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    min_quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    safety_stock numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    preferred_partner_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_po_reorder_rules_max_ge_min CHECK ((max_quantity >= min_quantity)),
    CONSTRAINT ck_po_reorder_rules_min_nonneg CHECK ((min_quantity >= (0)::numeric)),
    CONSTRAINT ck_po_reorder_rules_safety_nonneg CHECK ((safety_stock >= (0)::numeric))
);


--
-- Name: po_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    approval_threshold numeric(14,2),
    approval_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: print_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_agents (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    printer_type character varying(50) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_version character varying(50),
    protocol_version integer
);


--
-- Name: print_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_jobs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    labels jsonb NOT NULL,
    created_by uuid,
    attempts integer NOT NULL,
    lease_until timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    width_mm double precision DEFAULT 50.0 NOT NULL,
    height_mm double precision DEFAULT 24.0 NOT NULL,
    scale double precision
);


--
-- Name: product_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_templates (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    brand character varying(255),
    barcode character varying(50),
    sku character varying(50),
    uom_id uuid,
    weight_value numeric(14,6),
    weight_uom_id uuid,
    volume_value numeric(14,6),
    volume_uom_id uuid,
    image_url character varying(500),
    description character varying(500),
    min_quantity double precision,
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    removal_strategy character varying(10)
);


--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_lines (
    id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_template_id uuid,
    name character varying(255) NOT NULL,
    quantity_ordered numeric(12,3) NOT NULL,
    quantity_received numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_price numeric(12,2),
    uom_id uuid,
    tax_rate numeric(5,2),
    line_number integer NOT NULL,
    notes text,
    source_reorder_rule_id uuid
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    partner_id uuid,
    scheduled_date date,
    notes text,
    currency character varying(3),
    created_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_capacity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_capacity (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    max_quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: putaway_location_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_location_settings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    location_id uuid NOT NULL,
    single_product boolean DEFAULT false NOT NULL
);


--
-- Name: putaway_rule_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rule_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    location_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: putaway_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.putaway_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid,
    category_id uuid,
    context_tag character varying(100),
    storage_type_code character varying(50),
    priority integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_putaway_rules_at_least_one_match CHECK (((product_template_id IS NOT NULL) OR (category_id IS NOT NULL) OR (context_tag IS NOT NULL) OR (storage_type_code IS NOT NULL)))
);


--
-- Name: recipe_collection_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collection_members (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_collections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(64),
    parent_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    template_id uuid,
    name character varying(255) NOT NULL,
    display_text character varying(500),
    ingredient_group_name character varying(100),
    quantity numeric(10,3) NOT NULL,
    uom_id uuid,
    original_quantity numeric(10,3),
    original_unit_text character varying(50),
    is_optional boolean NOT NULL,
    picking_skip boolean,
    sort_order integer NOT NULL,
    calories_kcal_per_100g numeric(8,2),
    price numeric(10,2),
    price_uom_id uuid,
    price_currency character varying(3),
    allergens jsonb NOT NULL,
    is_spice boolean NOT NULL
);


--
-- Name: recipe_tag_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_tag_configs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    instructions text,
    servings integer NOT NULL,
    prep_time_minutes integer,
    image_url text,
    source_url text,
    tags jsonb,
    is_favorite boolean NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_requests (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    token character varying(255),
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    accepted_at timestamp with time zone,
    rejected_at timestamp with time zone,
    is_rejected boolean DEFAULT false NOT NULL,
    approved_by_id uuid
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: shopping_exclusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_exclusions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    name_normalized character varying(255) NOT NULL,
    template_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_history (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    original_list_id uuid NOT NULL,
    original_list_name character varying(255) NOT NULL,
    item_name character varying(255) NOT NULL,
    quantity numeric(12,3) DEFAULT '1'::numeric NOT NULL,
    estimated_price numeric(10,2),
    purchased_at timestamp with time zone,
    purchased_by uuid,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list_items (
    id uuid NOT NULL,
    shopping_list_id uuid NOT NULL,
    item_id uuid,
    category_id uuid,
    name character varying(255) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom_id uuid,
    notes text,
    estimated_price numeric(10,2),
    is_purchased boolean NOT NULL,
    purchased_at timestamp with time zone,
    purchased_by uuid,
    source character varying(50) NOT NULL,
    priority integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_id uuid,
    note_data jsonb
);


--
-- Name: shopping_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_lists (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    completed_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_anchors (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_lots (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    is_serial boolean NOT NULL,
    expiry_date date,
    production_date date,
    use_by_date date,
    removal_strategy character varying(10) NOT NULL,
    status character varying(20) NOT NULL,
    meta_data jsonb,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: stock_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_moves (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    from_location_id uuid,
    to_location_id uuid,
    quantity numeric(12,3) NOT NULL,
    lot_id uuid,
    state character varying(20) DEFAULT 'done'::character varying NOT NULL,
    reference_type character varying(20),
    reference_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    owner_id uuid,
    expiry_date date,
    CONSTRAINT ck_stock_moves_at_least_one_location CHECK (((from_location_id IS NOT NULL) OR (to_location_id IS NOT NULL))),
    CONSTRAINT ck_stock_moves_qty_positive CHECK ((quantity > (0)::numeric))
);


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    document_line_id uuid,
    anchor_id uuid NOT NULL,
    lot_id uuid,
    owner_id uuid
);


--
-- Name: stock_quants_from_records; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.stock_quants_from_records AS
 SELECT (md5((((((((((organization_id)::text || '/'::text) || (product_template_id)::text) || '/'::text) || COALESCE((storage_location_id)::text, '-'::text)) || '/'::text) || COALESCE((lot_id)::text, '-'::text)) || '/'::text) || COALESCE((owner_id)::text, '-'::text))))::uuid AS id,
    organization_id,
    product_template_id,
    storage_location_id,
    lot_id,
    owner_id,
    (COALESCE(sum(quantity), (0)::numeric))::numeric(12,3) AS quantity,
    (COALESCE(sum(reserved_quantity), (0)::numeric))::numeric(12,3) AS reserved_quantity,
    'FIFO'::character varying(10) AS removal_strategy,
    min(created_at) AS created_at,
    max(updated_at) AS updated_at
   FROM ( SELECT i.organization_id,
            i.template_id AS product_template_id,
            i.storage_location_id,
            i.lot_id,
            i.owner_id,
            NULLIF(i.quantity, 'NaN'::numeric) AS quantity,
            NULL::numeric AS reserved_quantity,
            i.created_at,
            i.updated_at
           FROM public.items i
          WHERE ((i.is_deleted IS FALSE) AND (i.template_id IS NOT NULL))
        UNION ALL
         SELECT a.organization_id,
            a.product_template_id,
            a.storage_location_id,
            r.lot_id,
            r.owner_id,
            NULL::numeric AS "numeric",
            r.quantity,
            r.created_at,
            r.created_at
           FROM (public.stock_reservations r
             JOIN public.stock_anchors a ON ((a.id = r.anchor_id)))) sides
  GROUP BY organization_id, product_template_id, storage_location_id, lot_id, owner_id;


--
-- Name: stock_take_closed_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_closed_locations (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    storage_location_id uuid,
    path text NOT NULL,
    empty boolean DEFAULT false NOT NULL,
    closed_by uuid,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_counts (
    id uuid NOT NULL,
    stock_take_item_id uuid NOT NULL,
    sequence integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    counted_by uuid,
    counted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_take_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_items (
    id uuid NOT NULL,
    stock_take_id uuid NOT NULL,
    item_id uuid,
    item_name character varying(255) NOT NULL,
    item_brand character varying(255),
    uom_id uuid,
    assignee_id uuid,
    lot_id uuid,
    system_quantity numeric(12,3),
    counted_quantity numeric(10,3),
    location_in_storage character varying(255),
    notes text,
    discrepancy_reason character varying(255),
    is_discrepancy integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discrepancy_reason_code character varying(50),
    recount_requested boolean DEFAULT false NOT NULL,
    storage_location_id uuid,
    expected_location_id uuid
);


--
-- Name: stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_takes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    storage_location_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    notes text,
    blind_mode boolean NOT NULL,
    require_full_count boolean NOT NULL,
    tolerance_percent numeric(5,2),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule_id uuid,
    adjustment_document_id uuid,
    CONSTRAINT ck_stock_takes_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: stock_valuation_layers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_valuation_layers (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    product_template_id uuid NOT NULL,
    document_line_id uuid,
    quantity numeric(12,3) NOT NULL,
    remaining_qty numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    total_value numeric(14,2) NOT NULL,
    direction character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    currency character varying(3),
    reason character varying(30),
    item_id uuid,
    cost_basis character varying(10) NOT NULL,
    document_date date,
    CONSTRAINT ck_svl_remaining_not_negative CHECK ((remaining_qty >= (0)::numeric))
);


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    parent_id uuid,
    storage_type_id uuid,
    context_schema json DEFAULT '[]'::json NOT NULL,
    behavior_mode character varying(50) DEFAULT 'STOCK'::character varying NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    location_details character varying(255),
    short_code character varying(100),
    usage character varying(50) DEFAULT 'internal'::character varying NOT NULL,
    context_tag character varying(50),
    settings json,
    warehouse_config jsonb,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    sequence integer
);


--
-- Name: storage_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_types (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) NOT NULL,
    type_code character varying(50) NOT NULL,
    behavior_mode character varying(50) NOT NULL,
    context_schema json DEFAULT '[]'::json NOT NULL,
    field_definitions json DEFAULT '[]'::json NOT NULL,
    icon character varying(100),
    is_system boolean NOT NULL,
    created_by uuid,
    default_settings json
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by uuid
);


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    rate numeric(5,2) NOT NULL,
    code character varying(10),
    country character varying(2),
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: unit_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_conversions (
    id uuid NOT NULL,
    organization_id uuid,
    lang character varying(5) NOT NULL,
    ingredient_key character varying(100) NOT NULL,
    ingredient_name character varying(200) NOT NULL,
    source_unit character varying(50) NOT NULL,
    metric_quantity numeric(10,3) NOT NULL,
    metric_unit character varying(10) NOT NULL,
    category character varying(50) NOT NULL,
    is_system boolean NOT NULL
);


--
-- Name: uom_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom_categories (
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(50) NOT NULL
);


--
-- Name: uoms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uoms (
    id uuid NOT NULL,
    organization_id uuid,
    category_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(10) NOT NULL,
    factor numeric(18,9) NOT NULL,
    is_reference boolean NOT NULL,
    is_system boolean NOT NULL,
    rounding numeric(12,6) NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    blocking_reason character varying(500),
    failed_login_count bigint DEFAULT 0,
    locked_until timestamp with time zone,
    organization_id uuid
);


--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_delivery_logs (
    id uuid NOT NULL,
    webhook_endpoint_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload_json jsonb NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    attempt_number integer DEFAULT 1 NOT NULL,
    next_retry_at timestamp with time zone,
    delivery_status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    delivery_id character varying(36),
    abandon_reason character varying(40),
    last_attempt_at timestamp with time zone
);


--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_endpoints (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2048) NOT NULL,
    secret character varying(512),
    http_method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    event_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    retry_backoff_seconds integer DEFAULT 10 NOT NULL,
    timeout_seconds integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp with time zone,
    last_status_code integer,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auto_disabled_at timestamp with time zone
);


--
-- Name: wms_pick_line_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_line_lots (
    pick_line_id uuid NOT NULL,
    lot_id uuid NOT NULL,
    lot_name character varying(100) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_lines (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    document_line_id uuid NOT NULL,
    pick_order integer NOT NULL,
    status character varying(20) NOT NULL,
    picked_quantity numeric(12,3) NOT NULL,
    bin_location character varying(255),
    product_name character varying(255),
    lot_name character varying(100),
    expected_quantity numeric(12,3) NOT NULL,
    uom_symbol character varying(10),
    anchor_id uuid,
    lot_id uuid,
    location_id uuid,
    expiry_date date
);


--
-- Name: wms_pick_session_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_session_documents (
    session_id uuid NOT NULL,
    document_id uuid NOT NULL,
    "position" integer NOT NULL
);


--
-- Name: wms_pick_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wms_pick_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    document_id uuid NOT NULL,
    assigned_to uuid,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    meta_data jsonb,
    last_activity_at timestamp with time zone
);


--
-- Data for Name: ai_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version (version_num) VALUES ('docvis01');


--
-- Data for Name: alembic_version_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_api_keys (version_num) VALUES ('004_timestamps_carry_their_zone');


--
-- Data for Name: alembic_version_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_approvals (version_num) VALUES ('007_workflow_requester_scope');


--
-- Data for Name: alembic_version_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_equipment (version_num) VALUES ('009_timestamps_carry_their_zone');


--
-- Data for Name: alembic_version_example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_example_widgets (version_num) VALUES ('001_initial');


--
-- Data for Name: alembic_version_maker; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_maker (version_num) VALUES ('015_default_result_margin');


--
-- Data for Name: alembic_version_printing; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_printing (version_num) VALUES ('006_agent_versions');


--
-- Data for Name: alembic_version_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_purchase_orders (version_num) VALUES ('po_tzaware01');


--
-- Data for Name: alembic_version_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_recipes (version_num) VALUES ('011_image_url_keeps_the_key');


--
-- Data for Name: alembic_version_shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_shopping_lists (version_num) VALUES ('006_status_is_the_only_state');


--
-- Data for Name: alembic_version_stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_stock_takes (version_num) VALUES ('014_enums_are_text');


--
-- Data for Name: alembic_version_warehouse; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_warehouse (version_num) VALUES ('doc_post_key01');


--
-- Data for Name: alembic_version_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version_webhooks (version_num) VALUES ('005_timestamps_carry_their_zone');


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('6062d417-0623-4090-948f-b9cd8f084d2c', 'd666976f-5fc0-45a0-89a1-91cf6b67b462', 1, 'fdf258d7-766d-464d-abc5-78d7d8370739', 'APPROVED', NULL, '2026-10-20 20:45:35.714711+00', '2026-10-20 20:45:35.714711+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('6a760a03-abb5-435f-bfdd-eb9d7233b320', 'd666976f-5fc0-45a0-89a1-91cf6b67b462', 2, NULL, 'PENDING', NULL, NULL, '2026-10-20 17:45:35.714711+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('5e1e82e3-a424-43e1-901c-0c141ca6b476', '2aca0819-386a-4ca3-83da-87579cfcc104', 1, 'fdf258d7-766d-464d-abc5-78d7d8370739', 'APPROVED', NULL, '2026-10-13 20:45:35.714711+00', '2026-10-13 20:45:35.714711+00');
INSERT INTO public.approval_decisions (id, approval_request_id, stage_order, approver_id, status, notes, decided_at, created_at) VALUES ('b10f18f2-9a11-4649-bc84-1b2b85dda5e3', '2aca0819-386a-4ca3-83da-87579cfcc104', 2, '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'APPROVED', NULL, '2026-10-13 23:45:35.714711+00', '2026-10-13 23:45:35.714711+00');


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('d666976f-5fc0-45a0-89a1-91cf6b67b462', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '87664d76-98ea-4038-bfe0-4a47114962f8', 'purchase_order', '3203b634-da10-43ba-aab9-7589e8078d20', 'IN_PROGRESS', 2, 2, '1ea5bd84-066b-4ed1-91a9-eac1e17aef28', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-10-20 17:45:35.714711+00', NULL, NULL);
INSERT INTO public.approval_requests (id, organization_id, workflow_id, target_type, target_id, status, current_stage, total_stages, created_by, cancelled_by, cancelled_at, meta_data, created_at, consumed_at, consumed_by) VALUES ('2aca0819-386a-4ca3-83da-87579cfcc104', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '87664d76-98ea-4038-bfe0-4a47114962f8', 'purchase_order', 'a48fd68f-79ee-484a-bf35-a5382610a961', 'APPROVED', 2, 2, '1ea5bd84-066b-4ed1-91a9-eac1e17aef28', NULL, NULL, '{"notes": "Budgeted for this quarter; the old units go to the loan pool."}', '2026-10-13 17:45:35.714711+00', NULL, NULL);


--
-- Data for Name: approval_workflows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_workflows (id, organization_id, target_type, name, stages, is_active, created_at, updated_at, archived_at, requester_scope) VALUES ('87664d76-98ea-4038-bfe0-4a47114962f8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'purchase_order', 'Purchase orders over 10,000', '[{"order": 1, "role": "manager", "label": "Team lead", "approver_user_ids": []}, {"order": 2, "role": "admin", "label": "Finance", "approver_user_ids": []}]', true, '2026-10-23 16:45:36.307993+00', NULL, NULL, '{"everyone": true}');


--
-- Data for Name: audit_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_campaigns (id, organization_id, name, description, scope_type, scope_filter_id, launched_at, deadline, reminder_days_before, last_reminder_sent_at, status, email_subject, email_body, created_by, created_at, updated_at) VALUES ('5d56c708-9703-4d1c-82f4-3553b5d1a8cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Autumn equipment check', 'Confirm you still hold the equipment issued to you.', 'ALL', NULL, '2026-10-19 16:45:36.905292+00', '2026-11-09 23:59:00+00', 3, NULL, 'ACTIVE', NULL, NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-19 15:45:36.905292+00', '2026-10-23 16:45:36.906697+00');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('b65ae7ae-ec35-43e4-9efa-200f81c156fb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'module', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '{"name": "equipment", "subject": "profile:equipment_wms", "before": {"maintenance_warning_days": 7, "warranty_warning_days": 30}, "after": {"maintenance_warning_days": 14, "warranty_warning_days": 60}}', NULL, 'null', '2026-10-23 16:45:31.375088+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('425990d1-6478-47e7-b030-62e632720723', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', 'd5e826e5-a34a-47af-9ade-4a3593764805', '{"name": "UHT Milk 3.2%", "brand": "Meadowlane", "barcode": null, "quantity": 48.0, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51", "storage_location_name": "Fridge A", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-10-23 16:45:33.663095+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('a6781097-8366-4164-ba17-005b15cd5fc1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', 'eb48385c-c1ee-43bf-9484-0de0740dc6e1', '{"name": "Natural Yoghurt 400g", "brand": "Meadowlane", "barcode": null, "quantity": 24.0, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51", "storage_location_name": "Fridge A", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-10-23 16:45:33.726419+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4bdc411c-a899-4f61-9a79-f543f60ef368', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '{"name": "Butter Extra 82%", "brand": "Meadowlane", "barcode": null, "quantity": 36.0, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51", "storage_location_name": "Fridge A", "category_id": "1fdd0a5e-1353-487c-9625-ab52fbbcf496", "category_name": "Dairy", "category_code": "dairy"}', NULL, 'null', '2026-10-23 16:45:33.753973+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('eab9d895-c06e-4478-bf7a-b5b234b5f561', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '{"name": "Gouda Cheese", "brand": "Meadowlane", "barcode": null, "quantity": 60.0, "storage_location_id": "e26e9233-0ce2-481a-9e20-dbe5c3b92f75", "storage_location_name": "Fridge B", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-10-23 16:45:33.794953+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('d7497f9f-ce19-48cf-85df-bd630e7e5544', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '{"name": "Sour Cream 18%", "brand": "Meadowlane", "barcode": null, "quantity": 20.0, "storage_location_id": "e26e9233-0ce2-481a-9e20-dbe5c3b92f75", "storage_location_name": "Fridge B", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-10-23 16:45:33.817424+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('10effaba-0ae2-45b0-a840-f2d3550ba688', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', '26bce077-6f4c-4222-9fe4-7571c140e88a', '{"name": "Dell Latitude 5540", "brand": "Dell", "barcode": null, "quantity": 5.0, "storage_location_id": "c8bfa3e4-ad2a-4495-b431-ea5a87b731cc", "storage_location_name": "Server Rack A", "category_id": "f8a93cf2-ff82-4fc9-b6a1-177c9fc70671", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-10-23 16:45:33.853619+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('42a277fd-2363-4276-9075-a99dfa7f16b6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', 'ce96ce67-6bf3-4500-b106-411f73729c81', '{"name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "barcode": null, "quantity": 3.0, "storage_location_id": "c8bfa3e4-ad2a-4495-b431-ea5a87b731cc", "storage_location_name": "Server Rack A", "category_id": "f8a93cf2-ff82-4fc9-b6a1-177c9fc70671", "category_name": "Laptop", "category_code": "LAPTOP"}', NULL, 'null', '2026-10-23 16:45:33.892956+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('d5f88c28-6f8c-40b8-a815-35f30cf0d9f8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', 'd5e826e5-a34a-47af-9ade-4a3593764805', '{"name": "UHT Milk 3.2%", "before": {"quantity": "48.000"}, "after": {"quantity": "36.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "01a7d408-1611-439f-8094-70c228c14258"}', '2026-10-23 16:45:33.963292+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('4a436598-62e0-495b-91e7-9b78c5ce2edd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '{"name": "Butter Extra 82%", "before": {"quantity": "36.000"}, "after": {"quantity": "28.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/001", "source_document_id": "01a7d408-1611-439f-8094-70c228c14258"}', '2026-10-23 16:45:34.019155+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('194b5bf1-a67d-4adb-9862-ffe4e1e18b50', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "wms_session_id": "50eca74a-7254-4713-99dc-2d9e00110d3a", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-10-23 16:45:34.444504+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('288a58c0-cd82-4314-b5a7-d89adb8712c9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', '235e0124-96fe-461a-bef5-3e365fc4226c', '{"number": "OUT/2026/004", "wms_session_id": "50eca74a-7254-4713-99dc-2d9e00110d3a", "wms_session_status": "active", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-10-23 16:45:34.447366+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5cf25405-0b63-4e11-bdd9-36a2d9678ef6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "wms_session_id": "50eca74a-7254-4713-99dc-2d9e00110d3a", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-10-23 16:45:34.643255+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('29db89a9-ffb8-4a17-9538-f92fda5fbec1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', '235e0124-96fe-461a-bef5-3e365fc4226c', '{"number": "OUT/2026/004", "wms_session_id": "50eca74a-7254-4713-99dc-2d9e00110d3a", "wms_session_status": "completed", "picked_together": ["OUT/2026/003", "OUT/2026/004"]}', NULL, 'null', '2026-10-23 16:45:34.644799+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('f1c56fba-bfa3-4a7f-9c3b-8c5dcc30f900', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "weight_value": null}', NULL, 'null', '2026-10-23 16:45:35.000528+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('adcf2a6a-2639-4df9-863e-83668a4172ae', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P1", "name": "Natural Yoghurt 400g", "quantity": "6", "old_quantity": "0"}', NULL, 'null', '2026-10-23 16:45:35.029789+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9c9882b1-aa1b-42b2-a648-8300fafb864d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "weight_value": null}', NULL, 'null', '2026-10-23 16:45:35.049461+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('95bda79f-6bad-427c-9ec0-a95caeaa75a7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "code": "OUT/2026/003-P2", "name": "Butter Extra 82%", "quantity": "4", "old_quantity": "0"}', NULL, 'null', '2026-10-23 16:45:35.071879+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('0c37b7a7-7e63-4fe8-a363-1efcc17e7f7f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', 'eb48385c-c1ee-43bf-9484-0de0740dc6e1', '{"name": "Natural Yoghurt 400g", "before": {"quantity": "24.000"}, "after": {"quantity": "18.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4"}', '2026-10-23 16:45:35.276317+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9c96fdbc-32da-48d6-8210-f4c011d9b073', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '{"name": "Butter Extra 82%", "before": {"quantity": "28.000"}, "after": {"quantity": "24.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/003", "source_document_id": "de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4"}', '2026-10-23 16:45:35.338527+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('ee1bf20c-4128-454e-8cd1-34c9d6b0c65a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '{"number": "OUT/2026/003", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-10-23 16:45:35.351161+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('9446a8fb-b8b1-4ce1-84b2-179037a67d14', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '{"name": "Gouda Cheese", "before": {"quantity": "60.000"}, "after": {"quantity": "50.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "235e0124-96fe-461a-bef5-3e365fc4226c"}', '2026-10-23 16:45:35.56028+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('b62f78f4-f710-4af4-bea6-ce642efa7e27', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '{"name": "Sour Cream 18%", "before": {"quantity": "20.000"}, "after": {"quantity": "15.000"}}', 'document_execution', '{"document_type": "OUT", "document_number": "OUT/2026/004", "source_document_id": "235e0124-96fe-461a-bef5-3e365fc4226c"}', '2026-10-23 16:45:35.615227+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('26787282-8b47-4c40-a87f-8fa5a1660305', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'document', '235e0124-96fe-461a-bef5-3e365fc4226c', '{"number": "OUT/2026/004", "type": "OUT", "old_status": "CONFIRMED", "new_status": "COMPLETED", "lines": 2}', 'document_completed', 'null', '2026-10-23 16:45:35.626494+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('1b35268c-f587-41f2-816f-cc4a3dc04469', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'maker_production_order', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '{"name": "PR/2026/0001", "status": "DRAFT", "output": "Plum Butter", "planned_qty": 12.0}', NULL, 'null', '2026-10-23 16:45:35.91534+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('c7103043-d33a-4f35-b44f-1fc2ac671fd1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', 'cd5bbe19-c815-46cc-9334-ef10da619ec4', '{"name": "Damson Plums", "before": {"quantity": "40.000"}, "after": {"quantity": "13.600"}}', 'Production run PR/2026/0001', '{"production_order_id": "86b1825d-45ab-490c-b87c-d1e5d98798bc"}', '2026-10-23 16:45:36.019657+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('dc6bbe27-b5d4-4a4e-8266-732d2597e020', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', '15994ec8-01e3-495c-a8c7-ee9d268934d3', '{"name": "White Sugar", "before": {"quantity": "25.000"}, "after": {"quantity": "21.220"}}', 'Production run PR/2026/0001', '{"production_order_id": "86b1825d-45ab-490c-b87c-d1e5d98798bc"}', '2026-10-23 16:45:36.060357+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('5602f1a1-e22f-46ba-ae6e-23f2ef11cf63', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGE', 'item', '1bfd442f-eb46-402b-ae06-f3f2e068b798', '{"name": "Cassia Cinnamon", "before": {"quantity": "0.500"}, "after": {"quantity": "0.440"}}', 'Production run PR/2026/0001', '{"production_order_id": "86b1825d-45ab-490c-b87c-d1e5d98798bc"}', '2026-10-23 16:45:36.087387+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('c9023f24-1e07-4a4b-a21a-3e88db171265', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATE', 'item', '10c8d400-0c08-4b58-a26c-59e41e4937f9', '{"name": "Plum Butter", "brand": null, "barcode": null, "quantity": 11.4, "storage_location_id": "e45ba619-6cdd-4d90-9c01-d6d253e1cd14", "storage_location_name": "Shelf A - Bottom", "category_id": null, "category_name": null, "category_code": null}', NULL, 'null', '2026-10-23 16:45:36.114884+00');
INSERT INTO public.audit_log (id, organization_id, user_id, action, target_type, target_id, snapshot, reason, meta_data, created_at) VALUES ('fbcc2b0e-fd61-4356-a53a-ef1644454db4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'UPDATE', 'maker_production_order', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '{"name": "PR/2026/0001", "old_status": "DRAFT", "new_status": "COMPLETED", "output": "Plum Butter", "quantity": 11.4, "total_cost": 95.358}', NULL, 'null', '2026-10-23 16:45:36.126621+00');


--
-- Data for Name: audit_response_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at) VALUES ('400adb21-46c6-47f9-9fff-3a986d4e9ed4', '804f51a3-6f38-4523-bbb0-d5775c412596', '682467e8-01d3-4214-8062-a5967a45212e', '16bdf232-6dba-4418-968a-1f040742f58a', 'iPhone 15 Pro', 'SN-100027', 'CONFIRMED', NULL, NULL, '2026-10-23 16:45:36.914776+00');
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at) VALUES ('818d1de2-9f0c-47d8-9ea5-fb1f4f0c5595', '421a05f8-a51b-4cd0-ae5e-2db8c919661f', '0e2a81fb-ea86-4d5c-83d1-038c325248c0', 'b0cc9bd4-fd50-4f95-846a-4771e6e914fc', 'Dell Latitude 5540', 'SN-100002', 'DISPUTED', 'DAMAGED', 'The hinge on the lid is cracked and the screen flickers.', '2026-10-23 16:45:36.914782+00');
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at) VALUES ('7de7b78c-47bd-4ba3-be21-b497995f3085', 'f2e83325-bbec-4e64-88f1-e48bbc2ff0e0', '96e62076-3e54-4850-8041-e0c2fb7df8e6', '012cdc10-4164-49aa-bc48-35b5bb8d12f7', 'Dell Latitude 5540', 'SN-100001', 'PENDING', NULL, NULL, '2026-10-23 16:45:36.914783+00');
INSERT INTO public.audit_response_items (id, response_id, assignment_id, item_id, item_name, serial_number, status, dispute_type, dispute_reason, created_at) VALUES ('98dec945-f436-4cff-9429-3542e6fbe46b', 'fa80bb1b-3f17-4570-987d-a77c831431c9', '11c2814c-90f5-45a4-aed0-6b8e26134c97', 'b78d86d2-4050-4179-a20f-6969ce33e232', 'Dell Latitude 5540', 'SN-100000', 'PENDING', NULL, NULL, '2026-10-23 16:45:36.914783+00');


--
-- Data for Name: audit_responses; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('804f51a3-6f38-4523-bbb0-d5775c412596', '5d56c708-9703-4d1c-82f4-3553b5d1a8cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, 'admin@example.com', 'Demo Administrator', 'm45QcW7JlpYm1mHWQBUD__c2JiSw6zhnHKqeWfE8NSDEVBYxxPE1fHmWKYrcQf0R8lLY2oamM7mh4sw9XnugPw', '2026-11-09 23:59:00+00', 'CONFIRMED', '2026-10-20 16:45:36.905292+00', NULL, NULL, NULL, NULL, '2026-10-19 16:45:36.905292+00', NULL, '2026-10-23 16:45:36.909614+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('421a05f8-a51b-4cd0-ae5e-2db8c919661f', '5d56c708-9703-4d1c-82f4-3553b5d1a8cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, 'priya.raman@example.com', 'Priya Raman', 'TWKujpeG4A5_3qJDYiijb5sI2isJIiTXl06paZPKmnefnEAEPBPDiVslCjb668zp_MLiJagCwTnL6yJYLnEMLA', '2026-11-09 23:59:00+00', 'DISPUTED', '2026-10-20 17:45:36.905292+00', 'The hinge on the lid is cracked and the screen flickers.', 'DAMAGED', NULL, NULL, '2026-10-19 16:45:36.905292+00', NULL, '2026-10-23 16:45:36.909619+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('f2e83325-bbec-4e64-88f1-e48bbc2ff0e0', '5d56c708-9703-4d1c-82f4-3553b5d1a8cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, 'marcus.webb@example.com', 'Marcus Webb', 'xGs3xihWhSVEmctD8SIyWu9gsuPqOa697fw-wTdCAKIMD8HJfsNimQOWCldLOpSLTftvy3Vqag0LrtSRjXSEIQ', '2026-11-09 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-10-19 16:45:36.905292+00', NULL, '2026-10-23 16:45:36.909619+00');
INSERT INTO public.audit_responses (id, campaign_id, organization_id, assignment_id, assignee_email, assignee_name, token, token_expires_at, status, responded_at, dispute_reason, dispute_type, response_ip, response_user_agent, email_sent_at, reminder_sent_at, created_at) VALUES ('fa80bb1b-3f17-4570-987d-a77c831431c9', '5d56c708-9703-4d1c-82f4-3553b5d1a8cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, 'ava.brennan@example.com', 'Ava Brennan', '6MPKEl_5YqfONly5c9w6HipxLZpbEVKBrAWfLweX98pRyu0PEbGVQDhp4OobDnFAbEnqUn7Ns0NmBi2NXWHyRg', '2026-11-09 23:59:00+00', 'PENDING', NULL, NULL, NULL, NULL, NULL, '2026-10-19 16:45:36.905292+00', NULL, '2026-10-23 16:45:36.90962+00');


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Laptop', 'LAPTOP', 'equipment', 'laptop', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "os", "type": "text", "label": "Operating System", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('042a2c3d-6a32-4d60-a149-e3d416d66044', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Desktop Computer', 'DESKTOP', 'equipment', 'monitor', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "storage_gb", "type": "number", "label": "Storage (GB)", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('e12c34aa-6396-4b2a-a358-7cece1eefe15', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Monitor / Display', 'MONITOR', 'equipment', 'monitor-smartphone', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "size_inches", "type": "number", "label": "Screen Size (inches)", "visible": true, "required": false, "is_system": true}, {"key": "resolution", "type": "text", "label": "Resolution", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 7, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('2de1ae03-d82e-44be-a829-0d026a81c379', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Phone / Tablet', 'PHONE', 'equipment', 'smartphone', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "imei", "type": "text", "label": "IMEI", "visible": true, "required": false, "is_system": true}, {"key": "phone_number", "type": "text", "label": "Phone Number", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 3, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('dedaa1ae-49d3-4e0c-8f06-24f941a011a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Seafood', 'seafood', 'cold_storage', 'Shell', 5, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('d357abce-8e8b-4ab9-82aa-90312cb23f40', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen meals', 'frozen_meals', 'cold_storage', 'Soup', 6, NULL, NULL, true, '[]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('36a64ede-d0e3-4c12-93ce-bce953ffb2fa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen vegetables', 'frozen_vegetables', 'cold_storage', 'LeafyGreen', 7, NULL, NULL, true, '[]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('a144ebc7-efe0-4ffc-8e99-7f4e0105075f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen fruits', 'frozen_fruits', 'cold_storage', 'Apple', 8, NULL, NULL, true, '[]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('d1d5fe3a-c295-4568-a5d9-ac62b0857abb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Ice cream and desserts', 'ice_cream', 'cold_storage', 'IceCream', 9, NULL, NULL, true, '[]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('03f72fef-ecc7-47da-949c-a6c6e9d354e3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Network Device', 'NETWORK_DEVICE', 'equipment', 'wifi', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "mac_address", "type": "text", "label": "MAC Address", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 8, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('8a4adf2c-2e32-4eda-9115-de3b2733b60f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Peripheral', 'PERIPHERAL', 'equipment', 'mouse', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 4, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('c46e28ac-f524-4f1b-8cb2-46e076e3ece3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Server', 'SERVER', 'equipment', 'server', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "ip_address", "type": "text", "label": "IP Address", "visible": true, "required": false, "is_system": true}, {"key": "rack_position", "type": "text", "label": "Rack Position", "visible": true, "required": false, "is_system": true}, {"key": "ram_gb", "type": "number", "label": "RAM (GB)", "visible": true, "required": false, "is_system": true}, {"key": "cpu", "type": "text", "label": "CPU", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 10, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('15249a13-1095-4158-ab71-faaddc29bc6e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Other Equipment', 'OTHER_EQUIPMENT', 'equipment', 'package', 0, NULL, 'equipment', true, '[{"key": "category_id", "visible": true, "is_system": true}, {"key": "serial_number", "type": "text", "label": "Serial Number", "visible": true, "required": false, "is_system": true}, {"key": "asset_tag", "type": "text", "label": "Asset Tag", "visible": true, "required": false, "is_system": true}, {"key": "manufacturer", "type": "text", "label": "Manufacturer", "visible": true, "required": false, "is_system": true}, {"key": "model", "type": "text", "label": "Model", "visible": true, "required": false, "is_system": true}, {"key": "group_tag", "type": "text", "label": "Group / Kit Tag", "visible": true, "required": false, "is_system": true}, {"key": "purchase_date", "type": "date", "label": "Purchase Date", "visible": true, "required": false, "is_system": true}, {"key": "warranty_until", "type": "date", "label": "Warranty Until", "visible": true, "required": false, "is_system": true}, {"key": "equipment_status", "type": "select", "label": "Status", "visible": true, "required": false, "options": ["AVAILABLE", "DEPLOYED", "MAINTENANCE", "RETIRED"], "options_i18n": {"AVAILABLE": "equipment:status.available", "DEPLOYED": "equipment:status.deployed", "MAINTENANCE": "equipment:status.maintenance", "RETIRED": "equipment:status.retired"}, "is_system": true}, {"key": "useful_life_years", "type": "number", "label": "Useful Life (years)", "visible": true, "required": false, "default": 5, "is_system": true}]', NULL, NULL, NULL, NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('d6e4b45d-e804-4212-a103-d7a66c62c2b1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Pork', 'pork', 'cold_storage', 'Drumstick', 1, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('543824c1-b16e-439b-bf9e-8968db3e870e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Beef', 'beef', 'cold_storage', 'Drumstick', 2, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}, {"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('f28c8c62-9ad1-4797-905e-b593ee57c029', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Poultry', 'poultry', 'cold_storage', 'Drumstick', 3, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('07a46c38-3495-486c-9b42-2b72204ee7ca', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fish', 'fish', 'cold_storage', 'Fish', 4, NULL, NULL, true, '[{"key": "freeze_date", "is_system": true, "label": "Freeze date", "type": "date", "visible": true, "required": false}]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('50308a18-1e39-4184-bcb5-e20392d67ebb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen pizza', 'frozen_pizza', 'cold_storage', 'Pizza', 10, NULL, NULL, true, '[]', NULL, NULL, 'FREEZER', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('1fdd0a5e-1353-487c-9625-ab52fbbcf496', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dairy', 'dairy', 'cold_storage', 'Milk', 1, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('54d0e7e2-c4a7-4a9a-8d16-c1db646ae507', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cheese', 'cheese', 'cold_storage', 'Cheese', 2, NULL, NULL, true, '[{"key": "lactose_free", "is_system": true, "label": "Lactose free", "type": "select", "options": ["No", "Yes"], "options_i18n": {"No": "items:fieldOptions.lactose_free.No", "Yes": "items:fieldOptions.lactose_free.Yes"}, "visible": true, "required": false}]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('73c0cfe0-d0c7-4617-8946-e4a5ba89fd12', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Deli', 'deli', 'cold_storage', 'Beef', 3, NULL, NULL, true, '[]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('1f29d095-97b0-47c5-a726-899f6db0c5a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Eggs', 'eggs', 'cold_storage', 'Egg', 4, NULL, NULL, true, '[]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('fe3fdf59-486b-4e8b-b119-e2f0510ed063', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fresh vegetables', 'fresh_vegetables', 'cold_storage', 'LeafyGreen', 5, NULL, NULL, true, '[]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('0c229a06-71c8-40b0-b637-e5947523593e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fresh fruits', 'fresh_fruits', 'cold_storage', 'Apple', 6, NULL, NULL, true, '[]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('2669d193-0cc5-4cb7-8eea-8cbc0ebc0cc6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Drinks', 'drinks', 'cold_storage', 'GlassWater', 7, NULL, NULL, true, '[{"key": "abv", "is_system": true, "label": "Alcohol content (ABV %)", "type": "number", "visible": true, "required": false}]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('a88f68e0-dcad-42dd-b3a6-9b1983df19b4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Sauces and dips', 'sauces', 'cold_storage', 'Pint', 8, NULL, NULL, true, '[]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('4aa44529-a6b6-4a09-bf5b-857f7cf7dda1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fresh meat', 'fresh_meat', 'cold_storage', 'Drumstick', 9, NULL, NULL, true, '[{"key": "cut_type", "is_system": true, "label": "Cut type", "type": "text", "visible": true, "required": false}]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('5af2b622-dd02-4dfe-892d-7c1dea8342fc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fresh meals', 'fresh_meals', 'cold_storage', 'CookingPot', 10, NULL, NULL, true, '[]', NULL, NULL, 'FRIDGE', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('33cdaa4d-fc08-4c7e-8a94-f0f0979cbbf3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dry products', 'dry_products', 'dry_goods', 'Wheat', 1, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('2f9367e8-bca0-45ec-a9a1-5a469284ec65', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Pasta', 'pasta', 'dry_goods', 'Utensils', 2, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('7f3b6577-22a5-44e6-a432-2bca81bc730e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Rice and grains', 'rice_grains', 'dry_goods', 'Wheat', 3, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('87f79b27-b69a-4080-ac75-2cc6ecf92f64', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Canned goods', 'canned_goods', 'dry_goods', 'Container', 4, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('3be81a2d-811e-4356-9704-be025202e43a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Spices and herbs', 'spices_herbs', 'dry_goods', 'Leaf', 5, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('07f7aa72-9b17-43d6-9c09-6d85a8b575ac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Oils and vinegars', 'oils_vinegars', 'dry_goods', 'GlassWater', 6, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('94aca667-13e8-4c0e-bf97-7a759f17e0a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Flours and sugars', 'flours_sugars', 'dry_goods', 'Box', 7, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('8d7df3e0-abfc-48ba-9eb6-bf8499dc9f0f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Snacks', 'snacks', 'dry_goods', 'Cookie', 8, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('20dd00b7-5c42-4d49-be59-cdc95124f075', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Sweets', 'sweets', 'dry_goods', 'Candy', 9, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('bcfce18e-fb6f-4863-b4fb-ba5f0aefd789', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Beverages (non-refrigerated)', 'beverages', 'dry_goods', 'GlassWater', 10, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('134d101f-9b19-4253-a267-52016e5f503f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tea and coffee', 'tea_coffee', 'dry_goods', 'Coffee', 11, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('2693d9ae-6968-441a-b71e-180cf08d2f2c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cans and jars', 'cans_jars', 'dry_goods', 'Container', 12, NULL, NULL, true, '[]', NULL, NULL, 'PANTRY', NULL);
INSERT INTO public.categories (id, organization_id, name, code, context_tag, icon, sort_order, meta_data, module_name, is_active, field_definitions, emoji, color, group_label, default_removal_strategy) VALUES ('219d6aaf-1aa9-4de0-b6ac-ade91510690a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Other', 'other', NULL, 'Archive', 100, NULL, NULL, true, '[]', NULL, NULL, NULL, NULL);


--
-- Data for Name: cycle_count_schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_extra_costs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('a3a16e66-5ca1-4034-b487-836627e16935', 'bb4dc88e-7c20-44eb-b106-dfa148e0c4d7', 'bd717ba3-5fb3-4e94-a4c5-0efc64578a1d', '57298474-a0b7-4c3a-b9dc-d1f5743251fe', 'Butter Biscuits', 'Orchard & Oak', '2000000000718', 5.000, 5.000, 0.000, '21f0f763-a223-4344-bc0f-a0069453da54', NULL, NULL, NULL, NULL, NULL, NULL, 5.90, 8.00, 29.50, 2.36, 31.86, 'USD', 1, NULL, '{"name": "Butter Biscuits", "seed": "SEED-DOC", "brand": "Orchard & Oak"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('00ea17d8-0607-4049-b58d-e2d2cf790156', '0d79edb5-fd53-492f-b75c-a325527ee16c', 'd5e826e5-a34a-47af-9ade-4a3593764805', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 48.000, 48.000, 48.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, 8.00, 216.00, 17.28, 233.28, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('6eb79c7a-8b6a-4f4d-a666-2f8a3aa8e9fe', '0d79edb5-fd53-492f-b75c-a325527ee16c', 'eb48385c-c1ee-43bf-9484-0de0740dc6e1', 'd4d375c2-948d-482d-ae68-02e446edfa8f', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 24.000, 24.000, 24.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, 8.00, 124.80, 9.98, 134.78, 'USD', 2, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('a8d193e0-0be4-4721-a4f8-e795c168fd4f', '0d79edb5-fd53-492f-b75c-a325527ee16c', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 36.000, 36.000, 36.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, 8.00, 320.40, 25.63, 346.03, 'USD', 3, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('319fe24b-0b78-48a8-ae2d-b7c1fb1f32e1', 'c861b165-2f60-4301-bf23-28fcdfce2439', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'Gouda Cheese', 'Meadowlane', '2000000000046', 60.000, 60.000, 60.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 750.00, 60.00, 810.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('b2a59eac-a757-40dd-be60-bfec26ce4bcd', 'c861b165-2f60-4301-bf23-28fcdfce2439', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 20.000, 20.000, 20.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, 8.00, 82.00, 6.56, 88.56, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('151061dd-f459-4bd3-981d-1ca1aa60bb68', '1ad5e058-02ef-4f38-9db9-e99c8bff0e45', '26bce077-6f4c-4222-9fe4-7571c140e88a', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'Dell Latitude 5540', 'Dell', '5397184123456', 5.000, 5.000, 5.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 4200.00, 23.00, 21000.00, 4830.00, 25830.00, 'USD', 1, NULL, '{"name": "Dell Latitude 5540", "seed": "SEED-DOC", "brand": "Dell"}', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('7313fef2-93d5-48ca-9e5e-8f39e7116f42', '1ad5e058-02ef-4f38-9db9-e99c8bff0e45', 'ce96ce67-6bf3-4500-b106-411f73729c81', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'ThinkPad T14s Gen 4', 'Lenovo', '0196881123456', 3.000, 3.000, 3.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 5800.00, 23.00, 17400.00, 4002.00, 21402.00, 'USD', 2, NULL, '{"name": "ThinkPad T14s Gen 4", "seed": "SEED-DOC", "brand": "Lenovo"}', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('f1d10947-a638-4a1f-8626-6345aa10869e', '01a7d408-1611-439f-8094-70c228c14258', 'd5e826e5-a34a-47af-9ade-4a3593764805', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', 12.000, 12.000, 12.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 4.50, 8.00, 54.00, 4.32, 58.32, 'USD', 1, NULL, '{"name": "UHT Milk 3.2%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('0738966d-013a-428e-94ad-e7eaa58b8003', '01a7d408-1611-439f-8094-70c228c14258', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 8.000, 8.000, 8.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, 8.00, 71.20, 5.70, 76.90, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('04164b5b-6ddc-452a-ae25-87e9c587dcda', 'c1f6a402-1a53-4378-ba2e-78bbaebb54ba', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 0.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 125.00, 10.00, 135.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('87650eca-007b-41c1-a405-5f2f190d1779', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', 'eb48385c-c1ee-43bf-9484-0de0740dc6e1', 'd4d375c2-948d-482d-ae68-02e446edfa8f', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', 6.000, 6.000, 6.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 5.20, 8.00, 31.20, 2.50, 33.70, 'USD', 1, NULL, '{"name": "Natural Yoghurt 400g", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('7d240cc7-6440-4dd6-9a38-3e5c26d9f5aa', '923be1b4-0b7b-489f-b0b5-ebf7945d8360', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'Gouda Cheese', 'Meadowlane', '2000000000046', 8.000, 8.000, 0.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 100.00, 8.00, 108.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('4b3bb05c-e137-4db2-85cf-f46701b4f79d', '923be1b4-0b7b-489f-b0b5-ebf7945d8360', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 4.000, 4.000, 0.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, 8.00, 16.40, 1.31, 17.71, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('7f00e27a-9bb8-4f85-a6cf-4f889101f49e', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'Butter Extra 82%', 'Meadowlane', '2000000000039', 4.000, 4.000, 4.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 8.90, 8.00, 35.60, 2.85, 38.45, 'USD', 2, NULL, '{"name": "Butter Extra 82%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('fd15a26d-eb25-4593-90a8-8065fa54cb5a', '235e0124-96fe-461a-bef5-3e365fc4226c', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'Gouda Cheese', 'Meadowlane', '2000000000046', 10.000, 10.000, 10.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 12.50, 8.00, 125.00, 10.00, 135.00, 'USD', 1, NULL, '{"name": "Gouda Cheese", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);
INSERT INTO public.document_lines (id, document_id, item_id, product_template_id, name, brand, barcode, quantity, expected_quantity, done_quantity, uom_id, batch_number, serial_number, expiry_date, notes, discrepancy_code, discrepancy_reason, unit_price, tax_rate, line_value, line_tax, line_gross, currency, line_number, source_po_line_id, product_snapshot, executed_location_id, corrects_line_id, target_location_id, held_quantity, source_location_id, puts_away_line_id) VALUES ('bf3ed67c-b28d-40b5-b26e-8a3e6b0a18ea', '235e0124-96fe-461a-bef5-3e365fc4226c', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'Sour Cream 18%', 'Meadowlane', '2000000000053', 5.000, 5.000, 5.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 4.10, 8.00, 20.50, 1.64, 22.14, 'USD', 2, NULL, '{"name": "Sour Cream 18%", "seed": "SEED-DOC", "brand": "Meadowlane"}', NULL, NULL, NULL, 0.000, NULL, NULL);


--
-- Data for Name: document_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_number_sequences (organization_id, prefix, next_value) VALUES ('6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'PR/2026/', 2);


--
-- Data for Name: document_package_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('effb37e4-72fc-41d5-b7c2-c7355ed8b83b', 'e932cb80-6864-45f3-a956-600001b7d363', '87650eca-007b-41c1-a405-5f2f190d1779', 6.000, '2026-10-23 16:45:34.126956+00');
INSERT INTO public.document_package_lines (id, document_package_id, document_line_id, quantity, created_at) VALUES ('8da8ccc4-0d0a-4cfe-b460-d4e572328519', '8a78f9ca-abb4-49c4-8e65-0b53a5a4e501', '7f00e27a-9bb8-4f85-a6cf-4f889101f49e', 4.000, '2026-10-23 16:45:34.126956+00');


--
-- Data for Name: document_packages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('e932cb80-6864-45f3-a956-600001b7d363', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', 1, NULL, '2026-10-23 16:45:34.126956+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5');
INSERT INTO public.document_packages (id, organization_id, document_id, number, weight_kg, created_at, created_by) VALUES ('8a78f9ca-abb4-49c4-8e65-0b53a5a4e501', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', 2, NULL, '2026-10-23 16:45:34.126956+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5');


--
-- Data for Name: document_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_profiles (id, organization_id, name, value_tracking_enabled, tax_handling, default_tax_rate, require_partner_tax_id, numbering_format, type_labels, default_unit, visible_line_fields, print_template, default_currency, default_template_id, approval_threshold, approval_required_for_types, created_at, updated_at, number_padding, require_unit_price, confirm_shelf_by_scan, tracking_url_templates, quarantine_location_id) VALUES ('5c1aac32-4935-4303-9b27-cfc52a1544eb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Full Value', true, 'SIMPLE_RATE', NULL, NULL, '{TYPE}/{YEAR}/{SEQ:03d}', 'null', 'pcs', '[]', 'standard', NULL, NULL, NULL, NULL, '2026-10-23 16:45:31.387836+00', '2026-10-23 16:45:31.435487+00', 3, false, false, NULL, '920b58c7-39ea-43b8-8702-ea25eb233cef');


--
-- Data for Name: document_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_shipments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_shipments (id, organization_id, document_id, carrier, tracking_number, shipped_at, shipped_by, notes, created_at) VALUES ('cc0b9af5-c708-4f3e-b819-07e6f9774ace', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', 'InPost', '620012345678901234567890', '2026-10-23 16:45:35.187885+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, '2026-10-23 16:45:35.109721+00');


--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_type_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_warehouse_receiving; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_work_item_overlays; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('0d79edb5-fd53-492f-b75c-a325527ee16c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'IN', 'IN/2026/001', 'COMPLETED', '397d73b8-cda3-44fe-8705-4a6a615240af', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-14', NULL, 'Delivery note 7311', '{"code": "FFD-004", "name": "Freshfield Wholesale"}', NULL, NULL, 661.20, 52.89, 714.09, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-14 16:45:33.341716+00', '2026-10-23 16:45:33.424801+00', '2026-10-14 18:45:33.341716+00', '2026-10-15 14:45:33.341716+00', NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('c861b165-2f60-4301-bf23-28fcdfce2439', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'IN', 'IN/2026/002', 'COMPLETED', '8e6b16b3-57d3-4138-8636-cd57b848079c', NULL, 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', '2026-10-16', NULL, 'Delivery note 7312', '{"code": "MCC-005", "name": "Bulkline Cash & Carry"}', NULL, NULL, 832.00, 66.56, 898.56, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-16 16:45:33.341716+00', '2026-10-23 16:45:33.424807+00', '2026-10-16 18:45:33.341716+00', '2026-10-17 14:45:33.341716+00', NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('1ad5e058-02ef-4f38-9db9-e99c8bff0e45', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'IN', 'IN/2026/003', 'COMPLETED', 'c4543079-ea11-423e-a7d0-d07738f39388', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-21', NULL, 'Delivery note 7313', '{"code": "SUP-001", "name": "Eurodata Systems"}', NULL, NULL, 38400.00, 8832.00, 47232.00, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-21 16:45:33.341716+00', '2026-10-23 16:45:33.424808+00', '2026-10-21 18:45:33.341716+00', '2026-10-22 14:45:33.341716+00', NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('01a7d408-1611-439f-8094-70c228c14258', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'OUT', 'OUT/2026/001', 'COMPLETED', '2603b076-e5f3-4405-8438-ce6385719c2e', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, '2026-10-19', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 125.20, 10.02, 135.22, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-19 16:45:33.341716+00', '2026-10-23 16:45:33.424809+00', '2026-10-19 18:45:33.341716+00', '2026-10-20 14:45:33.341716+00', NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('c1f6a402-1a53-4378-ba2e-78bbaebb54ba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'OUT', 'OUT/2026/002', 'CONFIRMED', 'f8dfac00-df97-4160-a6e0-8881087b1e5b', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, '2026-10-21', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 125.00, 10.00, 135.00, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, '2026-10-21 16:45:33.341716+00', '2026-10-23 16:45:33.424809+00', '2026-10-21 18:45:33.341716+00', NULL, NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('923be1b4-0b7b-489f-b0b5-ebf7945d8360', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'OUT', 'OUT/2026/005', 'CONFIRMED', '2603b076-e5f3-4405-8438-ce6385719c2e', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, '2026-10-22', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 116.40, 9.31, 125.71, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, '2026-10-22 16:45:33.341716+00', '2026-10-23 16:45:33.424812+00', '2026-10-22 18:45:33.341716+00', NULL, NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('bb4dc88e-7c20-44eb-b106-dfa148e0c4d7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'INT', 'INT/2026/001', 'DRAFT', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', '38323184-273f-4032-8597-d48a45db1650', '2026-10-22', NULL, NULL, 'null', NULL, NULL, 29.50, 2.36, 31.86, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, NULL, '2026-10-22 16:45:33.341716+00', '2026-10-23 16:45:33.424813+00', NULL, NULL, NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'OUT', 'OUT/2026/003', 'COMPLETED', '2603b076-e5f3-4405-8438-ce6385719c2e', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, '2026-10-22', NULL, NULL, '{"code": "CUS-011", "name": "Harper Catering"}', NULL, NULL, 66.80, 5.35, 72.15, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-22 16:45:33.341716+00', '2026-10-23 16:45:35.352273+00', '2026-10-22 18:45:33.341716+00', '2026-10-23 16:45:35.350371+00', NULL, false, false, NULL, NULL, false, NULL);
INSERT INTO public.documents (id, organization_id, type, number, status, partner_id, source_location_id, target_location_id, scheduled_date, notes, external_reference, partner_snapshot, corrects_document_id, backorder_id, total_net, total_tax, total_gross, currency, created_by, confirmed_by, completed_by, created_at, updated_at, confirmed_at, completed_at, reason_code, is_opening, stock_already_applied, cancelled_by, cancelled_at, complete_on_approval, post_key) VALUES ('235e0124-96fe-461a-bef5-3e365fc4226c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'OUT', 'OUT/2026/004', 'COMPLETED', 'f8dfac00-df97-4160-a6e0-8881087b1e5b', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, '2026-10-22', NULL, NULL, '{"code": "CUS-012", "name": "Officeworks Services"}', NULL, NULL, 145.50, 11.64, 157.14, 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-22 16:45:33.341716+00', '2026-10-23 16:45:35.627257+00', '2026-10-22 18:45:33.341716+00', '2026-10-23 16:45:35.625592+00', NULL, false, false, NULL, NULL, false, NULL);


--
-- Data for Name: email_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('11c2814c-90f5-45a4-aed0-6b8e26134c97', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b78d86d2-4050-4179-a20f-6969ce33e232', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 'Ava Brennan', 'ava.brennan@example.com', '2026-10-09 16:45:35.758337+00', '2027-04-21 16:45:35.758347+00', NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-10-23 16:45:35.763115+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('96e62076-3e54-4850-8041-e0c2fb7df8e6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '012cdc10-4164-49aa-bc48-35b5bb8d12f7', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 'Marcus Webb', 'marcus.webb@example.com', '2026-09-30 16:45:35.758544+00', '2027-04-21 16:45:35.758548+00', NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-10-23 16:45:35.76312+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('0e2a81fb-ea86-4d5c-83d1-038c325248c0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0cc9bd4-fd50-4f95-846a-4771e6e914fc', NULL, 'f286056a-e01e-41c5-ba89-3ee011a8f021', 'Priya Raman', 'priya.raman@example.com', '2026-09-21 16:45:35.758595+00', '2027-04-21 16:45:35.758597+00', NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, 'Issued with the standard laptop kit.', NULL, NULL, '2026-10-23 16:45:35.763121+00');
INSERT INTO public.equipment_assignments (id, organization_id, item_id, assignee_partner_id, checkout_location_id, assigned_to_name, assigned_to_email, checked_out_at, expected_return_at, checked_in_at, checked_out_by, checked_in_by, checkout_notes, checkin_notes, checkin_condition, created_at) VALUES ('682467e8-01d3-4214-8062-a5967a45212e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '16bdf232-6dba-4418-968a-1f040742f58a', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 'Demo Administrator', 'admin@example.com', '2026-09-13 16:45:36.879517+00', NULL, NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', NULL, 'Work phone, with case and charger.', NULL, NULL, '2026-10-23 16:45:36.881341+00');


--
-- Data for Name: equipment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: equipment_maintenance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('d1d367bb-cef0-4ca7-b227-035a593ea2d0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '123f13da-5e18-4735-b23f-155dae3245ba', 'REPAIR', 'Replace failed PSU', 'Redundant power supply 2 reported a fault; unit sent to the vendor.', NULL, 'USD', '2026-10-20', 'Northgate IT Distribution', NULL, NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.289178+00', '2026-10-23 16:45:36.289182+00');
INSERT INTO public.equipment_maintenance_logs (id, organization_id, item_id, maintenance_type, title, description, cost, currency, performed_at, performed_by, service_partner_id, next_maintenance_at, created_by, created_at, updated_at) VALUES ('e3e65011-decd-45cf-bdae-8c26d61a47f8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'bf0db314-1400-440a-a329-24b813d661a1', 'INSPECTION', 'Battery self-test and runtime check', 'Runtime at full load 11 min, within spec. Batteries due next year.', 120.00, 'USD', '2026-09-13', 'Northgate IT Distribution', NULL, '2027-09-13', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.289183+00', '2026-10-23 16:45:36.289184+00');


--
-- Data for Name: event_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: event_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('00e426d3-a033-4742-acb8-40963513b28b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "d5e826e5-a34a-47af-9ade-4a3593764805", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "48.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.653997+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.654000+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "f6eb43ba-9fec-4772-ba83-fb547ad16461", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.674173+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('87fcdc05-ae15-4ff1-a084-30080ac9a4b3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "eb48385c-c1ee-43bf-9484-0de0740dc6e1", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.724186+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.724188+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "d4d375c2-948d-482d-ae68-02e446edfa8f", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.728576+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('54a70868-4b8b-4a62-ad1e-079ed49b12b0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "d95c493c-76d1-4ecd-853b-674e00dc27b8", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.751563+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.751565+00:00", "category_id": "1fdd0a5e-1353-487c-9625-ab52fbbcf496", "description": null, "expiry_date": null, "module_name": null, "template_id": "4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.756025+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('8255dee9-2e91-4a9a-b96c-f90c8f2ef76f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "b8ad8184-097a-45fc-a7cd-61564de5ecc7", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "60.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.792913+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.792916+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "6e248425-e0de-4710-b84a-3b6a6acd7713", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e26e9233-0ce2-481a-9e20-dbe5c3b92f75"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.796953+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('b66ea2d0-f60a-4437-9f2e-9cb935fdf9bf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "339bc42c-c550-4437-9e8d-a82a4d5e4f40", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "20.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.815351+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.815354+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "24283c68-c9dd-467a-ae4e-c4ee52291dc4", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e26e9233-0ce2-481a-9e20-dbe5c3b92f75"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.81992+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('578860e7-4203-4fe4-8527-86e2e35c4a1a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'document.shipped', '{"carrier": "InPost", "shipped_at": "2026-10-23T16:45:35.187885+00:00", "document_id": "de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4", "tracking_url": "https://inpost.pl/sledzenie-przesylek?number=620012345678901234567890", "document_type": "OUT", "package_count": 2, "document_number": "OUT/2026/003", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "tracking_number": "620012345678901234567890"}', '2026-10-23 16:45:35.357339+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('cb511f34-27d0-4999-9f89-9bff9eef8295', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "26bce077-6f4c-4222-9fe4-7571c140e88a", "name": "Dell Latitude 5540", "brand": "Dell", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "5.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.851256+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.851259+00:00", "category_id": "f8a93cf2-ff82-4fc9-b6a1-177c9fc70671", "description": null, "expiry_date": null, "module_name": null, "template_id": "8122a117-1950-4e6b-8afd-f1462766e3fc", "serial_number": null, "purchase_price": "4200.00", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "c8bfa3e4-ad2a-4495-b431-ea5a87b731cc"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.855728+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('d156111f-e626-4f5a-8d6d-a3bda09e226c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "ce96ce67-6bf3-4500-b106-411f73729c81", "name": "ThinkPad T14s Gen 4", "brand": "Lenovo", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "3.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:33.891068+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.891071+00:00", "category_id": "f8a93cf2-ff82-4fc9-b6a1-177c9fc70671", "description": null, "expiry_date": null, "module_name": null, "template_id": "3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf", "serial_number": null, "purchase_price": "5800.00", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "c8bfa3e4-ad2a-4495-b431-ea5a87b731cc"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "user", "email": null, "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.894647+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('715a1ecd-9cb8-45b0-921c-e6bad62a8b44', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "d5e826e5-a34a-47af-9ade-4a3593764805", "name": "UHT Milk 3.2%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "36.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-15", "created_at": "2026-10-15 14:45:33.341716+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:33.961136+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "f6eb43ba-9fec-4772-ba83-fb547ad16461", "serial_number": null, "purchase_price": "4.50", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": null, "changes": {"quantity": 36.0}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:33.964191+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('58bafad5-589f-4a6d-abdd-0cdecfd5773c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "d95c493c-76d1-4ecd-853b-674e00dc27b8", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "28.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-15", "created_at": "2026-10-15 14:45:33.341716+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:34.017192+00:00", "category_id": "1fdd0a5e-1353-487c-9625-ab52fbbcf496", "description": null, "expiry_date": null, "module_name": null, "template_id": "4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": null, "changes": {"quantity": 28.0}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:34.020125+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('06d17ffa-98c2-4101-9786-b4061ebf4014', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "eb48385c-c1ee-43bf-9484-0de0740dc6e1", "name": "Natural Yoghurt 400g", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "18.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-15", "created_at": "2026-10-15 14:45:33.341716+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:35.269857+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "d4d375c2-948d-482d-ae68-02e446edfa8f", "serial_number": null, "purchase_price": "5.20", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": null, "changes": {"quantity": 18.0}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:35.279901+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('a819a341-a80b-43b7-a036-b6740c810af1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "d95c493c-76d1-4ecd-853b-674e00dc27b8", "name": "Butter Extra 82%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "24.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-15", "created_at": "2026-10-15 14:45:33.341716+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:35.336536+00:00", "category_id": "1fdd0a5e-1353-487c-9625-ab52fbbcf496", "description": null, "expiry_date": null, "module_name": null, "template_id": "4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231", "serial_number": null, "purchase_price": "8.90", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": null, "changes": {"quantity": 24.0}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:35.33968+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('b581213e-5054-4c69-9078-030a5e7388ef', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'document.completed', '{"lines": [{"done_quantity": 6.0, "expected_quantity": 6.0, "source_po_line_id": null}, {"done_quantity": 4.0, "expected_quantity": 4.0, "source_po_line_id": null}], "document_id": "de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4", "document_type": "OUT", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:35.354154+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('0cc252ec-5db6-46f9-be2c-776b1b343a58', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "b8ad8184-097a-45fc-a7cd-61564de5ecc7", "name": "Gouda Cheese", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "50.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-17", "created_at": "2026-10-17 14:45:33.341716+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:35.554879+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "6e248425-e0de-4710-b84a-3b6a6acd7713", "serial_number": null, "purchase_price": "12.50", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e26e9233-0ce2-481a-9e20-dbe5c3b92f75"}, "user": null, "changes": {"quantity": 50.0}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:35.563098+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('05dcd049-6a79-4bd2-9d96-543594640078', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "339bc42c-c550-4437-9e8d-a82a4d5e4f40", "name": "Sour Cream 18%", "brand": "Meadowlane", "lot_id": null, "uom_id": "f8b6305e-461c-49e3-8928-bd1b56d3eabd", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "15.000", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-17", "created_at": "2026-10-17 14:45:33.341716+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:35.612667+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "24283c68-c9dd-467a-ae4e-c4ee52291dc4", "serial_number": null, "purchase_price": "4.10", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e26e9233-0ce2-481a-9e20-dbe5c3b92f75"}, "user": null, "changes": {"quantity": 15.0}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:35.616396+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('c90fd80a-f40f-4236-a7ba-b8117b0b5b27', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'document.completed', '{"lines": [{"done_quantity": 10.0, "expected_quantity": 10.0, "source_po_line_id": null}, {"done_quantity": 5.0, "expected_quantity": 5.0, "source_po_line_id": null}], "document_id": "235e0124-96fe-461a-bef5-3e365fc4226c", "document_type": "OUT", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:35.629189+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('dea3dfca-641a-44ae-ab5e-e5f01a72613a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "cd5bbe19-c815-46cc-9334-ef10da619ec4", "name": "Damson Plums", "brand": "Green Acre", "lot_id": null, "uom_id": "941f5080-e9d1-45ef-a876-04d75d5da6ea", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "13.600", "image_key": null, "item_type": null, "meta_data": null, "added_date": "2026-10-20", "created_at": "2026-10-23 16:45:32.300214+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:36.014942+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "ce2b02d1-16d5-4464-ab65-69c7633f3797", "serial_number": null, "purchase_price": "3.40", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "a2c28e46-9a3b-4a33-b1c8-4a6aae183c51"}, "user": null, "changes": {"quantity": 13.6}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:36.021385+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('fa7680b3-113a-4b1a-8d10-9a2992f50c49', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "15994ec8-01e3-495c-a8c7-ee9d268934d3", "name": "White Sugar", "brand": "Harvest Row", "lot_id": null, "uom_id": "941f5080-e9d1-45ef-a876-04d75d5da6ea", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "21.220", "image_key": null, "item_type": null, "meta_data": null, "added_date": "2026-10-03", "created_at": "2026-10-23 16:45:32.300220+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:36.058676+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "0ab48b73-76fb-4c25-aba6-265cd6b253f9", "serial_number": null, "purchase_price": "1.10", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e45ba619-6cdd-4d90-9c01-d6d253e1cd14"}, "user": null, "changes": {"quantity": 21.22}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:36.061278+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('b1982bf5-052e-4c8f-8bf2-0ce68c8e9343', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.updated', '{"item": {"id": "1bfd442f-eb46-402b-ae06-f3f2e068b798", "name": "Cassia Cinnamon", "brand": "Saltmill", "lot_id": null, "uom_id": "941f5080-e9d1-45ef-a876-04d75d5da6ea", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "0.440", "image_key": null, "item_type": null, "meta_data": null, "added_date": "2026-09-19", "created_at": "2026-10-23 16:45:32.300222+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:36.085810+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "543f25e9-9572-4b44-a548-fc2878ca5324", "serial_number": null, "purchase_price": "24.00", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e45ba619-6cdd-4d90-9c01-d6d253e1cd14"}, "user": null, "changes": {"quantity": 0.44}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:36.088335+00', NULL, 0, NULL);
INSERT INTO public.event_outbox (id, organization_id, event, payload, created_at, published_at, attempts, emitter_module) VALUES ('5bc68aca-cb7e-443b-b125-b0456db4c203', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'item.created', '{"item": {"id": "10c8d400-0c08-4b58-a26c-59e41e4937f9", "name": "Plum Butter", "brand": null, "lot_id": null, "uom_id": "941f5080-e9d1-45ef-a876-04d75d5da6ea", "barcode": null, "currency": "USD", "owner_id": null, "quantity": "11.400", "image_key": null, "item_type": null, "meta_data": {}, "added_date": "2026-10-23", "created_at": "2026-10-23 16:45:36.111108+00:00", "deleted_at": null, "deleted_by": null, "is_deleted": false, "label_code": null, "partner_id": null, "updated_at": "2026-10-23 16:45:36.111111+00:00", "category_id": null, "description": null, "expiry_date": null, "module_name": null, "template_id": "f1beac56-0318-4b69-a037-8ee13b25ee76", "serial_number": null, "purchase_price": "8.36", "shelf_location": null, "deletion_reason": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "is_catalog_entry": false, "source_document_id": null, "storage_location_id": "e45ba619-6cdd-4d90-9c01-d6d253e1cd14"}, "user": {"id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "role": "admin", "email": "admin@example.com", "permissions": "set()", "is_superuser": false, "organization": null, "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe", "extra_permissions": "set()"}, "user_id": "3f56745b-168d-495f-ae6b-57e85c48c2f5", "organization_id": "6c5ab9ac-47df-44ca-834d-cca2115b65fe"}', '2026-10-23 16:45:36.116672+00', NULL, 0, NULL);


--
-- Data for Name: example_widgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ingredient_nutrition_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_periods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: item_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d4dfb391-88aa-4152-9810-19b91e9ccdd0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd5e826e5-a34a-47af-9ade-4a3593764805', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "f6eb43ba-9fec-4772-ba83-fb547ad16461"}', '0d79edb5-fd53-492f-b75c-a325527ee16c', '2026-10-23 16:45:33.666914+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('168a91b0-5aad-421c-8718-f18a9755cec7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'eb48385c-c1ee-43bf-9484-0de0740dc6e1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "d4d375c2-948d-482d-ae68-02e446edfa8f"}', '0d79edb5-fd53-492f-b75c-a325527ee16c', '2026-10-23 16:45:33.72726+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('cdbcc7e1-a00e-43de-9907-e01d6a51ba7e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/001", "from_template": "4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231"}', '0d79edb5-fd53-492f-b75c-a325527ee16c', '2026-10-23 16:45:33.754755+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('5fa1bcf2-03ca-4826-a628-a09860667c3e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "6e248425-e0de-4710-b84a-3b6a6acd7713"}', 'c861b165-2f60-4301-bf23-28fcdfce2439', '2026-10-23 16:45:33.795729+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('33da01dd-0ae3-4647-ab52-54c0274fedba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/002", "from_template": "24283c68-c9dd-467a-ae4e-c4ee52291dc4"}', 'c861b165-2f60-4301-bf23-28fcdfce2439', '2026-10-23 16:45:33.818193+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('0104ae09-1c9a-4d02-b573-5cab8c0f25c9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '26bce077-6f4c-4222-9fe4-7571c140e88a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "8122a117-1950-4e6b-8afd-f1462766e3fc"}', '1ad5e058-02ef-4f38-9db9-e99c8bff0e45', '2026-10-23 16:45:33.854418+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('e093611c-68a5-41ab-9e15-b603d686cb32', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce96ce67-6bf3-4500-b106-411f73729c81', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true, "reason": "document_execution", "document_type": "IN", "document_number": "IN/2026/003", "from_template": "3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf"}', '1ad5e058-02ef-4f38-9db9-e99c8bff0e45', '2026-10-23 16:45:33.89363+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('f7fd5a9d-86f0-459b-9875-f7545d11e0e3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd5e826e5-a34a-47af-9ade-4a3593764805', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "48.000", "new": "36.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', '01a7d408-1611-439f-8094-70c228c14258', '2026-10-23 16:45:33.96259+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d08193c3-d9b4-4f19-9c5c-bb35c3c88755', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "36.000", "new": "28.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/001"}', '01a7d408-1611-439f-8094-70c228c14258', '2026-10-23 16:45:34.018428+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('bb3ba109-a1f9-4410-9f7c-d07f642820a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'eb48385c-c1ee-43bf-9484-0de0740dc6e1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "24.000", "new": "18.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '2026-10-23 16:45:35.27279+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('db38c46a-969a-4a14-941c-5a6ea99739a6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd95c493c-76d1-4ecd-853b-674e00dc27b8', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "28.000", "new": "24.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/003"}', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '2026-10-23 16:45:35.337555+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('d7b10940-6a70-4074-b4ea-63bfd51f3d14', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b8ad8184-097a-45fc-a7cd-61564de5ecc7', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "60.000", "new": "50.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', '235e0124-96fe-461a-bef5-3e365fc4226c', '2026-10-23 16:45:35.557615+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('0f9a2b01-b7bf-4b8e-bd03-c68fb2b51382', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '339bc42c-c550-4437-9e8d-a82a4d5e4f40', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "20.000", "new": "15.000", "reason": "document_execution", "document_type": "OUT", "document_number": "OUT/2026/004"}', '235e0124-96fe-461a-bef5-3e365fc4226c', '2026-10-23 16:45:35.614177+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('31103f42-b825-4383-a9eb-1629fb5078a3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cd5bbe19-c815-46cc-9334-ef10da619ec4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "40.000", "new": "13.600", "reason": "Production run PR/2026/0001", "production_order_id": "86b1825d-45ab-490c-b87c-d1e5d98798bc"}', NULL, '2026-10-23 16:45:36.017577+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('cb8277b2-3ea6-44e5-8aaa-5d36206db3e1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '15994ec8-01e3-495c-a8c7-ee9d268934d3', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "25.000", "new": "21.220", "reason": "Production run PR/2026/0001", "production_order_id": "86b1825d-45ab-490c-b87c-d1e5d98798bc"}', NULL, '2026-10-23 16:45:36.059621+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('5af0360f-2127-4a4f-9b7b-4434cec03471', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1bfd442f-eb46-402b-ae06-f3f2e068b798', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'QUANTITY_CHANGED', '{"old": "0.500", "new": "0.440", "reason": "Production run PR/2026/0001", "production_order_id": "86b1825d-45ab-490c-b87c-d1e5d98798bc"}', NULL, '2026-10-23 16:45:36.086685+00');
INSERT INTO public.item_history (id, organization_id, item_id, user_id, action, changes, source_document_id, created_at) VALUES ('7f619097-091d-4c1d-a23e-e75b7f53e1b0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10c8d400-0c08-4b58-a26c-59e41e4937f9', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'CREATED', '{"created": true}', NULL, '2026-10-23 16:45:36.115592+00');


--
-- Data for Name: item_type_definitions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('18bbc0bd-152b-496a-bcd5-ebbd871d732f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '07f7aa72-9b17-43d6-9c09-6d85a8b575ac', 'Soy Sauce', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cc4a417a-a291-477b-ad60-37812ee87741', 8.000, NULL, NULL, '2026-10-16', '2026-12-19', NULL, NULL, NULL, NULL, 4.97, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115974+00', '2026-10-23 16:45:32.115977+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('49bc8ea1-68ca-4e8d-ad1f-f16a65fd5d8a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0af2e08b-ef48-4f5a-8393-d6156d77ca60', '0c229a06-71c8-40b0-b637-e5947523593e', 'Fuji Apples', 'Green Acre', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', '0c90caa3-cd77-4a17-865c-1a2bd0f87f81', 4.300, NULL, NULL, '2026-10-21', '2026-10-28', NULL, NULL, NULL, NULL, 5.65, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115979+00', '2026-10-23 16:45:32.11598+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('48995c7f-6593-42ba-9746-8ad8c11b9a92', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5c455d0d-c913-45f9-84e4-3bbc34914845', '3be81a2d-811e-4356-9704-be025202e43a', 'Ground Ginger', 'Saltmill', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', 1.000, NULL, NULL, '2026-09-24', NULL, NULL, NULL, NULL, NULL, 5.69, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115981+00', '2026-10-23 16:45:32.115982+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('9bed0320-0c03-46a9-86ec-c14b4fe7402b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '33cdaa4d-fc08-4c7e-8a94-f0f0979cbbf3', 'Chicken Stock', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '23e939a9-42a2-4e13-a42d-0e6cea0e7acd', 2.000, NULL, NULL, '2026-09-13', '2027-03-14', NULL, NULL, NULL, NULL, 4.35, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115983+00', '2026-10-23 16:45:32.115983+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('627c3448-cedc-4e9e-b7de-3bc5b9174918', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2f9367e8-bca0-45ec-a9a1-5a469284ec65', 'Spaghetti 500g', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 6.000, NULL, NULL, '2026-09-02', '2027-07-15', NULL, NULL, NULL, NULL, 5.39, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115984+00', '2026-10-23 16:45:32.115985+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('295d6c19-1630-4150-8c31-2caf691e2cac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '20dd00b7-5c42-4d49-be59-cdc95124f075', 'Strawberry Jam', 'Orchard & Oak', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a7fca96a-563b-47f4-a449-292eca81f87b', 8.000, NULL, NULL, '2026-08-22', NULL, NULL, NULL, NULL, NULL, 4.49, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115985+00', '2026-10-23 16:45:32.115986+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('e0d39c7d-33b2-41ea-a30a-d62a8f3cd5a6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '3be81a2d-811e-4356-9704-be025202e43a', 'Granulated Garlic', 'Saltmill', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a1d8635b-fe0a-48fb-970d-672422f8d5e6', 3.000, NULL, NULL, '2026-10-14', '2027-10-12', NULL, NULL, NULL, NULL, 5.03, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115987+00', '2026-10-23 16:45:32.115987+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b5861876-0bb1-4f72-a48f-f7cdb66c226a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 'd357abce-8e8b-4ab9-82aa-90312cb23f40', 'Fish Fingers', 'Bluewater', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 'c0e9f75c-42fb-4d2e-82a3-562304bf0d7f', 7.000, NULL, NULL, '2026-10-03', '2028-02-10', NULL, NULL, NULL, NULL, 5.10, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115988+00', '2026-10-23 16:45:32.115988+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('f9fc0629-de1f-49ca-90d2-de22cdf9810e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2693d9ae-6968-441a-b71e-180cf08d2f2c', 'Tomato Passata', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '5b2f9e38-61d6-407a-8df2-3739042bbe79', 3.000, NULL, NULL, '2026-09-22', '2027-09-06', NULL, NULL, NULL, NULL, 4.56, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115989+00', '2026-10-23 16:45:32.11599+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ea4e5de8-8074-45c7-b7e4-2e0cb0c4cce0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '2693d9ae-6968-441a-b71e-180cf08d2f2c', 'Tomato Passata', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '5b2f9e38-61d6-407a-8df2-3739042bbe79', 5.000, NULL, NULL, '2026-09-11', '2027-05-14', NULL, NULL, NULL, NULL, 5.60, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.11599+00', '2026-10-23 16:45:32.115991+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('43b4b6c4-d8a4-42c6-8897-d8602df5cfd4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '73c0cfe0-d0c7-4617-8946-e4a5ba89fd12', 'Smoked Sausage', 'Fellbrook Farms', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', 2.000, NULL, NULL, '2026-10-18', '2026-10-29', NULL, NULL, NULL, NULL, 5.75, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115992+00', '2026-10-23 16:45:32.115992+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('dc91ca88-8631-4120-a745-29d9291de824', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 'd357abce-8e8b-4ab9-82aa-90312cb23f40', 'Potato and Cheese Dumplings', 'Northwind Frozen', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', 7.000, NULL, NULL, '2026-08-20', '2027-06-18', NULL, NULL, NULL, NULL, 5.06, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115993+00', '2026-10-23 16:45:32.115994+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('5e3217a8-acc4-46e0-83b4-e255b7948baa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '3be81a2d-811e-4356-9704-be025202e43a', 'Dried Oregano', 'Saltmill', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '4bc73840-44dc-4a70-97b8-f449a586d57e', 5.000, NULL, NULL, '2026-10-12', '2026-10-23', NULL, NULL, NULL, NULL, 5.25, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115995+00', '2026-10-23 16:45:32.115995+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('cca5b8c1-03a7-4ba4-82e1-bea2e825dd4a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '1f29d095-97b0-47c5-a726-899f6db0c5a5', 'Eggs Medium 10pk', 'Fellbrook Farms', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', 1.000, NULL, NULL, '2026-10-17', '2026-10-20', NULL, NULL, NULL, NULL, 4.72, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115996+00', '2026-10-23 16:45:32.115997+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('a095fa1a-86d2-45c2-ab47-f186f21a2411', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '2693d9ae-6968-441a-b71e-180cf08d2f2c', 'Peeled Tomatoes 400g', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2201036f-39da-4e0e-bb94-c675770c9438', 9.000, NULL, NULL, '2026-09-20', NULL, NULL, NULL, NULL, NULL, 5.04, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115997+00', '2026-10-23 16:45:32.115998+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b4599a37-8f52-4b1c-9362-fd9df41340b5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 'd357abce-8e8b-4ab9-82aa-90312cb23f40', 'Potato and Cheese Dumplings', 'Northwind Frozen', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', 1.000, NULL, NULL, '2026-09-09', '2028-03-23', NULL, NULL, NULL, NULL, 5.55, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.115999+00', '2026-10-23 16:45:32.115999+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('e35058b2-2e38-400f-a194-e2478667c688', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6588e3ed-0fc3-4ec0-be21-07fda324cb6e', '2669d193-0cc5-4cb7-8eea-8cbc0ebc0cc6', 'Orange Juice NFC', 'Orchard & Oak', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '707d1613-0643-4f34-b3ec-c8229a6a9aa9', 5.000, NULL, NULL, '2026-08-29', NULL, NULL, NULL, NULL, NULL, 4.55, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116+00', '2026-10-23 16:45:32.116001+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('9f05685a-44dc-4dd2-b62b-aba31a4ab308', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '38323184-273f-4032-8597-d48a45db1650', '1fdd0a5e-1353-487c-9625-ab52fbbcf496', 'Butter Extra 82%', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 8.000, NULL, NULL, '2026-10-17', '2026-10-26', NULL, NULL, NULL, NULL, 5.65, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116002+00', '2026-10-23 16:45:32.116002+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('fdd48d9c-011e-4586-be58-95eeb73a609b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '33cdaa4d-fc08-4c7e-8a94-f0f0979cbbf3', 'Instant Tomato Soup', 'Harvest Row', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 'f612f610-95b6-4dab-9644-c2594d96430f', 6.000, NULL, NULL, '2026-10-10', '2027-03-03', NULL, NULL, NULL, NULL, 5.28, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116003+00', '2026-10-23 16:45:32.116004+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('59f6bf9b-b127-44d1-a385-300dd9c68424', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '33cdaa4d-fc08-4c7e-8a94-f0f0979cbbf3', 'Cocoa Powder', 'Orchard & Oak', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '93156300-273c-4504-9d73-82c9cba20044', 5.000, NULL, NULL, '2026-09-29', '2027-10-09', NULL, NULL, NULL, NULL, 4.59, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116005+00', '2026-10-23 16:45:32.116005+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('172be898-0643-42ea-bcb7-523d49398323', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '2f9367e8-bca0-45ec-a9a1-5a469284ec65', 'Spaghetti 500g', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 7.000, NULL, NULL, '2026-09-18', '2027-07-14', NULL, NULL, NULL, NULL, 5.23, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116006+00', '2026-10-23 16:45:32.116006+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('692653f5-8152-434e-a78e-9518ca59758d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '87f79b27-b69a-4080-ac75-2cc6ecf92f64', 'Tuna in Oil', 'Bluewater', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '02b8cd00-e818-4a00-b200-7edfa26cc2cb', 5.000, NULL, NULL, '2026-09-07', '2027-04-20', NULL, NULL, NULL, NULL, 5.43, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116007+00', '2026-10-23 16:45:32.116008+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('5af64c3e-4713-4d55-8187-d5fb54c307bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '134d101f-9b19-4253-a267-52016e5f503f', 'Coffee Beans', 'Orchard & Oak', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '158f1823-7f6c-40da-bd8d-eb16a099d38b', 8.000, NULL, NULL, '2026-08-27', NULL, NULL, NULL, NULL, NULL, 4.28, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116009+00', '2026-10-23 16:45:32.116009+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('e06f12c2-a8a4-4de7-ad6f-4eff2a868bab', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a676029e-6f7e-4946-82c4-648b96093d6f', '1fdd0a5e-1353-487c-9625-ab52fbbcf496', 'Lean Quark', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'c5e23a58-4fcc-486f-ab6a-467242fec15c', 7.000, NULL, NULL, '2026-10-17', '2026-10-24', NULL, NULL, NULL, NULL, 5.06, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.11601+00', '2026-10-23 16:45:32.116011+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ff9bbe2c-0eed-41b6-a39d-6e4cfa189860', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '2f9367e8-bca0-45ec-a9a1-5a469284ec65', 'Spaghetti 500g', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 10.000, NULL, NULL, '2026-10-08', '2027-04-03', NULL, NULL, NULL, NULL, 5.47, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116011+00', '2026-10-23 16:45:32.116012+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('a8bb2959-1f15-4b02-8c21-e55cda3503ac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '73c0cfe0-d0c7-4617-8946-e4a5ba89fd12', 'Smoked Sausage', 'Fellbrook Farms', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', 2.000, NULL, NULL, '2026-10-21', '2026-10-25', NULL, NULL, NULL, NULL, 5.51, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116012+00', '2026-10-23 16:45:32.116013+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('933106c0-b448-43f1-9e7f-4cf358e9547c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0af2e08b-ef48-4f5a-8393-d6156d77ca60', '1fdd0a5e-1353-487c-9625-ab52fbbcf496', 'Cottage Cheese', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'e6a22858-75a9-491e-9dc3-420226894ee0', 5.000, NULL, NULL, '2026-10-20', '2026-10-30', NULL, NULL, NULL, NULL, 4.44, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116014+00', '2026-10-23 16:45:32.116014+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('7b3178c0-06fa-4762-86ea-da05abae4634', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '818c97a7-6560-482f-b172-913acf53f254', 'a144ebc7-efe0-4ffc-8e99-7f4e0105075f', 'Frozen Sour Cherries', 'Northwind Frozen', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', '6445c742-2b9a-4c27-be83-845a74fbbe23', 8.000, NULL, NULL, '2026-09-05', '2028-02-05', NULL, NULL, NULL, NULL, 5.50, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116015+00', '2026-10-23 16:45:32.116016+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('8b4e622d-795d-4565-b65b-0defef8f6c0e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '8d7df3e0-abfc-48ba-9eb6-bf8499dc9f0f', 'Salted Potato Crisps', 'Orchard & Oak', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'aee53ac2-5a8d-4cf2-b8c7-8871db10eb60', 9.000, NULL, NULL, '2026-08-25', '2027-02-09', NULL, NULL, NULL, NULL, 5.49, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116016+00', '2026-10-23 16:45:32.116017+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('8320ccd9-c1c7-4650-b88d-9efe168aed07', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '07f7aa72-9b17-43d6-9c09-6d85a8b575ac', 'Extra Virgin Olive Oil', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cf3acca4-5c34-494d-8ed3-00af16098627', 6.000, NULL, NULL, '2026-08-14', NULL, NULL, NULL, NULL, NULL, 4.97, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116017+00', '2026-10-23 16:45:32.116018+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('95847ea2-ad92-4055-908b-54ac8d8f9cc9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2f9367e8-bca0-45ec-a9a1-5a469284ec65', 'Spaghetti 500g', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 3.000, NULL, NULL, '2026-10-06', '2026-11-29', NULL, NULL, NULL, NULL, 4.99, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116018+00', '2026-10-23 16:45:32.116019+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('bfc89594-94b1-4cf0-ab22-17d07bf27d29', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5c455d0d-c913-45f9-84e4-3bbc34914845', '94aca667-13e8-4c0e-bf97-7a759f17e0a5', 'Wheat Flour Type 550', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', 7.000, NULL, NULL, '2026-09-25', NULL, NULL, NULL, NULL, NULL, 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116019+00', '2026-10-23 16:45:32.11602+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('bd717ba3-5fb3-4e94-a4c5-0efc64578a1d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '8d7df3e0-abfc-48ba-9eb6-bf8499dc9f0f', 'Butter Biscuits', 'Orchard & Oak', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', '57298474-a0b7-4c3a-b9dc-d1f5743251fe', 10.000, NULL, NULL, '2026-09-14', '2027-06-21', NULL, NULL, NULL, NULL, 4.28, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.11602+00', '2026-10-23 16:45:32.116021+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ab2cd10e-985d-4e51-9055-dd3caf7c73b0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5c455d0d-c913-45f9-84e4-3bbc34914845', '2693d9ae-6968-441a-b71e-180cf08d2f2c', 'Tomato Passata', 'Harvest Row', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '5b2f9e38-61d6-407a-8df2-3739042bbe79', 3.000, NULL, NULL, '2026-09-03', NULL, NULL, NULL, NULL, NULL, 5.14, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116021+00', '2026-10-23 16:45:32.116022+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('64603981-0929-4912-b837-dc9dbce645ca', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3ec3439d-33dd-4485-b8dd-496290b68ae8', 'd6e4b45d-e804-4212-a103-d7a66c62c2b1', 'Minced Pork', 'Fellbrook Farms', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', '1f160de2-c8bd-4710-bd24-618f056b1e05', 8.600, NULL, NULL, '2026-10-18', '2026-10-22', NULL, NULL, NULL, NULL, 5.23, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116022+00', '2026-10-23 16:45:32.116023+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('12c2f2de-2e0a-4751-a348-9233f2d128bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '3be81a2d-811e-4356-9704-be025202e43a', 'Ground Ginger', 'Saltmill', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', 3.000, NULL, NULL, '2026-10-15', NULL, NULL, NULL, NULL, NULL, 5.27, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116024+00', '2026-10-23 16:45:32.116024+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('60a21e41-90d5-43c1-ad7b-fc52c6870857', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '3be81a2d-811e-4356-9704-be025202e43a', 'Dried Basil', 'Saltmill', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '7e5233ae-eb17-495d-b280-8556ff16caba', 1.000, NULL, NULL, '2026-10-04', '2026-11-17', NULL, NULL, NULL, NULL, 4.32, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116025+00', '2026-10-23 16:45:32.116025+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('45a410c3-33a3-4f8b-b72f-e0e1b5b297f1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '07a46c38-3495-486c-9b42-2b72204ee7ca', 'Smoked Salmon', 'Bluewater', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'c9bd85c8-4d70-4ed9-ad2c-b3170dc45a63', 4.000, NULL, NULL, '2026-10-21', '2026-10-27', NULL, NULL, NULL, NULL, 4.36, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116026+00', '2026-10-23 16:45:32.116027+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('dc5c3645-7760-4ba9-b5c0-9b3950605425', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3ec3439d-33dd-4485-b8dd-496290b68ae8', 'd6e4b45d-e804-4212-a103-d7a66c62c2b1', 'Minced Pork', 'Fellbrook Farms', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', '1f160de2-c8bd-4710-bd24-618f056b1e05', 5.800, NULL, NULL, '2026-10-20', '2026-10-23', NULL, NULL, NULL, NULL, 5.10, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116027+00', '2026-10-23 16:45:32.116028+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('03d88570-169e-469c-924c-097a190cc56a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '3be81a2d-811e-4356-9704-be025202e43a', 'Sweet Paprika', 'Saltmill', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'ea1a768a-d6a2-4680-a2e1-1b090bc790bd', 1.000, NULL, NULL, '2026-09-01', NULL, NULL, NULL, NULL, NULL, 4.60, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.116029+00', '2026-10-23 16:45:32.116029+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('33445a19-14cf-45a2-9a3f-27de3c2a45f1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd507738e-d53e-49df-a82a-34ce64090c6a', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'Dell Latitude 5540', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8122a117-1950-4e6b-8afd-f1462766e3fc', 1.000, NULL, 'SN-100003', '2025-11-21', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-21", "warranty_until": "2028-11-20", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-21 09:00:00+00', '2026-10-23 16:45:32.240498+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('f6614652-8472-47a9-818e-45c73da80a97', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'Dell Latitude 5540', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8122a117-1950-4e6b-8afd-f1462766e3fc', 1.000, NULL, 'SN-100004', '2025-08-16', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-16", "warranty_until": "2028-08-15", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-16 09:00:00+00', '2026-10-23 16:45:32.240498+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('4af7f02a-b50d-47b8-b9f4-88812ccbb538', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 1.000, NULL, 'SN-100005', '2025-05-11', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-11", "warranty_until": "2028-05-10", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-11 09:00:00+00', '2026-10-23 16:45:32.240499+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ae6658f1-69bf-490c-8266-326e17f025b5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 1.000, NULL, 'SN-100006', '2025-02-03', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-03", "warranty_until": "2028-02-03", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-03 09:00:00+00', '2026-10-23 16:45:32.2405+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('a7cc334b-bca9-41df-afec-25114acd229b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd507738e-d53e-49df-a82a-34ce64090c6a', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 1.000, NULL, 'SN-100007', '2024-10-29', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-29", "warranty_until": "2027-10-29", "equipment_status": "AVAILABLE"}}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-29 09:00:00+00', '2026-10-23 16:45:32.2405+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('cbe47af3-20ab-432b-9b2e-90b2a1793c38', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'MacBook Pro 14 M3', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'ded630c1-2384-4eda-b549-77304d5b061f', 1.000, NULL, 'SN-100008', '2024-07-24', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-24", "warranty_until": "2027-07-24", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-24 09:00:00+00', '2026-10-23 16:45:32.240501+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('c193cea7-5ace-4268-b794-517e5ca52441', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'MacBook Pro 14 M3', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'ded630c1-2384-4eda-b549-77304d5b061f', 1.000, NULL, 'SN-100009', '2024-04-18', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-18", "warranty_until": "2027-04-18", "equipment_status": "AVAILABLE"}}', 9500.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-18 09:00:00+00', '2026-10-23 16:45:32.240502+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('4a9aaa0e-0d46-4d2a-b066-42762773b6e9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'HP EliteBook 840 G10', 'HP', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '11a51a5e-082b-4e76-900c-12421b9fca6d', 1.000, NULL, 'SN-100010', '2024-01-12', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-12", "warranty_until": "2027-01-11", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-12 09:00:00+00', '2026-10-23 16:45:32.240503+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('8b8ec988-ed8c-4b35-ac2e-12ea720e0768', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'HP EliteBook 840 G10', 'HP', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '11a51a5e-082b-4e76-900c-12421b9fca6d', 1.000, NULL, 'SN-100011', '2023-10-07', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-07", "warranty_until": "2026-10-06", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-07 09:00:00+00', '2026-10-23 16:45:32.240504+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('7592587b-463b-4687-a519-4c5c78200112', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'HP EliteBook 840 G10', 'HP', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '11a51a5e-082b-4e76-900c-12421b9fca6d', 1.000, NULL, 'SN-100012', '2026-07-06', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-06", "warranty_until": "2029-07-05", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-06 09:00:00+00', '2026-10-23 16:45:32.240505+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ccb6ad7c-5e67-4942-b30b-0b725c974639', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'HP EliteBook 840 G10', 'HP', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '11a51a5e-082b-4e76-900c-12421b9fca6d', 1.000, NULL, 'SN-100013', '2026-03-31', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-03-31", "warranty_until": "2029-03-30", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2026-03-31 09:00:00+00', '2026-10-23 16:45:32.240506+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('a940f565-56d3-4a8a-93b5-e30d8af68da9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'HP EliteBook 840 G10', 'HP', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '11a51a5e-082b-4e76-900c-12421b9fca6d', 1.000, NULL, 'SN-100014', '2025-12-24', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-24", "warranty_until": "2028-12-23", "equipment_status": "AVAILABLE"}}', 4600.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-24 09:00:00+00', '2026-10-23 16:45:32.240507+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('6731624f-d6a9-40a7-b5f4-b777921c76c4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '042a2c3d-6a32-4d60-a149-e3d416d66044', 'Dell OptiPlex 7010', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', 1.000, NULL, 'SN-100015', '2025-09-18', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-18", "warranty_until": "2028-09-17", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-18 09:00:00+00', '2026-10-23 16:45:32.240507+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('4d68fc77-33bc-4861-ad2c-54edc61e89f0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '042a2c3d-6a32-4d60-a149-e3d416d66044', 'Dell OptiPlex 7010', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', 1.000, NULL, 'SN-100017', '2025-03-08', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-08", "warranty_until": "2028-03-07", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-08 09:00:00+00', '2026-10-23 16:45:32.240509+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('aa2efb72-e817-40ba-99fc-6fb26ab6323a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', '042a2c3d-6a32-4d60-a149-e3d416d66044', 'Dell OptiPlex 7010', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', 1.000, NULL, 'SN-100018', '2024-12-01', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-01", "warranty_until": "2027-12-01", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-01 09:00:00+00', '2026-10-23 16:45:32.24051+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('f028ffdb-6158-4c06-9e2b-51af064128ab', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '042a2c3d-6a32-4d60-a149-e3d416d66044', 'HP ProDesk 400 G9', 'HP', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'ace5920e-c8d3-43bd-94b7-3b832bc1e18a', 1.000, NULL, 'SN-100019', '2024-08-26', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-26", "warranty_until": "2027-08-26", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-26 09:00:00+00', '2026-10-23 16:45:32.240511+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('11f739d1-7b47-4478-9c21-06528ec0413d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd507738e-d53e-49df-a82a-34ce64090c6a', '042a2c3d-6a32-4d60-a149-e3d416d66044', 'Lenovo ThinkCentre M90q', 'Lenovo', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '94d90f8e-ee00-4048-b247-70596dfe32ec', 1.000, NULL, 'SN-100020', '2024-05-21', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-21", "warranty_until": "2027-05-21", "equipment_status": "AVAILABLE"}}', 3600.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-21 09:00:00+00', '2026-10-23 16:45:32.240511+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('edcc1ef6-e565-44eb-b40b-af8f4cbbbe80', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 'e12c34aa-6396-4b2a-a358-7cece1eefe15', 'Dell UltraSharp U2723QE', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '91ffd7bf-4033-4656-aa36-f1034b7c0141', 1.000, NULL, 'SN-100021', '2024-02-14', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-14", "warranty_until": "2027-02-13", "equipment_status": "AVAILABLE"}}', 2100.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-14 09:00:00+00', '2026-10-23 16:45:32.240512+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('cd5bbe19-c815-46cc-9334-ef10da619ec4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 'Damson Plums', 'Green Acre', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 13.600, NULL, NULL, '2026-10-20', NULL, NULL, NULL, NULL, NULL, 3.40, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.300214+00', '2026-10-23 16:45:36.014942+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('3bcfabb3-0573-480d-a387-98a8080cb932', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '042a2c3d-6a32-4d60-a149-e3d416d66044', 'Dell OptiPlex 7010', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', 1.000, NULL, 'SN-100016', '2025-06-13', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-13", "warranty_until": "2028-06-12", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-13 09:00:00+00', '2026-10-23 16:45:36.940244+00', 'STM-S8HT', NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('1ceb3d15-2522-4f56-bac8-b7191e539f7e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', 'e12c34aa-6396-4b2a-a358-7cece1eefe15', 'LG 27UK850-W', 'LG', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '113aa38b-98d4-44a1-be3e-0f16882f1456', 1.000, NULL, 'SN-100022', '2023-11-09', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-09", "warranty_until": "2026-11-08", "equipment_status": "AVAILABLE"}}', 1600.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-09 09:00:00+00', '2026-10-23 16:45:32.240513+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('dc9207aa-3f80-4488-b9b0-f31b529eb5e1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', 'e12c34aa-6396-4b2a-a358-7cece1eefe15', 'Samsung Odyssey G5', 'Samsung', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '5f510017-5366-4204-afc9-f2e6282c6261', 1.000, NULL, 'SN-100023', '2026-08-08', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-08", "warranty_until": "2029-08-07", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-08 09:00:00+00', '2026-10-23 16:45:32.240514+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b3a212c0-900b-4479-bcff-3173062a4ea0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 'e12c34aa-6396-4b2a-a358-7cece1eefe15', 'Samsung Odyssey G5', 'Samsung', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '5f510017-5366-4204-afc9-f2e6282c6261', 1.000, NULL, 'SN-100024', '2026-05-03', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-03", "warranty_until": "2029-05-02", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-03 09:00:00+00', '2026-10-23 16:45:32.240515+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('7ae0794e-e118-4a2b-9840-c590449c49e1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 'e12c34aa-6396-4b2a-a358-7cece1eefe15', 'Samsung Odyssey G5', 'Samsung', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '5f510017-5366-4204-afc9-f2e6282c6261', 1.000, NULL, 'SN-100025', '2026-01-26', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-26", "warranty_until": "2029-01-25", "equipment_status": "AVAILABLE"}}', 1400.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-26 09:00:00+00', '2026-10-23 16:45:32.240515+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('f38805ea-907e-47bc-95d0-fe7802e68b7f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPhone 15 Pro', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 1.000, NULL, 'SN-100026', '2025-10-21', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-21", "warranty_until": "2028-10-20", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-21 09:00:00+00', '2026-10-23 16:45:32.240516+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ab44d2a1-afa7-4125-b698-b8d6226b9322', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPhone 15 Pro', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 1.000, NULL, 'SN-100028', '2025-04-10', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-10", "warranty_until": "2028-04-09", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-10 09:00:00+00', '2026-10-23 16:45:32.240518+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('6119a187-8288-4978-b6d2-a83f9326c10d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPhone 15 Pro', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 1.000, NULL, 'SN-100029', '2025-01-03', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-03", "warranty_until": "2028-01-03", "equipment_status": "AVAILABLE"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-03 09:00:00+00', '2026-10-23 16:45:32.240519+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('e0bebbd2-9725-4edc-8ded-5cf7f51abb19', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2de1ae03-d82e-44be-a829-0d026a81c379', 'Samsung Galaxy S24', 'Samsung', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '9d3aaf76-139c-42fd-a110-dd326335cd7f', 1.000, NULL, 'SN-100030', '2024-09-28', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-28", "warranty_until": "2027-09-28", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-28 09:00:00+00', '2026-10-23 16:45:32.240519+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('f48dc345-a7d4-49cb-b50b-2bd1ca774294', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', '2de1ae03-d82e-44be-a829-0d026a81c379', 'Samsung Galaxy S24', 'Samsung', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '9d3aaf76-139c-42fd-a110-dd326335cd7f', 1.000, NULL, 'SN-100031', '2024-06-23', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-23", "warranty_until": "2027-06-23", "equipment_status": "AVAILABLE"}}', 3800.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-23 09:00:00+00', '2026-10-23 16:45:32.24052+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('98f58717-acda-4fba-b63f-6c1679013d62', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPad Air M2', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', 1.000, NULL, 'SN-100032', '2024-03-18', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-18", "warranty_until": "2027-03-18", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-18 09:00:00+00', '2026-10-23 16:45:32.240521+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('3ac40c64-a75c-4154-80a3-49097d9c2647', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPad Air M2', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', 1.000, NULL, 'SN-100033', '2023-12-12', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-12", "warranty_until": "2026-12-11", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-12 09:00:00+00', '2026-10-23 16:45:32.240521+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('d8e00d64-a82b-4251-a062-d892686ade1c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPad Air M2', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', 1.000, NULL, 'SN-100034', '2023-09-06', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-09-06", "warranty_until": "2026-09-05", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2023-09-06 09:00:00+00', '2026-10-23 16:45:32.240522+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('0c9840b3-a6f0-4e76-877f-66da7ec1188e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPad Air M2', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', 1.000, NULL, 'SN-100035', '2026-06-05', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-05", "warranty_until": "2029-06-04", "equipment_status": "AVAILABLE"}}', 3400.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-05 09:00:00+00', '2026-10-23 16:45:32.240523+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('7869d18f-4f4c-4612-a47a-1278ca9ba3f5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '795801f3-98f0-40c7-8654-15134aaa9097', 1.000, NULL, 'SN-100037', '2025-11-23', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-11-23", "warranty_until": "2028-11-22", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2025-11-23 09:00:00+00', '2026-10-23 16:45:32.240524+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('152ca7c0-3490-44a1-bd45-2e13b0958764', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '795801f3-98f0-40c7-8654-15134aaa9097', 1.000, NULL, 'SN-100038', '2025-08-18', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-08-18", "warranty_until": "2028-08-17", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2025-08-18 09:00:00+00', '2026-10-23 16:45:32.240525+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('fc58882a-56b0-4621-aece-5325faf1e087', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '795801f3-98f0-40c7-8654-15134aaa9097', 1.000, NULL, 'SN-100039', '2025-05-13', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-05-13", "warranty_until": "2028-05-12", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2025-05-13 09:00:00+00', '2026-10-23 16:45:32.240525+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('a73ba785-9730-4866-ba25-089440414da5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', 1.000, NULL, 'SN-100040', '2025-02-05', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-02-05", "warranty_until": "2028-02-05", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2025-02-05 09:00:00+00', '2026-10-23 16:45:32.240526+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('cb76e281-b591-431e-97a8-d4d108a4a91d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', 1.000, NULL, 'SN-100041', '2024-10-31', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-10-31", "warranty_until": "2027-10-31", "equipment_status": "AVAILABLE"}}', 3200.00, 'USD', false, false, NULL, NULL, NULL, '2024-10-31 09:00:00+00', '2026-10-23 16:45:32.240526+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('38a4eedb-d6e3-4e09-a8e6-003778af9d31', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'TP-Link TL-SG3428', 'TP-Link', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '9a457f48-ab83-4c41-9d59-77286f59c20d', 1.000, NULL, 'SN-100042', '2024-07-26', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-07-26", "warranty_until": "2027-07-26", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-07-26 09:00:00+00', '2026-10-23 16:45:32.240527+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b1fe6604-5b13-4039-8364-9fcb4dba13b8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'TP-Link TL-SG3428', 'TP-Link', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '9a457f48-ab83-4c41-9d59-77286f59c20d', 1.000, NULL, 'SN-100043', '2024-04-20', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-04-20", "warranty_until": "2027-04-20", "equipment_status": "AVAILABLE"}}', 950.00, 'USD', false, false, NULL, NULL, NULL, '2024-04-20 09:00:00+00', '2026-10-23 16:45:32.240528+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('2aeb48c4-8fbf-4c28-ae80-1d9883515a3a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Meraki MR46', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 1.000, NULL, 'SN-100044', '2024-01-14', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-01-14", "warranty_until": "2027-01-13", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2024-01-14 09:00:00+00', '2026-10-23 16:45:32.240528+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('0d2c1a5e-1850-429e-b5bc-c64e7031ac67', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Meraki MR46', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 1.000, NULL, 'SN-100045', '2023-10-09', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-10-09", "warranty_until": "2026-10-08", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2023-10-09 09:00:00+00', '2026-10-23 16:45:32.240529+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('2e38944f-642e-425d-9820-44c1b441a6e0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Meraki MR46', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 1.000, NULL, 'SN-100046', '2026-07-08', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-07-08", "warranty_until": "2029-07-07", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-07-08 09:00:00+00', '2026-10-23 16:45:32.24053+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('8bf90665-caa6-42e7-9dcd-ea6c5361401b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Meraki MR46', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 1.000, NULL, 'SN-100047', '2026-04-02', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-04-02", "warranty_until": "2029-04-01", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2026-04-02 09:00:00+00', '2026-10-23 16:45:32.240531+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('c629351a-8d72-4dc4-b160-40bdff339e1e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '272eb045-e16d-48e8-9a21-2f539405d460', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech MX Keys S', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8e4a5228-a241-4e74-9a87-04fcf582a329', 1.000, NULL, 'SN-100049', '2025-09-20', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-09-20", "warranty_until": "2028-09-19", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-09-20 09:00:00+00', '2026-10-23 16:45:32.240532+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('8b05018c-03aa-4230-b661-893adc443d60', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech MX Keys S', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8e4a5228-a241-4e74-9a87-04fcf582a329', 1.000, NULL, 'SN-100050', '2025-06-15', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-06-15", "warranty_until": "2028-06-14", "equipment_status": "AVAILABLE"}}', 450.00, 'USD', false, false, NULL, NULL, NULL, '2025-06-15 09:00:00+00', '2026-10-23 16:45:32.240533+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('de6a0ea3-850c-4323-9266-e64b79bf86c3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech MX Master 3S', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '82d76422-6692-4b34-8c43-28faecac65b2', 1.000, NULL, 'SN-100051', '2025-03-10', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-03-10", "warranty_until": "2028-03-09", "equipment_status": "AVAILABLE"}}', 400.00, 'USD', false, false, NULL, NULL, NULL, '2025-03-10 09:00:00+00', '2026-10-23 16:45:32.240534+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('f1cb96ef-83d2-49c4-8fd0-91f6d65e0a6a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech C920 HD Pro', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', 1.000, NULL, 'SN-100052', '2024-12-03', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-12-03", "warranty_until": "2027-12-03", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-12-03 09:00:00+00', '2026-10-23 16:45:32.240535+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('10ddc409-0dcb-449f-845c-1bb370b07c75', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech C920 HD Pro', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', 1.000, NULL, 'SN-100053', '2024-08-28', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-08-28", "warranty_until": "2027-08-28", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-08-28 09:00:00+00', '2026-10-23 16:45:32.240536+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ed63ebf8-a467-4a99-8c1d-80f302c277aa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech C920 HD Pro', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', 1.000, NULL, 'SN-100054', '2024-05-23', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-05-23", "warranty_until": "2027-05-23", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-05-23 09:00:00+00', '2026-10-23 16:45:32.240536+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('47d2b443-0abd-430d-bab2-f8ab3b5b0b1f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Logitech C920 HD Pro', 'Logitech', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', 1.000, NULL, 'SN-100055', '2024-02-16', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-02-16", "warranty_until": "2027-02-15", "equipment_status": "AVAILABLE"}}', 350.00, 'USD', false, false, NULL, NULL, NULL, '2024-02-16 09:00:00+00', '2026-10-23 16:45:32.240537+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('cc9c3d5d-4786-4589-87df-14283445db93', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Jabra Evolve2 65', 'Jabra', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', 1.000, NULL, 'SN-100056', '2023-11-11', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-11-11", "warranty_until": "2026-11-10", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2023-11-11 09:00:00+00', '2026-10-23 16:45:32.240538+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('3f59884f-610d-4680-8545-58e25f43e431', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Jabra Evolve2 65', 'Jabra', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', 1.000, NULL, 'SN-100057', '2026-08-10', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-08-10", "warranty_until": "2029-08-09", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2026-08-10 09:00:00+00', '2026-10-23 16:45:32.240538+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('70bc7603-8cc4-4daa-b622-a1f8486b10a1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '8a4adf2c-2e32-4eda-9115-de3b2733b60f', 'Jabra Evolve2 65', 'Jabra', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', 1.000, NULL, 'SN-100058', '2026-05-05', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-05-05", "warranty_until": "2029-05-04", "equipment_status": "AVAILABLE"}}', 650.00, 'USD', false, false, NULL, NULL, NULL, '2026-05-05 09:00:00+00', '2026-10-23 16:45:32.240539+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('0b617b49-8355-472f-96ff-8248263574da', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 'c46e28ac-f524-4f1b-8cb2-46e076e3ece3', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '10deef65-5690-4f50-9510-cfa4ff2d502c', 1.000, NULL, 'SN-100060', '2025-10-23', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-10-23", "warranty_until": "2028-10-22", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2025-10-23 09:00:00+00', '2026-10-23 16:45:32.24054+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ef989857-07cf-44a0-b8b7-bbb39e188897', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd507738e-d53e-49df-a82a-34ce64090c6a', 'c46e28ac-f524-4f1b-8cb2-46e076e3ece3', 'HPE ProLiant DL380 Gen10', 'HPE', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '10deef65-5690-4f50-9510-cfa4ff2d502c', 1.000, NULL, 'SN-100061', '2025-07-18', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-18", "warranty_until": "2028-07-17", "equipment_status": "AVAILABLE"}}', 32000.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-18 09:00:00+00', '2026-10-23 16:45:32.240541+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('172a9aa9-ea5c-4f46-a9cf-2bc852652fbe', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd507738e-d53e-49df-a82a-34ce64090c6a', 'c46e28ac-f524-4f1b-8cb2-46e076e3ece3', 'Supermicro SYS-1029U', 'Supermicro', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', 1.000, NULL, 'SN-100062', '2025-04-12', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-04-12", "warranty_until": "2028-04-11", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2025-04-12 09:00:00+00', '2026-10-23 16:45:32.240542+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('fd296851-93ca-4224-9100-c809c2151f45', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 'c46e28ac-f524-4f1b-8cb2-46e076e3ece3', 'Supermicro SYS-1029U', 'Supermicro', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', 1.000, NULL, 'SN-100063', '2025-01-05', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-01-05", "warranty_until": "2028-01-05", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2025-01-05 09:00:00+00', '2026-10-23 16:45:32.240542+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('c3119cb5-3482-48b1-af87-b68123f7dfa2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 'c46e28ac-f524-4f1b-8cb2-46e076e3ece3', 'Supermicro SYS-1029U', 'Supermicro', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', 1.000, NULL, 'SN-100064', '2024-09-30', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-09-30", "warranty_until": "2027-09-30", "equipment_status": "AVAILABLE"}}', 18000.00, 'USD', false, false, NULL, NULL, NULL, '2024-09-30 09:00:00+00', '2026-10-23 16:45:32.240543+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('bf0db314-1400-440a-a329-24b813d661a1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '15249a13-1095-4158-ab71-faaddc29bc6e', 'APC Smart-UPS 3000VA', 'APC', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'd004ef0b-2410-4a4c-8068-b685e38a1570', 1.000, NULL, 'SN-100065', '2024-06-25', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-06-25", "warranty_until": "2027-06-25", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2024-06-25 09:00:00+00', '2026-10-23 16:45:32.240544+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('1421b012-d413-4ba3-9611-34298a67c311', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '15249a13-1095-4158-ab71-faaddc29bc6e', 'Rack 42U Open Frame', 'Rittal', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'dd14c900-66d6-4099-8d85-1175319e8b7b', 1.000, NULL, 'SN-100067', '2023-12-14', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2023-12-14", "warranty_until": "2026-12-13", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2023-12-14 09:00:00+00', '2026-10-23 16:45:32.240545+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('0c4ec75a-a0d3-49cb-b3c0-026c2fadbb78', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Meraki MR46', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 1.000, NULL, 'SN-100048', '2025-12-26', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-12-26", "warranty_until": "2028-12-25", "equipment_status": "AVAILABLE"}}', 2800.00, 'USD', false, false, NULL, NULL, NULL, '2025-12-26 09:00:00+00', '2026-10-23 16:45:36.940243+00', 'STM-XLO6', NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('26bce077-6f4c-4222-9fe4-7571c140e88a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'Dell Latitude 5540', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8122a117-1950-4e6b-8afd-f1462766e3fc', 5.000, NULL, NULL, '2026-10-22', NULL, NULL, NULL, NULL, '{}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-22 14:45:33.341716+00', '2026-10-23 16:45:33.903675+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('ce96ce67-6bf3-4500-b106-411f73729c81', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'ThinkPad T14s Gen 4', 'Lenovo', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 3.000, NULL, NULL, '2026-10-22', NULL, NULL, NULL, NULL, '{}', 5800.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-22 14:45:33.341716+00', '2026-10-23 16:45:33.903675+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('d5e826e5-a34a-47af-9ade-4a3593764805', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 'UHT Milk 3.2%', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 36.000, NULL, NULL, '2026-10-15', NULL, NULL, NULL, NULL, '{}', 4.50, 'USD', false, false, NULL, NULL, NULL, '2026-10-15 14:45:33.341716+00', '2026-10-23 16:45:33.961136+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('eb48385c-c1ee-43bf-9484-0de0740dc6e1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 'Natural Yoghurt 400g', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'd4d375c2-948d-482d-ae68-02e446edfa8f', 18.000, NULL, NULL, '2026-10-15', NULL, NULL, NULL, NULL, '{}', 5.20, 'USD', false, false, NULL, NULL, NULL, '2026-10-15 14:45:33.341716+00', '2026-10-23 16:45:35.269857+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('d95c493c-76d1-4ecd-853b-674e00dc27b8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '1fdd0a5e-1353-487c-9625-ab52fbbcf496', 'Butter Extra 82%', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 24.000, NULL, NULL, '2026-10-15', NULL, NULL, NULL, NULL, '{}', 8.90, 'USD', false, false, NULL, NULL, NULL, '2026-10-15 14:45:33.341716+00', '2026-10-23 16:45:35.336536+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b8ad8184-097a-45fc-a7cd-61564de5ecc7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, 'Gouda Cheese', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '6e248425-e0de-4710-b84a-3b6a6acd7713', 50.000, NULL, NULL, '2026-10-17', NULL, NULL, NULL, NULL, '{}', 12.50, 'USD', false, false, NULL, NULL, NULL, '2026-10-17 14:45:33.341716+00', '2026-10-23 16:45:35.554879+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('339bc42c-c550-4437-9e8d-a82a4d5e4f40', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, 'Sour Cream 18%', 'Meadowlane', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 15.000, NULL, NULL, '2026-10-17', NULL, NULL, NULL, NULL, '{}', 4.10, 'USD', false, false, NULL, NULL, NULL, '2026-10-17 14:45:33.341716+00', '2026-10-23 16:45:35.612667+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b0cc9bd4-fd50-4f95-846a-4771e6e914fc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f286056a-e01e-41c5-ba89-3ee011a8f021', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'Dell Latitude 5540', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8122a117-1950-4e6b-8afd-f1462766e3fc', 1.000, NULL, 'SN-100002', '2026-02-26', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-26", "warranty_until": "2029-02-25", "equipment_status": "DEPLOYED"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-26 09:00:00+00', '2026-10-23 16:45:35.759639+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('b78d86d2-4050-4179-a20f-6969ce33e232', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'Dell Latitude 5540', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8122a117-1950-4e6b-8afd-f1462766e3fc', 1.000, NULL, 'SN-100000', '2026-09-08', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-09-08", "warranty_until": "2029-09-07", "equipment_status": "DEPLOYED"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-09-08 09:00:00+00', '2026-10-23 16:45:35.75964+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('15994ec8-01e3-495c-a8c7-ee9d268934d3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', NULL, 'White Sugar', 'Harvest Row', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 21.220, NULL, NULL, '2026-10-03', NULL, NULL, NULL, NULL, NULL, 1.10, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.30022+00', '2026-10-23 16:45:36.058676+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('1bfd442f-eb46-402b-ae06-f3f2e068b798', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', NULL, 'Cassia Cinnamon', 'Saltmill', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', '543f25e9-9572-4b44-a548-fc2878ca5324', 0.440, NULL, NULL, '2026-09-19', NULL, NULL, NULL, NULL, NULL, 24.00, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:32.300222+00', '2026-10-23 16:45:36.08581+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('10c8d400-0c08-4b58-a26c-59e41e4937f9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', NULL, 'Plum Butter', NULL, NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 'f1beac56-0318-4b69-a037-8ee13b25ee76', 11.400, NULL, NULL, '2026-10-23', NULL, NULL, NULL, NULL, '{}', 8.36, 'USD', false, false, NULL, NULL, NULL, '2026-10-23 16:45:36.111108+00', '2026-10-23 16:45:36.111111+00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('16bdf232-6dba-4418-968a-1f040742f58a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2de1ae03-d82e-44be-a829-0d026a81c379', 'iPhone 15 Pro', 'Apple', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 1.000, NULL, 'SN-100027', '2025-07-16', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2025-07-16", "warranty_until": "2028-07-15", "equipment_status": "DEPLOYED"}}', 5200.00, 'USD', false, false, NULL, NULL, NULL, '2025-07-16 09:00:00+00', '2026-10-23 16:45:36.880182+00', NULL, NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('012cdc10-4164-49aa-bc48-35b5bb8d12f7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b36433d3-e05f-4f75-be3d-812e143d71f3', 'f8a93cf2-ff82-4fc9-b6a1-177c9fc70671', 'Dell Latitude 5540', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '8122a117-1950-4e6b-8afd-f1462766e3fc', 1.000, NULL, 'SN-100001', '2026-06-03', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-06-03", "warranty_until": "2029-06-02", "equipment_status": "DEPLOYED"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2026-06-03 09:00:00+00', '2026-10-23 16:45:36.940239+00', 'STM-JHAC', NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('028a5f28-ed45-44f6-9322-da4729d72bd5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd507738e-d53e-49df-a82a-34ce64090c6a', '03f72fef-ecc7-47da-949c-a6c6e9d354e3', 'Cisco Catalyst 9200L', 'Cisco', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '795801f3-98f0-40c7-8654-15134aaa9097', 1.000, NULL, 'SN-100036', '2026-02-28', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-02-28", "warranty_until": "2029-02-27", "equipment_status": "AVAILABLE"}}', 8500.00, 'USD', false, false, NULL, NULL, NULL, '2026-02-28 09:00:00+00', '2026-10-23 16:45:36.940242+00', 'STM-8Y5Q', NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('123f13da-5e18-4735-b23f-155dae3245ba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', 'c46e28ac-f524-4f1b-8cb2-46e076e3ece3', 'Dell PowerEdge R750', 'Dell', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', '4fe1ef8f-389b-478e-a8cd-420ccbeeb010', 1.000, NULL, 'SN-100059', '2026-01-28', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2026-01-28", "warranty_until": "2029-01-27", "equipment_status": "MAINTENANCE"}}', 28000.00, 'USD', false, false, NULL, NULL, NULL, '2026-01-28 09:00:00+00', '2026-10-23 16:45:36.940244+00', 'STM-0PLJ', NULL, NULL, 'equipment', NULL, NULL);
INSERT INTO public.items (id, organization_id, storage_location_id, category_id, name, brand, description, uom_id, template_id, quantity, barcode, serial_number, added_date, expiry_date, shelf_location, item_type, image_url, meta_data, purchase_price, currency, is_deleted, is_catalog_entry, deleted_at, deleted_by, deletion_reason, created_at, updated_at, label_code, partner_id, source_document_id, module_name, lot_id, owner_id) VALUES ('7d050eff-da10-40e8-afc8-4bad97bea00c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '15249a13-1095-4158-ab71-faaddc29bc6e', 'APC Smart-UPS 3000VA', 'APC', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 'd004ef0b-2410-4a4c-8068-b685e38a1570', 1.000, NULL, 'SN-100066', '2024-03-20', NULL, NULL, NULL, NULL, '{"equipment": {"purchase_date": "2024-03-20", "warranty_until": "2027-03-20", "equipment_status": "AVAILABLE"}}', 4200.00, 'USD', false, false, NULL, NULL, NULL, '2024-03-20 09:00:00+00', '2026-10-23 16:45:36.940245+00', 'STM-VC94', NULL, NULL, 'equipment', NULL, NULL);


--
-- Data for Name: label_pool; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('3c61673a-dff5-499b-bb74-35334c10045a', 'STM-VC94', true, '2026-10-12 16:45:36.938487+00', '7d050eff-da10-40e8-afc8-4bad97bea00c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('ba409a93-daae-4cdc-97b2-b350e3dc81d5', 'STM-8Y5Q', true, '2026-10-12 16:45:36.938487+00', '028a5f28-ed45-44f6-9322-da4729d72bd5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('caf9eaa9-8369-412f-8329-6896a9935c2d', 'STM-XLO6', true, '2026-10-12 16:45:36.938487+00', '0c4ec75a-a0d3-49cb-b3c0-026c2fadbb78', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('bed193ca-36e1-48bd-8c94-fe90da9d9f8d', 'STM-JHAC', true, '2026-10-12 16:45:36.938487+00', '012cdc10-4164-49aa-bc48-35b5bb8d12f7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('33b96526-5f52-49c3-8bfe-70bd11a22b7c', 'STM-S8HT', true, '2026-10-12 16:45:36.938487+00', '3bcfabb3-0573-480d-a387-98a8080cb932', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('cc5bc701-a533-438f-a29d-4eb3093e2074', 'STM-0PLJ', true, '2026-10-12 16:45:36.938487+00', '123f13da-5e18-4735-b23f-155dae3245ba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('1e508c80-00bc-4f6b-aa33-bd534b335da7', 'STM-HPSA', false, NULL, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('30ac2d72-6177-4761-a931-350dd6a06e25', 'STM-0DUP', false, NULL, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('534c5140-8507-460b-aa81-9797cd6d9c34', 'STM-FUET', false, NULL, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('74ece512-eba3-42cf-81d4-b28e836f5223', 'STM-0T2F', false, NULL, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('d1199897-00ca-4acc-94ee-2c2bdb6a86ca', 'STM-3M8C', false, NULL, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);
INSERT INTO public.label_pool (id, short_code, is_assigned, assigned_at, item_id, organization_id, created_by, label_type, description, target_storage_location_id, context_tag, created_at, printed_at, scan_count, last_scanned_at) VALUES ('337aad60-5d41-42e2-9430-75b3a99bdb62', 'STM-T7DU', false, NULL, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'GENERIC', NULL, NULL, NULL, '2026-10-11 16:45:36.938487+00', '2026-10-11 16:45:36.938487+00', 0, NULL);


--
-- Data for Name: location_relocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_bom_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('30d83b4f-1e6d-4b47-bc4a-0df46179d6e5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 'kg', 10.00, 'stone fruit', '2026-10-23 16:45:31.950755+00', '2026-10-23 16:45:31.950759+00', 'cf4de40d-d95f-49d9-92bb-b0c759ec26fa', 2.0000, '941f5080-e9d1-45ef-a876-04d75d5da6ea');
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('86a04d2f-e64d-4154-a85d-d319c1c3abdf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 'kg', 5.00, 'sweetener', '2026-10-23 16:45:31.950763+00', '2026-10-23 16:45:31.950763+00', 'cf4de40d-d95f-49d9-92bb-b0c759ec26fa', 0.3000, '941f5080-e9d1-45ef-a876-04d75d5da6ea');
INSERT INTO public.maker_bom_lines (id, organization_id, parent_template_id, child_template_id, unit, yield_loss_pct, notes, created_at, updated_at, recipe_id, qty_per_batch, uom_id) VALUES ('84f6f77c-f56a-4f78-ba63-65d791584589', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', '543f25e9-9572-4b44-a548-fc2878ca5324', 'kg', 0.00, 'spice', '2026-10-23 16:45:31.950766+00', '2026-10-23 16:45:31.950766+00', 'cf4de40d-d95f-49d9-92bb-b0c759ec26fa', 0.0050, '941f5080-e9d1-45ef-a876-04d75d5da6ea');


--
-- Data for Name: maker_module_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_module_settings (organization_id, reference_direction, created_at, updated_at, allow_overproduction, availability_check_scope, create_on_shortage_strategy) VALUES ('6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'MARGIN', '2026-10-23 16:45:35.85017+00', '2026-10-23 16:45:35.850174+00', true, 'GLOBAL', 'WARN');


--
-- Data for Name: maker_production_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('e56da853-e5e9-40a7-87cd-bcde9fc51259', '86b1825d-45ab-490c-b87c-d1e5d98798bc', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 26.4000, 'kg', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 3.4000, 'fifo', NULL);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('9bfecc23-d29f-4698-b2ad-16fb9a33807e', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 3.7800, 'kg', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 1.1000, 'fifo', NULL);
INSERT INTO public.maker_production_order_lines (id, production_order_id, child_template_id, consumed_qty, unit, source_storage_location_id, unit_cost_snapshot, cost_source, shortfall_qty) VALUES ('aa262532-e2d4-458d-b740-beda93faf967', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '543f25e9-9572-4b44-a548-fc2878ca5324', 0.0600, 'kg', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 24.0000, 'fifo', NULL);


--
-- Data for Name: maker_production_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_production_orders (id, organization_id, output_template_id, planned_qty, output_storage_location_id, status, total_cost, production_date, notes, created_by, completed_by, created_at, completed_at, cancel_reason, produced_item_id, recipe_id, actual_qty, overproduced, scrap_qty, unit_cost_snapshot, reference_price_snapshot, result_per_unit, result_per_batch, number, short_at_create) VALUES ('86b1825d-45ab-490c-b87c-d1e5d98798bc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', 12.000, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 'COMPLETED', 95.36, '2026-10-23', 'Autumn batch, first of the season.', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:35.907942+00', '2026-10-23 16:45:36.126184+00', NULL, '10c8d400-0c08-4b58-a26c-59e41e4937f9', 'cf4de40d-d95f-49d9-92bb-b0c759ec26fa', 11.400, false, 0.600, 8.3647, 18.00, 9.64, 9.64, 'PR/2026/0001', false);


--
-- Data for Name: maker_recipe_cost_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: maker_recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.maker_recipes (id, organization_id, output_template_id, name, batch_yield_qty, batch_yield_uom_id, process_steps, reference_price, is_default, source_recipe_id, source_snapshot_at, created_at, updated_at) VALUES ('cf4de40d-d95f-49d9-92bb-b0c759ec26fa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', 'Plum Butter', 1.0000, NULL, NULL, 18.00, true, NULL, NULL, '2026-10-23 16:45:31.928671+00', '2026-10-23 16:45:31.928677+00');


--
-- Data for Name: meal_plan_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('2f6761de-d946-42e7-9b70-dbcabf8d25ea', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-19', 'BREAKFAST', '6547fce5-3807-4dc2-a059-ae2da2c93c08', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('4aa8bf00-7f5b-4368-b254-0a57f0fe822b', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-19', 'DINNER', 'f658c6e6-2470-452f-86f8-21c01540c417', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('d4376d81-e6a0-4f98-88f1-bb738e9fe793', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-20', 'DINNER', '57caefe2-f9e2-400c-9c26-4145c42926dd', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('9d74ffe0-2794-4f8d-84dc-904c26e8fa9e', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-21', 'BREAKFAST', '6547fce5-3807-4dc2-a059-ae2da2c93c08', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('97630e36-7402-4d07-90a8-dc429ce8333c', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-21', 'DINNER', '62f2244d-e4b1-4ea6-ac32-bdd75a641678', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('58f96f53-16b0-49e9-8753-c60dd6f40785', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-22', 'DINNER', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('2b72b0b5-868a-41aa-8fc6-e3fc1e087d99', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-23', 'DINNER', '155a62b6-4c52-41e9-98ef-82cfa1212489', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('3b495c4e-3cf3-4880-8d95-ea5a573528cd', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-24', 'BREAKFAST', 'bc56699e-b8eb-4386-90cd-030cbb81e9cd', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('cb48d142-a902-4b05-8a29-6560f513b3cf', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-24', 'DINNER', '1af03414-66b6-4753-ae0f-398345c5de05', NULL, NULL, 0);
INSERT INTO public.meal_plan_entries (id, meal_plan_id, date, slot, recipe_id, servings, notes, "order") VALUES ('d638e5b8-26ac-430e-834a-65de6ed59e2b', 'eb4e15bd-285c-4592-bd7a-a6f000752a78', '2026-10-25', 'BREAKFAST', '464bee53-96de-4ac5-bd5d-8689cb77ab97', NULL, NULL, 0);


--
-- Data for Name: meal_plans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.meal_plans (id, organization_id, name, start_date, end_date, enabled_slots, default_servings, shopping_list_id, notes, created_by, created_at, updated_at) VALUES ('eb4e15bd-285c-4592-bd7a-a6f000752a78', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'This week', '2026-10-19', '2026-10-25', '["BREAKFAST", "DINNER"]', NULL, '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.237601+00', '2026-10-23 16:45:36.237605+00');


--
-- Data for Name: module_installations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.organizations (id, name, created_at, created_by, enabled_modules, allowed_modules, settings, short_id, active_profile_id, onboarding_completed, currency, timezone, tax_id, country, address, logo_url, focus_module, pre_focus_enabled_modules, print_page_size, pre_onboarding_manual_modules) VALUES ('6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Larkspur Trading Co.', '2026-10-23 16:45:31.123407+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '["warehouse", "purchase_orders", "stats", "core", "stock_takes", "approvals", "partners", "announcements", "recipes", "nutrition", "maker", "shopping_lists", "printing", "equipment", "items", "categories", "locations"]', NULL, '{"module:equipment": {"warranty_warning_days": 60, "maintenance_warning_days": 14, "__schema_version": 1}, "module:stats": {"enable_analytics": true, "show_inventory_value": true, "__schema_version": 1}, "show_module_data": true, "demo_last_reset_at": "2026-10-23T16:45:37.314579+00:00"}', NULL, 'equipment_wms', true, 'USD', 'UTC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('c4543079-ea11-423e-a7d0-d07738f39388', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Eurodata Systems', 'SUP-001', 'SUPPLIER', NULL, 'orders@eurodata.example.com', '+44 20 7946 0101', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964669+00', '2026-10-23 16:45:31.964674+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('d1396ba4-ac3e-48da-a1c7-185dfdd5605c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Northgate IT Distribution', 'ITD-002', 'SUPPLIER', NULL, 'sales@northgate-it.example.com', '+44 20 7946 0102', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964676+00', '2026-10-23 16:45:31.964677+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('3091f547-6234-4297-84a6-bec0bd53b716', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'TechSupply Europe', 'TSE-003', 'SUPPLIER', NULL, 'orders@techsupply.example.net', '+44 20 7946 0103', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964678+00', '2026-10-23 16:45:31.964678+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('397d73b8-cda3-44fe-8705-4a6a615240af', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Freshfield Wholesale', 'FFD-004', 'SUPPLIER', NULL, 'orders@freshfield.example.com', '+44 20 7946 0104', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964679+00', '2026-10-23 16:45:31.96468+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('8e6b16b3-57d3-4138-8636-cd57b848079c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Bulkline Cash & Carry', 'MCC-005', 'SUPPLIER', NULL, 'b2b@bulkline.example.com', '+44 20 7946 0105', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.96468+00', '2026-10-23 16:45:31.964681+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('0a3da5ab-f746-40ba-9e6f-b30b30478fd4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cornerstore Deliveries', 'ZAB-006', 'SUPPLIER', NULL, 'deliveries@cornerstore.example.com', '+44 20 7946 0106', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964681+00', '2026-10-23 16:45:31.964682+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('c98bad5f-04b8-4c7d-9199-b3faa5ba9f04', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cisco Systems', 'CSC-007', 'MANUFACTURER', NULL, 'enterprise@cisco.example.com', '+44 20 7946 0107', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964683+00', '2026-10-23 16:45:31.964683+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('198b1c39-096e-4280-b12a-1d0a0ac537e0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dell Technologies', 'DLL-008', 'MANUFACTURER', NULL, 'enterprise@dell.example.com', '+44 20 7946 0108', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964684+00', '2026-10-23 16:45:31.964685+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('1686c45e-a40d-4d08-9d99-fdcd1efa4096', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Hewlett Packard Enterprise', 'HPE-009', 'MANUFACTURER', NULL, 'sales@hpe.example.com', '+44 20 7946 0109', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964685+00', '2026-10-23 16:45:31.964686+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('36c7bd57-3ee5-45c4-835b-adc5c1ab57f5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Apple', 'APL-010', 'MANUFACTURER', NULL, 'business@apple.example.com', '+44 20 7946 0110', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964687+00', '2026-10-23 16:45:31.964687+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('2603b076-e5f3-4405-8438-ce6385719c2e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Harper Catering', 'CUS-011', 'CUSTOMER', NULL, 'orders@harpercatering.example.com', '+44 20 7946 0111', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964688+00', '2026-10-23 16:45:31.964689+00', false);
INSERT INTO public.partners (id, organization_id, name, code, type, tax_id, email, phone, website, contact_person, address, notes, is_active, created_by, created_at, updated_at, is_consumer) VALUES ('f8dfac00-df97-4160-a6e0-8881087b1e5b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Officeworks Services', 'CUS-012', 'CUSTOMER', NULL, 'office@officeworks.example.net', '+44 20 7946 0112', NULL, NULL, NULL, NULL, true, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:31.964689+00', '2026-10-23 16:45:31.96469+00', false);


--
-- Data for Name: picking_session_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: picking_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: po_partner_pricelist; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('c19d6b40-f478-4c24-bfce-cd4c6a4c2b65', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '397d73b8-cda3-44fe-8705-4a6a615240af', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 3.2000, 'USD', '941f5080-e9d1-45ef-a876-04d75d5da6ea', NULL, '2026-08-24', NULL, NULL, '2026-10-23 16:45:37.010934+00', '2026-10-23 16:45:37.010939+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('39f9f7ba-6d48-493f-b82d-78e2d0578546', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e6b16b3-57d3-4138-8636-cd57b848079c', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 1.0500, 'USD', '941f5080-e9d1-45ef-a876-04d75d5da6ea', NULL, '2026-08-24', NULL, NULL, '2026-10-23 16:45:37.01094+00', '2026-10-23 16:45:37.010941+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('89564121-31cc-4d52-b124-b7bdf803b1d4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e6b16b3-57d3-4138-8636-cd57b848079c', '543f25e9-9572-4b44-a548-fc2878ca5324', 22.5000, 'USD', '941f5080-e9d1-45ef-a876-04d75d5da6ea', NULL, '2026-08-24', NULL, NULL, '2026-10-23 16:45:37.010941+00', '2026-10-23 16:45:37.010942+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('61aee05d-c771-4cd5-827f-6a793516dbed', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c4543079-ea11-423e-a7d0-d07738f39388', '8122a117-1950-4e6b-8afd-f1462766e3fc', 4100.0000, 'USD', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, '2026-08-24', NULL, NULL, '2026-10-23 16:45:37.010942+00', '2026-10-23 16:45:37.010942+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('c3a401b2-7ce8-4025-aca0-bf3817410834', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd1396ba4-ac3e-48da-a1c7-185dfdd5605c', '8122a117-1950-4e6b-8afd-f1462766e3fc', 4180.0000, 'USD', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, '2026-08-24', NULL, NULL, '2026-10-23 16:45:37.010943+00', '2026-10-23 16:45:37.010944+00');
INSERT INTO public.po_partner_pricelist (id, organization_id, partner_id, product_template_id, unit_price, currency, uom_id, min_quantity, valid_from, valid_to, notes, created_at, updated_at) VALUES ('41e73f10-22e6-4763-b95f-263e976414e2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd1396ba4-ac3e-48da-a1c7-185dfdd5605c', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 5650.0000, 'USD', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, '2026-08-24', NULL, NULL, '2026-10-23 16:45:37.010944+00', '2026-10-23 16:45:37.010944+00');


--
-- Data for Name: po_reorder_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('f3f0a7b4-0d86-4c77-9d6a-0676e8675195', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 20.000, 40.000, 10.000, '397d73b8-cda3-44fe-8705-4a6a615240af', NULL, '2026-10-23 16:45:36.997263+00', '2026-10-23 16:45:36.997268+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('34fee4ec-3015-463b-bc50-b23d9f4eb1a8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 5.000, 25.000, 2.000, '8e6b16b3-57d3-4138-8636-cd57b848079c', NULL, '2026-10-23 16:45:36.99727+00', '2026-10-23 16:45:36.99727+00');
INSERT INTO public.po_reorder_rules (id, organization_id, product_template_id, storage_location_id, min_quantity, max_quantity, safety_stock, preferred_partner_id, notes, created_at, updated_at) VALUES ('c02bcfc1-4526-4f16-a44e-2050509db669', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '543f25e9-9572-4b44-a548-fc2878ca5324', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 0.100, 0.500, 0.100, '8e6b16b3-57d3-4138-8636-cd57b848079c', NULL, '2026-10-23 16:45:36.997271+00', '2026-10-23 16:45:36.997272+00');


--
-- Data for Name: po_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.po_settings (id, organization_id, approval_threshold, approval_required, created_at, updated_at) VALUES ('be3e28c9-2411-442c-a27e-868ba7cc4185', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 10000.00, false, '2026-10-23 16:45:36.85425+00', '2026-10-23 16:45:36.854255+00');


--
-- Data for Name: print_agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: print_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('f6eb43ba-9fec-4772-ba83-fb547ad16461', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'UHT Milk 3.2%', 'Meadowlane', '2000000000015', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 3.2, "carbs_g": 4.8, "protein_g": 3.2, "calories_kcal": 62}}', '2026-10-23 16:45:31.889406+00', '2026-10-23 16:45:31.889417+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('d4d375c2-948d-482d-ae68-02e446edfa8f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Natural Yoghurt 400g', 'Meadowlane', '2000000000022', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.5, "carbs_g": 7.5, "protein_g": 4.0, "calories_kcal": 67}}', '2026-10-23 16:45:31.889418+00', '2026-10-23 16:45:31.889419+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Butter Extra 82%', 'Meadowlane', '2000000000039', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 200.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 82.0, "carbs_g": 0.8, "protein_g": 0.5, "calories_kcal": 748}}', '2026-10-23 16:45:31.88942+00', '2026-10-23 16:45:31.88942+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('6e248425-e0de-4710-b84a-3b6a6acd7713', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Gouda Cheese', 'Meadowlane', '2000000000046', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 300.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 27.0, "carbs_g": 1.3, "protein_g": 24.0, "calories_kcal": 356}}', '2026-10-23 16:45:31.889421+00', '2026-10-23 16:45:31.889421+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('24283c68-c9dd-467a-ae4e-c4ee52291dc4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Sour Cream 18%', 'Meadowlane', '2000000000053', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 300.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 18.0, "carbs_g": 3.4, "protein_g": 2.5, "calories_kcal": 182}}', '2026-10-23 16:45:31.889422+00', '2026-10-23 16:45:31.889423+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('e6a22858-75a9-491e-9dc3-420226894ee0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cottage Cheese', 'Meadowlane', '2000000000060', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 200.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 7.0, "carbs_g": 5.0, "protein_g": 9.0, "calories_kcal": 125}}', '2026-10-23 16:45:31.889423+00', '2026-10-23 16:45:31.889424+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('c5e23a58-4fcc-486f-ab6a-467242fec15c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Lean Quark', 'Meadowlane', '2000000000077', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 250.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.5, "carbs_g": 3.5, "protein_g": 18.0, "calories_kcal": 85}}', '2026-10-23 16:45:31.889424+00', '2026-10-23 16:45:31.889425+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('522843f5-a1b0-44e2-a842-2f190d0ad24c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Chicken Ham', 'Fellbrook Farms', '2000000000091', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 4.5, "carbs_g": 1.0, "protein_g": 16.0, "calories_kcal": 110}}', '2026-10-23 16:45:31.889426+00', '2026-10-23 16:45:31.889427+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('7a39aaea-c7fb-4d61-a243-0f18c98c4cdd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Pork Frankfurters', 'Fellbrook Farms', '2000000000107', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 22.0, "carbs_g": 2.0, "protein_g": 12.0, "calories_kcal": 253}}', '2026-10-23 16:45:31.889427+00', '2026-10-23 16:45:31.889428+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('b5cb650b-8a22-4d66-965e-d24dceaa0379', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Smoked Sausage', 'Fellbrook Farms', '2000000000114', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 27.0, "carbs_g": 3.0, "protein_g": 12.0, "calories_kcal": 301}}', '2026-10-23 16:45:31.889428+00', '2026-10-23 16:45:31.889429+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('acb743b9-7c59-4ef9-998d-d8cc104ab240', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Smoked Bacon', 'Fellbrook Farms', '2000000000121', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 38.0, "carbs_g": 1.0, "protein_g": 12.0, "calories_kcal": 393}}', '2026-10-23 16:45:31.889429+00', '2026-10-23 16:45:31.88943+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('6aa02172-c358-453d-91c0-856ff4792509', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Chicken Breast Fillet', 'Fellbrook Farms', '2000000000138', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 600.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.2, "carbs_g": 0.0, "protein_g": 23.0, "calories_kcal": 110}}', '2026-10-23 16:45:31.889431+00', '2026-10-23 16:45:31.889431+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('c9bd85c8-4d70-4ed9-ad2c-b3170dc45a63', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Smoked Salmon', 'Bluewater', '2000000000145', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 150.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 13.0, "carbs_g": 0.0, "protein_g": 20.0, "calories_kcal": 196}}', '2026-10-23 16:45:31.889432+00', '2026-10-23 16:45:31.889432+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('b21c646e-d74f-45b5-b5eb-35d7000219b9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Mayonnaise', 'Harvest Row', '2000000000152', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 300.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 79.0, "carbs_g": 1.0, "protein_g": 1.0, "calories_kcal": 714}}', '2026-10-23 16:45:31.889433+00', '2026-10-23 16:45:31.889433+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('6b0fb76a-eaca-4ac8-933e-c092a13acd3b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tomato Ketchup', 'Harvest Row', '2000000000169', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.1, "carbs_g": 26.0, "protein_g": 1.0, "calories_kcal": 112}}', '2026-10-23 16:45:31.889434+00', '2026-10-23 16:45:31.889434+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('707d1613-0643-4f34-b3ec-c8229a6a9aa9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Orange Juice NFC', 'Orchard & Oak', '2000000000176', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.7, "calories_kcal": 45}}', '2026-10-23 16:45:31.889435+00', '2026-10-23 16:45:31.889435+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('06b0dc92-58ea-4196-b8ad-a890577403b2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Chocolate Milk Drink', 'Meadowlane', '2000000000183', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.5, "carbs_g": 14.0, "protein_g": 3.2, "calories_kcal": 84}}', '2026-10-23 16:45:31.889436+00', '2026-10-23 16:45:31.889436+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('70677fbe-9b54-4c83-92c1-b6f2aae24c33', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Classic Hummus', 'Green Acre', '2000000000190', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 200.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 14.0, "carbs_g": 14.0, "protein_g": 7.0, "calories_kcal": 215}}', '2026-10-23 16:45:31.889437+00', '2026-10-23 16:45:31.889437+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('80b78db4-7391-49de-923f-11e280e7f056', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Red Pesto', 'Harvest Row', '2000000000206', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 190.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 25.0, "carbs_g": 5.0, "protein_g": 3.0, "calories_kcal": 267}}', '2026-10-23 16:45:31.889438+00', '2026-10-23 16:45:31.889439+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('7affd8cc-a2db-465b-8537-9e4fccbd31ef', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Carrots 1kg', 'Green Acre', '6940306368753', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 10.0, "protein_g": 0.9, "calories_kcal": 41}}', '2026-10-23 16:45:31.889439+00', '2026-10-23 16:45:31.88944+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('569ee175-4452-4e53-b201-9ec148777f95', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Broccoli', 'Green Acre', '8527959940727', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.4, "carbs_g": 7.0, "protein_g": 2.8, "calories_kcal": 34}}', '2026-10-23 16:45:31.88944+00', '2026-10-23 16:45:31.889441+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('becdc6b4-2022-4469-a39f-efc7776485e5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cherry Tomatoes', 'Green Acre', '5063699218206', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 3.9, "protein_g": 0.9, "calories_kcal": 18}}', '2026-10-23 16:45:31.889441+00', '2026-10-23 16:45:31.889442+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ace7d6d7-0007-4dbc-88b0-e9e822594fde', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cucumber', 'Green Acre', '1037508727266', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 300.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.1, "carbs_g": 3.6, "protein_g": 0.7, "calories_kcal": 16}}', '2026-10-23 16:45:31.889442+00', '2026-10-23 16:45:31.889443+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('0c90caa3-cd77-4a17-865c-1a2bd0f87f81', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fuji Apples', 'Green Acre', '8877943494617', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 14.0, "protein_g": 0.3, "calories_kcal": 52}}', '2026-10-23 16:45:31.889443+00', '2026-10-23 16:45:31.889444+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('6de60e67-d0ba-4c9a-8df7-e46ae7e3b03a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Green Grapes', 'Green Acre', '3313189389808', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 18.0, "protein_g": 0.7, "calories_kcal": 69}}', '2026-10-23 16:45:31.889445+00', '2026-10-23 16:45:31.889445+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ce3e8424-8c73-417a-801a-13184a08b88c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Strawberries', 'Green Acre', '2169283524565', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.3, "carbs_g": 7.7, "protein_g": 0.7, "calories_kcal": 32}}', '2026-10-23 16:45:31.889446+00', '2026-10-23 16:45:31.889446+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('3a179dca-a0f0-4430-8957-a0deb04acb7e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Bananas', 'Green Acre', '4303320253157', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.3, "carbs_g": 23.0, "protein_g": 1.1, "calories_kcal": 89}}', '2026-10-23 16:45:31.889447+00', '2026-10-23 16:45:31.889447+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('08e62e7e-af30-4c20-b722-50d62a2bcd99', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Vanilla Ice Cream', 'Northwind Frozen', '2000000000299', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 11.0, "carbs_g": 24.0, "protein_g": 3.5, "calories_kcal": 207}}', '2026-10-23 16:45:31.889448+00', '2026-10-23 16:45:31.889448+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('da5cc8a4-183a-4935-989d-ca863acb9f79', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen Pepperoni Pizza', 'Northwind Frozen', '2000000000305', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 350.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 12.0, "carbs_g": 28.0, "protein_g": 11.0, "calories_kcal": 266}}', '2026-10-23 16:45:31.889449+00', '2026-10-23 16:45:31.889449+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Potato and Cheese Dumplings', 'Northwind Frozen', '2000000000312', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 600.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 7.0, "carbs_g": 28.0, "protein_g": 5.0, "calories_kcal": 196}}', '2026-10-23 16:45:31.88945+00', '2026-10-23 16:45:31.88945+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('f92f2895-0533-428b-97d5-44f7bb166620', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen Mixed Vegetables', 'Northwind Frozen', '2000000000336', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 750.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.5, "carbs_g": 5.0, "protein_g": 2.0, "calories_kcal": 35}}', '2026-10-23 16:45:31.889452+00', '2026-10-23 16:45:31.889452+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('63936837-dd29-4b5c-8954-bedad2ae4ec1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen Green Peas', 'Northwind Frozen', '2000000000343', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 450.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.4, "carbs_g": 14.0, "protein_g": 5.0, "calories_kcal": 81}}', '2026-10-23 16:45:31.889453+00', '2026-10-23 16:45:31.889453+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('65a5b34e-99ce-4a0b-9e97-adcfc2ded0b2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen Chips', 'Northwind Frozen', '2000000000350', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 750.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 5.0, "carbs_g": 24.0, "protein_g": 2.5, "calories_kcal": 152}}', '2026-10-23 16:45:31.889454+00', '2026-10-23 16:45:31.889454+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('8bf7978f-62d3-42b3-8233-6c66c773961e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen Blueberries', 'Northwind Frozen', '2000000000367', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.3, "carbs_g": 14.0, "protein_g": 0.7, "calories_kcal": 57}}', '2026-10-23 16:45:31.889455+00', '2026-10-23 16:45:31.889455+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('6445c742-2b9a-4c27-be83-845a74fbbe23', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Frozen Sour Cherries', 'Northwind Frozen', '2000000000374', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.3, "carbs_g": 12.0, "protein_g": 1.0, "calories_kcal": 50}}', '2026-10-23 16:45:31.889456+00', '2026-10-23 16:45:31.889456+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('1f160de2-c8bd-4710-bd24-618f056b1e05', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Minced Pork', 'Fellbrook Farms', '2000000000381', NULL, '941f5080-e9d1-45ef-a876-04d75d5da6ea', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 19.0, "carbs_g": 0.0, "protein_g": 15.0, "calories_kcal": 242}}', '2026-10-23 16:45:31.889457+00', '2026-10-23 16:45:31.889457+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a757c372-a4a9-4cf8-9733-a7c0ae6274a1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Spaghetti 500g', 'Harvest Row', '2000000000398', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-10-23 16:45:31.889458+00', '2026-10-23 16:45:31.889458+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('1a597cee-ffa7-4c78-9eb2-4ffb172c99e4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Penne Pasta', 'Harvest Row', '2000000000404', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-10-23 16:45:31.889459+00', '2026-10-23 16:45:31.889459+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ba1c8f7c-f92a-41db-a8d4-58421dbd6cda', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fusilli Pasta', 'Harvest Row', '2000000000411', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.5, "carbs_g": 75.0, "protein_g": 13.0, "calories_kcal": 371}}', '2026-10-23 16:45:31.88946+00', '2026-10-23 16:45:31.88946+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('b290e359-2cbe-4ea2-9f8c-260c6f3fdcae', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Jasmine Rice 1kg', 'Harvest Row', '2000000000428', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.5, "carbs_g": 78.0, "protein_g": 7.0, "calories_kcal": 348}}', '2026-10-23 16:45:31.889461+00', '2026-10-23 16:45:31.889461+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('21ef0577-ed29-482d-b4c1-9277b3c964a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Buckwheat Groats', 'Harvest Row', '2000000000435', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 3.0, "carbs_g": 62.0, "protein_g": 12.0, "calories_kcal": 343}}', '2026-10-23 16:45:31.889462+00', '2026-10-23 16:45:31.889462+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('8328b271-9c18-4e10-8194-9fc3b4ab1b9d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Rolled Oats', 'Harvest Row', '2000000000442', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 7.0, "carbs_g": 68.0, "protein_g": 13.0, "calories_kcal": 379}}', '2026-10-23 16:45:31.889463+00', '2026-10-23 16:45:31.889463+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('71748049-0262-4487-8f1b-835262e8adfd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fruit Muesli', 'Harvest Row', '2000000000459', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 9.0, "carbs_g": 67.0, "protein_g": 9.0, "calories_kcal": 398}}', '2026-10-23 16:45:31.889464+00', '2026-10-23 16:45:31.889464+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('17ba6366-fc71-4d8a-ba66-b9e720453234', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Corn Flakes', 'Harvest Row', '2000000000466', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 375.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.0, "carbs_g": 84.0, "protein_g": 6.0, "calories_kcal": 361}}', '2026-10-23 16:45:31.889465+00', '2026-10-23 16:45:31.889465+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Wheat Flour Type 550', 'Harvest Row', '2000000000473', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.0, "carbs_g": 72.0, "protein_g": 10.0, "calories_kcal": 341}}', '2026-10-23 16:45:31.889466+00', '2026-10-23 16:45:31.889466+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('bdc068d6-6a42-495d-a4c3-600a07cec306', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'White Sugar 1kg', 'Harvest Row', '2000000000480', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.0, "carbs_g": 100.0, "protein_g": 0.0, "calories_kcal": 387}}', '2026-10-23 16:45:31.889467+00', '2026-10-23 16:45:31.889467+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('246549c8-6e44-4ca8-892c-3543ab483af3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Iodised Salt', 'Saltmill', '2000000000497', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889468+00', '2026-10-23 16:45:31.889468+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('3ee0b869-3e36-487c-8ee4-f116a84b42bf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Ground Black Pepper', 'Saltmill', '2000000000503', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 40.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889469+00', '2026-10-23 16:45:31.889469+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('4bc73840-44dc-4a70-97b8-f449a586d57e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dried Oregano', 'Saltmill', '2000000000510', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 15.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.88947+00', '2026-10-23 16:45:31.88947+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('7e5233ae-eb17-495d-b280-8556ff16caba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dried Basil', 'Saltmill', '2000000000527', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 10.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889471+00', '2026-10-23 16:45:31.889471+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a1d8635b-fe0a-48fb-970d-672422f8d5e6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Granulated Garlic', 'Saltmill', '2000000000534', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 25.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889472+00', '2026-10-23 16:45:31.889472+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('cf3acca4-5c34-494d-8ed3-00af16098627', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Extra Virgin Olive Oil', 'Harvest Row', '2000000000541', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 750.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-10-23 16:45:31.889473+00', '2026-10-23 16:45:31.889473+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('65119867-1a85-44cf-bbd1-a56124c16d07', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Sunflower Oil', 'Harvest Row', '2000000000558', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 100.0, "carbs_g": 0.0, "protein_g": 0.0, "calories_kcal": 884}}', '2026-10-23 16:45:31.889474+00', '2026-10-23 16:45:31.889475+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('5b2f9e38-61d6-407a-8df2-3739042bbe79', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tomato Passata', 'Harvest Row', '2000000000565', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 700.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 5.5, "protein_g": 1.5, "calories_kcal": 32}}', '2026-10-23 16:45:31.889475+00', '2026-10-23 16:45:31.889476+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('2201036f-39da-4e0e-bb94-c675770c9438', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Peeled Tomatoes 400g', 'Harvest Row', '2000000000572', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.2, "carbs_g": 4.0, "protein_g": 1.2, "calories_kcal": 26}}', '2026-10-23 16:45:31.889476+00', '2026-10-23 16:45:31.889477+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('d5509db6-dcae-4f32-85d0-bc75b0be7423', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Canned Chickpeas', 'Harvest Row', '2000000000589', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 2.6, "carbs_g": 27.0, "protein_g": 9.0, "calories_kcal": 164}}', '2026-10-23 16:45:31.889477+00', '2026-10-23 16:45:31.889478+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('06a30bc2-377e-424f-b860-530326fb3a6d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Canned White Beans', 'Harvest Row', '2000000000596', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.5, "carbs_g": 25.0, "protein_g": 9.0, "calories_kcal": 139}}', '2026-10-23 16:45:31.889478+00', '2026-10-23 16:45:31.889479+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('b26bc4cd-6ed5-4e11-bae1-5413f589b31f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Canned Sweetcorn', 'Harvest Row', '2000000000602', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 340.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 1.5, "carbs_g": 19.0, "protein_g": 3.0, "calories_kcal": 96}}', '2026-10-23 16:45:31.889479+00', '2026-10-23 16:45:31.88948+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('02b8cd00-e818-4a00-b200-7edfa26cc2cb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tuna in Oil', 'Bluewater', '2000000000619', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 160.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 9.0, "carbs_g": 0.0, "protein_g": 26.0, "calories_kcal": 198}}', '2026-10-23 16:45:31.88948+00', '2026-10-23 16:45:31.889481+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('23e939a9-42a2-4e13-a42d-0e6cea0e7acd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Chicken Stock', 'Harvest Row', '2000000000626', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 120.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889481+00', '2026-10-23 16:45:31.889482+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('53fc368d-1441-4065-a54c-434d0c44e6d9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Earl Grey Tea', 'Orchard & Oak', '2000000000633', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 50.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889482+00', '2026-10-23 16:45:31.889483+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('42ab7bc7-d956-47c4-aab7-a7798508841f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Ground Coffee', 'Orchard & Oak', '2000000000640', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 250.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889483+00', '2026-10-23 16:45:31.889484+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('158f1823-7f6c-40da-bd8d-eb16a099d38b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Coffee Beans', 'Orchard & Oak', '2000000000657', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889484+00', '2026-10-23 16:45:31.889484+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('df32418b-e743-46b3-bde9-22b6e5fbd3df', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Peanut Butter', 'Orchard & Oak', '2000000000671', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 250.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 50.0, "carbs_g": 20.0, "protein_g": 25.0, "calories_kcal": 588}}', '2026-10-23 16:45:31.889486+00', '2026-10-23 16:45:31.889486+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('208bddff-8254-4f64-9558-8e6b5ed4e415', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dark Chocolate 85%', 'Orchard & Oak', '2000000000688', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 100.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 44.0, "carbs_g": 39.0, "protein_g": 8.0, "calories_kcal": 598}}', '2026-10-23 16:45:31.889487+00', '2026-10-23 16:45:31.889487+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('aee53ac2-5a8d-4cf2-b8c7-8871db10eb60', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Salted Potato Crisps', 'Orchard & Oak', '2000000000695', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 165.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 35.0, "carbs_g": 53.0, "protein_g": 4.0, "calories_kcal": 536}}', '2026-10-23 16:45:31.889488+00', '2026-10-23 16:45:31.889488+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('f8f82f0a-57a4-468d-a2aa-26313ab858bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Rice Cakes', 'Harvest Row', '2000000000701', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 120.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 2.0, "carbs_g": 82.0, "protein_g": 7.0, "calories_kcal": 387}}', '2026-10-23 16:45:31.889489+00', '2026-10-23 16:45:31.889489+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('57298474-a0b7-4c3a-b9dc-d1f5743251fe', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Butter Biscuits', 'Orchard & Oak', '2000000000718', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 200.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 17.0, "carbs_g": 71.0, "protein_g": 6.0, "calories_kcal": 454}}', '2026-10-23 16:45:31.88949+00', '2026-10-23 16:45:31.88949+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('cc4a417a-a291-477b-ad60-37812ee87741', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Soy Sauce', 'Harvest Row', '2000000000725', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 250.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.0, "carbs_g": 5.0, "protein_g": 8.0, "calories_kcal": 53}}', '2026-10-23 16:45:31.889491+00', '2026-10-23 16:45:31.889491+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a066c20d-6a5e-47d5-aa4e-46c46e6fd11c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tomato Paste', 'Harvest Row', '2000000000732', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 170.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.3, "carbs_g": 9.0, "protein_g": 3.0, "calories_kcal": 55}}', '2026-10-23 16:45:31.889492+00', '2026-10-23 16:45:31.889492+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('647cd982-42cd-4a21-80c4-29f5ce92240c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Potato Starch', 'Harvest Row', '2000000000749', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 500.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.0, "carbs_g": 85.0, "protein_g": 0.5, "calories_kcal": 341}}', '2026-10-23 16:45:31.889493+00', '2026-10-23 16:45:31.889493+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('b111b911-4b42-40cd-aba8-ef08554ee9e0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Baking Powder', 'Harvest Row', '2000000000756', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 50.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889494+00', '2026-10-23 16:45:31.889494+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('76be551f-0706-4072-adc2-0a93e43e6b93', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dry Yeast', 'Harvest Row', '2000000000763', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 14.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889495+00', '2026-10-23 16:45:31.889495+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('44b854b2-5b2d-489d-b878-55e8f7f58507', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Vanilla Sugar', 'Harvest Row', '2000000000770', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 32.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889496+00', '2026-10-23 16:45:31.889496+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a5e72fd0-fa95-4bd7-bc7a-5a14287b0aa6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Ground Cinnamon', 'Saltmill', '2000000000787', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 20.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889497+00', '2026-10-23 16:45:31.889497+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ea1a768a-d6a2-4680-a2e1-1b090bc790bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Sweet Paprika', 'Saltmill', '2000000000794', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 30.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889498+00', '2026-10-23 16:45:31.889498+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('3e4f9159-d879-4b1a-9164-41377be492d9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Curry Powder', 'Saltmill', '2000000000800', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 25.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889499+00', '2026-10-23 16:45:31.889499+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('3cb1142f-c864-4117-bc3a-cd753c0bfb69', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Ground Ginger', 'Saltmill', '2000000000817', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 20.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.8895+00', '2026-10-23 16:45:31.889501+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('91060ddf-774c-4304-8ca4-e47dfa308289', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Wildflower Honey', 'Orchard & Oak', '2000000000824', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 0.0, "carbs_g": 82.0, "protein_g": 0.3, "calories_kcal": 304}}', '2026-10-23 16:45:31.889501+00', '2026-10-23 16:45:31.889502+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ce93ac35-96ce-4ef0-a981-5ae2053c8a1e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Walnuts', 'Green Acre', '2000000000831', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 200.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 65.0, "carbs_g": 14.0, "protein_g": 15.0, "calories_kcal": 654}}', '2026-10-23 16:45:31.889502+00', '2026-10-23 16:45:31.889503+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('0adfeff0-74a2-4996-97d0-682bca96e197', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Almonds', 'Green Acre', '2000000000848', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 200.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 50.0, "carbs_g": 22.0, "protein_g": 21.0, "calories_kcal": 579}}', '2026-10-23 16:45:31.889503+00', '2026-10-23 16:45:31.889504+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('f612f610-95b6-4dab-9644-c2594d96430f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Instant Tomato Soup', 'Harvest Row', '2000000000855', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 85.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, 'null', '2026-10-23 16:45:31.889504+00', '2026-10-23 16:45:31.889505+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('93156300-273c-4504-9d73-82c9cba20044', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cocoa Powder', 'Orchard & Oak', '2000000000862', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 100.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"nutrition": {"fat_g": 15.0, "carbs_g": 36.0, "protein_g": 24.0, "calories_kcal": 348}}', '2026-10-23 16:45:31.889505+00', '2026-10-23 16:45:31.889506+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('8122a117-1950-4e6b-8afd-f1462766e3fc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dell Latitude 5540', 'Dell', '5397184123456', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel i5-1345U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-10-23 16:45:31.908626+00', '2026-10-23 16:45:31.90863+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ThinkPad T14s Gen 4', 'Lenovo', '0196881123456', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "AMD Ryzen 7 PRO", "ram": "32GB", "storage": "1TB SSD"}}', '2026-10-23 16:45:31.908632+00', '2026-10-23 16:45:31.908632+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ded630c1-2384-4eda-b549-77304d5b061f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'MacBook Pro 14 M3', 'Apple', '0194252123456', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Apple M3 Pro", "ram": "18GB", "storage": "512GB SSD"}}', '2026-10-23 16:45:31.908633+00', '2026-10-23 16:45:31.908633+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('11a51a5e-082b-4e76-900c-12421b9fca6d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'HP EliteBook 840 G10', 'HP', '0196882123456', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel i7-1365U", "ram": "16GB", "storage": "512GB SSD"}}', '2026-10-23 16:45:31.908634+00', '2026-10-23 16:45:31.908634+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a139a2dd-a867-4b3f-b7fa-b290acdb5262', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dell OptiPlex 7010', 'Dell', '5397184234567', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel i5-13500", "ram": "16GB", "storage": "512GB SSD"}}', '2026-10-23 16:45:31.908635+00', '2026-10-23 16:45:31.908635+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ace5920e-c8d3-43bd-94b7-3b832bc1e18a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'HP ProDesk 400 G9', 'HP', '0196883234567', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel i5-12500", "ram": "8GB", "storage": "256GB SSD"}}', '2026-10-23 16:45:31.908636+00', '2026-10-23 16:45:31.908636+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('94d90f8e-ee00-4048-b247-70596dfe32ec', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Lenovo ThinkCentre M90q', 'Lenovo', '0196884234567', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel i7-13700", "ram": "16GB", "storage": "1TB SSD"}}', '2026-10-23 16:45:31.908637+00', '2026-10-23 16:45:31.908638+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('91ffd7bf-4033-4656-aa36-f1034b7c0141', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dell UltraSharp U2723QE', 'Dell', '5397184345678', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-10-23 16:45:31.908638+00', '2026-10-23 16:45:31.908639+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('113aa38b-98d4-44a1-be3e-0f16882f1456', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'LG 27UK850-W', 'LG', '8806097345678', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"size": "27\"", "panel": "IPS", "resolution": "3840x2160"}}', '2026-10-23 16:45:31.908639+00', '2026-10-23 16:45:31.90864+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('5f510017-5366-4204-afc9-f2e6282c6261', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Samsung Odyssey G5', 'Samsung', '8806098345678', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"size": "32\"", "panel": "VA", "resolution": "2560x1440"}}', '2026-10-23 16:45:31.90864+00', '2026-10-23 16:45:31.908641+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('2d29fe1c-bfb6-48b5-9faf-4f909223cb09', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'iPhone 15 Pro', 'Apple', '0194253456789', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"color": "Natural Titanium", "storage": "256GB"}}', '2026-10-23 16:45:31.908642+00', '2026-10-23 16:45:31.908642+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('9d3aaf76-139c-42fd-a110-dd326335cd7f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Samsung Galaxy S24', 'Samsung', '8806099456789', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"color": "Phantom Black", "storage": "128GB"}}', '2026-10-23 16:45:31.908643+00', '2026-10-23 16:45:31.908644+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('acd839b8-ec68-4f09-b952-9bcb7da27b46', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'iPad Air M2', 'Apple', '0194254456789', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"color": "Space Gray", "storage": "128GB"}}', '2026-10-23 16:45:31.908644+00', '2026-10-23 16:45:31.908645+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('795801f3-98f0-40c7-8654-15134aaa9097', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cisco Catalyst 9200L', 'Cisco', '0882658567890', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"ports": "24x 1GbE", "management": "DNA Center"}}', '2026-10-23 16:45:31.908646+00', '2026-10-23 16:45:31.908646+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('2de1ab9e-40cd-4938-ae62-72aedc7c9c69', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Ubiquiti UniFi USW-Pro-48', 'Ubiquiti', '8100014567890', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"ports": "48x 1GbE + 4x 10GbE"}}', '2026-10-23 16:45:31.908647+00', '2026-10-23 16:45:31.908647+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('9a457f48-ab83-4c41-9d59-77286f59c20d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'TP-Link TL-SG3428', 'TP-Link', '6935364567890', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"ports": "24x 1GbE + 4x SFP"}}', '2026-10-23 16:45:31.908648+00', '2026-10-23 16:45:31.908648+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('cce012c7-dc22-43f4-94ca-1510c4305d92', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cisco Meraki MR46', 'Cisco', '0882659567890', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"speed": "AX5400", "standard": "Wi-Fi 6"}}', '2026-10-23 16:45:31.908649+00', '2026-10-23 16:45:31.90865+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('8e4a5228-a241-4e74-9a87-04fcf582a329', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Logitech MX Keys S', 'Logitech', '0978551678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"type": "Mechanical", "layout": "US"}}', '2026-10-23 16:45:31.90865+00', '2026-10-23 16:45:31.908651+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('82d76422-6692-4b34-8c43-28faecac65b2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Logitech MX Master 3S', 'Logitech', '0978552678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"dpi": 8000, "buttons": 7}}', '2026-10-23 16:45:31.908651+00', '2026-10-23 16:45:31.908652+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Logitech C920 HD Pro', 'Logitech', '0978553678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"fps": 30, "resolution": "1080p"}}', '2026-10-23 16:45:31.908653+00', '2026-10-23 16:45:31.908653+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Jabra Evolve2 65', 'Jabra', '5707054678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"type": "Headset", "connection": "Bluetooth"}}', '2026-10-23 16:45:31.908654+00', '2026-10-23 16:45:31.908654+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('4fe1ef8f-389b-478e-a8cd-420ccbeeb010', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Dell PowerEdge R750', 'Dell', '5397185678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel Xeon Silver 4314", "ram": "64GB", "storage": "2x 480GB SSD"}}', '2026-10-23 16:45:31.908655+00', '2026-10-23 16:45:31.908655+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('10deef65-5690-4f50-9510-cfa4ff2d502c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'HPE ProLiant DL380 Gen10', 'HPE', '8881825678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel Xeon Gold 5318Y", "ram": "128GB", "storage": "4x 960GB SSD"}}', '2026-10-23 16:45:31.908656+00', '2026-10-23 16:45:31.908656+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a84ce6f6-41ac-4148-a90a-22d5a9af2895', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Supermicro SYS-1029U', 'Supermicro', '1234565678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"cpu": "Intel Xeon Silver 4214", "ram": "96GB", "storage": "2x 1TB SSD"}}', '2026-10-23 16:45:31.908657+00', '2026-10-23 16:45:31.908658+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('d004ef0b-2410-4a4c-8068-b685e38a1570', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'APC Smart-UPS 3000VA', 'APC', '0731303678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"runtime": "~15min at full load", "capacity": "3000VA/2700W"}}', '2026-10-23 16:45:31.908658+00', '2026-10-23 16:45:31.908659+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('dd14c900-66d6-4099-8d85-1175319e8b7b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Rack 42U Open Frame', 'Rittal', '4017304678901', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"equipment": {"size": "42U", "width": "19 inch"}}', '2026-10-23 16:45:31.908659+00', '2026-10-23 16:45:31.90866+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('f1beac56-0318-4b69-a037-8ee13b25ee76', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Plum Butter', 'Hollow Lane Orchard', '2000000009018', 'PLB-001', '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"maker_demo": true}', '2026-10-23 16:45:31.923515+00', '2026-10-23 16:45:31.923519+00', 'FIFO');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('ce2b02d1-16d5-4464-ab65-69c7633f3797', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Damson Plums', 'Green Acre', '2000000009025', 'PLM-001', '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"maker_demo": true}', '2026-10-23 16:45:31.92352+00', '2026-10-23 16:45:31.92352+00', 'FIFO');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('0ab48b73-76fb-4c25-aba6-265cd6b253f9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'White Sugar', 'Harvest Row', '2000000009032', 'SUG-001', '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"maker_demo": true}', '2026-10-23 16:45:31.923521+00', '2026-10-23 16:45:31.923521+00', 'FIFO');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('543f25e9-9572-4b44-a548-fc2878ca5324', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Cassia Cinnamon', 'Saltmill', '2000000009049', 'CIN-001', '941f5080-e9d1-45ef-a876-04d75d5da6ea', 1000.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 0, '{"maker_demo": true}', '2026-10-23 16:45:31.923522+00', '2026-10-23 16:45:31.923522+00', 'FIFO');
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('0916de9c-f9f8-409c-96ef-6d7e08837fa8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Eggs Medium 10pk', 'Fellbrook Farms', '2000000000084', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 600.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 1, '{"nutrition": {"fat_g": 11.0, "carbs_g": 1.1, "protein_g": 13.0, "calories_kcal": 155}}', '2026-10-23 16:45:31.889425+00', '2026-10-23 16:45:32.111248+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('a7fca96a-563b-47f4-a449-292eca81f87b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Strawberry Jam', 'Orchard & Oak', '2000000000664', NULL, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 350.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 8, '{"nutrition": {"fat_g": 0.1, "carbs_g": 65.0, "protein_g": 0.5, "calories_kcal": 264}}', '2026-10-23 16:45:31.889485+00', '2026-10-23 16:45:32.111253+00', NULL);
INSERT INTO public.product_templates (id, organization_id, name, brand, barcode, sku, uom_id, weight_value, weight_uom_id, volume_value, volume_uom_id, image_url, description, min_quantity, meta_data, created_at, updated_at, removal_strategy) VALUES ('c0e9f75c-42fb-4d2e-82a3-562304bf0d7f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fish Fingers', 'Bluewater', '2000000000329', NULL, '21f0f763-a223-4344-bc0f-a0069453da54', 400.000000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, NULL, NULL, 7, '{"nutrition": {"fat_g": 10.0, "carbs_g": 22.0, "protein_g": 10.0, "calories_kcal": 215}}', '2026-10-23 16:45:31.889451+00', '2026-10-23 16:45:32.111254+00', NULL);


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('38d75b5a-8203-4ed3-9f3a-32752cfb8289', '3203b634-da10-43ba-aab9-7589e8078d20', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'Dell Latitude 5540', 4.000, 0.000, 4200.00, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 23.00, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('288e23b0-3759-4c4c-94f0-657d332bb055', 'a48fd68f-79ee-484a-bf35-a5382610a961', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'Dell Latitude 5540', 6.000, 0.000, 4200.00, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 23.00, 1, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('8b5f0158-b997-4823-8821-4484ffcb7548', 'a48fd68f-79ee-484a-bf35-a5382610a961', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'ThinkPad T14s Gen 4', 2.000, 0.000, 5800.00, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 23.00, 2, NULL, NULL);
INSERT INTO public.purchase_order_lines (id, purchase_order_id, product_template_id, name, quantity_ordered, quantity_received, unit_price, uom_id, tax_rate, line_number, notes, source_reorder_rule_id) VALUES ('372b231b-744a-4629-972d-69ccb69edddc', '2ddf5148-f0e0-483a-a8f1-2bb8e1ffc670', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'ThinkPad T14s Gen 4', 5.000, 3.000, 5800.00, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', 23.00, 1, NULL, NULL);


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('2ddf5148-f0e0-483a-a8f1-2bb8e1ffc670', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'PO/2026/003', 'CONFIRMED', 'c4543079-ea11-423e-a7d0-d07738f39388', '2026-10-10', 'Partly delivered; the rest is on back order with the supplier.', 'USD', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-03 16:45:35.714711+00', NULL, NULL, '2026-10-03 16:45:35.714711+00', '2026-10-23 16:45:36.374956+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('3203b634-da10-43ba-aab9-7589e8078d20', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'PO/2026/001', 'PENDING_APPROVAL', 'd1396ba4-ac3e-48da-a1c7-185dfdd5605c', '2026-10-27', 'Laptops for the two November starters and two for the loan pool.', 'USD', '1ea5bd84-066b-4ed1-91a9-eac1e17aef28', NULL, NULL, NULL, NULL, '2026-10-20 16:45:35.714711+00', '2026-10-23 16:45:36.858331+00');
INSERT INTO public.purchase_orders (id, organization_id, number, status, partner_id, scheduled_date, notes, currency, created_by, confirmed_by, confirmed_at, cancelled_by, cancelled_at, created_at, updated_at) VALUES ('a48fd68f-79ee-484a-bf35-a5382610a961', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'PO/2026/002', 'CONFIRMED', 'd1396ba4-ac3e-48da-a1c7-185dfdd5605c', '2026-10-20', 'Quarterly refresh of the support desk.', 'USD', '1ea5bd84-066b-4ed1-91a9-eac1e17aef28', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-14 00:45:35.714711+00', NULL, NULL, '2026-10-13 16:45:35.714711+00', '2026-10-23 16:45:36.859124+00');


--
-- Data for Name: putaway_capacity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_location_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: putaway_rule_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('511fdc8a-b7df-41a3-8167-b62063a27eac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f2a102d0-212f-4464-8dc4-57b3a4586cdb', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('d9b33db4-acc1-461f-b555-0a871bb4b92f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f2a102d0-212f-4464-8dc4-57b3a4586cdb', '3ec3439d-33dd-4485-b8dd-496290b68ae8', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('34f26f17-2155-42cb-9aee-332a116028b4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5aeb44f5-7fd5-4e24-b861-5b661af10f6d', 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('7a729f11-5a29-494f-8d0a-eb5d40322ff2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5aeb44f5-7fd5-4e24-b861-5b661af10f6d', 'ee91a55d-d24f-4b98-842d-6b93e3b5781c', 1);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('7d318374-6044-42ce-901c-aea1d9c38bd6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5739594e-4b4a-49a1-8786-ed509553f668', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 0);
INSERT INTO public.putaway_rule_locations (id, organization_id, rule_id, location_id, "position") VALUES ('7a31d9a3-a76d-4545-87a9-6a0614043bd9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5739594e-4b4a-49a1-8786-ed509553f668', '3ec3439d-33dd-4485-b8dd-496290b68ae8', 1);


--
-- Data for Name: putaway_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('f2a102d0-212f-4464-8dc4-57b3a4586cdb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '1fdd0a5e-1353-487c-9625-ab52fbbcf496', NULL, NULL, 50, true, '2026-10-23 16:45:36.307993+00', '2026-10-23 16:45:36.307993+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('5aeb44f5-7fd5-4e24-b861-5b661af10f6d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, 'd357abce-8e8b-4ab9-82aa-90312cb23f40', NULL, NULL, 50, true, '2026-10-23 16:45:36.307993+00', '2026-10-23 16:45:36.307993+00');
INSERT INTO public.putaway_rules (id, organization_id, product_template_id, category_id, context_tag, storage_type_code, priority, is_active, created_at, updated_at) VALUES ('5739594e-4b4a-49a1-8786-ed509553f668', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', NULL, NULL, NULL, 10, true, '2026-10-23 16:45:36.307993+00', '2026-10-23 16:45:36.307993+00');


--
-- Data for Name: recipe_collection_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('47d5ae18-d9fc-4eeb-8e7d-ecad901ec356', 'f658c6e6-2470-452f-86f8-21c01540c417', 'd5509db6-dcae-4f32-85d0-bc75b0be7423', 'Canned Chickpeas', NULL, NULL, 2.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('25afbd11-df16-4080-b762-79be8120897e', 'f658c6e6-2470-452f-86f8-21c01540c417', '5b2f9e38-61d6-407a-8df2-3739042bbe79', 'Tomato Passata', NULL, NULL, 500.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('85ca4045-7992-410b-8c7c-efb3de25a081', 'f658c6e6-2470-452f-86f8-21c01540c417', 'cf3acca4-5c34-494d-8ed3-00af16098627', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1c954260-ead9-49b4-8548-3f8ad7f9fff1', 'f658c6e6-2470-452f-86f8-21c01540c417', 'ea1a768a-d6a2-4680-a2e1-1b090bc790bd', 'Sweet Paprika', NULL, NULL, 3.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('c4beb054-ea80-4a55-abff-182893010ba7', '57caefe2-f9e2-400c-9c26-4145c42926dd', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 'Spaghetti 500g', NULL, NULL, 200.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('2708adde-ace9-4aad-a02e-644b16119851', '57caefe2-f9e2-400c-9c26-4145c42926dd', 'cf3acca4-5c34-494d-8ed3-00af16098627', 'Extra Virgin Olive Oil', NULL, NULL, 40.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('fbc64fe1-ef37-4596-9e88-585bbf99776a', '57caefe2-f9e2-400c-9c26-4145c42926dd', 'a1d8635b-fe0a-48fb-970d-672422f8d5e6', 'Granulated Garlic', NULL, NULL, 3.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('daa98b3d-591d-4de1-ad19-82678731665b', '57caefe2-f9e2-400c-9c26-4145c42926dd', '246549c8-6e44-4ca8-892c-3543ab483af3', 'Iodised Salt', NULL, NULL, 10.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('77f16892-26ce-481f-9fc4-2e2e28d38647', '62f2244d-e4b1-4ea6-ac32-bdd75a641678', '6aa02172-c358-453d-91c0-856ff4792509', 'Chicken Breast Fillet', NULL, NULL, 600.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('ad3f0c7b-43f8-4cb0-b453-ab8721243d72', '62f2244d-e4b1-4ea6-ac32-bdd75a641678', 'b290e359-2cbe-4ea2-9f8c-260c6f3fdcae', 'Jasmine Rice 1kg', NULL, NULL, 300.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('009dd4ca-35f0-4c7b-aaae-32d863d2ea2d', '62f2244d-e4b1-4ea6-ac32-bdd75a641678', '3e4f9159-d879-4b1a-9164-41377be492d9', 'Curry Powder', NULL, NULL, 10.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('637d604b-307f-4d15-b755-85288d899dbd', '62f2244d-e4b1-4ea6-ac32-bdd75a641678', '2201036f-39da-4e0e-bb94-c675770c9438', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bf11523c-09f8-4da0-8786-88b558207fff', '62f2244d-e4b1-4ea6-ac32-bdd75a641678', NULL, 'Coconut Milk', NULL, NULL, 400.000, '27a06e30-48a3-462e-b842-3291e7b1a8d0', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('23ac5871-db0d-4eb5-88cc-5cdd084c294b', '155a62b6-4c52-41e9-98ef-82cfa1212489', '1a597cee-ffa7-4c78-9eb2-4ffb172c99e4', 'Penne Pasta', NULL, NULL, 200.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('aa6d8c53-c845-4a65-9e85-e261511dd1f0', '155a62b6-4c52-41e9-98ef-82cfa1212489', '80b78db4-7391-49de-923f-11e280e7f056', 'Red Pesto', NULL, NULL, 90.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('50a10b39-0692-4f6c-b710-c7fd52729b05', '155a62b6-4c52-41e9-98ef-82cfa1212489', 'becdc6b4-2022-4469-a39f-efc7776485e5', 'Cherry Tomatoes', NULL, NULL, 250.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('5d0a2d3b-08be-413a-ac10-e403310845bd', '155a62b6-4c52-41e9-98ef-82cfa1212489', NULL, 'Parmesan', NULL, NULL, 40.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0b9319a8-5d97-4207-a3ea-b91c5974d970', '6547fce5-3807-4dc2-a059-ae2da2c93c08', '8328b271-9c18-4e10-8194-9fc3b4ab1b9d', 'Rolled Oats', NULL, NULL, 100.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a0b5075f-f881-4357-ba66-3fb39aae0193', '6547fce5-3807-4dc2-a059-ae2da2c93c08', 'd4d375c2-948d-482d-ae68-02e446edfa8f', 'Natural Yoghurt 400g', NULL, NULL, 300.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('07304245-aa1a-474d-a8cf-3070c561072e', '6547fce5-3807-4dc2-a059-ae2da2c93c08', '8bf7978f-62d3-42b3-8233-6c66c773961e', 'Frozen Blueberries', NULL, NULL, 120.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a70b18da-1426-48c7-961a-0fff90c7dbd3', '6547fce5-3807-4dc2-a059-ae2da2c93c08', '91060ddf-774c-4304-8ca4-e47dfa308289', 'Wildflower Honey', NULL, NULL, 20.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f72d0480-65e3-4360-ae23-dad21153b0e4', '464bee53-96de-4ac5-bd5d-8689cb77ab97', '3a179dca-a0f0-4430-8957-a0deb04acb7e', 'Bananas', NULL, NULL, 500.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('911ff4b1-a991-408a-81bf-b6084553588d', '464bee53-96de-4ac5-bd5d-8689cb77ab97', 'f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', 'Wheat Flour Type 550', NULL, NULL, 250.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('88085d70-db6d-4912-add0-9c9287e90d8a', '464bee53-96de-4ac5-bd5d-8689cb77ab97', 'bdc068d6-6a42-495d-a4c3-600a07cec306', 'White Sugar 1kg', NULL, NULL, 150.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('2d7df7cb-f9cf-4824-8829-02e459809ec1', '464bee53-96de-4ac5-bd5d-8689cb77ab97', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', 'Eggs Medium 10pk', NULL, NULL, 1.000, '21f0f763-a223-4344-bc0f-a0069453da54', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('577fb724-d2a8-4b2a-8599-18721bda79cd', '464bee53-96de-4ac5-bd5d-8689cb77ab97', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'Butter Extra 82%', NULL, NULL, 100.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f35cc0fe-3a0f-4044-b701-0c9185795e6d', '464bee53-96de-4ac5-bd5d-8689cb77ab97', 'b111b911-4b42-40cd-aba8-ef08554ee9e0', 'Baking Powder', NULL, NULL, 8.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('405f2e62-b374-4e5d-a670-71b19a471887', '464bee53-96de-4ac5-bd5d-8689cb77ab97', 'ce93ac35-96ce-4ef0-a981-5ae2053c8a1e', 'Walnuts', NULL, NULL, 100.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 6, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('898d3860-96e6-4cff-aeb4-9ab9599770cb', '1af03414-66b6-4753-ae0f-398345c5de05', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', 'Eggs Medium 10pk', NULL, NULL, 1.000, '21f0f763-a223-4344-bc0f-a0069453da54', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('33b8da5a-aa5e-4cc4-8bcc-de324bdee140', '1af03414-66b6-4753-ae0f-398345c5de05', '2201036f-39da-4e0e-bb94-c675770c9438', 'Peeled Tomatoes 400g', NULL, NULL, 1.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('62c9f2c6-3260-4cd2-978a-6d8e85cbac35', '1af03414-66b6-4753-ae0f-398345c5de05', 'ea1a768a-d6a2-4680-a2e1-1b090bc790bd', 'Sweet Paprika', NULL, NULL, 3.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('161e449c-1b59-4eff-aaf9-332d41ad2c5d', '1af03414-66b6-4753-ae0f-398345c5de05', 'cf3acca4-5c34-494d-8ed3-00af16098627', 'Extra Virgin Olive Oil', NULL, NULL, 25.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('5cbf72db-ca37-4f94-8843-f469d43ca3d6', '1af03414-66b6-4753-ae0f-398345c5de05', NULL, 'Onion', NULL, NULL, 1.000, NULL, NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('6e016eb2-6229-4684-aebd-df4ce5eb9fd7', 'bc56699e-b8eb-4386-90cd-030cbb81e9cd', 'f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', 'Wheat Flour Type 550', NULL, NULL, 250.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('304abd56-5869-44e2-9b1e-25c127cd8e6d', 'bc56699e-b8eb-4386-90cd-030cbb81e9cd', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 'UHT Milk 3.2%', NULL, NULL, 500.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('bbfd3c6f-8bcb-4f9b-8fe6-91a729620311', 'bc56699e-b8eb-4386-90cd-030cbb81e9cd', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', 'Eggs Medium 10pk', NULL, NULL, 1.000, '21f0f763-a223-4344-bc0f-a0069453da54', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a16e9003-7bac-4efa-b052-617d143e7492', 'bc56699e-b8eb-4386-90cd-030cbb81e9cd', 'ce3e8424-8c73-417a-801a-13184a08b88c', 'Strawberries', NULL, NULL, 300.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('81e6ab79-9af0-4014-a381-99e53ae899af', 'bc56699e-b8eb-4386-90cd-030cbb81e9cd', '65119867-1a85-44cf-bbd1-a56124c16d07', 'Sunflower Oil', NULL, NULL, 25.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('0e20aef8-cc07-49d3-930d-dd85a5592b7b', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', 'ba1c8f7c-f92a-41db-a8d4-58421dbd6cda', 'Fusilli Pasta', NULL, NULL, 300.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 0, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('51de0720-cc84-450e-9840-c996afd2641c', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', '02b8cd00-e818-4a00-b200-7edfa26cc2cb', 'Tuna in Oil', NULL, NULL, 1.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, 1, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('f83a5b3c-3c48-4727-8c66-a05486593515', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', 'b26bc4cd-6ed5-4e11-bae1-5413f589b31f', 'Canned Sweetcorn', NULL, NULL, 1.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, 2, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('1d1ea497-1c70-4420-ae22-5b1d874a6db9', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', 'b21c646e-d74f-45b5-b5eb-35d7000219b9', 'Mayonnaise', NULL, NULL, 75.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 3, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('b38266ae-c402-4aab-86bb-c9bc61346462', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', 'ace7d6d7-0007-4dbc-88b0-e9e822594fde', 'Cucumber', NULL, NULL, 1.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, 4, NULL, NULL, NULL, NULL, '[]', false);
INSERT INTO public.recipe_ingredients (id, recipe_id, template_id, name, display_text, ingredient_group_name, quantity, uom_id, original_quantity, original_unit_text, is_optional, picking_skip, sort_order, calories_kcal_per_100g, price, price_uom_id, price_currency, allergens, is_spice) VALUES ('a2ae02d0-f564-4615-abc6-3005543a62b7', '3afaf813-9b00-4b94-ab0a-1a653414b1b3', NULL, 'Fresh Basil', NULL, NULL, 10.000, 'bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, NULL, false, NULL, 5, NULL, NULL, NULL, NULL, '[]', false);


--
-- Data for Name: recipe_tag_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('155a62b6-4c52-41e9-98ef-82cfa1212489', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Penne with Red Pesto', 'Fifteen minutes, one pan, no chopping board.', '1. Cook the penne.
2. Halve the tomatoes and warm them in the pesto.
3. Toss with the pasta and finish with grated parmesan.', 2, 15, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/155a62b6-4c52-41e9-98ef-82cfa1212489/cover.jpg', NULL, '["quick", "pasta", "vegetarian"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.203248+00', '2026-10-23 16:45:37.262098+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('1af03414-66b6-4753-ae0f-398345c5de05', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Shakshuka', 'Eggs poached in a spiced tomato sauce, straight from the pan.', '1. Soften the sliced onion in the oil with the paprika.
2. Add the tomatoes and simmer until thick.
3. Make four wells, crack in the eggs, cover and cook until set.', 2, 25, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/1af03414-66b6-4753-ae0f-398345c5de05/cover.jpg', NULL, '["breakfast", "vegetarian"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.211354+00', '2026-10-23 16:45:37.262103+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('3afaf813-9b00-4b94-ab0a-1a653414b1b3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tuna Pasta Salad', 'A lunchbox that keeps until Wednesday.', '1. Cook the fusilli and cool it under running water.
2. Mix with the tuna, sweetcorn, diced cucumber and mayonnaise.
3. Tear the basil over the top before serving.', 3, 20, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/3afaf813-9b00-4b94-ab0a-1a653414b1b3/cover.jpg', NULL, '["quick", "pasta"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.215584+00', '2026-10-23 16:45:37.262104+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('464bee53-96de-4ac5-bd5d-8689cb77ab97', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Banana Bread', 'What the bananas going brown on the counter are for.', '1. Mash the bananas and beat in the melted butter, sugar and eggs.
2. Fold in the flour, baking powder and chopped walnuts.
3. Bake in a lined loaf tin at 175 C for about an hour.', 8, 70, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/464bee53-96de-4ac5-bd5d-8689cb77ab97/cover.jpg', NULL, '["baking"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.208957+00', '2026-10-23 16:45:37.262104+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('57caefe2-f9e2-400c-9c26-4145c42926dd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Spaghetti with Garlic and Oil', 'The five-ingredient supper worth knowing by heart.', '1. Cook the spaghetti in well-salted water.
2. Warm the oil gently with the garlic; do not let it brown.
3. Toss the drained pasta in the oil with a splash of cooking water.', 2, 20, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/57caefe2-f9e2-400c-9c26-4145c42926dd/cover.jpg', NULL, '["quick", "pasta"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.195418+00', '2026-10-23 16:45:37.262105+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('62f2244d-e4b1-4ea6-ac32-bdd75a641678', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Chicken Curry with Jasmine Rice', 'A weeknight curry from the freezer and the spice drawer.', '1. Brown the diced chicken, then stir in the curry powder.
2. Add the tomatoes and coconut milk; simmer for twenty minutes.
3. Serve over the rice.', 4, 40, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/62f2244d-e4b1-4ea6-ac32-bdd75a641678/cover.jpg', NULL, '["dinner"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.201065+00', '2026-10-23 16:45:37.262105+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('6547fce5-3807-4dc2-a059-ae2da2c93c08', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Overnight Oats with Blueberries', 'Made the evening before, eaten on the way out.', '1. Stir the oats into the yoghurt with a spoon of honey.
2. Fold in the blueberries straight from the freezer.
3. Cover and leave in the fridge overnight.', 2, 10, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/6547fce5-3807-4dc2-a059-ae2da2c93c08/cover.jpg', NULL, '["breakfast", "vegetarian"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.205678+00', '2026-10-23 16:45:37.262106+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('bc56699e-b8eb-4386-90cd-030cbb81e9cd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Pancakes with Strawberries', 'Saturday breakfast, twelve thin pancakes.', '1. Whisk the flour, milk and eggs into a thin batter; rest it ten minutes.
2. Fry in a lightly oiled pan, a ladle at a time.
3. Serve with sliced strawberries.', 4, 30, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/bc56699e-b8eb-4386-90cd-030cbb81e9cd/cover.jpg', NULL, '["breakfast"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.213669+00', '2026-10-23 16:45:37.262106+00');
INSERT INTO public.recipes (id, organization_id, name, description, instructions, servings, prep_time_minutes, image_url, source_url, tags, is_favorite, created_by, created_at, updated_at) VALUES ('f658c6e6-2470-452f-86f8-21c01540c417', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tomato and Chickpea Stew', 'One pot, thirty minutes, everything from the pantry shelf.', '1. Warm the oil and toast the paprika for thirty seconds.
2. Add the passata and the drained chickpeas.
3. Simmer for twenty minutes, season and serve with bread.', 4, 30, '6c5ab9ac-47df-44ca-834d-cca2115b65fe/recipes/f658c6e6-2470-452f-86f8-21c01540c417/cover.jpg', NULL, '["quick", "vegetarian"]', false, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.192086+00', '2026-10-23 16:45:37.262107+00');


--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_exclusions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shopping_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('0f61536d-8ce4-4081-b1b1-fedc8097b577', '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, NULL, 'Coconut Milk', 1.000, NULL, 'For the curry on Wednesday', NULL, false, NULL, NULL, 'manual', 0, '2026-10-23 16:45:36.242541+00', '2026-10-23 16:45:36.242546+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('0c47277c-e79b-4aff-80ea-05de4a5586b7', '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, NULL, 'Parmesan', 1.000, NULL, 'For the penne on Friday', NULL, false, NULL, NULL, 'manual', 0, '2026-10-23 16:45:36.242548+00', '2026-10-23 16:45:36.242548+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('9057c040-152b-40e1-815b-6a3532283894', '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, NULL, 'Onion', 3.000, NULL, 'Shakshuka on Saturday', NULL, false, NULL, NULL, 'manual', 0, '2026-10-23 16:45:36.242549+00', '2026-10-23 16:45:36.24255+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('73ed1303-09e8-4a53-b987-4771e625628a', '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, NULL, 'Fresh Basil', 1.000, NULL, 'Tuna pasta salad', NULL, false, NULL, NULL, 'manual', 0, '2026-10-23 16:45:36.242551+00', '2026-10-23 16:45:36.242551+00', NULL, NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('7d0270fa-6393-4726-b216-056b4337a9a6', '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, NULL, 'UHT Milk 3.2%', 2.000, 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-10-23 16:45:36.242552+00', '2026-10-23 16:45:36.242553+00', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', NULL);
INSERT INTO public.shopping_list_items (id, shopping_list_id, item_id, category_id, name, quantity, uom_id, notes, estimated_price, is_purchased, purchased_at, purchased_by, source, priority, created_at, updated_at, template_id, note_data) VALUES ('cee0e24a-95bd-4489-a974-bae0c063dda1', '3bc608c8-d0cb-41e1-8bef-91d45bc22410', NULL, NULL, 'Bananas', 1.000, '941f5080-e9d1-45ef-a876-04d75d5da6ea', NULL, NULL, false, NULL, NULL, 'manual', 0, '2026-10-23 16:45:36.242553+00', '2026-10-23 16:45:36.242554+00', '3a179dca-a0f0-4430-8957-a0deb04acb7e', NULL);


--
-- Data for Name: shopping_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.shopping_lists (id, organization_id, name, status, completed_at, archived_at, created_by, created_at, updated_at) VALUES ('3bc608c8-d0cb-41e1-8bef-91d45bc22410', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Weekly shop', 'active', NULL, NULL, '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.234389+00', '2026-10-23 16:45:36.234394+00');


--
-- Data for Name: stock_anchors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2fda08b2-3ad3-4752-a11d-e1a63c662a01', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cc4a417a-a291-477b-ad60-37812ee87741', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f86c1f3a-4913-484c-b90d-af8306e9351e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0c90caa3-cd77-4a17-865c-1a2bd0f87f81', '0af2e08b-ef48-4f5a-8393-d6156d77ca60', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0b9acb3f-6f67-43cc-8bbb-32ec34f7c6e1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', '5c455d0d-c913-45f9-84e4-3bbc34914845', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a0097343-aa46-4906-bb54-6bc58ae25cf5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '23e939a9-42a2-4e13-a42d-0e6cea0e7acd', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ba8c45af-5501-40a5-a265-eac22e0e2f5b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('56058dfa-c911-4e78-a083-aa6c76aed97c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7fca96a-563b-47f4-a449-292eca81f87b', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b896fffc-8b64-4276-9ffa-7d462e6fbe2b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a1d8635b-fe0a-48fb-970d-672422f8d5e6', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c55ba26e-fc1a-4b9f-abd1-e4a7498ee9ae', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c0e9f75c-42fb-4d2e-82a3-562304bf0d7f', 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0b464001-4876-433d-ab37-d335a6a745ef', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('df3a8e18-718d-4090-bae7-7731955d4c07', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9396df62-7893-4e6c-a46a-3278c0805688', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('12d000ba-734f-4750-8cd9-9dde73906c81', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('bcc65731-6d16-4db8-96f5-448c66e4f135', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4bc73840-44dc-4a70-97b8-f449a586d57e', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7d01d4b7-a978-4a0b-9633-fe1384ef907e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fba351e3-12bd-442e-8414-53b8ebc657e3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2201036f-39da-4e0e-bb94-c675770c9438', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d76b6fbc-ad98-46d7-95e6-36e3ebb1bbe8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '707d1613-0643-4f34-b3ec-c8229a6a9aa9', '6588e3ed-0fc3-4ec0-be21-07fda324cb6e', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('433b0d0f-b7e9-4d79-b8e1-ffb8cbb5a1cf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', '38323184-273f-4032-8597-d48a45db1650', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b2f276ba-55d8-4221-a919-9dc5a5193e96', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f612f610-95b6-4dab-9644-c2594d96430f', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fc7fb8da-6256-4713-b5cd-3d23d977a09f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '93156300-273c-4504-9d73-82c9cba20044', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ae9a8230-cfe6-46b4-ad33-0ebea9d6be91', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ec939482-768d-4ecc-bb38-79f357f7f8b1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '02b8cd00-e818-4a00-b200-7edfa26cc2cb', 'da39ed54-154a-4e49-9ed7-6def76c07da1', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b0dc347c-ebe7-4c16-a2d2-84ce721eed32', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '158f1823-7f6c-40da-bd8d-eb16a099d38b', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('952b7442-d7f2-4234-973a-2ef29a04e803', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c5e23a58-4fcc-486f-ab6a-467242fec15c', 'a676029e-6f7e-4946-82c4-648b96093d6f', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('fb6aa78f-e6f1-4d35-8143-4593fb8b5432', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a35dad76-2dc0-4268-ae21-7ca1a671f20e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e6a22858-75a9-491e-9dc3-420226894ee0', '0af2e08b-ef48-4f5a-8393-d6156d77ca60', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9ad5629a-900a-4a1f-a8b2-c5d79f7506bf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6445c742-2b9a-4c27-be83-845a74fbbe23', '818c97a7-6560-482f-b172-913acf53f254', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('1ab1ac98-5abc-4e7b-a2c7-1fc6ceb9b29a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'aee53ac2-5a8d-4cf2-b8c7-8871db10eb60', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c453dd31-3b87-4944-b6e6-522dba74d55e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cf3acca4-5c34-494d-8ed3-00af16098627', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2fdc0e8c-73a6-4f94-b78d-d9d7ac50e409', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3debceb6-d2da-4a47-ace5-0486eac1644e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', '5c455d0d-c913-45f9-84e4-3bbc34914845', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('20779083-2152-4b01-9816-b86af747390e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '57298474-a0b7-4c3a-b9dc-d1f5743251fe', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('06e9af97-4d78-4bdf-82f2-61f1c281f65a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', '5c455d0d-c913-45f9-84e4-3bbc34914845', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2f98c032-bcec-4b54-9730-ceb010580335', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1f160de2-c8bd-4710-bd24-618f056b1e05', '3ec3439d-33dd-4485-b8dd-496290b68ae8', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f2b96706-04f6-4c2a-91c9-16d0480d4e65', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('23714795-feb1-48d6-b033-4428e4a7089c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '7e5233ae-eb17-495d-b280-8556ff16caba', 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('03be6ba6-5079-4aec-b672-0a8a81155e38', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c9bd85c8-4d70-4ed9-ad2c-b3170dc45a63', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a8a18b17-64a6-4267-b0d1-b08c8a5e1245', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ea1a768a-d6a2-4680-a2e1-1b090bc790bd', '33799830-f9a7-4fa6-83c7-6216d3f007db', '2026-10-23 16:45:31.982046+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b5e8e555-3516-430d-bee6-ea5e37261dbc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2217c5fc-c596-451e-80dc-1b6b81490bed', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ec19c02f-410b-4c03-879b-72ab2f3565d4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7dc7ffbb-9917-42c8-a146-d63bb21119fb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'd507738e-d53e-49df-a82a-34ce64090c6a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('919f9bfd-2064-4847-8d18-5c3da88441a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6e432294-26f3-4417-a156-9ed63b1bbef0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5faad1c0-d0e8-42bd-82eb-bc37d7e247d8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'd507738e-d53e-49df-a82a-34ce64090c6a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('27b5ce79-36ec-44f2-a86f-8c30c33e1381', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ded630c1-2384-4eda-b549-77304d5b061f', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('967699e4-c2cb-4c2d-adbe-7437e2d1a305', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ded630c1-2384-4eda-b549-77304d5b061f', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('572a7e3b-2f78-49bb-9e3d-d87934568a05', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('6ca7474d-faf8-46b1-a748-5d0d515aa57c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e7d329ab-e069-4e3a-9401-f5552ccc758d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('061b8399-0285-4e49-b7ca-a70f3622482e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', '272eb045-e16d-48e8-9a21-2f539405d460', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7f69e8cf-4585-41d7-8362-050847faf219', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2ad3113e-0189-4905-ba08-90c7eba5fc23', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0ba4db26-ba45-4aff-926e-e87cd127a8ce', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', '272eb045-e16d-48e8-9a21-2f539405d460', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4cf4c47b-7830-4325-8193-03d95dbdad88', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ace5920e-c8d3-43bd-94b7-3b832bc1e18a', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('a51d44ec-7018-4167-8328-127e97edd8a3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '94d90f8e-ee00-4048-b247-70596dfe32ec', 'd507738e-d53e-49df-a82a-34ce64090c6a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c029ae0f-1639-48b9-bf07-aafca46d1c98', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91ffd7bf-4033-4656-aa36-f1034b7c0141', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('afffe93b-3d85-4f8f-a1da-f3d2639dbb52', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '113aa38b-98d4-44a1-be3e-0f16882f1456', '272eb045-e16d-48e8-9a21-2f539405d460', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8f711013-622a-448d-94f5-1306245f1dce', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('021bbae5-c38b-4e03-87b3-f674a210ece1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f7f846a7-1804-474c-910e-805e5a598188', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4df95ded-7834-44a8-aad5-8bb60de69fd1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8a1df762-3c15-4790-b4bd-8b43de1f4322', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3758610b-c1c8-42a1-9d5a-00c0424b2caa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b36e4c1e-2f50-409d-a26f-fc6398f1c30b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9d3aaf76-139c-42fd-a110-dd326335cd7f', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e0d8cbb4-4074-4ac3-aa3d-4611618c383a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9d3aaf76-139c-42fd-a110-dd326335cd7f', 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3f158efa-9391-4216-b721-bc124abc6f28', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('b80607fc-f231-45f1-afee-28fcf6e4e877', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7c0c1768-510f-41fa-b289-9e0916477966', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', '272eb045-e16d-48e8-9a21-2f539405d460', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('716a37f5-6258-47b0-844b-8843a954cf09', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', 'd507738e-d53e-49df-a82a-34ce64090c6a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('26641ab5-d551-4ec7-800f-fe7bd0438259', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7b7d2da8-4b84-417c-8c24-929009559425', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('66810bba-0f38-414f-ad40-703d25c2cafc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0075e092-69ee-474d-85d0-8687332a087e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4f767685-a148-4e59-8eaa-e0e770c606a1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', '272eb045-e16d-48e8-9a21-2f539405d460', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('ccd39fa5-8a35-40fb-8d74-5f10a11e4eca', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9a457f48-ab83-4c41-9d59-77286f59c20d', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d96170f3-d466-476f-9908-cfe2e1e163ff', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7acf1c55-aa17-49ea-8cca-a29e2cdf12cd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('951c48b2-ed4e-4db9-b628-66fe40b5f8aa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('34727393-a50d-4c4b-92da-61bc00336db8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('58fc252d-88e6-4921-8834-40e815728cb8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cb673be6-1f2f-4c92-ac04-8da1c07badea', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e4a5228-a241-4e74-9a87-04fcf582a329', '272eb045-e16d-48e8-9a21-2f539405d460', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('00da9a0e-77d2-4cae-ba82-674757230f22', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e4a5228-a241-4e74-9a87-04fcf582a329', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d3609e25-ec30-45d6-978e-f9cb28dffb56', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '82d76422-6692-4b34-8c43-28faecac65b2', 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('2fbd997c-64fb-4561-8ce1-aed2089bd12c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c173e134-acf7-40e9-8b27-92dcba8779f0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9c90ff51-7d56-4fc2-b52c-518acb82f6fa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', 'b36433d3-e05f-4f75-be3d-812e143d71f3', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('32b689e2-bd6e-45e2-baa2-f26448a6ef72', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', 'f286056a-e01e-41c5-ba89-3ee011a8f021', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7762c37c-5d90-47f8-a33c-a4792f0f8401', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4fe1ef8f-389b-478e-a8cd-420ccbeeb010', 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('d93c9b13-6a61-430c-9fe0-8b554f8d08e7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10deef65-5690-4f50-9510-cfa4ff2d502c', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('759e1320-f138-4d5f-a718-451494f31786', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10deef65-5690-4f50-9510-cfa4ff2d502c', 'd507738e-d53e-49df-a82a-34ce64090c6a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('5658225b-d808-46fa-9c0e-bba2aabd98dd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', 'd507738e-d53e-49df-a82a-34ce64090c6a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('8a472000-c6d7-4421-888d-7156fe5a6857', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', '2df4cc52-efba-41e3-ada5-ba08aa06ce54', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('be7ab4ec-47d9-430b-b44a-ab014625fa6e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('9771593d-812b-43d0-a4ef-be264cf16966', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd004ef0b-2410-4a4c-8068-b685e38a1570', '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('7e028db4-5a15-4d28-8225-f4d91836fa53', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'dd14c900-66d6-4099-8d85-1175319e8b7b', 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '2026-10-23 16:45:32.144992+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('88d757f0-7b73-4945-8285-3a201de72c7e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:32.26979+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('e4d79d42-6a59-4770-b6a0-cdc0de1f29a6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2026-10-23 16:45:32.26979+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('0647b2ca-1ae3-46f2-9c8b-7f7214733ecf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '543f25e9-9572-4b44-a548-fc2878ca5324', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2026-10-23 16:45:32.26979+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c318ee2f-3577-4346-9ab2-7fc4d1ae0e2c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('f86018c7-3a75-4e3d-b0b0-273f27e6f1d0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd4d375c2-948d-482d-ae68-02e446edfa8f', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('3a5b448f-9b58-4dd9-aeb4-e4370975a7b6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('22c6bfaf-2dca-48e2-8ad5-2450d1d9ff3a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('cb66d3ed-c20d-4a01-b65b-4d2ddaf12342', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('611acd7a-15d6-4777-a926-975b35b0e6e3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('4a533beb-2fb5-46f5-927e-b8a72250cc85', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '2026-10-23 16:45:33.492981+00');
INSERT INTO public.stock_anchors (id, organization_id, product_template_id, storage_location_id, created_at) VALUES ('c4ee7b38-0e84-4751-81ce-1e75d454c790', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '2026-10-23 16:45:35.818998+00');


--
-- Data for Name: stock_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_moves; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('52e6d633-1789-4f12-9e4f-267501409d98', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', 'd8e00d64-a82b-4251-a062-d892686ade1c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-09-06 07:00:00+00', '2026-10-23 16:45:32.388827+00', '2023-09-06 07:00:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('36dfbef2-c761-4e5b-aa9b-46f3b81eed41', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 1.000, NULL, 'done', 'opening_balance', '8b8ec988-ed8c-4b35-ac2e-12ea720e0768', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-10-07 08:07:00+00', '2026-10-23 16:45:32.412901+00', '2023-10-07 08:07:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('cffc6544-a5ed-4768-a81b-b7797e2eabbd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '0d2c1a5e-1850-429e-b5bc-c64e7031ac67', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-10-09 09:14:00+00', '2026-10-23 16:45:32.423322+00', '2023-10-09 09:14:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('24a6b165-ffa2-4cbc-9d51-c9a5a8d810d8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '113aa38b-98d4-44a1-be3e-0f16882f1456', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', '1ceb3d15-2522-4f56-bac8-b7191e539f7e', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-11-09 10:21:00+00', '2026-10-23 16:45:32.431405+00', '2023-11-09 10:21:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('82452fd9-1006-43aa-bb66-f06efa1d73ff', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', 'cc9c3d5d-4786-4589-87df-14283445db93', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-11-11 11:28:00+00', '2026-10-23 16:45:32.441057+00', '2023-11-11 11:28:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('e24ff934-c6e9-4df4-894d-c60c4e38234d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '3ac40c64-a75c-4154-80a3-49097d9c2647', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-12-12 12:35:00+00', '2026-10-23 16:45:32.448811+00', '2023-12-12 12:35:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('0f2ad115-a877-441f-8392-09f4a25f7394', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'dd14c900-66d6-4099-8d85-1175319e8b7b', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '1421b012-d413-4ba3-9611-34298a67c311', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2023-12-14 13:42:00+00', '2026-10-23 16:45:32.45691+00', '2023-12-14 13:42:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('747a20c8-e63f-4b9f-8c69-36c51e1711d7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 1.000, NULL, 'done', 'opening_balance', '4a9aaa0e-0d46-4d2a-b066-42762773b6e9', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-01-12 14:49:00+00', '2026-10-23 16:45:32.463172+00', '2024-01-12 14:49:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('661ae836-9513-44c8-b950-3ed7b4c1b3db', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 1.000, NULL, 'done', 'opening_balance', '2aeb48c4-8fbf-4c28-ae80-1d9883515a3a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-01-14 15:56:00+00', '2026-10-23 16:45:32.470641+00', '2024-01-14 15:56:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('1f8ca6e5-5c8a-471e-9273-e68288b59236', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91ffd7bf-4033-4656-aa36-f1034b7c0141', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 1.000, NULL, 'done', 'opening_balance', 'edcc1ef6-e565-44eb-b40b-af8f4cbbbe80', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-02-14 16:03:00+00', '2026-10-23 16:45:32.483569+00', '2024-02-14 16:03:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('3cc301ac-3fa3-4323-9507-3d670c403456', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', '47d2b443-0abd-430d-bab2-f8ab3b5b0b1f', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-02-16 07:10:00+00', '2026-10-23 16:45:32.490858+00', '2024-02-16 07:10:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('2604ce6e-164d-4f5d-9d08-a2500cd48f34', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 1.000, NULL, 'done', 'opening_balance', '98f58717-acda-4fba-b63f-6c1679013d62', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-03-18 08:17:00+00', '2026-10-23 16:45:32.498456+00', '2024-03-18 08:17:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('698d6db8-5c88-49bc-b067-861264a560d7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd004ef0b-2410-4a4c-8068-b685e38a1570', NULL, '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 1.000, NULL, 'done', 'opening_balance', '7d050eff-da10-40e8-afc8-4bad97bea00c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-03-20 09:24:00+00', '2026-10-23 16:45:32.505353+00', '2024-03-20 09:24:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('314889e0-32dd-47b0-8172-af65cc9b2893', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ded630c1-2384-4eda-b549-77304d5b061f', NULL, 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 1.000, NULL, 'done', 'opening_balance', 'c193cea7-5ace-4268-b794-517e5ca52441', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-04-18 10:31:00+00', '2026-10-23 16:45:32.513587+00', '2024-04-18 10:31:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('75175892-8cf9-432a-99c5-4e9ae2ef0aa4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9a457f48-ab83-4c41-9d59-77286f59c20d', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', 'b1fe6604-5b13-4039-8364-9fcb4dba13b8', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-04-20 11:38:00+00', '2026-10-23 16:45:32.520101+00', '2024-04-20 11:38:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ffe8daae-3cb7-4564-bf3e-3cd76c0e8b63', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '94d90f8e-ee00-4048-b247-70596dfe32ec', NULL, 'd507738e-d53e-49df-a82a-34ce64090c6a', 1.000, NULL, 'done', 'opening_balance', '11f739d1-7b47-4478-9c21-06528ec0413d', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-05-21 12:45:00+00', '2026-10-23 16:45:32.526544+00', '2024-05-21 12:45:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('38f2148a-9fc3-43b1-9ce6-ad847188882b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', 'ed63ebf8-a467-4a99-8c1d-80f302c277aa', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-05-23 13:52:00+00', '2026-10-23 16:45:32.532992+00', '2024-05-23 13:52:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('db4a0d7f-fb6f-4ecc-82b3-db99d31b7494', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9d3aaf76-139c-42fd-a110-dd326335cd7f', NULL, 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', 1.000, NULL, 'done', 'opening_balance', 'f48dc345-a7d4-49cb-b50b-2bd1ca774294', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-06-23 14:59:00+00', '2026-10-23 16:45:32.540079+00', '2024-06-23 14:59:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('83542aa4-bd7b-4514-8714-892a6b2dd938', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd004ef0b-2410-4a4c-8068-b685e38a1570', NULL, '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 1.000, NULL, 'done', 'opening_balance', 'bf0db314-1400-440a-a329-24b813d661a1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-06-25 15:06:00+00', '2026-10-23 16:45:32.547047+00', '2024-06-25 15:06:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('a60b8619-a085-4798-a2e0-63e75a7c1fcb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ded630c1-2384-4eda-b549-77304d5b061f', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 1.000, NULL, 'done', 'opening_balance', 'cbe47af3-20ab-432b-9b2e-90b2a1793c38', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-07-24 16:13:00+00', '2026-10-23 16:45:32.558948+00', '2024-07-24 16:13:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('b4d3110f-b79c-406d-a278-23c6de39d09a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9a457f48-ab83-4c41-9d59-77286f59c20d', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', '38a4eedb-d6e3-4e09-a8e6-003778af9d31', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-07-26 07:20:00+00', '2026-10-23 16:45:32.565506+00', '2024-07-26 07:20:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d0cfabe9-b104-43da-9894-444ca2a6a6bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ace5920e-c8d3-43bd-94b7-3b832bc1e18a', NULL, 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 1.000, NULL, 'done', 'opening_balance', 'f028ffdb-6158-4c06-9e2b-51af064128ab', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-08-26 08:27:00+00', '2026-10-23 16:45:32.574534+00', '2024-08-26 08:27:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('20aabbaa-a578-40e7-aca8-5f44ff3363cf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '10ddc409-0dcb-449f-845c-1bb370b07c75', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-08-28 09:34:00+00', '2026-10-23 16:45:32.586273+00', '2024-08-28 09:34:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('4cef7a4d-eb97-45c1-a60c-38ddd959aae0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9d3aaf76-139c-42fd-a110-dd326335cd7f', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', 'e0bebbd2-9725-4edc-8ded-5cf7f51abb19', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-09-28 10:41:00+00', '2026-10-23 16:45:32.592831+00', '2024-09-28 10:41:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('8fb32706-5bcf-4c05-98f7-0729a8245347', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 1.000, NULL, 'done', 'opening_balance', 'c3119cb5-3482-48b1-af87-b68123f7dfa2', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-09-30 11:48:00+00', '2026-10-23 16:45:32.5998+00', '2024-09-30 11:48:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('9d05306e-3afe-4acd-b27b-93cf4c99df7c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 'd507738e-d53e-49df-a82a-34ce64090c6a', 1.000, NULL, 'done', 'opening_balance', 'a7cc334b-bca9-41df-afec-25114acd229b', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-10-29 12:55:00+00', '2026-10-23 16:45:32.606365+00', '2024-10-29 12:55:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('cb0c67a9-3c81-4173-8123-337ad6f0c883', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', 'cb76e281-b591-431e-97a8-d4d108a4a91d', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-10-31 13:02:00+00', '2026-10-23 16:45:32.613307+00', '2024-10-31 13:02:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('b747b2c7-4482-4207-a84c-0cda445f43f5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', 'aa2efb72-e817-40ba-99fc-6fb26ab6323a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-12-01 14:09:00+00', '2026-10-23 16:45:32.619716+00', '2024-12-01 14:09:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('461eaa2a-22ab-4edc-89a2-690160eb05ce', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', 'f1cb96ef-83d2-49c4-8fd0-91f6d65e0a6a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2024-12-03 15:16:00+00', '2026-10-23 16:45:32.630519+00', '2024-12-03 15:16:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('145605ad-bb45-4477-aede-4c61cfcd2001', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', '6119a187-8288-4978-b6d2-a83f9326c10d', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-01-03 16:23:00+00', '2026-10-23 16:45:32.637079+00', '2025-01-03 16:23:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('a5d06b31-41d4-4899-b630-bd0c9d008a07', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 1.000, NULL, 'done', 'opening_balance', 'fd296851-93ca-4224-9100-c809c2151f45', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-01-05 07:30:00+00', '2026-10-23 16:45:32.64376+00', '2025-01-05 07:30:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ddd3f1b6-dc04-4cbd-9ef1-557e58c62fb4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 1.000, NULL, 'done', 'opening_balance', 'ae6658f1-69bf-490c-8266-326e17f025b5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-02-03 08:37:00+00', '2026-10-23 16:45:32.650139+00', '2025-02-03 08:37:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('c55424e3-7dd0-4a50-ae8b-85d56bd0d291', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 1.000, NULL, 'done', 'opening_balance', 'a73ba785-9730-4866-ba25-089440414da5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-02-05 09:44:00+00', '2026-10-23 16:45:32.656744+00', '2025-02-05 09:44:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('a1480338-1fdc-4b12-8f83-c439b3d0f3cf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 1.000, NULL, 'done', 'opening_balance', '4d68fc77-33bc-4861-ad2c-54edc61e89f0', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-03-08 10:51:00+00', '2026-10-23 16:45:32.663339+00', '2025-03-08 10:51:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('c2e12d1b-f14c-4dd4-ba27-bf07bb2a1f9f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '82d76422-6692-4b34-8c43-28faecac65b2', NULL, 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 1.000, NULL, 'done', 'opening_balance', 'de6a0ea3-850c-4323-9266-e64b79bf86c3', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-03-10 11:58:00+00', '2026-10-23 16:45:32.669803+00', '2025-03-10 11:58:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d24fa5f7-8412-4b0b-a652-73a0b1a4e9a5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 1.000, NULL, 'done', 'opening_balance', 'ab44d2a1-afa7-4125-b698-b8d6226b9322', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-04-10 12:05:00+00', '2026-10-23 16:45:32.676371+00', '2025-04-10 12:05:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('4bd1bd58-06f9-4ae5-b76d-807a0d9de2f6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', NULL, 'd507738e-d53e-49df-a82a-34ce64090c6a', 1.000, NULL, 'done', 'opening_balance', '172a9aa9-ea5c-4f46-a9cf-2bc852652fbe', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-04-12 13:12:00+00', '2026-10-23 16:45:32.68238+00', '2025-04-12 13:12:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('92139994-9263-4ab0-9a0c-40f245291cc7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '4af7f02a-b50d-47b8-b9f4-88812ccbb538', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-05-11 14:19:00+00', '2026-10-23 16:45:32.688439+00', '2025-05-11 14:19:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('f593cc02-570f-4b41-9eb7-9fa2fc663c9a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 'f286056a-e01e-41c5-ba89-3ee011a8f021', 1.000, NULL, 'done', 'opening_balance', 'fc58882a-56b0-4621-aece-5325faf1e087', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-05-13 15:26:00+00', '2026-10-23 16:45:32.694477+00', '2025-05-13 15:26:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('f441f544-899e-4a56-9662-39468e089033', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 1.000, NULL, 'done', 'opening_balance', '3bcfabb3-0573-480d-a387-98a8080cb932', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-06-13 16:33:00+00', '2026-10-23 16:45:32.700559+00', '2025-06-13 16:33:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('9d1b2cc1-f297-4692-8925-55e3d9a23a69', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e4a5228-a241-4e74-9a87-04fcf582a329', NULL, 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 1.000, NULL, 'done', 'opening_balance', '8b05018c-03aa-4230-b661-893adc443d60', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-06-15 07:40:00+00', '2026-10-23 16:45:32.706672+00', '2025-06-15 07:40:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('dca0ea3c-db1c-45f9-86db-02bb029221ff', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', '16bdf232-6dba-4418-968a-1f040742f58a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-07-16 08:47:00+00', '2026-10-23 16:45:32.712569+00', '2025-07-16 08:47:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('820f59a8-878e-450c-91d7-b975d809d83f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10deef65-5690-4f50-9510-cfa4ff2d502c', NULL, 'd507738e-d53e-49df-a82a-34ce64090c6a', 1.000, NULL, 'done', 'opening_balance', 'ef989857-07cf-44a0-b8b7-bbb39e188897', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-07-18 09:54:00+00', '2026-10-23 16:45:32.718364+00', '2025-07-18 09:54:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ec81b412-7fdf-45a8-a672-ad7eca40c8cb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', 'f6614652-8472-47a9-818e-45c73da80a97', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-08-16 10:01:00+00', '2026-10-23 16:45:32.725365+00', '2025-08-16 10:01:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('22ba5855-f6b8-4c7f-946d-a6f1cad390a8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '152ca7c0-3490-44a1-bd45-2e13b0958764', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-08-18 11:08:00+00', '2026-10-23 16:45:32.734159+00', '2025-08-18 11:08:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('20cec805-1c31-4410-afda-aa97df64fc28', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '6731624f-d6a9-40a7-b5f4-b777921c76c4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-09-18 12:15:00+00', '2026-10-23 16:45:32.740593+00', '2025-09-18 12:15:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('4cd95153-51a6-4123-a998-776c2b00fb85', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e4a5228-a241-4e74-9a87-04fcf582a329', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', 'c629351a-8d72-4dc4-b160-40bdff339e1e', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-09-20 13:22:00+00', '2026-10-23 16:45:32.747301+00', '2025-09-20 13:22:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('e27f6fa4-a124-44c6-a1e5-8ed9f4ebad11', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 1.000, NULL, 'done', 'opening_balance', 'f38805ea-907e-47bc-95d0-fe7802e68b7f', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-10-21 14:29:00+00', '2026-10-23 16:45:32.754677+00', '2025-10-21 14:29:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('69c48e08-cd1a-4590-8f73-53e3933418e1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10deef65-5690-4f50-9510-cfa4ff2d502c', NULL, 'b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', 1.000, NULL, 'done', 'opening_balance', '0b617b49-8355-472f-96ff-8248263574da', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-10-23 15:36:00+00', '2026-10-23 16:45:32.761261+00', '2025-10-23 15:36:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('719d69cb-7983-4250-99e7-639edf2e7d3c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 'd507738e-d53e-49df-a82a-34ce64090c6a', 1.000, NULL, 'done', 'opening_balance', '33445a19-14cf-45a2-9a3f-27de3c2a45f1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-11-21 16:43:00+00', '2026-10-23 16:45:32.767638+00', '2025-11-21 16:43:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('510f7f30-202b-4be1-b55f-c12af156b67a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 1.000, NULL, 'done', 'opening_balance', '7869d18f-4f4c-4612-a47a-1278ca9ba3f5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-11-23 07:50:00+00', '2026-10-23 16:45:32.774172+00', '2025-11-23 07:50:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('0be7f462-1e92-43c2-b522-ee82ad9b0d8b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 1.000, NULL, 'done', 'opening_balance', 'a940f565-56d3-4a8a-93b5-e30d8af68da9', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-12-24 08:57:00+00', '2026-10-23 16:45:32.781057+00', '2025-12-24 08:57:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('118df4fa-50bc-4e68-b496-59cab5dff9bb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 'f286056a-e01e-41c5-ba89-3ee011a8f021', 1.000, NULL, 'done', 'opening_balance', '0c4ec75a-a0d3-49cb-b3c0-026c2fadbb78', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2025-12-26 09:04:00+00', '2026-10-23 16:45:32.787596+00', '2025-12-26 09:04:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('37fe36a2-3801-44a3-a666-4037853c6000', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 1.000, NULL, 'done', 'opening_balance', '7ae0794e-e118-4a2b-9840-c590449c49e1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-01-26 10:11:00+00', '2026-10-23 16:45:32.794229+00', '2026-01-26 10:11:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d645406d-e89a-4f40-98bf-b4982af953fd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4fe1ef8f-389b-478e-a8cd-420ccbeeb010', NULL, 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', 1.000, NULL, 'done', 'opening_balance', '123f13da-5e18-4735-b23f-155dae3245ba', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-01-28 11:18:00+00', '2026-10-23 16:45:32.800632+00', '2026-01-28 11:18:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('91e778a6-3c2d-4bb6-a7e9-6d308e2a79ba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 'f286056a-e01e-41c5-ba89-3ee011a8f021', 1.000, NULL, 'done', 'opening_balance', 'b0cc9bd4-fd50-4f95-846a-4771e6e914fc', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-02-26 12:25:00+00', '2026-10-23 16:45:32.807067+00', '2026-02-26 12:25:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('fe840753-8baf-4691-8a85-3f4715a6a04b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 'd507738e-d53e-49df-a82a-34ce64090c6a', 1.000, NULL, 'done', 'opening_balance', '028a5f28-ed45-44f6-9322-da4729d72bd5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-02-28 13:32:00+00', '2026-10-23 16:45:32.814008+00', '2026-02-28 13:32:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ff70bf51-c25f-47be-954d-4282e2859620', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', 'ccb6ad7c-5e67-4942-b30b-0b725c974639', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-03-31 14:39:00+00', '2026-10-23 16:45:32.820919+00', '2026-03-31 14:39:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('9aaaea9a-a59b-4fae-a38b-e2eac3289cc3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 'a7712e9f-8cf9-4586-bc61-a5af7ae4818f', 1.000, NULL, 'done', 'opening_balance', '8bf90665-caa6-42e7-9dcd-ea6c5361401b', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-04-02 15:46:00+00', '2026-10-23 16:45:32.828574+00', '2026-04-02 15:46:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d9bea9df-6206-4365-a470-7947bf318d01', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', NULL, '91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', 1.000, NULL, 'done', 'opening_balance', 'b3a212c0-900b-4479-bcff-3173062a4ea0', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-05-03 16:53:00+00', '2026-10-23 16:45:32.835799+00', '2026-05-03 16:53:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('5a6048a8-a1bb-40c7-9737-4b6451acb68f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', '70bc7603-8cc4-4daa-b622-a1f8486b10a1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-05-05 07:00:00+00', '2026-10-23 16:45:32.842595+00', '2026-05-05 07:00:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('13d4ccd4-e2d6-44d1-b1dd-1f4142612fe0', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 'b36433d3-e05f-4f75-be3d-812e143d71f3', 1.000, NULL, 'done', 'opening_balance', '012cdc10-4164-49aa-bc48-35b5bb8d12f7', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-06-03 08:07:00+00', '2026-10-23 16:45:32.849458+00', '2026-06-03 08:07:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('94cbae4f-f2a9-4a9f-8345-577b19af9eaa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, '272eb045-e16d-48e8-9a21-2f539405d460', 1.000, NULL, 'done', 'opening_balance', '0c9840b3-a6f0-4e76-877f-66da7ec1188e', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-06-05 09:14:00+00', '2026-10-23 16:45:32.861368+00', '2026-06-05 09:14:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ccccb915-bb07-4e45-ae68-8b61306b0003', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 1.000, NULL, 'done', 'opening_balance', '7592587b-463b-4687-a519-4c5c78200112', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-07-06 10:21:00+00', '2026-10-23 16:45:32.868855+00', '2026-07-06 10:21:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('60834ed2-6776-4c55-b09a-1b7a90e8256d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 'ad55bce4-e2d4-4a36-825e-c627b4bf0357', 1.000, NULL, 'done', 'opening_balance', '2e38944f-642e-425d-9820-44c1b441a6e0', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-07-08 11:28:00+00', '2026-10-23 16:45:32.875729+00', '2026-07-08 11:28:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('3f728421-783b-4e2e-b39c-3b9b3f286f70', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', NULL, 'b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', 1.000, NULL, 'done', 'opening_balance', 'dc9207aa-3f80-4488-b9b0-f31b529eb5e1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-08 12:35:00+00', '2026-10-23 16:45:32.882998+00', '2026-08-08 12:35:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('b873518d-bf54-46d5-b18f-fa5698ea7b4e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', NULL, 'f286056a-e01e-41c5-ba89-3ee011a8f021', 1.000, NULL, 'done', 'opening_balance', '3f59884f-610d-4680-8545-58e25f43e431', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-10 13:42:00+00', '2026-10-23 16:45:32.889735+00', '2026-08-10 13:42:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('6fd37464-cedf-4dff-9e98-57cd4f629c5e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, '2df4cc52-efba-41e3-ada5-ba08aa06ce54', 1.000, NULL, 'done', 'opening_balance', 'b78d86d2-4050-4179-a20f-6969ce33e232', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-08 14:49:00+00', '2026-10-23 16:45:32.896112+00', '2026-09-08 14:49:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ede9ca19-2cd5-4547-a38b-35558b4bb608', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cc4a417a-a291-477b-ad60-37812ee87741', NULL, 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', 8.000, NULL, 'done', 'opening_balance', '18bbc0bd-152b-496a-bcd5-ebbd871d732f', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-16 15:56:00+00', '2026-10-23 16:45:32.902379+00', '2026-10-16 15:56:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d853a79a-6898-4745-8cd5-482064059334', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0c90caa3-cd77-4a17-865c-1a2bd0f87f81', NULL, '0af2e08b-ef48-4f5a-8393-d6156d77ca60', 4.300, NULL, 'done', 'opening_balance', '49bc8ea1-68ca-4e8d-ad1f-f16a65fd5d8a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-21 16:03:00+00', '2026-10-23 16:45:32.910768+00', '2026-10-21 16:03:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d9a86ff4-0ef5-4d68-bb17-4b810e39b90c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', NULL, '5c455d0d-c913-45f9-84e4-3bbc34914845', 1.000, NULL, 'done', 'opening_balance', '48995c7f-6593-42ba-9746-8ad8c11b9a92', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-24 07:10:00+00', '2026-10-23 16:45:32.918331+00', '2026-09-24 07:10:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('f9e9c13f-8002-4a70-9ae6-7b0305322545', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '23e939a9-42a2-4e13-a42d-0e6cea0e7acd', NULL, 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', 2.000, NULL, 'done', 'opening_balance', '9bed0320-0c03-46a9-86ec-c14b4fe7402b', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-13 08:17:00+00', '2026-10-23 16:45:32.925883+00', '2026-09-13 08:17:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('434ff8c6-7cf6-4e65-b89f-b5ba3069a1c9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 6.000, NULL, 'done', 'opening_balance', '627c3448-cedc-4e9e-b7de-3bc5b9174918', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-02 09:24:00+00', '2026-10-23 16:45:32.933746+00', '2026-09-02 09:24:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('0567ec1d-a320-4df5-8d2f-c5f6d5c5f381', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7fca96a-563b-47f4-a449-292eca81f87b', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 8.000, NULL, 'done', 'opening_balance', '295d6c19-1630-4150-8c31-2caf691e2cac', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-22 10:31:00+00', '2026-10-23 16:45:32.941546+00', '2026-08-22 10:31:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('6b5a8f6a-4e64-4edb-bdd4-18f262310f3a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a1d8635b-fe0a-48fb-970d-672422f8d5e6', NULL, 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', 3.000, NULL, 'done', 'opening_balance', 'e0d39c7d-33b2-41ea-a30a-d62a8f3cd5a6', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-14 11:38:00+00', '2026-10-23 16:45:32.949273+00', '2026-10-14 11:38:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('94112462-eeeb-4123-a81f-ac76734c4177', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c0e9f75c-42fb-4d2e-82a3-562304bf0d7f', NULL, 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 7.000, NULL, 'done', 'opening_balance', 'b5861876-0bb1-4f72-a48f-f7cdb66c226a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-03 12:45:00+00', '2026-10-23 16:45:32.956788+00', '2026-10-03 12:45:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ce5fb2b8-2d13-49bb-91bb-491103a71b06', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 3.000, NULL, 'done', 'opening_balance', 'f9fc0629-de1f-49ca-90d2-de22cdf9810e', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-22 13:52:00+00', '2026-10-23 16:45:32.96415+00', '2026-09-22 13:52:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('e6c36dc7-84e6-4036-9240-d6b9f491cbf9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', NULL, 'da39ed54-154a-4e49-9ed7-6def76c07da1', 5.000, NULL, 'done', 'opening_balance', 'ea4e5de8-8074-45c7-b7e4-2e0cb0c4cce0', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-11 14:59:00+00', '2026-10-23 16:45:32.971788+00', '2026-09-11 14:59:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('b5c2785f-330e-4a6e-98f9-64b084b67929', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 2.000, NULL, 'done', 'opening_balance', '43b4b6c4-d8a4-42c6-8897-d8602df5cfd4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-18 15:06:00+00', '2026-10-23 16:45:32.980908+00', '2026-10-18 15:06:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('f1f98701-d999-4d8d-ae02-3ff442f9337c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', NULL, 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 7.000, NULL, 'done', 'opening_balance', 'dc91ca88-8631-4120-a745-29d9291de824', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-20 16:13:00+00', '2026-10-23 16:45:32.988529+00', '2026-08-20 16:13:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('37054ce2-1185-45fd-b7a1-ee87f4190dcf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4bc73840-44dc-4a70-97b8-f449a586d57e', NULL, 'da39ed54-154a-4e49-9ed7-6def76c07da1', 5.000, NULL, 'done', 'opening_balance', '5e3217a8-acc4-46e0-83b4-e255b7948baa', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-12 07:20:00+00', '2026-10-23 16:45:32.996064+00', '2026-10-12 07:20:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('4b4f242b-7479-4f40-a25d-6268dcb8a29e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 1.000, NULL, 'done', 'opening_balance', 'cca5b8c1-03a7-4ba4-82e1-bea2e825dd4a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-17 08:27:00+00', '2026-10-23 16:45:33.003234+00', '2026-10-17 08:27:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('38fccd52-76a8-4770-8543-88b1a9ba2523', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2201036f-39da-4e0e-bb94-c675770c9438', NULL, 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', 9.000, NULL, 'done', 'opening_balance', 'a095fa1a-86d2-45c2-ab47-f186f21a2411', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-20 09:34:00+00', '2026-10-23 16:45:33.011462+00', '2026-09-20 09:34:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('9fcc1768-5b72-4108-b7a8-7a35166e5e7e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', NULL, 'd66ab48c-90c0-47df-9e57-5e4c95ab681e', 1.000, NULL, 'done', 'opening_balance', 'b4599a37-8f52-4b1c-9362-fd9df41340b5', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-09 10:41:00+00', '2026-10-23 16:45:33.019161+00', '2026-09-09 10:41:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ffefdf75-ef04-4509-8ee1-0ef79c3dae69', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '707d1613-0643-4f34-b3ec-c8229a6a9aa9', NULL, '6588e3ed-0fc3-4ec0-be21-07fda324cb6e', 5.000, NULL, 'done', 'opening_balance', 'e35058b2-2e38-400f-a194-e2478667c688', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-29 11:48:00+00', '2026-10-23 16:45:33.026822+00', '2026-08-29 11:48:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('c5f7c774-227e-4702-b33e-4c011cce86f1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', NULL, '38323184-273f-4032-8597-d48a45db1650', 8.000, NULL, 'done', 'opening_balance', '9f05685a-44dc-4dd2-b62b-aba31a4ab308', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-17 12:55:00+00', '2026-10-23 16:45:33.034419+00', '2026-10-17 12:55:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('6280bc61-d9a2-4475-9a62-72f8c6fc8b24', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f612f610-95b6-4dab-9644-c2594d96430f', NULL, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 6.000, NULL, 'done', 'opening_balance', 'fdd48d9c-011e-4586-be58-95eeb73a609b', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-10 13:02:00+00', '2026-10-23 16:45:33.042289+00', '2026-10-10 13:02:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('142c1d2f-61c5-4ecc-a994-af774d9a5338', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '93156300-273c-4504-9d73-82c9cba20044', NULL, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 5.000, NULL, 'done', 'opening_balance', '59f6bf9b-b127-44d1-a385-300dd9c68424', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-29 14:09:00+00', '2026-10-23 16:45:33.054242+00', '2026-09-29 14:09:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('fba799b7-59bf-44f7-bdd2-5accf42a6c45', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 'da39ed54-154a-4e49-9ed7-6def76c07da1', 7.000, NULL, 'done', 'opening_balance', '172be898-0643-42ea-bcb7-523d49398323', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-18 15:16:00+00', '2026-10-23 16:45:33.062062+00', '2026-09-18 15:16:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('055669f1-4a42-45fa-bdc2-15ba42d8ceba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '02b8cd00-e818-4a00-b200-7edfa26cc2cb', NULL, 'da39ed54-154a-4e49-9ed7-6def76c07da1', 5.000, NULL, 'done', 'opening_balance', '692653f5-8152-434e-a78e-9518ca59758d', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-07 16:23:00+00', '2026-10-23 16:45:33.070022+00', '2026-09-07 16:23:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('98855be8-e3ae-49c3-9108-ceb30fd9f80b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '158f1823-7f6c-40da-bd8d-eb16a099d38b', NULL, 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', 8.000, NULL, 'done', 'opening_balance', '5af64c3e-4713-4d55-8187-d5fb54c307bd', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-27 07:30:00+00', '2026-10-23 16:45:33.077932+00', '2026-08-27 07:30:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('e7cd4db9-890b-48d6-8cd0-d9d0d6b7630e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c5e23a58-4fcc-486f-ab6a-467242fec15c', NULL, 'a676029e-6f7e-4946-82c4-648b96093d6f', 7.000, NULL, 'done', 'opening_balance', 'e06f12c2-a8a4-4de7-ad6f-4eff2a868bab', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-17 08:37:00+00', '2026-10-23 16:45:33.085455+00', '2026-10-17 08:37:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('74f20d2f-381f-4a0f-9cd9-915bdbd6f5a1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 'db1da8be-7485-44e6-9e96-22ddd61d7f6c', 10.000, NULL, 'done', 'opening_balance', 'ff9bbe2c-0eed-41b6-a39d-6e4cfa189860', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-08 09:44:00+00', '2026-10-23 16:45:33.095782+00', '2026-10-08 09:44:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('3e945272-8ab7-4999-8d27-bd6c610324c2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 2.000, NULL, 'done', 'opening_balance', 'a8bb2959-1f15-4b02-8c21-e55cda3503ac', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-21 10:51:00+00', '2026-10-23 16:45:33.103387+00', '2026-10-21 10:51:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ab787658-dd3f-4df6-8017-c287f23c1850', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e6a22858-75a9-491e-9dc3-420226894ee0', NULL, '0af2e08b-ef48-4f5a-8393-d6156d77ca60', 5.000, NULL, 'done', 'opening_balance', '933106c0-b448-43f1-9e7f-4cf358e9547c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-20 11:58:00+00', '2026-10-23 16:45:33.110777+00', '2026-10-20 11:58:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('7d8cb99e-e715-4fe9-8d6f-873996c99f91', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6445c742-2b9a-4c27-be83-845a74fbbe23', NULL, '818c97a7-6560-482f-b172-913acf53f254', 8.000, NULL, 'done', 'opening_balance', '7b3178c0-06fa-4762-86ea-da05abae4634', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-05 12:05:00+00', '2026-10-23 16:45:33.118251+00', '2026-09-05 12:05:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('b4046a0f-0b24-4357-923e-47f4c04c1843', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'aee53ac2-5a8d-4cf2-b8c7-8871db10eb60', NULL, 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', 9.000, NULL, 'done', 'opening_balance', '8b4e622d-795d-4565-b65b-0defef8f6c0e', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-25 13:12:00+00', '2026-10-23 16:45:33.131431+00', '2026-08-25 13:12:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('9632992f-d9b4-4d3b-9692-38f8c6465aac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cf3acca4-5c34-494d-8ed3-00af16098627', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 6.000, NULL, 'done', 'opening_balance', '8320ccd9-c1c7-4650-b88d-9efe168aed07', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-08-14 14:19:00+00', '2026-10-23 16:45:33.138922+00', '2026-08-14 14:19:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('3c680046-93b2-4ec8-9dac-f3111244dd0d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 3.000, NULL, 'done', 'opening_balance', '95847ea2-ad92-4055-908b-54ac8d8f9cc9', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-06 15:26:00+00', '2026-10-23 16:45:33.146683+00', '2026-10-06 15:26:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('571f710d-229e-47da-beb9-97b2071eadcc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', NULL, '5c455d0d-c913-45f9-84e4-3bbc34914845', 7.000, NULL, 'done', 'opening_balance', 'bfc89594-94b1-4cf0-ab22-17d07bf27d29', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-25 16:33:00+00', '2026-10-23 16:45:33.154165+00', '2026-09-25 16:33:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('1e77a6c2-58b9-441b-b951-01908b6a668c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '57298474-a0b7-4c3a-b9dc-d1f5743251fe', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 10.000, NULL, 'done', 'opening_balance', 'bd717ba3-5fb3-4e94-a4c5-0efc64578a1d', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-14 07:40:00+00', '2026-10-23 16:45:33.161906+00', '2026-09-14 07:40:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('3da269d4-153a-4d61-8fdd-857afb3830fe', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', NULL, '5c455d0d-c913-45f9-84e4-3bbc34914845', 3.000, NULL, 'done', 'opening_balance', 'ab2cd10e-985d-4e51-9055-dd3caf7c73b0', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-03 08:47:00+00', '2026-10-23 16:45:33.17023+00', '2026-09-03 08:47:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('94fd0cb3-dd98-49c6-9831-6d96204ccb02', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1f160de2-c8bd-4710-bd24-618f056b1e05', NULL, '3ec3439d-33dd-4485-b8dd-496290b68ae8', 8.600, NULL, 'done', 'opening_balance', '64603981-0929-4912-b837-dc9dbce645ca', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-18 09:54:00+00', '2026-10-23 16:45:33.186313+00', '2026-10-18 09:54:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('03ae7882-ca06-40fb-9a02-10554214b1ee', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 3.000, NULL, 'done', 'opening_balance', '12c2f2de-2e0a-4751-a348-9233f2d128bd', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-15 10:01:00+00', '2026-10-23 16:45:33.194643+00', '2026-10-15 10:01:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d6a89093-7d87-4818-ad05-c48fb760cc03', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '7e5233ae-eb17-495d-b280-8556ff16caba', NULL, 'a395c81d-3ad5-41a0-83a5-580bd33d8c5b', 1.000, NULL, 'done', 'opening_balance', '60a21e41-90d5-43c1-ad7b-fc52c6870857', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-04 11:08:00+00', '2026-10-23 16:45:33.201878+00', '2026-10-04 11:08:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('7c67f69b-71b5-48de-aeb9-b2126b1906e8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c9bd85c8-4d70-4ed9-ad2c-b3170dc45a63', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 4.000, NULL, 'done', 'opening_balance', '45a410c3-33a3-4f8b-b72f-e0e1b5b297f1', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-21 12:15:00+00', '2026-10-23 16:45:33.215226+00', '2026-10-21 12:15:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ff7fbe2e-d6fc-4ef4-b67e-dae9be04cea2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1f160de2-c8bd-4710-bd24-618f056b1e05', NULL, '3ec3439d-33dd-4485-b8dd-496290b68ae8', 5.800, NULL, 'done', 'opening_balance', 'dc5c3645-7760-4ba9-b5c0-9b3950605425', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-20 13:22:00+00', '2026-10-23 16:45:33.223521+00', '2026-10-20 13:22:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('c60e3530-393e-4b8e-b032-9df577a9b29d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ea1a768a-d6a2-4680-a2e1-1b090bc790bd', NULL, '33799830-f9a7-4fa6-83c7-6216d3f007db', 1.000, NULL, 'done', 'opening_balance', '03d88570-169e-469c-924c-097a190cc56a', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-01 14:29:00+00', '2026-10-23 16:45:33.230919+00', '2026-09-01 14:29:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ab6b9389-45ca-4f76-87f7-e5ee4212784e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 40.000, NULL, 'done', 'opening_balance', 'cd5bbe19-c815-46cc-9334-ef10da619ec4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-20 15:36:00+00', '2026-10-23 16:45:33.239658+00', '2026-10-20 15:36:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('149cf6d8-6fa1-44d8-86ea-6f8af9bbf245', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', NULL, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 25.000, NULL, 'done', 'opening_balance', '15994ec8-01e3-495c-a8c7-ee9d268934d3', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-03 16:43:00+00', '2026-10-23 16:45:33.247254+00', '2026-10-03 16:43:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('23447497-bb08-41ec-85de-c3505f71a79a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '543f25e9-9572-4b44-a548-fc2878ca5324', NULL, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 0.500, NULL, 'done', 'opening_balance', '1bfd442f-eb46-402b-ae06-f3f2e068b798', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-09-19 07:50:00+00', '2026-10-23 16:45:33.267363+00', '2026-09-19 07:50:00+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('b6a43e6e-68aa-4fcf-92b1-d339b1d64504', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 48.000, NULL, 'done', 'document', '0d79edb5-fd53-492f-b75c-a325527ee16c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-15 14:45:33.341716+00', '2026-10-23 16:45:33.766048+00', '2026-10-15 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ae587456-3d2e-4a6a-b070-ad90474fcb3f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd4d375c2-948d-482d-ae68-02e446edfa8f', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 24.000, NULL, 'done', 'document', '0d79edb5-fd53-492f-b75c-a325527ee16c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-15 14:45:33.341716+00', '2026-10-23 16:45:33.766048+00', '2026-10-15 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('8ccd3029-e09f-4463-acc9-26fb723e416b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', 36.000, NULL, 'done', 'document', '0d79edb5-fd53-492f-b75c-a325527ee16c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-15 14:45:33.341716+00', '2026-10-23 16:45:33.766048+00', '2026-10-15 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('ac604394-9d24-4ea8-bb76-80d3292f6eeb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6e248425-e0de-4710-b84a-3b6a6acd7713', NULL, 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', 60.000, NULL, 'done', 'document', 'c861b165-2f60-4301-bf23-28fcdfce2439', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-17 14:45:33.341716+00', '2026-10-23 16:45:33.829549+00', '2026-10-17 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('58afaddb-5723-46db-98e1-a7495ba93fd7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', NULL, 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', 20.000, NULL, 'done', 'document', 'c861b165-2f60-4301-bf23-28fcdfce2439', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-17 14:45:33.341716+00', '2026-10-23 16:45:33.829549+00', '2026-10-17 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('a09bbe88-4272-4097-8c7e-6143f9fa4c62', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 5.000, NULL, 'done', 'document', '1ad5e058-02ef-4f38-9db9-e99c8bff0e45', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-22 14:45:33.341716+00', '2026-10-23 16:45:33.902306+00', '2026-10-22 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('1f56cb1f-2b07-42ae-b256-1f52776048dc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 'c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', 3.000, NULL, 'done', 'document', '1ad5e058-02ef-4f38-9db9-e99c8bff0e45', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-22 14:45:33.341716+00', '2026-10-23 16:45:33.902306+00', '2026-10-22 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('61edc57d-0ae9-49f7-9928-38ad05d3c73b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 12.000, NULL, 'done', 'document', '01a7d408-1611-439f-8094-70c228c14258', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-20 14:45:33.341716+00', '2026-10-23 16:45:34.030301+00', '2026-10-20 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('658860b6-e924-4627-a4f1-9be2dc35f3cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 8.000, NULL, 'done', 'document', '01a7d408-1611-439f-8094-70c228c14258', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-20 14:45:33.341716+00', '2026-10-23 16:45:34.030301+00', '2026-10-20 14:45:33.341716+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('6caab0d1-d161-4468-af26-ccbc27d3ed3a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd4d375c2-948d-482d-ae68-02e446edfa8f', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 6.000, NULL, 'done', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:35.28467+00', '2026-10-23 16:45:35.284672+00', '2026-10-23 16:45:35.283801+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('55cbd33e-a069-4b7a-8801-3b8773b76d2d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 4.000, NULL, 'done', 'document', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:35.342521+00', '2026-10-23 16:45:35.342523+00', '2026-10-23 16:45:35.342268+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('9e33ee75-a880-4adc-8b0a-ef98f0fb0ed3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, 10.000, NULL, 'done', 'document', '235e0124-96fe-461a-bef5-3e365fc4226c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:35.567213+00', '2026-10-23 16:45:35.567215+00', '2026-10-23 16:45:35.566904+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('58bc4035-a40f-4caf-9edf-a3e6f03ab31f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL, 5.000, NULL, 'done', 'document', '235e0124-96fe-461a-bef5-3e365fc4226c', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:35.617625+00', '2026-10-23 16:45:35.617626+00', '2026-10-23 16:45:35.617439+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('d7624433-a4ae-4eca-a556-3284c44b6254', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL, 26.400, NULL, 'done', 'maker_production', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.023921+00', '2026-10-23 16:45:36.023922+00', '2026-10-23 16:45:36.023178+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('a4ac214f-edaf-4c2c-828a-92de7b5a97ae', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', NULL, 3.780, NULL, 'done', 'maker_production', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.062426+00', '2026-10-23 16:45:36.062427+00', '2026-10-23 16:45:36.062241+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('c17ba198-6e97-4a45-80cf-c3efee130fad', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '543f25e9-9572-4b44-a548-fc2878ca5324', 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', NULL, 0.060, NULL, 'done', 'maker_production', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.089481+00', '2026-10-23 16:45:36.089482+00', '2026-10-23 16:45:36.089296+00', NULL, NULL);
INSERT INTO public.stock_moves (id, organization_id, product_template_id, from_location_id, to_location_id, quantity, lot_id, state, reference_type, reference_id, created_by, created_at, updated_at, completed_at, owner_id, expiry_date) VALUES ('a76f7952-f1df-4c60-8edb-2e1c5906fd7d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', NULL, 'e45ba619-6cdd-4d90-9c01-d6d253e1cd14', 11.400, NULL, 'done', 'maker_production', '86b1825d-45ab-490c-b87c-d1e5d98798bc', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '2026-10-23 16:45:36.120662+00', '2026-10-23 16:45:36.120664+00', '2026-10-23 16:45:36.120449+00', NULL, NULL);


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_closed_locations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_counts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_take_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('adac3a21-99a8-4185-91d4-eb9e1f8cdeca', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', '18bbc0bd-152b-496a-bcd5-ebbd871d732f', 'Soy Sauce', 'Harvest Row', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 8.000, 7.000, NULL, NULL, NULL, 1, '2026-10-23 16:45:36.176311+00', '2026-10-23 16:45:36.176316+00', 'MISCOUNT', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('ae71c879-8efc-418c-8d22-de20e48ce719', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', '48995c7f-6593-42ba-9746-8ad8c11b9a92', 'Ground Ginger', 'Saltmill', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 1.000, 1.000, NULL, NULL, NULL, 0, '2026-10-23 16:45:36.176317+00', '2026-10-23 16:45:36.176318+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('13f4a101-3e5b-4842-9aaa-da8f052fbeeb', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', '9bed0320-0c03-46a9-86ec-c14b4fe7402b', 'Chicken Stock', 'Harvest Row', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 2.000, 2.000, NULL, NULL, NULL, 0, '2026-10-23 16:45:36.176319+00', '2026-10-23 16:45:36.176319+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('51ea8df4-e76a-4c51-8eea-40630e915d80', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', '627c3448-cedc-4e9e-b7de-3bc5b9174918', 'Spaghetti 500g', 'Harvest Row', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 6.000, 4.000, NULL, NULL, NULL, 1, '2026-10-23 16:45:36.17632+00', '2026-10-23 16:45:36.17632+00', 'DAMAGE', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('03dbfb6e-0654-47e7-9d1b-7b31c6d65d08', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', '295d6c19-1630-4150-8c31-2caf691e2cac', 'Strawberry Jam', 'Orchard & Oak', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 8.000, 8.000, NULL, NULL, NULL, 0, '2026-10-23 16:45:36.176321+00', '2026-10-23 16:45:36.176321+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('35b7c500-02fc-4bdb-addc-7af78f312798', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', 'e0d39c7d-33b2-41ea-a30a-d62a8f3cd5a6', 'Granulated Garlic', 'Saltmill', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 3.000, 4.000, NULL, NULL, NULL, 1, '2026-10-23 16:45:36.176322+00', '2026-10-23 16:45:36.176322+00', 'WRONG_LOCATION', false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('93551d7c-81d5-40b9-a29b-e34241c1438f', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', 'f9fc0629-de1f-49ca-90d2-de22cdf9810e', 'Tomato Passata', 'Harvest Row', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 3.000, 3.000, NULL, NULL, NULL, 0, '2026-10-23 16:45:36.176323+00', '2026-10-23 16:45:36.176324+00', NULL, false, NULL, NULL);
INSERT INTO public.stock_take_items (id, stock_take_id, item_id, item_name, item_brand, uom_id, assignee_id, lot_id, system_quantity, counted_quantity, location_in_storage, notes, discrepancy_reason, is_discrepancy, created_at, updated_at, discrepancy_reason_code, recount_requested, storage_location_id, expected_location_id) VALUES ('dfa2d0de-33f5-4b1f-b61f-461ca8a67953', 'aa05523f-f6f5-49e7-86e3-9fb82f7fd967', 'ea4e5de8-8074-45c7-b7e4-2e0cb0c4cce0', 'Tomato Passata', 'Harvest Row', 'f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, NULL, 5.000, 5.000, NULL, NULL, NULL, 0, '2026-10-23 16:45:36.176324+00', '2026-10-23 16:45:36.176325+00', NULL, false, NULL, NULL);


--
-- Data for Name: stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_takes (id, user_id, organization_id, storage_location_id, name, description, status, started_at, completed_at, notes, blind_mode, require_full_count, tolerance_percent, deleted_at, created_at, updated_at, schedule_id, adjustment_document_id) VALUES ('aa05523f-f6f5-49e7-86e3-9fb82f7fd967', '3f56745b-168d-495f-ae6b-57e85c48c2f5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', 'Dry Goods count', 'Quarterly count of the dry goods shelves.', 'completed', '2026-10-20 14:45:36.170824+00', '2026-10-20 16:45:36.170834+00', NULL, false, true, 2.00, NULL, '2026-10-23 16:45:36.17168+00', '2026-10-23 16:45:36.380266+00', NULL, NULL);


--
-- Data for Name: stock_valuation_layers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('edddec66-6f61-4d55-9760-1b0392166199', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, 1.000, 1.000, 3400.0000, 3400.00, 'IN', '2026-10-23 16:45:32.401395+00', 'USD', NULL, NULL, 'stated', '2023-09-06');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1f299893-75e5-4015-9237-54c5a0d11303', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, 1.000, 1.000, 4600.0000, 4600.00, 'IN', '2026-10-23 16:45:32.418914+00', 'USD', NULL, NULL, 'stated', '2023-10-07');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('93a5bd78-07a9-4c33-be5f-814ad1029860', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.426819+00', 'USD', NULL, NULL, 'stated', '2023-10-09');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('d3540a20-e87c-4cce-9a3e-8c7c52b8a4c1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '113aa38b-98d4-44a1-be3e-0f16882f1456', NULL, 1.000, 1.000, 1600.0000, 1600.00, 'IN', '2026-10-23 16:45:32.435335+00', 'USD', NULL, NULL, 'stated', '2023-11-09');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('e9fa3f70-5dc3-422b-b2b0-cf0c101c1909', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', NULL, 1.000, 1.000, 650.0000, 650.00, 'IN', '2026-10-23 16:45:32.444557+00', 'USD', NULL, NULL, 'stated', '2023-11-11');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c68d1368-3034-4477-a6a9-af7f72fd702f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, 1.000, 1.000, 3400.0000, 3400.00, 'IN', '2026-10-23 16:45:32.453388+00', 'USD', NULL, NULL, 'stated', '2023-12-12');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('070c4a6d-d834-4d64-994b-3ff534b99d2a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'dd14c900-66d6-4099-8d85-1175319e8b7b', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.459892+00', 'USD', NULL, NULL, 'stated', '2023-12-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('45f25dff-e1d3-47c2-b66e-5785f5fd2d64', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, 1.000, 1.000, 4600.0000, 4600.00, 'IN', '2026-10-23 16:45:32.466661+00', 'USD', NULL, NULL, 'stated', '2024-01-12');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('e5edf140-90d6-4ec6-91fe-b7dbd993313f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.479195+00', 'USD', NULL, NULL, 'stated', '2024-01-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('2924ef8e-2865-4843-b244-44a78ccd321d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '91ffd7bf-4033-4656-aa36-f1034b7c0141', NULL, 1.000, 1.000, 2100.0000, 2100.00, 'IN', '2026-10-23 16:45:32.48668+00', 'USD', NULL, NULL, 'stated', '2024-02-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1494cfc6-3604-4084-9702-b2fbcfd83433', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 1.000, 1.000, 350.0000, 350.00, 'IN', '2026-10-23 16:45:32.494266+00', 'USD', NULL, NULL, 'stated', '2024-02-16');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('d69e57ee-68ed-44a8-8cfc-105473af4602', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, 1.000, 1.000, 3400.0000, 3400.00, 'IN', '2026-10-23 16:45:32.501815+00', 'USD', NULL, NULL, 'stated', '2024-03-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('5a6a9541-590e-431e-ba85-3deb679d3866', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd004ef0b-2410-4a4c-8068-b685e38a1570', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.509637+00', 'USD', NULL, NULL, 'stated', '2024-03-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('f1a91c25-7990-4b15-8f2a-7ea691821e29', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ded630c1-2384-4eda-b549-77304d5b061f', NULL, 1.000, 1.000, 9500.0000, 9500.00, 'IN', '2026-10-23 16:45:32.516656+00', 'USD', NULL, NULL, 'stated', '2024-04-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('4136c93a-035d-4429-b57d-c59d42d53941', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9a457f48-ab83-4c41-9d59-77286f59c20d', NULL, 1.000, 1.000, 950.0000, 950.00, 'IN', '2026-10-23 16:45:32.523071+00', 'USD', NULL, NULL, 'stated', '2024-04-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c7c8d3e9-ea4d-44d3-badc-f42c006be3b4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '94d90f8e-ee00-4048-b247-70596dfe32ec', NULL, 1.000, 1.000, 3600.0000, 3600.00, 'IN', '2026-10-23 16:45:32.529544+00', 'USD', NULL, NULL, 'stated', '2024-05-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('8c4cd94f-0335-487b-ad03-7d8761f32aa4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 1.000, 1.000, 350.0000, 350.00, 'IN', '2026-10-23 16:45:32.535984+00', 'USD', NULL, NULL, 'stated', '2024-05-23');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('21531c6e-b63c-4442-b459-c713b5bacd46', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9d3aaf76-139c-42fd-a110-dd326335cd7f', NULL, 1.000, 1.000, 3800.0000, 3800.00, 'IN', '2026-10-23 16:45:32.543141+00', 'USD', NULL, NULL, 'stated', '2024-06-23');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1638bef4-fbc8-4ce3-b0b2-4412c03b1868', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd004ef0b-2410-4a4c-8068-b685e38a1570', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.554941+00', 'USD', NULL, NULL, 'stated', '2024-06-25');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('b65c89ff-bfad-4878-8cca-606182bbdbe7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ded630c1-2384-4eda-b549-77304d5b061f', NULL, 1.000, 1.000, 9500.0000, 9500.00, 'IN', '2026-10-23 16:45:32.562053+00', 'USD', NULL, NULL, 'stated', '2024-07-24');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('391f02a5-3475-4712-91b2-4b4846e9831b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9a457f48-ab83-4c41-9d59-77286f59c20d', NULL, 1.000, 1.000, 950.0000, 950.00, 'IN', '2026-10-23 16:45:32.569379+00', 'USD', NULL, NULL, 'stated', '2024-07-26');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1adb31b9-2077-4349-b3f6-8e14cc5fab3a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ace5920e-c8d3-43bd-94b7-3b832bc1e18a', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.582112+00', 'USD', NULL, NULL, 'stated', '2024-08-26');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('cb80d103-6410-4e9c-8b5a-0bbc36ffffe9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 1.000, 1.000, 350.0000, 350.00, 'IN', '2026-10-23 16:45:32.589344+00', 'USD', NULL, NULL, 'stated', '2024-08-28');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('14e5fcb7-da7f-4964-b9f8-167507f64325', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9d3aaf76-139c-42fd-a110-dd326335cd7f', NULL, 1.000, 1.000, 3800.0000, 3800.00, 'IN', '2026-10-23 16:45:32.596398+00', 'USD', NULL, NULL, 'stated', '2024-09-28');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('5dfc79f5-11f7-4e59-be4b-89a6b1b6383a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', NULL, 1.000, 1.000, 18000.0000, 18000.00, 'IN', '2026-10-23 16:45:32.602859+00', 'USD', NULL, NULL, 'stated', '2024-09-30');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('fb12ae66-66c8-4cf2-9dfd-e4453f63a099', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 1.000, 1.000, 5800.0000, 5800.00, 'IN', '2026-10-23 16:45:32.609403+00', 'USD', NULL, NULL, 'stated', '2024-10-29');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('2b0747aa-2193-48d9-9bc1-941303c31943', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', NULL, 1.000, 1.000, 3200.0000, 3200.00, 'IN', '2026-10-23 16:45:32.616338+00', 'USD', NULL, NULL, 'stated', '2024-10-31');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('d2104ebe-d159-4f9c-bfef-4f5623721577', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 1.000, 1.000, 3200.0000, 3200.00, 'IN', '2026-10-23 16:45:32.626922+00', 'USD', NULL, NULL, 'stated', '2024-12-01');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('a71e3ec7-d025-4030-bafb-e608d6c3c1f5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'fa1a6de1-1dcb-4304-a5cf-c3882ee08cb6', NULL, 1.000, 1.000, 350.0000, 350.00, 'IN', '2026-10-23 16:45:32.633584+00', 'USD', NULL, NULL, 'stated', '2024-12-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('4ecce2a3-42a3-480b-ac80-7e01d0116f43', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 1.000, 1.000, 5200.0000, 5200.00, 'IN', '2026-10-23 16:45:32.640075+00', 'USD', NULL, NULL, 'stated', '2025-01-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('5a8d8980-6cc9-4306-bb46-0f60f371a1d5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', NULL, 1.000, 1.000, 18000.0000, 18000.00, 'IN', '2026-10-23 16:45:32.646786+00', 'USD', NULL, NULL, 'stated', '2025-01-05');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('9a11a64a-8db1-4290-a195-4403a5be0ed4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 1.000, 1.000, 5800.0000, 5800.00, 'IN', '2026-10-23 16:45:32.653183+00', 'USD', NULL, NULL, 'stated', '2025-02-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('b36c56ad-a517-4752-909d-87a1f1b4062d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2de1ab9e-40cd-4938-ae62-72aedc7c9c69', NULL, 1.000, 1.000, 3200.0000, 3200.00, 'IN', '2026-10-23 16:45:32.659835+00', 'USD', NULL, NULL, 'stated', '2025-02-05');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('357eca3f-5669-44a0-b07d-e3fa741caed7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 1.000, 1.000, 3200.0000, 3200.00, 'IN', '2026-10-23 16:45:32.666535+00', 'USD', NULL, NULL, 'stated', '2025-03-08');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('40a5c3fe-2e36-432f-87c5-3025303a5998', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '82d76422-6692-4b34-8c43-28faecac65b2', NULL, 1.000, 1.000, 400.0000, 400.00, 'IN', '2026-10-23 16:45:32.672841+00', 'USD', NULL, NULL, 'stated', '2025-03-10');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('08308cee-c5a9-4db4-9ccd-2beafbd21bf2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 1.000, 1.000, 5200.0000, 5200.00, 'IN', '2026-10-23 16:45:32.679271+00', 'USD', NULL, NULL, 'stated', '2025-04-10');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('cecb6def-0948-49bc-a1b9-5b5451f1d07b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a84ce6f6-41ac-4148-a90a-22d5a9af2895', NULL, 1.000, 1.000, 18000.0000, 18000.00, 'IN', '2026-10-23 16:45:32.685268+00', 'USD', NULL, NULL, 'stated', '2025-04-12');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('7a62366b-d1e3-4607-9803-cd30db58021e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', NULL, 1.000, 1.000, 5800.0000, 5800.00, 'IN', '2026-10-23 16:45:32.691239+00', 'USD', NULL, NULL, 'stated', '2025-05-11');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('a2d7c8ac-6078-455d-87b9-0ad2ad47833e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 1.000, 1.000, 8500.0000, 8500.00, 'IN', '2026-10-23 16:45:32.697366+00', 'USD', NULL, NULL, 'stated', '2025-05-13');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('7fc2f5bb-fab8-46ed-85ab-98ff9804561c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 1.000, 1.000, 3200.0000, 3200.00, 'IN', '2026-10-23 16:45:32.7035+00', 'USD', NULL, NULL, 'stated', '2025-06-13');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('4e97c457-993d-417a-993e-40e852e994d6', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e4a5228-a241-4e74-9a87-04fcf582a329', NULL, 1.000, 1.000, 450.0000, 450.00, 'IN', '2026-10-23 16:45:32.709464+00', 'USD', NULL, NULL, 'stated', '2025-06-15');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('bbd35b61-0673-44fd-bb72-9e8c93e403fa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 1.000, 1.000, 5200.0000, 5200.00, 'IN', '2026-10-23 16:45:32.715305+00', 'USD', NULL, NULL, 'stated', '2025-07-16');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('d1324d6a-68bb-4553-92ed-c0d551cdb55e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10deef65-5690-4f50-9510-cfa4ff2d502c', NULL, 1.000, 1.000, 32000.0000, 32000.00, 'IN', '2026-10-23 16:45:32.721368+00', 'USD', NULL, NULL, 'stated', '2025-07-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('d9e0511a-c16c-4185-bb15-ca16ea64b585', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.730368+00', 'USD', NULL, NULL, 'stated', '2025-08-16');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('edb59187-eabc-4198-9c20-fd2e52646877', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 1.000, 1.000, 8500.0000, 8500.00, 'IN', '2026-10-23 16:45:32.73707+00', 'USD', NULL, NULL, 'stated', '2025-08-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('dc8bdcca-dbd3-47c7-aefb-df667b34809d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a139a2dd-a867-4b3f-b7fa-b290acdb5262', NULL, 1.000, 1.000, 3200.0000, 3200.00, 'IN', '2026-10-23 16:45:32.743813+00', 'USD', NULL, NULL, 'stated', '2025-09-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('24b08e9a-c9e6-4d62-96d5-a93c0432a0ce', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8e4a5228-a241-4e74-9a87-04fcf582a329', NULL, 1.000, 1.000, 450.0000, 450.00, 'IN', '2026-10-23 16:45:32.750404+00', 'USD', NULL, NULL, 'stated', '2025-09-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('23fc142e-5c07-436e-a6c2-4ba75a3ab55a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2d29fe1c-bfb6-48b5-9faf-4f909223cb09', NULL, 1.000, 1.000, 5200.0000, 5200.00, 'IN', '2026-10-23 16:45:32.757738+00', 'USD', NULL, NULL, 'stated', '2025-10-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('50a2ca3e-c019-4381-97cf-bd18c88c83c8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '10deef65-5690-4f50-9510-cfa4ff2d502c', NULL, 1.000, 1.000, 32000.0000, 32000.00, 'IN', '2026-10-23 16:45:32.764267+00', 'USD', NULL, NULL, 'stated', '2025-10-23');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('cb628a46-787c-4dd1-94df-4aa956ec2b1e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.770728+00', 'USD', NULL, NULL, 'stated', '2025-11-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('2c19a0b5-8802-4587-92fd-3df9e2556909', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 1.000, 1.000, 8500.0000, 8500.00, 'IN', '2026-10-23 16:45:32.777222+00', 'USD', NULL, NULL, 'stated', '2025-11-23');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('a099856b-19fb-4a1b-a6ef-52a4f69e242f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, 1.000, 1.000, 4600.0000, 4600.00, 'IN', '2026-10-23 16:45:32.784106+00', 'USD', NULL, NULL, 'stated', '2025-12-24');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('fdd4f60d-235b-4d27-8cb8-199e4a344a58', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.790697+00', 'USD', NULL, NULL, 'stated', '2025-12-26');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('2a034904-dd0a-4c1b-82cc-cac715aff2ac', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', NULL, 1.000, 1.000, 1400.0000, 1400.00, 'IN', '2026-10-23 16:45:32.79723+00', 'USD', NULL, NULL, 'stated', '2026-01-26');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('dd8b8f8d-7152-4d27-aed8-754e0268bb5f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4fe1ef8f-389b-478e-a8cd-420ccbeeb010', NULL, 1.000, 1.000, 28000.0000, 28000.00, 'IN', '2026-10-23 16:45:32.803641+00', 'USD', NULL, NULL, 'stated', '2026-01-28');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('9b13dd71-8cdf-43e5-88fa-b5a564101fbe', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.810341+00', 'USD', NULL, NULL, 'stated', '2026-02-26');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('e370f159-88ce-4fe1-97f3-71e09be026fa', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '795801f3-98f0-40c7-8654-15134aaa9097', NULL, 1.000, 1.000, 8500.0000, 8500.00, 'IN', '2026-10-23 16:45:32.817125+00', 'USD', NULL, NULL, 'stated', '2026-02-28');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1a886910-792d-4427-8a42-8bc740f01c8c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, 1.000, 1.000, 4600.0000, 4600.00, 'IN', '2026-10-23 16:45:32.824867+00', 'USD', NULL, NULL, 'stated', '2026-03-31');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('9bff8c61-be22-4efd-89dd-3200dc62cd58', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.832103+00', 'USD', NULL, NULL, 'stated', '2026-04-02');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('6c7d1d9e-db3b-4667-807b-c0a75674cd7f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', NULL, 1.000, 1.000, 1400.0000, 1400.00, 'IN', '2026-10-23 16:45:32.838831+00', 'USD', NULL, NULL, 'stated', '2026-05-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('e65dee4a-479b-4181-95c5-5b6f7dba3068', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', NULL, 1.000, 1.000, 650.0000, 650.00, 'IN', '2026-10-23 16:45:32.845842+00', 'USD', NULL, NULL, 'stated', '2026-05-05');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('3a4311c7-a99a-44c6-a470-98087328c7bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.852935+00', 'USD', NULL, NULL, 'stated', '2026-06-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('95766f42-b3d5-4c12-8d9a-ddc4c9bb7abd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'acd839b8-ec68-4f09-b952-9bcb7da27b46', NULL, 1.000, 1.000, 3400.0000, 3400.00, 'IN', '2026-10-23 16:45:32.865173+00', 'USD', NULL, NULL, 'stated', '2026-06-05');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c75107cd-1e72-49be-a815-d476eaf851bc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '11a51a5e-082b-4e76-900c-12421b9fca6d', NULL, 1.000, 1.000, 4600.0000, 4600.00, 'IN', '2026-10-23 16:45:32.872147+00', 'USD', NULL, NULL, 'stated', '2026-07-06');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1b8bc270-d5b9-49bd-b3de-5aa282700835', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cce012c7-dc22-43f4-94ca-1510c4305d92', NULL, 1.000, 1.000, 2800.0000, 2800.00, 'IN', '2026-10-23 16:45:32.879189+00', 'USD', NULL, NULL, 'stated', '2026-07-08');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('5af02dba-bdd0-4ed8-97b7-6482f0a61726', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5f510017-5366-4204-afc9-f2e6282c6261', NULL, 1.000, 1.000, 1400.0000, 1400.00, 'IN', '2026-10-23 16:45:32.886191+00', 'USD', NULL, NULL, 'stated', '2026-08-08');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('42c0e3e3-05ef-4a53-8b67-bfcd8948393d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3686c9ba-d583-49a5-abe1-a0f8cbfe16ec', NULL, 1.000, 1.000, 650.0000, 650.00, 'IN', '2026-10-23 16:45:32.892737+00', 'USD', NULL, NULL, 'stated', '2026-08-10');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c79ed9fa-7998-4012-945b-22f120b28126', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', NULL, 1.000, 1.000, 4200.0000, 4200.00, 'IN', '2026-10-23 16:45:32.899025+00', 'USD', NULL, NULL, 'stated', '2026-09-08');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('7fd44428-5188-47da-af3d-cd80bcea695a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cc4a417a-a291-477b-ad60-37812ee87741', NULL, 8.000, 8.000, 4.9700, 39.76, 'IN', '2026-10-23 16:45:32.907196+00', 'USD', NULL, NULL, 'stated', '2026-10-16');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('9ee9dd3d-d97e-4c52-81af-8536f212fca4', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0c90caa3-cd77-4a17-865c-1a2bd0f87f81', NULL, 4.300, 4.300, 5.6500, 24.30, 'IN', '2026-10-23 16:45:32.914653+00', 'USD', NULL, NULL, 'stated', '2026-10-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('58e702f6-e330-4eaf-843a-6e481b53e39c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', NULL, 1.000, 1.000, 5.6900, 5.69, 'IN', '2026-10-23 16:45:32.922361+00', 'USD', NULL, NULL, 'stated', '2026-09-24');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('19b24819-1ffe-480b-8255-c38de3e067bd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '23e939a9-42a2-4e13-a42d-0e6cea0e7acd', NULL, 2.000, 2.000, 4.3500, 8.70, 'IN', '2026-10-23 16:45:32.930005+00', 'USD', NULL, NULL, 'stated', '2026-09-13');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('8aa7b2d4-8e67-4915-9e0a-9a335f68a1d9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 6.000, 6.000, 5.3900, 32.34, 'IN', '2026-10-23 16:45:32.93786+00', 'USD', NULL, NULL, 'stated', '2026-09-02');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('8b8b4f86-ed4e-4fc8-b207-42ebe447e4fd', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a7fca96a-563b-47f4-a449-292eca81f87b', NULL, 8.000, 8.000, 4.4900, 35.92, 'IN', '2026-10-23 16:45:32.945703+00', 'USD', NULL, NULL, 'stated', '2026-08-22');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('7171a4e0-59b1-4807-97b2-ee1fe9cab70b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a1d8635b-fe0a-48fb-970d-672422f8d5e6', NULL, 3.000, 3.000, 5.0300, 15.09, 'IN', '2026-10-23 16:45:32.95323+00', 'USD', NULL, NULL, 'stated', '2026-10-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('47f9bb44-ccfd-4b4e-9d3c-5dfdf25fb944', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c0e9f75c-42fb-4d2e-82a3-562304bf0d7f', NULL, 7.000, 7.000, 5.1000, 35.70, 'IN', '2026-10-23 16:45:32.960835+00', 'USD', NULL, NULL, 'stated', '2026-10-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('3d2c7dd6-b5ec-4c3a-8154-b9de9d36d29b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', NULL, 3.000, 3.000, 4.5600, 13.68, 'IN', '2026-10-23 16:45:32.968179+00', 'USD', NULL, NULL, 'stated', '2026-09-22');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c3cd176d-c5d7-42d5-a494-4c8a5cab6d1d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', NULL, 5.000, 5.000, 5.6000, 28.00, 'IN', '2026-10-23 16:45:32.975953+00', 'USD', NULL, NULL, 'stated', '2026-09-11');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('142e73b7-d75e-46ed-8a0e-bd679a8d669a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', NULL, 2.000, 2.000, 5.7500, 11.50, 'IN', '2026-10-23 16:45:32.985057+00', 'USD', NULL, NULL, 'stated', '2026-10-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('f13b215a-a59f-4ddc-b235-6695f668171d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', NULL, 7.000, 7.000, 5.0600, 35.42, 'IN', '2026-10-23 16:45:32.992578+00', 'USD', NULL, NULL, 'stated', '2026-08-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('8f00d541-4c04-4b8c-96d0-6588e6778960', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4bc73840-44dc-4a70-97b8-f449a586d57e', NULL, 5.000, 5.000, 5.2500, 26.25, 'IN', '2026-10-23 16:45:32.999871+00', 'USD', NULL, NULL, 'stated', '2026-10-12');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('ceff731a-6406-473b-bb2b-1ea75df767a9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0916de9c-f9f8-409c-96ef-6d7e08837fa8', NULL, 1.000, 1.000, 4.7200, 4.72, 'IN', '2026-10-23 16:45:33.007578+00', 'USD', NULL, NULL, 'stated', '2026-10-17');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('03792540-01ca-4bf3-9237-725a0e5f4aa2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '2201036f-39da-4e0e-bb94-c675770c9438', NULL, 9.000, 9.000, 5.0400, 45.36, 'IN', '2026-10-23 16:45:33.015637+00', 'USD', NULL, NULL, 'stated', '2026-09-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c16335ef-bdf4-41e9-aa54-12a3f52e194f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '40fd9e1e-6c0c-4f63-851b-3a35fbe1d8ac', NULL, 1.000, 1.000, 5.5500, 5.55, 'IN', '2026-10-23 16:45:33.023285+00', 'USD', NULL, NULL, 'stated', '2026-09-09');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('ebac7ea2-9048-4377-8e2e-3f7160c7a7a8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '707d1613-0643-4f34-b3ec-c8229a6a9aa9', NULL, 5.000, 5.000, 4.5500, 22.75, 'IN', '2026-10-23 16:45:33.030986+00', 'USD', NULL, NULL, 'stated', '2026-08-29');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('944cb410-38dc-4fd3-b486-b75ad47daf30', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', NULL, 8.000, 8.000, 5.6500, 45.20, 'IN', '2026-10-23 16:45:33.038364+00', 'USD', NULL, NULL, 'stated', '2026-10-17');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('f27331d7-6cdc-4b82-98ee-53ca65a4153b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f612f610-95b6-4dab-9644-c2594d96430f', NULL, 6.000, 6.000, 5.2800, 31.68, 'IN', '2026-10-23 16:45:33.050511+00', 'USD', NULL, NULL, 'stated', '2026-10-10');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('3d926885-344e-436e-91ba-03f410361e94', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '93156300-273c-4504-9d73-82c9cba20044', NULL, 5.000, 5.000, 4.5900, 22.95, 'IN', '2026-10-23 16:45:33.058295+00', 'USD', NULL, NULL, 'stated', '2026-09-29');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('5a0a96e8-f9d2-46c7-86e0-eeec402894ff', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 7.000, 7.000, 5.2300, 36.61, 'IN', '2026-10-23 16:45:33.066244+00', 'USD', NULL, NULL, 'stated', '2026-09-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('2c6b95cf-ec96-49f5-832b-2e01893e0c90', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '02b8cd00-e818-4a00-b200-7edfa26cc2cb', NULL, 5.000, 5.000, 5.4300, 27.15, 'IN', '2026-10-23 16:45:33.074312+00', 'USD', NULL, NULL, 'stated', '2026-09-07');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('4cf13500-8405-49f3-9134-edc0d3a1c188', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '158f1823-7f6c-40da-bd8d-eb16a099d38b', NULL, 8.000, 8.000, 4.2800, 34.24, 'IN', '2026-10-23 16:45:33.081866+00', 'USD', NULL, NULL, 'stated', '2026-08-27');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('8a3c2d3a-6b68-4f3e-a233-5699b4f5c618', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c5e23a58-4fcc-486f-ab6a-467242fec15c', NULL, 7.000, 7.000, 5.0600, 35.42, 'IN', '2026-10-23 16:45:33.092043+00', 'USD', NULL, NULL, 'stated', '2026-10-17');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('e4dca063-0828-4e18-9537-024ee935d390', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 10.000, 10.000, 5.4700, 54.70, 'IN', '2026-10-23 16:45:33.099868+00', 'USD', NULL, NULL, 'stated', '2026-10-08');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('8955665b-97e7-409f-bfca-9786bb995284', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b5cb650b-8a22-4d66-965e-d24dceaa0379', NULL, 2.000, 2.000, 5.5100, 11.02, 'IN', '2026-10-23 16:45:33.107196+00', 'USD', NULL, NULL, 'stated', '2026-10-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('9d0cfd49-c8a1-4b72-9960-a2790384f529', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'e6a22858-75a9-491e-9dc3-420226894ee0', NULL, 5.000, 5.000, 4.4400, 22.20, 'IN', '2026-10-23 16:45:33.114788+00', 'USD', NULL, NULL, 'stated', '2026-10-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('ed009ab4-c32f-4ea3-bd75-7be2eb9f59a2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6445c742-2b9a-4c27-be83-845a74fbbe23', NULL, 8.000, 8.000, 5.5000, 44.00, 'IN', '2026-10-23 16:45:33.12776+00', 'USD', NULL, NULL, 'stated', '2026-09-05');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('a49b780e-2028-4d2c-a8c8-18744629082b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'aee53ac2-5a8d-4cf2-b8c7-8871db10eb60', NULL, 9.000, 9.000, 5.4900, 49.41, 'IN', '2026-10-23 16:45:33.135488+00', 'USD', NULL, NULL, 'stated', '2026-08-25');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('57f5e864-ca2d-42b8-88f9-69f7fc8b9eb1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'cf3acca4-5c34-494d-8ed3-00af16098627', NULL, 6.000, 6.000, 4.9700, 29.82, 'IN', '2026-10-23 16:45:33.143077+00', 'USD', NULL, NULL, 'stated', '2026-08-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('4186f326-c3eb-449d-a175-c4b7a97a8496', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a757c372-a4a9-4cf8-9733-a7c0ae6274a1', NULL, 3.000, 3.000, 4.9900, 14.97, 'IN', '2026-10-23 16:45:33.150721+00', 'USD', NULL, NULL, 'stated', '2026-10-06');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('95b3116c-a8bc-42c8-a28e-02b894445c69', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1c1feba-6e1d-4691-9e7c-d68f2daba2e9', NULL, 7.000, 7.000, 5.2000, 36.40, 'IN', '2026-10-23 16:45:33.158239+00', 'USD', NULL, NULL, 'stated', '2026-09-25');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('dc2b281c-c2c9-4127-8a7b-1052cfde91ba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '57298474-a0b7-4c3a-b9dc-d1f5743251fe', NULL, 10.000, 10.000, 4.2800, 42.80, 'IN', '2026-10-23 16:45:33.166679+00', 'USD', NULL, NULL, 'stated', '2026-09-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('38c411cd-fa74-4929-9c53-286a2539476d', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '5b2f9e38-61d6-407a-8df2-3739042bbe79', NULL, 3.000, 3.000, 5.1400, 15.42, 'IN', '2026-10-23 16:45:33.175846+00', 'USD', NULL, NULL, 'stated', '2026-09-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('2f8a7f74-35cd-4572-a849-9954e3bd7b93', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1f160de2-c8bd-4710-bd24-618f056b1e05', NULL, 8.600, 8.600, 5.2300, 44.98, 'IN', '2026-10-23 16:45:33.190962+00', 'USD', NULL, NULL, 'stated', '2026-10-18');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('9b05e85c-16c8-41f5-a90e-49f0945a1ef2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3cb1142f-c864-4117-bc3a-cd753c0bfb69', NULL, 3.000, 3.000, 5.2700, 15.81, 'IN', '2026-10-23 16:45:33.198549+00', 'USD', NULL, NULL, 'stated', '2026-10-15');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('daa0eab9-9830-479c-a566-bda90e9364c1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '7e5233ae-eb17-495d-b280-8556ff16caba', NULL, 1.000, 1.000, 4.3200, 4.32, 'IN', '2026-10-23 16:45:33.211308+00', 'USD', NULL, NULL, 'stated', '2026-10-04');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('709d0303-cc82-47ae-a791-5571ec5a03cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'c9bd85c8-4d70-4ed9-ad2c-b3170dc45a63', NULL, 4.000, 4.000, 4.3600, 17.44, 'IN', '2026-10-23 16:45:33.219889+00', 'USD', NULL, NULL, 'stated', '2026-10-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('7f843d17-dd20-4adc-b531-962174ce64b2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1f160de2-c8bd-4710-bd24-618f056b1e05', NULL, 5.800, 5.800, 5.1000, 29.58, 'IN', '2026-10-23 16:45:33.227353+00', 'USD', NULL, NULL, 'stated', '2026-10-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('0dd01827-2865-42d6-a198-0ba1f984bb8e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ea1a768a-d6a2-4680-a2e1-1b090bc790bd', NULL, 1.000, 1.000, 4.6000, 4.60, 'IN', '2026-10-23 16:45:33.23588+00', 'USD', NULL, NULL, 'stated', '2026-09-01');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('fc1315f6-2064-48f2-acf6-0c76849fa006', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '8122a117-1950-4e6b-8afd-f1462766e3fc', '151061dd-f459-4bd3-981d-1ca1aa60bb68', 5.000, 5.000, 4200.0000, 21000.00, 'IN', '2026-10-23 16:45:33.880663+00', 'USD', NULL, NULL, 'stated', '2026-10-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('f6f99fbd-68f4-4818-93ad-405c9c7b202a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '3a5e2cd8-75a6-4391-9b30-eaf37f2ff4bf', '7313fef2-93d5-48ca-9e5e-8f39e7116f42', 3.000, 3.000, 5800.0000, 17400.00, 'IN', '2026-10-23 16:45:33.901342+00', 'USD', NULL, NULL, 'stated', '2026-10-21');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('cb192fe4-62e9-4317-9506-77e6f8ed01b3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd4d375c2-948d-482d-ae68-02e446edfa8f', '6eb79c7a-8b6a-4f4d-a666-2f8a3aa8e9fe', 24.000, 18.000, 5.2000, 124.80, 'IN', '2026-10-23 16:45:33.737871+00', 'USD', NULL, NULL, 'stated', '2026-10-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('20668039-bd58-4d5f-9bc8-97eaa6864cc5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6e248425-e0de-4710-b84a-3b6a6acd7713', '319fe24b-0b78-48a8-ae2d-b7c1fb1f32e1', 60.000, 50.000, 12.5000, 750.00, 'IN', '2026-10-23 16:45:33.805013+00', 'USD', NULL, NULL, 'stated', '2026-10-16');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('1102ee51-ceca-46b4-a215-3585371cf8cf', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'b2a59eac-a757-40dd-be60-bfec26ce4bcd', 20.000, 15.000, 4.1000, 82.00, 'IN', '2026-10-23 16:45:33.828339+00', 'USD', NULL, NULL, 'stated', '2026-10-16');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('af68b001-0f16-461f-851e-1fcfea6e9819', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', NULL, 40.000, 13.600, 3.4000, 136.00, 'IN', '2026-10-23 16:45:33.24388+00', 'USD', NULL, NULL, 'stated', '2026-10-20');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('f8f9f2be-733a-428d-812a-42807a826f2b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', NULL, 25.000, 21.220, 1.1000, 27.50, 'IN', '2026-10-23 16:45:33.263662+00', 'USD', NULL, NULL, 'stated', '2026-10-03');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('096801c2-a209-4128-939f-53f70f06c266', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '543f25e9-9572-4b44-a548-fc2878ca5324', NULL, 0.500, 0.440, 24.0000, 12.00, 'IN', '2026-10-23 16:45:33.272182+00', 'USD', NULL, NULL, 'stated', '2026-09-19');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('a622bb4d-b210-4b3f-b63c-eeca75758610', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', '00ea17d8-0607-4049-b58d-e2d2cf790156', 48.000, 36.000, 4.5000, 216.00, 'IN', '2026-10-23 16:45:33.703846+00', 'USD', NULL, NULL, 'stated', '2026-10-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('3a175efc-41ac-4422-bee0-a9884c59ce29', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f6eb43ba-9fec-4772-ba83-fb547ad16461', 'f1d10947-a638-4a1f-8626-6345aa10869e', 12.000, 0.000, 4.5000, 54.00, 'OUT', '2026-10-23 16:45:33.981196+00', 'USD', NULL, NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('d6129bc0-4473-4135-80b8-68feb376057f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', '0738966d-013a-428e-94ad-e7eaa58b8003', 8.000, 0.000, 8.9000, 71.20, 'OUT', '2026-10-23 16:45:34.029348+00', 'USD', NULL, NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('f0cd5083-c9d3-44fb-9b0d-19865c87a7f8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd4d375c2-948d-482d-ae68-02e446edfa8f', '87650eca-007b-41c1-a405-5f2f190d1779', 6.000, 0.000, 5.2000, 31.20, 'OUT', '2026-10-23 16:45:35.306517+00', 'USD', NULL, NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('c255cd26-93e9-448e-9b55-ddaf09cc4b8c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', 'a8d193e0-0be4-4721-a4f8-e795c168fd4f', 36.000, 24.000, 8.9000, 320.40, 'IN', '2026-10-23 16:45:33.764449+00', 'USD', NULL, NULL, 'stated', '2026-10-14');
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('5731c91e-e88c-4643-bed0-f41274501aec', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '4d9f0f2d-a3ea-4e23-b3c0-0fd7b9e99231', '7f00e27a-9bb8-4f85-a6cf-4f889101f49e', 4.000, 0.000, 8.9000, 35.60, 'OUT', '2026-10-23 16:45:35.349645+00', 'USD', NULL, NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('b3b4b8d1-c690-4335-b7f8-ac0632d89cec', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '6e248425-e0de-4710-b84a-3b6a6acd7713', 'fd15a26d-eb25-4593-90a8-8065fa54cb5a', 10.000, 0.000, 12.5000, 125.00, 'OUT', '2026-10-23 16:45:35.581053+00', 'USD', NULL, NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('74d97b82-1074-4a25-a472-22f9775224c9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '24283c68-c9dd-467a-ae4e-c4ee52291dc4', 'bf3ed67c-b28d-40b5-b26e-8a3e6b0a18ea', 5.000, 0.000, 4.1000, 20.50, 'OUT', '2026-10-23 16:45:35.624861+00', 'USD', NULL, NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('07f071de-206f-4b85-9ade-d7101a09ad38', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'ce2b02d1-16d5-4464-ab65-69c7633f3797', NULL, 26.400, 0.000, 3.4000, 89.76, 'OUT', '2026-10-23 16:45:36.040343+00', 'USD', 'USED', NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('90bf52b4-1e0a-4a33-bcf8-3bcbd6d47f96', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0ab48b73-76fb-4c25-aba6-265cd6b253f9', NULL, 3.780, 0.000, 1.1000, 4.16, 'OUT', '2026-10-23 16:45:36.068189+00', 'USD', 'USED', NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('6261bd0b-0e29-44af-b77a-28dc26bb03db', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '543f25e9-9572-4b44-a548-fc2878ca5324', NULL, 0.060, 0.000, 24.0000, 1.44, 'OUT', '2026-10-23 16:45:36.095177+00', 'USD', 'USED', NULL, 'fifo', NULL);
INSERT INTO public.stock_valuation_layers (id, organization_id, product_template_id, document_line_id, quantity, remaining_qty, unit_cost, total_value, direction, created_at, currency, reason, item_id, cost_basis, document_date) VALUES ('61081d06-03c5-4a07-aa60-8da710c5e8dc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f1beac56-0318-4b69-a037-8ee13b25ee76', NULL, 11.400, 11.400, 8.3647, 95.36, 'IN', '2026-10-23 16:45:36.125528+00', 'USD', NULL, NULL, 'stated', NULL);


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('f62b967a-66d2-419c-96f7-79ca6c173ea7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, NULL, '[]', 'STOCK', '[]', 'Main Warehouse', 'Receiving and dispatch — shared by every module', NULL, NULL, 'internal', NULL, '{"seed": {"code": "MAIN_WAREHOUSE", "name": "Main Warehouse"}}', NULL, '2026-10-23 16:45:31.359873+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 1);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('287338dd-e36a-4109-9706-abc0b729ffef', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, NULL, '[]', 'NONE', '[]', 'Server Room', 'Primary server room / data center', NULL, NULL, 'internal', 'equipment', '{"seed": {"code": "SERVER_ROOM", "name": "Server Room"}}', NULL, '2026-10-23 16:45:31.359879+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 44);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('3ccadb2a-fcf6-4e9a-9da1-07a162a8bf54', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '92df146f-5fd7-42d2-a146-a4c53da078f7', '[]', 'STOCK', '[]', 'Consumed (Virtual)', NULL, 'System location', NULL, 'customer', NULL, '{"seed": {"code": "CONSUMED_VIRTUAL", "name": "Consumed (Virtual)"}}', NULL, '2026-10-23 16:45:31.412768+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 39);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('680223a0-23c5-4d1b-a179-05abbe379442', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '92df146f-5fd7-42d2-a146-a4c53da078f7', '[]', 'STOCK', '[]', 'Inventory Loss (Virtual)', NULL, 'System location', NULL, 'inventory', NULL, '{"seed": {"code": "LOSS_VIRTUAL", "name": "Inventory Loss (Virtual)"}}', NULL, '2026-10-23 16:45:31.415611+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 41);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('038d1a2b-8536-4441-9729-9fddc3411521', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '85d4cc00-6c99-4d1f-9c58-db5eb9665559', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Workstations', NULL, NULL, 'LOC-KQRX', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.851895+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 34);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('71200bdb-d629-496d-9598-f48cab342502', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, NULL, '[]', 'NONE', '[]', 'IT Storage', 'IT equipment storage and logistics warehouse', NULL, NULL, 'internal', 'equipment', '{"seed": {"code": "IT_STORAGE", "name": "IT Storage"}}', NULL, '2026-10-23 16:45:31.359881+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 40);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('8861fcda-52ac-4685-9f00-17649c98642a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '92df146f-5fd7-42d2-a146-a4c53da078f7', '[]', 'STOCK', '[]', 'Production (Virtual)', NULL, 'System location', NULL, 'production', NULL, '{"seed": {"code": "PRODUCTION_VIRTUAL", "name": "Production (Virtual)"}}', NULL, '2026-10-23 16:45:31.418045+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 42);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('920b58c7-39ea-43b8-8702-ea25eb233cef', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '3dcecc12-7e4f-4a25-a481-497f95bed685', '[]', 'STOCK', '[]', 'Quarantine', NULL, NULL, NULL, 'internal', NULL, '{"seed": {"code": "QUARANTINE", "name": "Quarantine"}}', NULL, '2026-10-23 16:45:31.424576+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 43);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('0af2e08b-ef48-4f5a-8393-d6156d77ca60', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd9388a4f-3bf6-4427-be77-04cee47871eb', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Fridge C', NULL, NULL, 'LOC-7S9I', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.808968+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 7);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('0f0d957d-7140-48c7-b438-5a537ce47f07', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '85d4cc00-6c99-4d1f-9c58-db5eb9665559', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'IT Workshop', NULL, NULL, 'LOC-3K0B', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.845988+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 30);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('1651685e-9233-4cb1-8bec-ee0c0129e4fc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '34820f16-d5d4-4965-9d89-559750108063', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'STOCK', '[]', 'Beverages', NULL, NULL, 'LOC-YDVE', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.828291+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 21);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('272eb045-e16d-48e8-9a21-2f539405d460', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '038d1a2b-8536-4441-9729-9fddc3411521', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Floor 2 - Row B', NULL, NULL, 'LOC-N7HD', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.857104+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 38);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('2df4cc52-efba-41e3-ada5-ba08aa06ce54', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9037f1b-c7e7-4c85-87ef-abc05185ba76', '6c2ad2e8-760b-487e-b0af-52b9e4e5faf1', '[]', 'STOCK', '[]', 'UPS Bay', NULL, NULL, 'LOC-JQ7V', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.843027+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 28);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('33799830-f9a7-4fa6-83c7-6216d3f007db', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Shelf A - Middle', NULL, NULL, 'LOC-K8FZ', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.820934+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 16);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('34820f16-d5d4-4965-9d89-559750108063', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '3dcecc12-7e4f-4a25-a481-497f95bed685', '[]', 'STOCK', '[]', 'Pantry Building', NULL, NULL, 'LOC-A7FW', 'internal', NULL, NULL, NULL, '2026-10-23 16:45:31.816858+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 13);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('38323184-273f-4032-8597-d48a45db1650', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Fridge A - Top Shelf', NULL, NULL, 'LOC-QI41', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.804593+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 4);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('3ec3439d-33dd-4485-b8dd-496290b68ae8', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Fridge A - Door', NULL, NULL, 'LOC-P3LL', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.806079+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 5);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('5c455d0d-c913-45f9-84e4-3bbc34914845', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Shelf B - Top', NULL, NULL, 'LOC-ZRGR', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.823363+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 18);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('6588e3ed-0fc3-4ec0-be21-07fda324cb6e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1651685e-9233-4cb1-8bec-ee0c0129e4fc', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'STOCK', '[]', 'Beverage Rack 1', NULL, NULL, 'LOC-SAX5', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.829665+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 22);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('818c97a7-6560-482f-b172-913acf53f254', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9b4df7f8-2e04-43a4-9c55-7cb2933cbd0a', 'd47eb5fd-b6d8-407b-9638-92e65414432e', '[]', 'FREEZING', '[]', 'Freezer 2', NULL, NULL, 'LOC-BRIA', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.813906+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 11);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('85d4cc00-6c99-4d1f-9c58-db5eb9665559', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', NULL, '3dcecc12-7e4f-4a25-a481-497f95bed685', '[]', 'STOCK', '[]', 'Office Building', NULL, NULL, 'LOC-B4IJ', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.833129+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 24);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('91b1a777-77e2-4c54-af1f-a6ef79dd1f0a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0f0d957d-7140-48c7-b438-5a537ce47f07', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Spare Parts Bin', NULL, NULL, 'LOC-Y5DP', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.850385+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 33);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('9b4df7f8-2e04-43a4-9c55-7cb2933cbd0a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f62b967a-66d2-419c-96f7-79ca6c173ea7', 'd47eb5fd-b6d8-407b-9638-92e65414432e', '[]', 'FREEZING', '[]', 'Freezer Zone', NULL, NULL, 'LOC-9GZI', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.811531+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 9);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd9388a4f-3bf6-4427-be77-04cee47871eb', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Fridge A', NULL, NULL, 'LOC-9GVX', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.802974+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 3);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('a395c81d-3ad5-41a0-83a5-580bd33d8c5b', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Shelf B - Middle', NULL, NULL, 'LOC-R91Q', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.825353+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 19);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('a676029e-6f7e-4946-82c4-648b96093d6f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd9388a4f-3bf6-4427-be77-04cee47871eb', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Walk-in Cooler', NULL, NULL, 'LOC-E2IV', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.81031+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 8);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('a7712e9f-8cf9-4586-bc61-a5af7ae4818f', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '038d1a2b-8536-4441-9729-9fddc3411521', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Floor 1 - Row B', NULL, NULL, 'LOC-W8S4', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.854586+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 36);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('ad55bce4-e2d4-4a36-825e-c627b4bf0357', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9037f1b-c7e7-4c85-87ef-abc05185ba76', '6c2ad2e8-760b-487e-b0af-52b9e4e5faf1', '[]', 'STOCK', '[]', 'Patch Panel', NULL, NULL, 'LOC-NYBP', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.844505+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 29);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('b0499158-d77a-4d3d-a1a6-1bbbf53e6bf2', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '038d1a2b-8536-4441-9729-9fddc3411521', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Floor 1 - Row A', NULL, NULL, 'LOC-VUNT', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.85325+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 35);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('b36433d3-e05f-4f75-be3d-812e143d71f3', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '038d1a2b-8536-4441-9729-9fddc3411521', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Floor 2 - Row A', NULL, NULL, 'LOC-82LN', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.855859+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 37);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('b389b0ab-05b0-43a0-adc8-a87ab85fa2d9', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0f0d957d-7140-48c7-b438-5a537ce47f07', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Workshop Shelf 2', NULL, NULL, 'LOC-HJKN', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.848962+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 32);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('b9037f1b-c7e7-4c85-87ef-abc05185ba76', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '85d4cc00-6c99-4d1f-9c58-db5eb9665559', '6c2ad2e8-760b-487e-b0af-52b9e4e5faf1', '[]', 'STOCK', '[]', 'Server Room', NULL, NULL, 'LOC-XXTG', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.838222+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 25);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '34820f16-d5d4-4965-9d89-559750108063', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Dry Goods', NULL, NULL, 'LOC-ZX0L', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.818258+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 14);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('c8bfa3e4-ad2a-4495-b431-ea5a87b731cc', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9037f1b-c7e7-4c85-87ef-abc05185ba76', '6c2ad2e8-760b-487e-b0af-52b9e4e5faf1', '[]', 'STOCK', '[]', 'Server Rack A', NULL, NULL, 'LOC-0A3O', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.839931+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 26);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('d0c4df57-f9e2-4ab1-a639-4b77784d8577', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '1651685e-9233-4cb1-8bec-ee0c0129e4fc', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'STOCK', '[]', 'Beverage Rack 2', NULL, NULL, 'LOC-P8K1', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.831185+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 23);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('d507738e-d53e-49df-a82a-34ce64090c6a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9037f1b-c7e7-4c85-87ef-abc05185ba76', '6c2ad2e8-760b-487e-b0af-52b9e4e5faf1', '[]', 'STOCK', '[]', 'Server Rack B', NULL, NULL, 'LOC-10SH', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.841573+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 27);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('d66ab48c-90c0-47df-9e57-5e4c95ab681e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9b4df7f8-2e04-43a4-9c55-7cb2933cbd0a', 'd47eb5fd-b6d8-407b-9638-92e65414432e', '[]', 'FREEZING', '[]', 'Chest Freezer', NULL, NULL, 'LOC-8GWQ', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.815192+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 12);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('d9388a4f-3bf6-4427-be77-04cee47871eb', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'f62b967a-66d2-419c-96f7-79ca6c173ea7', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Cold Storage', NULL, NULL, 'LOC-5IL1', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.80082+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 2);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('da39ed54-154a-4e49-9ed7-6def76c07da1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Shelf B - Bottom', NULL, NULL, 'LOC-4B0D', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.826902+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 20);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('db1da8be-7485-44e6-9e96-22ddd61d7f6c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Shelf A - Top', NULL, NULL, 'LOC-W119', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.819535+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 15);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('e26e9233-0ce2-481a-9e20-dbe5c3b92f75', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'd9388a4f-3bf6-4427-be77-04cee47871eb', '1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '[]', 'EXPIRY', '[]', 'Fridge B', NULL, NULL, 'LOC-JTO0', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.807483+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 6);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('e45ba619-6cdd-4d90-9c01-d6d253e1cd14', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'b9957987-9c8f-4ed1-a2c5-cbc58383baba', '6a59cd6b-b01f-4086-8203-9cede0a54362', '[]', 'EXPIRY', '[]', 'Shelf A - Bottom', NULL, NULL, 'LOC-YEU0', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.822171+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 17);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('ee91a55d-d24f-4b98-842d-6b93e3b5781c', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '9b4df7f8-2e04-43a4-9c55-7cb2933cbd0a', 'd47eb5fd-b6d8-407b-9638-92e65414432e', '[]', 'FREEZING', '[]', 'Freezer 1', NULL, NULL, 'LOC-G9BG', 'internal', 'food', NULL, NULL, '2026-10-23 16:45:31.812731+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 10);
INSERT INTO public.storage_locations (id, organization_id, parent_id, storage_type_id, context_schema, behavior_mode, field_definitions, name, description, location_details, short_code, usage, context_tag, settings, warehouse_config, created_at, created_by, sequence) VALUES ('f286056a-e01e-41c5-ba89-3ee011a8f021', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', '0f0d957d-7140-48c7-b438-5a537ce47f07', '597c9958-cc01-4bee-9505-cb4520670c07', '[]', 'STOCK', '[]', 'Workshop Shelf 1', NULL, NULL, 'LOC-NC6E', 'internal', 'equipment', NULL, NULL, '2026-10-23 16:45:31.847444+00', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 31);


--
-- Data for Name: storage_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('94200f32-745f-4e2f-bf65-50a6915d44e5', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Shelf / Cabinet', 'SHELF', 'STOCK', '["quantity", "unit"]', '[]', 'BookOpen', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('3dcecc12-7e4f-4a25-a481-497f95bed685', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Storage Room', 'STORAGE_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Warehouse', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('92df146f-5fd7-42d2-a146-a4c53da078f7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'System', 'SYSTEM', 'NONE', '[]', '[]', 'Settings', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('09d72313-2503-455f-92c9-59cf665e8c85', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Tool Room', 'TOOL_ROOM', 'STOCK', '["quantity", "unit"]', '[]', 'Wrench', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('f6b171c2-158e-4da7-87e1-36aff136aba7', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Maintenance Bay', 'MAINTENANCE_BAY', 'NONE', '["quantity", "unit"]', '[]', 'Hammer', true, NULL, '{"check_expiry": false}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('6c2ad2e8-760b-487e-b0af-52b9e4e5faf1', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Server Room', 'SERVER_ROOM', 'NONE', '["serial_number", "manufacturer", "model", "ip_address", "equipment_status"]', '[]', 'server', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('597c9958-cc01-4bee-9505-cb4520670c07', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'IT Storage / Warehouse', 'IT_STORAGE', 'NONE', '["serial_number", "manufacturer", "model", "equipment_status"]', '[]', 'warehouse', true, NULL, NULL);
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('d47eb5fd-b6d8-407b-9638-92e65414432e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Freezer', 'FREEZER', 'FREEZING', '[]', '[]', 'Snowflake', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('1b0f05c8-aa79-4f5e-bd63-a63f4491e05e', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Fridge', 'FRIDGE', 'EXPIRY', '[]', '[]', 'Refrigerator', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('6a59cd6b-b01f-4086-8203-9cede0a54362', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Pantry', 'PANTRY', 'EXPIRY', '[]', '[]', 'ShoppingBasket', true, NULL, '{"check_expiry": true}');
INSERT INTO public.storage_types (id, organization_id, name, type_code, behavior_mode, context_schema, field_definitions, icon, is_system, created_by, default_settings) VALUES ('0e19ace3-fc99-440b-915f-8eeea7939f03', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'Medicine Cabinet', 'MEDICINE_CABINET', 'EXPIRY', '[]', '[]', 'Cross', true, NULL, '{"check_expiry": true}');


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.system_settings (key, value, updated_at, updated_by) VALUES ('default_org_limits', '{"max_members": null, "max_products": null, "ai_scans_monthly": null, "ai_requests_monthly": 20}', '2026-10-23 16:45:37.306118+00', NULL);


--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unit_conversions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: uom_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('4bf0502b-8ab9-4ef6-bf2b-cef2dbf7782a', NULL, 'Pack');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('c30de62e-a192-4a21-9392-859de3ad4854', NULL, 'Can');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('5631468e-2d6a-4649-af3c-5272a7ddfdaf', NULL, 'Bottle');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('acc31471-9302-44c3-8078-a41c04a37331', NULL, 'Box');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('56746f23-dce3-4434-99ad-8dc80ecea614', NULL, 'Bag');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('093a6086-d09b-4fae-9a83-b5aaa3a5adb7', NULL, 'Weight');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('a394eff8-ad1b-4904-b629-5f10c09e8d54', NULL, 'Volume');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('93e573f8-b08e-4924-acca-8abcab3cb8e7', NULL, 'Unit');
INSERT INTO public.uom_categories (id, organization_id, name) VALUES ('f571e102-bd3a-427d-8a0f-00a4218a1c42', NULL, 'Length');


--
-- Data for Name: uoms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('bd938325-0f1c-4ed0-8869-5c1dfb5c4a11', NULL, '093a6086-d09b-4fae-9a83-b5aaa3a5adb7', 'Gram', 'g', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('941f5080-e9d1-45ef-a876-04d75d5da6ea', NULL, '093a6086-d09b-4fae-9a83-b5aaa3a5adb7', 'Kilogram', 'kg', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('ead9ad39-a350-404f-ade4-5533568fcce6', NULL, '093a6086-d09b-4fae-9a83-b5aaa3a5adb7', 'Milligram', 'mg', 0.001000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('109ff1cb-062a-4566-a38c-d03ae459fa40', NULL, '093a6086-d09b-4fae-9a83-b5aaa3a5adb7', 'Ounce', 'oz', 28.349500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('735f88b8-23a5-40be-a5a5-506849791b8b', NULL, '093a6086-d09b-4fae-9a83-b5aaa3a5adb7', 'Pound', 'lb', 453.592000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('27a06e30-48a3-462e-b842-3291e7b1a8d0', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Milliliter', 'ml', 1.000000000, true, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('50001a69-41d5-4737-8c05-f006a09195e8', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Liter', 'l', 1000.000000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f8b6305e-461c-49e3-8928-bd1b56d3eabd', NULL, '93e573f8-b08e-4924-acca-8abcab3cb8e7', 'Piece', 'pcs', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('21f0f763-a223-4344-bc0f-a0069453da54', NULL, '4bf0502b-8ab9-4ef6-bf2b-cef2dbf7782a', 'Pack', 'pack', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('871ffb9f-4e69-43f6-9bb8-ea8ebd59ef76', NULL, 'c30de62e-a192-4a21-9392-859de3ad4854', 'Can', 'can', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('561f7364-e2b0-4f38-834d-4ee46f49735a', NULL, '5631468e-2d6a-4649-af3c-5272a7ddfdaf', 'Bottle', 'bottle', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('dbd9638d-0d26-438c-9a61-4da3c987d7b2', NULL, 'acc31471-9302-44c3-8078-a41c04a37331', 'Box', 'box', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('c38dad60-7645-4b6f-bd05-d06f7d4c69d9', NULL, '56746f23-dce3-4434-99ad-8dc80ecea614', 'Bag', 'bag', 1.000000000, true, true, 1.000000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('16ad4be8-3c2f-4ceb-b122-caa98e9ddabe', NULL, 'f571e102-bd3a-427d-8a0f-00a4218a1c42', 'Centimeter', 'cm', 1.000000000, true, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('f818391b-0aa0-456b-a742-109e817cfd12', NULL, 'f571e102-bd3a-427d-8a0f-00a4218a1c42', 'Meter', 'm', 100.000000000, false, true, 0.010000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('9f1e3f5d-49ad-477d-8d42-f9ecd0f6bb2d', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Fluid Ounce', 'fl oz', 29.573500000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('8c754097-bda6-4052-9a74-a2a3625130fe', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Cup (US)', 'cup', 236.588000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('6f6473a0-cb4e-4875-86bd-f0595adb2ae3', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Pint (US)', 'pt', 473.176000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('2a55deb7-1160-41c7-b040-4facfd2fffdf', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Quart (US)', 'qt', 946.353000000, false, true, 0.001000);
INSERT INTO public.uoms (id, organization_id, category_id, name, symbol, factor, is_reference, is_system, rounding) VALUES ('76c104d5-b446-4dc8-8cb8-0f30e57190c2', NULL, 'a394eff8-ad1b-4904-b629-5f10c09e8d54', 'Gallon (US)', 'gal', 3785.410000000, false, true, 0.001000);


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('3f56745b-168d-495f-ae6b-57e85c48c2f5', 'admin@example.com', '$2b$12$B7YbkH9qm4pmzAMArLmQR.XgMKl4OugRp3ZrLjnY8PBhDcRHTWQLe', 'Demo Administrator', '2026-10-23 16:45:31.11405+00', '2026-10-23 16:45:31.140085+00', 'en', 'admin', true, false, false, NULL, NULL, 0, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('1ea5bd84-066b-4ed1-91a9-eac1e17aef28', 'ava.brennan@example.com', '$2b$12$gINXydyrz.gfbp4AEZVgVu1gHx9pAdj4Vy8JEriDIiwawHriwC0Ey', 'Ava Brennan', '2026-10-23 16:45:36.82954+00', '2026-10-23 16:45:36.829544+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe');
INSERT INTO public.users (id, email, hashed_password, full_name, created_at, updated_at, preferred_language, role, is_active, is_superuser, is_blocked, blocked_at, blocking_reason, failed_login_count, locked_until, organization_id) VALUES ('fdf258d7-766d-464d-abc5-78d7d8370739', 'marcus.webb@example.com', '$2b$12$j4RlpLcMzlr4W0FfACOhD.YXeaLLzw5Lgfrz5nXrgYYIwkdZ5o1HG', 'Marcus Webb', '2026-10-23 16:45:36.829547+00', '2026-10-23 16:45:36.829548+00', 'en', 'user', true, false, false, NULL, NULL, 0, NULL, '6c5ab9ac-47df-44ca-834d-cca2115b65fe');


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_line_lots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wms_pick_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('19d0b186-a5c1-476c-a351-25e4f6c69f2d', '50eca74a-7254-4713-99dc-2d9e00110d3a', 'bf3ed67c-b28d-40b5-b26e-8a3e6b0a18ea', 3, 'picked', 5.000, 'LOC-JTO0 · Fridge B', 'Sour Cream 18%', NULL, 5.000, 'pcs', 'cb66d3ed-c20d-4a01-b65b-4d2ddaf12342', NULL, 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('b5c859ab-62b5-4d2a-b6be-ae4acf5e4741', '50eca74a-7254-4713-99dc-2d9e00110d3a', 'fd15a26d-eb25-4593-90a8-8065fa54cb5a', 2, 'picked', 10.000, 'LOC-JTO0 · Fridge B', 'Gouda Cheese', NULL, 10.000, 'pcs', '22c6bfaf-2dca-48e2-8ad5-2450d1d9ff3a', NULL, 'e26e9233-0ce2-481a-9e20-dbe5c3b92f75', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('c606d90d-17a4-4ebd-bc12-6fda638084cf', '50eca74a-7254-4713-99dc-2d9e00110d3a', '87650eca-007b-41c1-a405-5f2f190d1779', 0, 'picked', 6.000, 'LOC-9GVX · Fridge A', 'Natural Yoghurt 400g', NULL, 6.000, 'pcs', 'f86018c7-3a75-4e3d-b0b0-273f27e6f1d0', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL);
INSERT INTO public.wms_pick_lines (id, session_id, document_line_id, pick_order, status, picked_quantity, bin_location, product_name, lot_name, expected_quantity, uom_symbol, anchor_id, lot_id, location_id, expiry_date) VALUES ('d7f12156-f91c-4b90-b6ea-4dd87ef743f0', '50eca74a-7254-4713-99dc-2d9e00110d3a', '7f00e27a-9bb8-4f85-a6cf-4f889101f49e', 1, 'picked', 4.000, 'LOC-9GVX · Fridge A', 'Butter Extra 82%', NULL, 4.000, 'pcs', '3a5b448f-9b58-4dd9-aeb4-e4370975a7b6', NULL, 'a2c28e46-9a3b-4a33-b1c8-4a6aae183c51', NULL);


--
-- Data for Name: wms_pick_session_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('50eca74a-7254-4713-99dc-2d9e00110d3a', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', 0);
INSERT INTO public.wms_pick_session_documents (session_id, document_id, "position") VALUES ('50eca74a-7254-4713-99dc-2d9e00110d3a', '235e0124-96fe-461a-bef5-3e365fc4226c', 1);


--
-- Data for Name: wms_pick_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wms_pick_sessions (id, organization_id, document_id, assigned_to, status, started_at, completed_at, meta_data, last_activity_at) VALUES ('50eca74a-7254-4713-99dc-2d9e00110d3a', '6c5ab9ac-47df-44ca-834d-cca2115b65fe', 'de2d8b86-c2a0-4a1b-93f7-cfe6a8c410d4', '3f56745b-168d-495f-ae6b-57e85c48c2f5', 'completed', '2026-10-23 16:45:34.277513+00', '2026-10-23 16:45:34.639452+00', 'null', '2026-10-23 16:45:34.600166+00');


--
-- Name: ai_connections ai_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version_api_keys alembic_version_api_keys_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_api_keys
    ADD CONSTRAINT alembic_version_api_keys_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_approvals alembic_version_approvals_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_approvals
    ADD CONSTRAINT alembic_version_approvals_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_equipment alembic_version_equipment_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_equipment
    ADD CONSTRAINT alembic_version_equipment_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_example_widgets alembic_version_example_widgets_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_example_widgets
    ADD CONSTRAINT alembic_version_example_widgets_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_maker alembic_version_maker_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_maker
    ADD CONSTRAINT alembic_version_maker_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_printing alembic_version_printing_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_printing
    ADD CONSTRAINT alembic_version_printing_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_purchase_orders alembic_version_purchase_orders_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_purchase_orders
    ADD CONSTRAINT alembic_version_purchase_orders_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_recipes alembic_version_recipes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_recipes
    ADD CONSTRAINT alembic_version_recipes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_shopping_lists alembic_version_shopping_lists_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_shopping_lists
    ADD CONSTRAINT alembic_version_shopping_lists_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_stock_takes alembic_version_stock_takes_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_stock_takes
    ADD CONSTRAINT alembic_version_stock_takes_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_warehouse alembic_version_warehouse_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_warehouse
    ADD CONSTRAINT alembic_version_warehouse_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_webhooks alembic_version_webhooks_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version_webhooks
    ADD CONSTRAINT alembic_version_webhooks_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approval_decisions approval_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: approval_workflows approval_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);


--
-- Name: audit_campaigns audit_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_response_items audit_response_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_pkey PRIMARY KEY (id);


--
-- Name: audit_responses audit_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cycle_count_schedules cycle_count_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_pkey PRIMARY KEY (id);


--
-- Name: document_extra_costs document_extra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_pkey PRIMARY KEY (id);


--
-- Name: document_lines document_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_pkey PRIMARY KEY (id);


--
-- Name: document_number_sequences document_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_pkey PRIMARY KEY (organization_id, prefix);


--
-- Name: document_package_lines document_package_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_pkey PRIMARY KEY (id);


--
-- Name: document_packages document_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_pkey PRIMARY KEY (id);


--
-- Name: document_profiles document_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_pkey PRIMARY KEY (id);


--
-- Name: document_relations document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_pkey PRIMARY KEY (id);


--
-- Name: document_shipments document_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: document_type_configs document_type_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_pkey PRIMARY KEY (id);


--
-- Name: document_warehouse_receiving document_warehouse_receiving_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_pkey PRIMARY KEY (id);


--
-- Name: document_work_item_overlays document_work_item_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_jobs email_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_jobs
    ADD CONSTRAINT email_jobs_pkey PRIMARY KEY (id);


--
-- Name: equipment_assignments equipment_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_pkey PRIMARY KEY (id);


--
-- Name: equipment_attachments equipment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_pkey PRIMARY KEY (id);


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: event_deliveries event_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT event_deliveries_pkey PRIMARY KEY (id);


--
-- Name: event_outbox event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox
    ADD CONSTRAINT event_outbox_pkey PRIMARY KEY (id);


--
-- Name: example_widgets example_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_pkey PRIMARY KEY (id);


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_pkey PRIMARY KEY (id);


--
-- Name: inventory_periods inventory_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_pkey PRIMARY KEY (id);


--
-- Name: item_attachments item_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT item_attachments_pkey PRIMARY KEY (id);


--
-- Name: item_history item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT item_history_pkey PRIMARY KEY (id);


--
-- Name: item_type_definitions item_type_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_type_definitions
    ADD CONSTRAINT item_type_definitions_pkey PRIMARY KEY (code);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: label_pool label_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT label_pool_pkey PRIMARY KEY (id);


--
-- Name: location_relocations location_relocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_pkey PRIMARY KEY (id);


--
-- Name: maker_bom_lines maker_bom_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_module_settings maker_module_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_pkey PRIMARY KEY (organization_id);


--
-- Name: maker_production_order_lines maker_production_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_production_orders maker_production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_pkey PRIMARY KEY (id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_pkey PRIMARY KEY (id);


--
-- Name: maker_recipes maker_recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_entries meal_plan_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_pkey PRIMARY KEY (id);


--
-- Name: meal_plans meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_pkey PRIMARY KEY (id);


--
-- Name: module_installations module_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_installations
    ADD CONSTRAINT module_installations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: picking_session_items picking_session_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_pkey PRIMARY KEY (id);


--
-- Name: picking_sessions picking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_pkey PRIMARY KEY (id);


--
-- Name: po_partner_pricelist po_partner_pricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_pkey PRIMARY KEY (id);


--
-- Name: po_reorder_rules po_reorder_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_pkey PRIMARY KEY (id);


--
-- Name: po_settings po_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_pkey PRIMARY KEY (id);


--
-- Name: print_agents print_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_pkey PRIMARY KEY (id);


--
-- Name: print_jobs print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_pkey PRIMARY KEY (id);


--
-- Name: product_templates product_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT product_templates_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: putaway_capacity putaway_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_pkey PRIMARY KEY (id);


--
-- Name: putaway_location_settings putaway_location_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_pkey PRIMARY KEY (id);


--
-- Name: putaway_rule_locations putaway_rule_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_pkey PRIMARY KEY (id);


--
-- Name: putaway_rules putaway_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_pkey PRIMARY KEY (id);


--
-- Name: recipe_collection_members recipe_collection_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_pkey PRIMARY KEY (id);


--
-- Name: recipe_collections recipe_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipe_tag_configs recipe_tag_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shopping_exclusions shopping_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_history shopping_list_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_pkey PRIMARY KEY (id);


--
-- Name: shopping_list_items shopping_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_pkey PRIMARY KEY (id);


--
-- Name: shopping_lists shopping_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_pkey PRIMARY KEY (id);


--
-- Name: stock_anchors stock_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_pkey PRIMARY KEY (id);


--
-- Name: stock_lots stock_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT stock_lots_pkey PRIMARY KEY (id);


--
-- Name: stock_moves stock_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_closed_locations stock_take_closed_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_pkey PRIMARY KEY (id);


--
-- Name: stock_take_counts stock_take_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_take_items stock_take_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);


--
-- Name: stock_takes stock_takes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);


--
-- Name: stock_valuation_layers stock_valuation_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: storage_types storage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT storage_types_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: unit_conversions unit_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom_categories uom_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uom_categories_pkey PRIMARY KEY (id);


--
-- Name: uoms uoms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uoms_pkey PRIMARY KEY (id);


--
-- Name: ai_connections uq_ai_connections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT uq_ai_connections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_bom_lines uq_bom_recipe_child; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT uq_bom_recipe_child UNIQUE (recipe_id, child_template_id);


--
-- Name: document_type_configs uq_doctype_config_org_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT uq_doctype_config_org_type UNIQUE (organization_id, document_type);


--
-- Name: documents uq_document_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT uq_document_org_number UNIQUE (organization_id, number);


--
-- Name: document_package_lines uq_document_package_lines_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT uq_document_package_lines_line UNIQUE (document_package_id, document_line_id);


--
-- Name: document_packages uq_document_packages_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT uq_document_packages_number UNIQUE (document_id, number);


--
-- Name: document_profiles uq_document_profile_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT uq_document_profile_org UNIQUE (organization_id);


--
-- Name: document_shipments uq_document_shipments_document; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT uq_document_shipments_document UNIQUE (document_id);


--
-- Name: document_warehouse_receiving uq_document_warehouse_receiving_org_warehouse; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT uq_document_warehouse_receiving_org_warehouse UNIQUE (organization_id, warehouse_id);


--
-- Name: event_deliveries uq_event_deliveries_event_handler; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_deliveries
    ADD CONSTRAINT uq_event_deliveries_event_handler UNIQUE (event_id, handler);


--
-- Name: ingredient_nutrition_defaults uq_ingredient_defaults_org_lang_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT uq_ingredient_defaults_org_lang_name UNIQUE (organization_id, lang, name_normalized);


--
-- Name: inventory_periods uq_inventory_period_org_year_month; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT uq_inventory_period_org_year_month UNIQUE (organization_id, year, month);


--
-- Name: label_pool uq_label_pool_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT uq_label_pool_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: stock_lots uq_lot_org_product_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT uq_lot_org_product_name UNIQUE (organization_id, product_template_id, name);


--
-- Name: meal_plan_entries uq_meal_plan_entries_plan_date_slot_order; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT uq_meal_plan_entries_plan_date_slot_order UNIQUE (meal_plan_id, date, slot, "order");


--
-- Name: partners uq_partner_org_name_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT uq_partner_org_name_type UNIQUE (organization_id, name, type);


--
-- Name: po_reorder_rules uq_po_reorder_rules_org_product_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT uq_po_reorder_rules_org_product_loc UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: po_settings uq_po_settings_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT uq_po_settings_org UNIQUE (organization_id);


--
-- Name: print_agents uq_print_agents_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT uq_print_agents_org_name UNIQUE (organization_id, name);


--
-- Name: purchase_orders uq_purchase_orders_org_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT uq_purchase_orders_org_number UNIQUE (organization_id, number);


--
-- Name: putaway_capacity uq_putaway_capacity_org_loc_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT uq_putaway_capacity_org_loc_product UNIQUE (organization_id, location_id, product_template_id);


--
-- Name: putaway_location_settings uq_putaway_location_settings_org_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT uq_putaway_location_settings_org_loc UNIQUE (organization_id, location_id);


--
-- Name: putaway_rule_locations uq_putaway_rule_locations_rule_loc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT uq_putaway_rule_locations_rule_loc UNIQUE (rule_id, location_id);


--
-- Name: recipe_collection_members uq_recipe_collection_members; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT uq_recipe_collection_members UNIQUE (collection_id, recipe_id);


--
-- Name: recipe_collections uq_recipe_collections_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT uq_recipe_collections_org_name UNIQUE (organization_id, name);


--
-- Name: maker_recipes uq_recipe_org_template_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT uq_recipe_org_template_name UNIQUE (organization_id, output_template_id, name);


--
-- Name: recipe_tag_configs uq_recipe_tag_configs_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT uq_recipe_tag_configs_org_name UNIQUE (organization_id, name);


--
-- Name: shopping_exclusions uq_shopping_exclusions_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT uq_shopping_exclusions_org_name UNIQUE (organization_id, name_normalized);


--
-- Name: stock_anchors uq_stock_anchor_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT uq_stock_anchor_group UNIQUE (organization_id, product_template_id, storage_location_id);


--
-- Name: stock_take_closed_locations uq_stock_take_closed_locations_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT uq_stock_take_closed_locations_location UNIQUE (stock_take_id, storage_location_id);


--
-- Name: storage_locations uq_storage_locations_org_short_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT uq_storage_locations_org_short_code UNIQUE (organization_id, short_code);


--
-- Name: unit_conversions uq_unit_conv_org_ingredient_unit_lang; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT uq_unit_conv_org_ingredient_unit_lang UNIQUE (organization_id, ingredient_key, source_unit, lang);


--
-- Name: uom_categories uq_uom_category_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT uq_uom_category_org_name UNIQUE (organization_id, name);


--
-- Name: uoms uq_uom_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT uq_uom_org_name UNIQUE (organization_id, name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pkey PRIMARY KEY (pick_line_id, lot_id);


--
-- Name: wms_pick_lines wms_pick_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_pkey PRIMARY KEY (id);


--
-- Name: wms_pick_session_documents wms_pick_session_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_pkey PRIMARY KEY (session_id, document_id);


--
-- Name: wms_pick_sessions wms_pick_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_connections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_connections_organization_id ON public.ai_connections USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_created_at ON public.ai_usage_logs USING btree (created_at);


--
-- Name: ix_ai_usage_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_organization_id ON public.ai_usage_logs USING btree (organization_id);


--
-- Name: ix_ai_usage_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_logs_user_id ON public.ai_usage_logs USING btree (user_id);


--
-- Name: ix_api_keys_hashed_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_api_keys_hashed_key ON public.api_keys USING btree (hashed_key);


--
-- Name: ix_api_keys_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_organization_id ON public.api_keys USING btree (organization_id);


--
-- Name: ix_approval_decisions_approval_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_decisions_approval_request_id ON public.approval_decisions USING btree (approval_request_id);


--
-- Name: ix_approval_requests_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_organization_id ON public.approval_requests USING btree (organization_id);


--
-- Name: ix_approval_requests_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_target ON public.approval_requests USING btree (target_type, target_id, organization_id);


--
-- Name: ix_approval_workflows_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_workflows_organization_id ON public.approval_workflows USING btree (organization_id);


--
-- Name: ix_audit_campaigns_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_org ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_campaigns_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_campaigns_organization_id ON public.audit_campaigns USING btree (organization_id);


--
-- Name: ix_audit_log_org_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_created_at_id ON public.audit_log USING btree (organization_id, created_at DESC, id);


--
-- Name: ix_audit_log_org_type_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_org_type_created_at ON public.audit_log USING btree (organization_id, target_type, created_at DESC, id);


--
-- Name: ix_audit_log_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_organization_id ON public.audit_log USING btree (organization_id);


--
-- Name: ix_audit_log_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_target ON public.audit_log USING btree (target_type, target_id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_audit_response_items_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_assignment_id ON public.audit_response_items USING btree (assignment_id);


--
-- Name: ix_audit_response_items_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_item_id ON public.audit_response_items USING btree (item_id);


--
-- Name: ix_audit_response_items_response_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_response_items_response_id ON public.audit_response_items USING btree (response_id);


--
-- Name: ix_audit_responses_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_assignment_id ON public.audit_responses USING btree (assignment_id);


--
-- Name: ix_audit_responses_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_id ON public.audit_responses USING btree (campaign_id);


--
-- Name: ix_audit_responses_campaign_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_campaign_status ON public.audit_responses USING btree (campaign_id, status);


--
-- Name: ix_audit_responses_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_responses_organization_id ON public.audit_responses USING btree (organization_id);


--
-- Name: ix_audit_responses_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_responses_token ON public.audit_responses USING btree (token);


--
-- Name: ix_bom_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_org ON public.maker_bom_lines USING btree (organization_id);


--
-- Name: ix_bom_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_parent ON public.maker_bom_lines USING btree (parent_template_id);


--
-- Name: ix_bom_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bom_recipe ON public.maker_bom_lines USING btree (recipe_id);


--
-- Name: ix_categories_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_code ON public.categories USING btree (code);


--
-- Name: ix_categories_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_context_tag ON public.categories USING btree (context_tag);


--
-- Name: ix_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_is_active ON public.categories USING btree (is_active);


--
-- Name: ix_categories_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_module_name ON public.categories USING btree (module_name);


--
-- Name: ix_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_organization_id ON public.categories USING btree (organization_id);


--
-- Name: ix_cycle_count_schedules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cycle_count_schedules_organization_id ON public.cycle_count_schedules USING btree (organization_id);


--
-- Name: ix_doc_relation_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_source ON public.document_relations USING btree (source_document_id);


--
-- Name: ix_doc_relation_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_relation_target ON public.document_relations USING btree (target_document_id);


--
-- Name: ix_doc_templates_org_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_templates_org_module ON public.document_templates USING btree (organization_id, module);


--
-- Name: ix_document_extra_costs_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_document ON public.document_extra_costs USING btree (document_id);


--
-- Name: ix_document_extra_costs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_extra_costs_organization_id ON public.document_extra_costs USING btree (organization_id);


--
-- Name: ix_document_lines_corrects_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_corrects_line_id ON public.document_lines USING btree (corrects_line_id);


--
-- Name: ix_document_lines_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_document_id ON public.document_lines USING btree (document_id);


--
-- Name: ix_document_lines_puts_away_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_puts_away_line_id ON public.document_lines USING btree (puts_away_line_id);


--
-- Name: ix_document_lines_source_po_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_lines_source_po_line_id ON public.document_lines USING btree (source_po_line_id);


--
-- Name: ix_document_org_partner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_partner ON public.documents USING btree (organization_id, partner_id);


--
-- Name: ix_document_org_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_status_created_at ON public.documents USING btree (organization_id, status, created_at);


--
-- Name: ix_document_org_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_org_type_status ON public.documents USING btree (organization_id, type, status);


--
-- Name: ix_document_package_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_line_id ON public.document_package_lines USING btree (document_line_id);


--
-- Name: ix_document_package_lines_document_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_package_lines_document_package_id ON public.document_package_lines USING btree (document_package_id);


--
-- Name: ix_document_packages_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_document_id ON public.document_packages USING btree (document_id);


--
-- Name: ix_document_packages_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_packages_organization_id ON public.document_packages USING btree (organization_id);


--
-- Name: ix_document_profiles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_profiles_organization_id ON public.document_profiles USING btree (organization_id);


--
-- Name: ix_document_shipments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shipments_organization_id ON public.document_shipments USING btree (organization_id);


--
-- Name: ix_document_templates_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_module ON public.document_templates USING btree (module);


--
-- Name: ix_document_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_organization_id ON public.document_templates USING btree (organization_id);


--
-- Name: ix_document_type_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_type_configs_organization_id ON public.document_type_configs USING btree (organization_id);


--
-- Name: ix_document_warehouse_receiving_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_warehouse_receiving_organization_id ON public.document_warehouse_receiving USING btree (organization_id);


--
-- Name: ix_document_work_item_overlays_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_work_item_overlays_organization_id ON public.document_work_item_overlays USING btree (organization_id);


--
-- Name: ix_documents_backorder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_backorder_id ON public.documents USING btree (backorder_id);


--
-- Name: ix_documents_corrects_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_corrects_document_id ON public.documents USING btree (corrects_document_id);


--
-- Name: ix_documents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_organization_id ON public.documents USING btree (organization_id);


--
-- Name: ix_email_jobs_next_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_next_attempt_at ON public.email_jobs USING btree (next_attempt_at);


--
-- Name: ix_email_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_organization_id ON public.email_jobs USING btree (organization_id);


--
-- Name: ix_email_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_jobs_status ON public.email_jobs USING btree (status);


--
-- Name: ix_eq_assignments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_assignments_org_item ON public.equipment_assignments USING btree (organization_id, item_id);


--
-- Name: ix_eq_attachments_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_attachments_org_item ON public.equipment_attachments USING btree (organization_id, item_id);


--
-- Name: ix_eq_maintenance_org_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_eq_maintenance_org_item ON public.equipment_maintenance_logs USING btree (organization_id, item_id);


--
-- Name: ix_equipment_assignments_assignee_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_assignee_partner_id ON public.equipment_assignments USING btree (assignee_partner_id);


--
-- Name: ix_equipment_assignments_checkout_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_checkout_location_id ON public.equipment_assignments USING btree (checkout_location_id);


--
-- Name: ix_equipment_assignments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_item_id ON public.equipment_assignments USING btree (item_id);


--
-- Name: ix_equipment_assignments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_assignments_organization_id ON public.equipment_assignments USING btree (organization_id);


--
-- Name: ix_equipment_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_item_id ON public.equipment_attachments USING btree (item_id);


--
-- Name: ix_equipment_attachments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_attachments_organization_id ON public.equipment_attachments USING btree (organization_id);


--
-- Name: ix_equipment_maintenance_logs_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_item_id ON public.equipment_maintenance_logs USING btree (item_id);


--
-- Name: ix_equipment_maintenance_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_equipment_maintenance_logs_organization_id ON public.equipment_maintenance_logs USING btree (organization_id);


--
-- Name: ix_event_deliveries_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_organization_id ON public.event_deliveries USING btree (organization_id);


--
-- Name: ix_event_deliveries_status_next_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_deliveries_status_next_attempt ON public.event_deliveries USING btree (status, next_attempt_at);


--
-- Name: ix_event_outbox_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_organization_id ON public.event_outbox USING btree (organization_id);


--
-- Name: ix_event_outbox_unpublished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_unpublished ON public.event_outbox USING btree (created_at) WHERE (published_at IS NULL);


--
-- Name: ix_example_widgets_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_example_widgets_organization_id ON public.example_widgets USING btree (organization_id);


--
-- Name: ix_ingredient_defaults_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_defaults_lookup ON public.ingredient_nutrition_defaults USING btree (name_normalized, lang, organization_id);


--
-- Name: ix_ingredient_nutrition_defaults_name_normalized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_name_normalized ON public.ingredient_nutrition_defaults USING btree (name_normalized);


--
-- Name: ix_ingredient_nutrition_defaults_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ingredient_nutrition_defaults_organization_id ON public.ingredient_nutrition_defaults USING btree (organization_id);


--
-- Name: ix_item_attachments_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_attachments_item_id ON public.item_attachments USING btree (item_id);


--
-- Name: ix_item_history_item_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_item_created ON public.item_history USING btree (item_id, created_at);


--
-- Name: ix_item_history_org_action_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_org_action_created ON public.item_history USING btree (organization_id, action, created_at);


--
-- Name: ix_item_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_organization_id ON public.item_history USING btree (organization_id);


--
-- Name: ix_item_history_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_source_document_id ON public.item_history USING btree (source_document_id);


--
-- Name: ix_item_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_history_user_id ON public.item_history USING btree (user_id);


--
-- Name: ix_item_type_definitions_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_type_definitions_is_active ON public.item_type_definitions USING btree (is_active);


--
-- Name: ix_item_type_definitions_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_type_definitions_module_name ON public.item_type_definitions USING btree (module_name);


--
-- Name: ix_item_type_definitions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_item_type_definitions_organization_id ON public.item_type_definitions USING btree (organization_id);


--
-- Name: ix_items_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode ON public.items USING btree (barcode);


--
-- Name: ix_items_barcode_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_barcode_trgm ON public.items USING gin (barcode public.gin_trgm_ops);


--
-- Name: ix_items_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_brand_trgm ON public.items USING gin (brand public.gin_trgm_ops);


--
-- Name: ix_items_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_created_at ON public.items USING btree (created_at);


--
-- Name: ix_items_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_expiry_date ON public.items USING btree (expiry_date);


--
-- Name: ix_items_is_catalog_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_catalog_entry ON public.items USING btree (is_catalog_entry);


--
-- Name: ix_items_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_is_deleted ON public.items USING btree (is_deleted);


--
-- Name: ix_items_item_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_item_type ON public.items USING btree (item_type);


--
-- Name: ix_items_label_code_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_label_code_trgm ON public.items USING gin (label_code public.gin_trgm_ops);


--
-- Name: ix_items_meta_data_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_meta_data_gin ON public.items USING gin (meta_data);


--
-- Name: ix_items_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_module_name ON public.items USING btree (module_name);


--
-- Name: ix_items_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_name_trgm ON public.items USING gin (name public.gin_trgm_ops);


--
-- Name: ix_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_barcode_active ON public.items USING btree (organization_id, barcode, is_deleted);


--
-- Name: ix_items_org_category_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_category_active ON public.items USING btree (organization_id, category_id, is_deleted);


--
-- Name: ix_items_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_created ON public.items USING btree (organization_id, is_deleted, created_at DESC);


--
-- Name: ix_items_org_not_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_not_deleted ON public.items USING btree (organization_id, is_deleted);


--
-- Name: ix_items_org_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_org_template_active ON public.items USING btree (organization_id, template_id, is_deleted);


--
-- Name: ix_items_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_organization_id ON public.items USING btree (organization_id);


--
-- Name: ix_items_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_partner_id ON public.items USING btree (partner_id);


--
-- Name: ix_items_quantity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_quantity ON public.items USING btree (quantity);


--
-- Name: ix_items_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_serial_number ON public.items USING btree (serial_number);


--
-- Name: ix_items_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_source_document_id ON public.items USING btree (source_document_id);


--
-- Name: ix_items_stock_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_stock_group ON public.items USING btree (organization_id, template_id, storage_location_id, lot_id, owner_id) INCLUDE (quantity, is_deleted);


--
-- Name: ix_items_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_items_storage_location_id ON public.items USING btree (storage_location_id);


--
-- Name: ix_label_pool_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_context_tag ON public.label_pool USING btree (context_tag);


--
-- Name: ix_label_pool_is_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_pool_is_assigned ON public.label_pool USING btree (is_assigned);


--
-- Name: ix_location_relocations_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_relocations_org_moved_at ON public.location_relocations USING btree (organization_id, moved_at);


--
-- Name: ix_lot_org_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_org_expiry ON public.stock_lots USING btree (organization_id, expiry_date);


--
-- Name: ix_meal_plan_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_date ON public.meal_plan_entries USING btree (date);


--
-- Name: ix_meal_plan_entries_meal_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_meal_plan_id ON public.meal_plan_entries USING btree (meal_plan_id);


--
-- Name: ix_meal_plan_entries_plan_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_plan_date ON public.meal_plan_entries USING btree (meal_plan_id, date);


--
-- Name: ix_meal_plan_entries_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plan_entries_recipe ON public.meal_plan_entries USING btree (recipe_id);


--
-- Name: ix_meal_plans_org_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_end ON public.meal_plans USING btree (organization_id, end_date);


--
-- Name: ix_meal_plans_org_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_org_start ON public.meal_plans USING btree (organization_id, start_date);


--
-- Name: ix_meal_plans_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meal_plans_organization_id ON public.meal_plans USING btree (organization_id);


--
-- Name: ix_module_installations_module_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_module_installations_module_name ON public.module_installations USING btree (module_name);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_organization_invitations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organization_invitations_code ON public.organization_invitations USING btree (code);


--
-- Name: ix_organizations_short_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_short_id ON public.organizations USING btree (short_id);


--
-- Name: ix_partners_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_code ON public.partners USING btree (code);


--
-- Name: ix_partners_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_is_active ON public.partners USING btree (is_active);


--
-- Name: ix_partners_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_name_trgm ON public.partners USING gin (name public.gin_trgm_ops);


--
-- Name: ix_partners_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_organization_id ON public.partners USING btree (organization_id);


--
-- Name: ix_picking_session_items_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_session_items_session_id ON public.picking_session_items USING btree (session_id);


--
-- Name: ix_picking_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_organization_id ON public.picking_sessions USING btree (organization_id);


--
-- Name: ix_picking_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_picking_sessions_user_id ON public.picking_sessions USING btree (user_id);


--
-- Name: ix_po_partner_pricelist_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_organization_id ON public.po_partner_pricelist USING btree (organization_id);


--
-- Name: ix_po_partner_pricelist_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_partner_id ON public.po_partner_pricelist USING btree (partner_id);


--
-- Name: ix_po_partner_pricelist_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_product_template_id ON public.po_partner_pricelist USING btree (product_template_id);


--
-- Name: ix_po_partner_pricelist_template_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_partner_pricelist_template_active ON public.po_partner_pricelist USING btree (product_template_id, valid_from, valid_to);


--
-- Name: ix_po_reorder_rules_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_organization_id ON public.po_reorder_rules USING btree (organization_id);


--
-- Name: ix_po_reorder_rules_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_product_template_id ON public.po_reorder_rules USING btree (product_template_id);


--
-- Name: ix_po_reorder_rules_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_reorder_rules_storage_location_id ON public.po_reorder_rules USING btree (storage_location_id);


--
-- Name: ix_po_settings_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_po_settings_organization_id ON public.po_settings USING btree (organization_id);


--
-- Name: ix_print_agents_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_agents_organization_id ON public.print_agents USING btree (organization_id);


--
-- Name: ix_print_jobs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_agent_id ON public.print_jobs USING btree (agent_id);


--
-- Name: ix_print_jobs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_organization_id ON public.print_jobs USING btree (organization_id);


--
-- Name: ix_print_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_jobs_status ON public.print_jobs USING btree (status);


--
-- Name: ix_prod_line_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_line_order ON public.maker_production_order_lines USING btree (production_order_id);


--
-- Name: ix_prod_org_output; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_output ON public.maker_production_orders USING btree (organization_id, output_template_id);


--
-- Name: ix_prod_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prod_org_status ON public.maker_production_orders USING btree (organization_id, status);


--
-- Name: ix_product_templates_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_barcode ON public.product_templates USING btree (barcode);


--
-- Name: ix_product_templates_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_name_trgm ON public.product_templates USING gin (name public.gin_trgm_ops);


--
-- Name: ix_product_templates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_organization_id ON public.product_templates USING btree (organization_id);


--
-- Name: ix_product_templates_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku ON public.product_templates USING btree (sku);


--
-- Name: ix_product_templates_sku_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_templates_sku_trgm ON public.product_templates USING gin (sku public.gin_trgm_ops);


--
-- Name: ix_purchase_order_lines_purchase_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_purchase_order_id ON public.purchase_order_lines USING btree (purchase_order_id);


--
-- Name: ix_purchase_order_lines_source_reorder_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_lines_source_reorder_rule_id ON public.purchase_order_lines USING btree (source_reorder_rule_id);


--
-- Name: ix_purchase_orders_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_number ON public.purchase_orders USING btree (number);


--
-- Name: ix_purchase_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_organization_id ON public.purchase_orders USING btree (organization_id);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_putaway_capacity_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_capacity_org ON public.putaway_capacity USING btree (organization_id);


--
-- Name: ix_putaway_rule_locations_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rule_locations_rule ON public.putaway_rule_locations USING btree (rule_id);


--
-- Name: ix_putaway_rules_org_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_category ON public.putaway_rules USING btree (organization_id, category_id);


--
-- Name: ix_putaway_rules_org_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_priority ON public.putaway_rules USING btree (organization_id, priority);


--
-- Name: ix_putaway_rules_org_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_putaway_rules_org_product ON public.putaway_rules USING btree (organization_id, product_template_id);


--
-- Name: ix_recipe_collection_members_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_collection_id ON public.recipe_collection_members USING btree (collection_id);


--
-- Name: ix_recipe_collection_members_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collection_members_recipe_id ON public.recipe_collection_members USING btree (recipe_id);


--
-- Name: ix_recipe_collections_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_organization_id ON public.recipe_collections USING btree (organization_id);


--
-- Name: ix_recipe_collections_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_collections_parent_id ON public.recipe_collections USING btree (parent_id);


--
-- Name: ix_recipe_cost_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_org ON public.maker_recipe_cost_lines USING btree (organization_id);


--
-- Name: ix_recipe_cost_recipe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_cost_recipe ON public.maker_recipe_cost_lines USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_ingredient_group_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_ingredient_group_name ON public.recipe_ingredients USING btree (ingredient_group_name);


--
-- Name: ix_recipe_ingredients_recipe_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_recipe_id ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: ix_recipe_ingredients_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_ingredients_template_id ON public.recipe_ingredients USING btree (template_id);


--
-- Name: ix_recipe_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_org_template ON public.maker_recipes USING btree (organization_id, output_template_id);


--
-- Name: ix_recipe_tag_configs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipe_tag_configs_organization_id ON public.recipe_tag_configs USING btree (organization_id);


--
-- Name: ix_recipes_is_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_is_favorite ON public.recipes USING btree (is_favorite);


--
-- Name: ix_recipes_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recipes_organization_id ON public.recipes USING btree (organization_id);


--
-- Name: ix_registration_requests_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);


--
-- Name: ix_registration_requests_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_registration_requests_token ON public.registration_requests USING btree (token);


--
-- Name: ix_reservation_anchor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_anchor ON public.stock_reservations USING btree (anchor_id);


--
-- Name: ix_reservation_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_document ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_reservation_org_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservation_org_doc ON public.stock_reservations USING btree (organization_id, document_id);


--
-- Name: ix_roles_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_organization_id ON public.roles USING btree (organization_id);


--
-- Name: ix_shopping_exclusions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_exclusions_organization_id ON public.shopping_exclusions USING btree (organization_id);


--
-- Name: ix_shopping_list_history_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_organization_id ON public.shopping_list_history USING btree (organization_id);


--
-- Name: ix_shopping_list_history_original_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_history_original_list_id ON public.shopping_list_history USING btree (original_list_id);


--
-- Name: ix_shopping_list_items_is_purchased; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_list_items_is_purchased ON public.shopping_list_items USING btree (is_purchased);


--
-- Name: ix_shopping_lists_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shopping_lists_status ON public.shopping_lists USING btree (status);


--
-- Name: ix_stock_anchors_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_product_template_id ON public.stock_anchors USING btree (product_template_id);


--
-- Name: ix_stock_anchors_storage_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_anchors_storage_location_id ON public.stock_anchors USING btree (storage_location_id);


--
-- Name: ix_stock_lots_expiry_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_expiry_date ON public.stock_lots USING btree (expiry_date);


--
-- Name: ix_stock_lots_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_organization_id ON public.stock_lots USING btree (organization_id);


--
-- Name: ix_stock_lots_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_lots_product_template_id ON public.stock_lots USING btree (product_template_id);


--
-- Name: ix_stock_moves_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_completed_at ON public.stock_moves USING btree (completed_at);


--
-- Name: ix_stock_moves_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_at ON public.stock_moves USING btree (created_at);


--
-- Name: ix_stock_moves_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_created_by ON public.stock_moves USING btree (created_by);


--
-- Name: ix_stock_moves_from_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_from_loc ON public.stock_moves USING btree (from_location_id);


--
-- Name: ix_stock_moves_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_lot_id ON public.stock_moves USING btree (lot_id);


--
-- Name: ix_stock_moves_org_moved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_moved_at ON public.stock_moves USING btree (organization_id, COALESCE(completed_at, created_at) DESC, id);


--
-- Name: ix_stock_moves_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_org_template ON public.stock_moves USING btree (organization_id, product_template_id);


--
-- Name: ix_stock_moves_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_organization_id ON public.stock_moves USING btree (organization_id);


--
-- Name: ix_stock_moves_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_owner_id ON public.stock_moves USING btree (owner_id);


--
-- Name: ix_stock_moves_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_product_template_id ON public.stock_moves USING btree (product_template_id);


--
-- Name: ix_stock_moves_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_reference ON public.stock_moves USING btree (reference_type, reference_id);


--
-- Name: ix_stock_moves_to_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_moves_to_loc ON public.stock_moves USING btree (to_location_id);


--
-- Name: ix_stock_reservations_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_document_id ON public.stock_reservations USING btree (document_id);


--
-- Name: ix_stock_reservations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_reservations_organization_id ON public.stock_reservations USING btree (organization_id);


--
-- Name: ix_stock_take_closed_locations_stock_take_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_closed_locations_stock_take_id ON public.stock_take_closed_locations USING btree (stock_take_id);


--
-- Name: ix_stock_take_counts_stock_take_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_counts_stock_take_item_id ON public.stock_take_counts USING btree (stock_take_item_id);


--
-- Name: ix_stock_takes_schedule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_takes_schedule_id ON public.stock_takes USING btree (schedule_id);


--
-- Name: ix_stock_valuation_layers_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_organization_id ON public.stock_valuation_layers USING btree (organization_id);


--
-- Name: ix_stock_valuation_layers_product_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_valuation_layers_product_template_id ON public.stock_valuation_layers USING btree (product_template_id);


--
-- Name: ix_storage_locations_context_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_context_tag ON public.storage_locations USING btree (context_tag);


--
-- Name: ix_storage_locations_org_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_org_name ON public.storage_locations USING btree (organization_id, name);


--
-- Name: ix_storage_locations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_organization_id ON public.storage_locations USING btree (organization_id);


--
-- Name: ix_storage_locations_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_locations_parent_id ON public.storage_locations USING btree (parent_id);


--
-- Name: ix_svl_org_direction_dated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_dated_at ON public.stock_valuation_layers USING btree (organization_id, direction, COALESCE(document_date, ((created_at AT TIME ZONE 'UTC'::text))::date), created_at, id);


--
-- Name: ix_svl_org_direction_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_direction_reason ON public.stock_valuation_layers USING btree (organization_id, direction, reason);


--
-- Name: ix_svl_org_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_org_template ON public.stock_valuation_layers USING btree (organization_id, product_template_id);


--
-- Name: ix_svl_template_remaining; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_svl_template_remaining ON public.stock_valuation_layers USING btree (organization_id, product_template_id, remaining_qty);


--
-- Name: ix_tax_rates_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rates_organization_id ON public.tax_rates USING btree (organization_id);


--
-- Name: ix_unit_conv_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conv_lookup ON public.unit_conversions USING btree (ingredient_key, source_unit, lang, organization_id);


--
-- Name: ix_unit_conversions_ingredient_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_ingredient_key ON public.unit_conversions USING btree (ingredient_key);


--
-- Name: ix_unit_conversions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_unit_conversions_organization_id ON public.unit_conversions USING btree (organization_id);


--
-- Name: ix_uom_categories_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uom_categories_organization_id ON public.uom_categories USING btree (organization_id);


--
-- Name: ix_uoms_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_uoms_organization_id ON public.uoms USING btree (organization_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_is_superuser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_is_superuser ON public.users USING btree (is_superuser);


--
-- Name: ix_users_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_organization_id ON public.users USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_organization_id ON public.webhook_delivery_logs USING btree (organization_id);


--
-- Name: ix_webhook_delivery_logs_webhook_endpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_delivery_logs_webhook_endpoint_id ON public.webhook_delivery_logs USING btree (webhook_endpoint_id);


--
-- Name: ix_webhook_endpoints_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_endpoints_organization_id ON public.webhook_endpoints USING btree (organization_id);


--
-- Name: ix_wms_pick_line_lots_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_line_lots_lot_id ON public.wms_pick_line_lots USING btree (lot_id);


--
-- Name: ix_wms_pick_lines_document_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_document_line_id ON public.wms_pick_lines USING btree (document_line_id);


--
-- Name: ix_wms_pick_lines_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_lines_session_id ON public.wms_pick_lines USING btree (session_id);


--
-- Name: ix_wms_pick_session_documents_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_session_documents_document_id ON public.wms_pick_session_documents USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_document_id ON public.wms_pick_sessions USING btree (document_id);


--
-- Name: ix_wms_pick_sessions_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wms_pick_sessions_organization_id ON public.wms_pick_sessions USING btree (organization_id);


--
-- Name: uq_document_org_post_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_org_post_key ON public.documents USING btree (organization_id, post_key) WHERE (post_key IS NOT NULL);


--
-- Name: uq_document_work_item_overlays_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_document_work_item_overlays_source ON public.document_work_item_overlays USING btree (organization_id, source_kind, source_id) WHERE (source_id IS NOT NULL);


--
-- Name: uq_eq_assignments_active_per_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_eq_assignments_active_per_item ON public.equipment_assignments USING btree (item_id) WHERE (checked_in_at IS NULL);


--
-- Name: uq_items_org_barcode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_barcode_active ON public.items USING btree (organization_id, barcode) WHERE ((barcode IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_items_org_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_items_org_serial ON public.items USING btree (organization_id, serial_number) WHERE ((serial_number IS NOT NULL) AND (is_deleted = false));


--
-- Name: uq_partner_org_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_partner_org_code ON public.partners USING btree (organization_id, code);


--
-- Name: uq_pending_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pending_request ON public.approval_requests USING btree (organization_id, target_type, target_id) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying])::text[]));


--
-- Name: uq_prod_org_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_prod_org_number ON public.maker_production_orders USING btree (organization_id, number) WHERE (number IS NOT NULL);


--
-- Name: uq_recipe_default_per_template; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_recipe_default_per_template ON public.maker_recipes USING btree (organization_id, output_template_id) WHERE (is_default = true);


--
-- Name: uq_stock_moves_backfill_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_stock_moves_backfill_ref ON public.stock_moves USING btree (reference_type, reference_id) WHERE ((reference_type)::text = 'item_history'::text);


--
-- Name: uq_templates_org_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_barcode ON public.product_templates USING btree (organization_id, barcode) WHERE (barcode IS NOT NULL);


--
-- Name: uq_templates_org_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_templates_org_sku ON public.product_templates USING btree (organization_id, sku) WHERE (sku IS NOT NULL);


--
-- Name: uq_uom_category_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uom_category_reference ON public.uoms USING btree (category_id) WHERE (is_reference = true);


--
-- Name: uq_workflow_org_target; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_workflow_org_target ON public.approval_workflows USING btree (organization_id, target_type) WHERE (archived_at IS NULL);


--
-- Name: audit_log audit_log_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_log_immutable BEFORE DELETE OR UPDATE ON public.audit_log FOR EACH ROW EXECUTE FUNCTION public.audit_log_immutable();


--
-- Name: items ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER UPDATE OF quantity, lot_id, owner_id, storage_location_id, template_id, is_deleted ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL) AND ((new.is_deleted IS NOT FALSE) OR (new.template_id IS DISTINCT FROM old.template_id) OR (new.storage_location_id IS DISTINCT FROM old.storage_location_id) OR (new.lot_id IS DISTINCT FROM old.lot_id) OR (new.owner_id IS DISTINCT FROM old.owner_id) OR (new.quantity IS NULL) OR (new.quantity = 'NaN'::numeric) OR (new.quantity < old.quantity)))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: stock_reservations ck_stock_holds_within_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock AFTER INSERT OR UPDATE OF quantity, anchor_id, lot_id, owner_id ON public.stock_reservations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: items ck_stock_holds_within_stock_on_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER ck_stock_holds_within_stock_on_delete AFTER DELETE ON public.items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.is_deleted IS FALSE) AND (old.template_id IS NOT NULL) AND (old.storage_location_id IS NOT NULL))) EXECUTE FUNCTION public.stock_holds_within_stock();


--
-- Name: ai_connections ai_connections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_connections
    ADD CONSTRAINT ai_connections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approval_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approval_request_id_fkey FOREIGN KEY (approval_request_id) REFERENCES public.approval_requests(id) ON DELETE CASCADE;


--
-- Name: approval_decisions approval_decisions_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_decisions
    ADD CONSTRAINT approval_decisions_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.approval_workflows(id) ON DELETE RESTRICT;


--
-- Name: approval_workflows approval_workflows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_campaigns audit_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_campaigns audit_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_campaigns
    ADD CONSTRAINT audit_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: audit_response_items audit_response_items_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_response_items
    ADD CONSTRAINT audit_response_items_response_id_fkey FOREIGN KEY (response_id) REFERENCES public.audit_responses(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.equipment_assignments(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.audit_campaigns(id) ON DELETE CASCADE;


--
-- Name: audit_responses audit_responses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_responses
    ADD CONSTRAINT audit_responses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cycle_count_schedules cycle_count_schedules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cycle_count_schedules
    ADD CONSTRAINT cycle_count_schedules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_extra_costs document_extra_costs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_extra_costs document_extra_costs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extra_costs
    ADD CONSTRAINT document_extra_costs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_corrects_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_corrects_line_id_fkey FOREIGN KEY (corrects_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_lines document_lines_executed_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_executed_location_id_fkey FOREIGN KEY (executed_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_puts_away_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_puts_away_line_id_fkey FOREIGN KEY (puts_away_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_lines document_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_lines
    ADD CONSTRAINT document_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: document_number_sequences document_number_sequences_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_number_sequences
    ADD CONSTRAINT document_number_sequences_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: document_package_lines document_package_lines_document_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_package_lines
    ADD CONSTRAINT document_package_lines_document_package_id_fkey FOREIGN KEY (document_package_id) REFERENCES public.document_packages(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_packages document_packages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_packages document_packages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_packages
    ADD CONSTRAINT document_packages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_default_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_default_template_id_fkey FOREIGN KEY (default_template_id) REFERENCES public.document_templates(id) ON DELETE SET NULL;


--
-- Name: document_profiles document_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_profiles document_profiles_quarantine_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_profiles
    ADD CONSTRAINT document_profiles_quarantine_location_id_fkey FOREIGN KEY (quarantine_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_relations document_relations_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_relations document_relations_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_relations
    ADD CONSTRAINT document_relations_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_shipments document_shipments_shipped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shipments
    ADD CONSTRAINT document_shipments_shipped_by_fkey FOREIGN KEY (shipped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_type_configs document_type_configs_default_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_source_location_id_fkey FOREIGN KEY (default_source_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_default_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_default_target_location_id_fkey FOREIGN KEY (default_target_location_id) REFERENCES public.storage_locations(id);


--
-- Name: document_type_configs document_type_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_type_configs
    ADD CONSTRAINT document_type_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_receiving_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_receiving_location_id_fkey FOREIGN KEY (receiving_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: document_warehouse_receiving document_warehouse_receiving_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_warehouse_receiving
    ADD CONSTRAINT document_warehouse_receiving_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: document_work_item_overlays document_work_item_overlays_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_work_item_overlays document_work_item_overlays_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_work_item_overlays
    ADD CONSTRAINT document_work_item_overlays_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_backorder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_backorder_id_fkey FOREIGN KEY (backorder_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: documents documents_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_corrects_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_corrects_document_id_fkey FOREIGN KEY (corrects_document_id) REFERENCES public.documents(id) ON DELETE RESTRICT;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: documents documents_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: documents documents_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: documents documents_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_assignee_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_assignee_partner_id_fkey FOREIGN KEY (assignee_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_in_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_in_by_fkey FOREIGN KEY (checked_in_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checked_out_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checked_out_by_fkey FOREIGN KEY (checked_out_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_checkout_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_checkout_location_id_fkey FOREIGN KEY (checkout_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: equipment_assignments equipment_assignments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_assignments equipment_assignments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_assignments
    ADD CONSTRAINT equipment_assignments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_attachments equipment_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_attachments
    ADD CONSTRAINT equipment_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: equipment_maintenance_logs equipment_maintenance_logs_service_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_maintenance_logs
    ADD CONSTRAINT equipment_maintenance_logs_service_partner_id_fkey FOREIGN KEY (service_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: example_widgets example_widgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.example_widgets
    ADD CONSTRAINT example_widgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs fk_ai_usage_logs_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT fk_ai_usage_logs_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs fk_ai_usage_logs_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT fk_ai_usage_logs_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approval_requests fk_approval_requests_consumed_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_approval_requests_consumed_by_users FOREIGN KEY (consumed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log fk_audit_log_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT fk_audit_log_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log fk_audit_log_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT fk_audit_log_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: categories fk_categories_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_categories_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: document_templates fk_document_templates_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT fk_document_templates_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_templates fk_document_templates_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT fk_document_templates_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_attachments fk_item_attachments_item_id_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_attachments
    ADD CONSTRAINT fk_item_attachments_item_id_items FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history fk_item_history_item_id_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_item_id_items FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_history fk_item_history_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: item_history fk_item_history_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: item_history fk_item_history_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_history
    ADD CONSTRAINT fk_item_history_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: item_type_definitions fk_item_type_definitions_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_type_definitions
    ADD CONSTRAINT fk_item_type_definitions_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: items fk_items_category_id_categories; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_category_id_categories FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: items fk_items_deleted_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_deleted_by_users FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: items fk_items_lot_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_lot_id FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: items fk_items_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: items fk_items_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_owner_id FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items fk_items_partner_id_partners; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_partner_id_partners FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: items fk_items_source_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_source_document_id FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: items fk_items_stock_anchor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_stock_anchor FOREIGN KEY (organization_id, template_id, storage_location_id) REFERENCES public.stock_anchors(organization_id, product_template_id, storage_location_id);


--
-- Name: items fk_items_storage_location_id_storage_locations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_storage_location_id_storage_locations FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: items fk_items_template_id_product_templates; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_template_id_product_templates FOREIGN KEY (template_id) REFERENCES public.product_templates(id);


--
-- Name: items fk_items_uom_id_uoms; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_items_uom_id_uoms FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: label_pool fk_label_pool_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: label_pool fk_label_pool_item_id_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_item_id_items FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: label_pool fk_label_pool_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: label_pool fk_label_pool_target_storage_location_id_storage_locations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_pool
    ADD CONSTRAINT fk_label_pool_target_storage_location_id_storage_locations FOREIGN KEY (target_storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: notifications fk_notifications_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_notifications_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_invitations fk_organization_invitations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT fk_organization_invitations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: organization_invitations fk_organization_invitations_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT fk_organization_invitations_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations fk_organization_invitations_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT fk_organization_invitations_role_id FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: organization_invitations fk_organization_invitations_used_by_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT fk_organization_invitations_used_by_user_id_users FOREIGN KEY (used_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: organizations fk_organizations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT fk_organizations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: partners fk_partners_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT fk_partners_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: partners fk_partners_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT fk_partners_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates fk_product_templates_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT fk_product_templates_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: product_templates fk_product_templates_uom_id_uoms; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT fk_product_templates_uom_id_uoms FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates fk_product_templates_volume_uom_id_uoms; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT fk_product_templates_volume_uom_id_uoms FOREIGN KEY (volume_uom_id) REFERENCES public.uoms(id);


--
-- Name: product_templates fk_product_templates_weight_uom_id_uoms; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_templates
    ADD CONSTRAINT fk_product_templates_weight_uom_id_uoms FOREIGN KEY (weight_uom_id) REFERENCES public.uoms(id);


--
-- Name: registration_requests fk_registration_requests_approved_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT fk_registration_requests_approved_by_id_users FOREIGN KEY (approved_by_id) REFERENCES public.users(id);


--
-- Name: roles fk_roles_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT fk_roles_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: stock_lots fk_stock_lots_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT fk_stock_lots_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_lots fk_stock_lots_product_template_id_product_templates; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_lots
    ADD CONSTRAINT fk_stock_lots_product_template_id_product_templates FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_reservations fk_stock_reservations_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT fk_stock_reservations_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_expected_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_expected_location_id FOREIGN KEY (expected_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_items fk_stock_take_items_storage_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT fk_stock_take_items_storage_location_id FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_document_line_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_document_line_id FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE SET NULL;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers fk_stock_valuation_layers_product_template_id_product_templates; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT fk_stock_valuation_layers_product_template_id_product_templates FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: storage_locations fk_storage_locations_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT fk_storage_locations_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_locations fk_storage_locations_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT fk_storage_locations_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: storage_locations fk_storage_locations_parent_id_storage_locations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT fk_storage_locations_parent_id_storage_locations FOREIGN KEY (parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: storage_locations fk_storage_locations_storage_type_id_storage_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT fk_storage_locations_storage_type_id_storage_types FOREIGN KEY (storage_type_id) REFERENCES public.storage_types(id);


--
-- Name: storage_types fk_storage_types_created_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT fk_storage_types_created_by_users FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: storage_types fk_storage_types_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_types
    ADD CONSTRAINT fk_storage_types_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: system_settings fk_system_settings_updated_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT fk_system_settings_updated_by_users FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: uom_categories fk_uom_categories_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_categories
    ADD CONSTRAINT fk_uom_categories_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uoms fk_uoms_category_id_uom_categories; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT fk_uoms_category_id_uom_categories FOREIGN KEY (category_id) REFERENCES public.uom_categories(id);


--
-- Name: uoms fk_uoms_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoms
    ADD CONSTRAINT fk_uoms_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_roles fk_user_roles_role_id_roles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_user_roles_role_id_roles FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles fk_user_roles_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_user_roles_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users fk_users_organization_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization_id_organizations FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wms_pick_lines fk_wms_pick_lines_anchor_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_anchor_id FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines fk_wms_pick_lines_lot_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT fk_wms_pick_lines_lot_id FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: ingredient_nutrition_defaults ingredient_nutrition_defaults_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_nutrition_defaults
    ADD CONSTRAINT ingredient_nutrition_defaults_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_periods inventory_periods_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: inventory_periods inventory_periods_reopened_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_periods
    ADD CONSTRAINT inventory_periods_reopened_by_fkey FOREIGN KEY (reopened_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_from_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_from_parent_id_fkey FOREIGN KEY (from_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: location_relocations location_relocations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: location_relocations location_relocations_to_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_relocations
    ADD CONSTRAINT location_relocations_to_parent_id_fkey FOREIGN KEY (to_parent_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: maker_bom_lines maker_bom_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_parent_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_parent_template_id_fkey FOREIGN KEY (parent_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_bom_lines maker_bom_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_bom_lines
    ADD CONSTRAINT maker_bom_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_module_settings maker_module_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_module_settings
    ADD CONSTRAINT maker_module_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_child_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_child_template_id_fkey FOREIGN KEY (child_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_order_lines maker_production_order_lines_production_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_production_order_id_fkey FOREIGN KEY (production_order_id) REFERENCES public.maker_production_orders(id) ON DELETE CASCADE;


--
-- Name: maker_production_order_lines maker_production_order_lines_source_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_order_lines
    ADD CONSTRAINT maker_production_order_lines_source_storage_location_id_fkey FOREIGN KEY (source_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: maker_production_orders maker_production_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_production_orders maker_production_orders_output_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_storage_location_id_fkey FOREIGN KEY (output_storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: maker_production_orders maker_production_orders_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id);


--
-- Name: maker_production_orders maker_production_orders_produced_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_produced_item_id_fkey FOREIGN KEY (produced_item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: maker_production_orders maker_production_orders_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_production_orders
    ADD CONSTRAINT maker_production_orders_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id);


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipe_cost_lines maker_recipe_cost_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipe_cost_lines
    ADD CONSTRAINT maker_recipe_cost_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.maker_recipes(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_batch_yield_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_batch_yield_uom_id_fkey FOREIGN KEY (batch_yield_uom_id) REFERENCES public.uoms(id);


--
-- Name: maker_recipes maker_recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: maker_recipes maker_recipes_output_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maker_recipes
    ADD CONSTRAINT maker_recipes_output_template_id_fkey FOREIGN KEY (output_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_meal_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_meal_plan_id_fkey FOREIGN KEY (meal_plan_id) REFERENCES public.meal_plans(id) ON DELETE CASCADE;


--
-- Name: meal_plan_entries meal_plan_entries_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_entries
    ADD CONSTRAINT meal_plan_entries_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: meal_plans meal_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: meal_plans meal_plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_session_items picking_session_items_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.recipe_ingredients(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: picking_session_items picking_session_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_session_items
    ADD CONSTRAINT picking_session_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.picking_sessions(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: picking_sessions picking_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.picking_sessions
    ADD CONSTRAINT picking_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: po_partner_pricelist po_partner_pricelist_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_partner_pricelist po_partner_pricelist_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_partner_pricelist
    ADD CONSTRAINT po_partner_pricelist_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_preferred_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_preferred_partner_id_fkey FOREIGN KEY (preferred_partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: po_reorder_rules po_reorder_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: po_reorder_rules po_reorder_rules_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_reorder_rules
    ADD CONSTRAINT po_reorder_rules_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: po_settings po_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_settings
    ADD CONSTRAINT po_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_agents print_agents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_agents
    ADD CONSTRAINT print_agents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.print_agents(id) ON DELETE CASCADE;


--
-- Name: print_jobs print_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_jobs print_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_jobs
    ADD CONSTRAINT print_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines purchase_order_lines_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines purchase_order_lines_source_reorder_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_source_reorder_rule_id_fkey FOREIGN KEY (source_reorder_rule_id) REFERENCES public.po_reorder_rules(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines purchase_order_lines_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: purchase_orders purchase_orders_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: putaway_capacity putaway_capacity_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_capacity putaway_capacity_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_capacity
    ADD CONSTRAINT putaway_capacity_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_location_settings putaway_location_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_location_settings
    ADD CONSTRAINT putaway_location_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rule_locations putaway_rule_locations_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rule_locations
    ADD CONSTRAINT putaway_rule_locations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.putaway_rules(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: putaway_rules putaway_rules_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.putaway_rules
    ADD CONSTRAINT putaway_rules_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_collection_members recipe_collection_members_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collection_members
    ADD CONSTRAINT recipe_collection_members_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipe_collections recipe_collections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipe_collections recipe_collections_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_collections
    ADD CONSTRAINT recipe_collections_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.recipe_collections(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_price_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_price_uom_id_fkey FOREIGN KEY (price_uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id) ON DELETE SET NULL;


--
-- Name: recipe_tag_configs recipe_tag_configs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_tag_configs
    ADD CONSTRAINT recipe_tag_configs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: recipes recipes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_exclusions shopping_exclusions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_exclusions shopping_exclusions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_exclusions
    ADD CONSTRAINT shopping_exclusions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_history shopping_list_history_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: shopping_list_history shopping_list_history_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_history
    ADD CONSTRAINT shopping_list_history_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: shopping_list_items shopping_list_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_purchased_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_purchased_by_fkey FOREIGN KEY (purchased_by) REFERENCES public.users(id);


--
-- Name: shopping_list_items shopping_list_items_shopping_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_shopping_list_id_fkey FOREIGN KEY (shopping_list_id) REFERENCES public.shopping_lists(id) ON DELETE CASCADE;


--
-- Name: shopping_list_items shopping_list_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.product_templates(id) ON DELETE SET NULL;


--
-- Name: shopping_list_items shopping_list_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT shopping_list_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: shopping_lists shopping_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shopping_lists shopping_lists_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT shopping_lists_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_anchors stock_anchors_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_anchors
    ADD CONSTRAINT stock_anchors_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_moves stock_moves_product_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_product_template_id_fkey FOREIGN KEY (product_template_id) REFERENCES public.product_templates(id) ON DELETE CASCADE;


--
-- Name: stock_moves stock_moves_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_anchor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_anchor_id_fkey FOREIGN KEY (anchor_id) REFERENCES public.stock_anchors(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_reservations stock_reservations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.partners(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_closed_locations stock_take_closed_locations_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_closed_locations
    ADD CONSTRAINT stock_take_closed_locations_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_counted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_counted_by_fkey FOREIGN KEY (counted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_take_counts stock_take_counts_stock_take_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_counts
    ADD CONSTRAINT stock_take_counts_stock_take_item_id_fkey FOREIGN KEY (stock_take_item_id) REFERENCES public.stock_take_items(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: stock_take_items stock_take_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: stock_take_items stock_take_items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id);


--
-- Name: stock_take_items stock_take_items_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id) ON DELETE CASCADE;


--
-- Name: stock_take_items stock_take_items_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_uom_id_fkey FOREIGN KEY (uom_id) REFERENCES public.uoms(id);


--
-- Name: stock_takes stock_takes_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.cycle_count_schedules(id) ON DELETE SET NULL;


--
-- Name: stock_takes stock_takes_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON DELETE CASCADE;


--
-- Name: stock_takes stock_takes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_valuation_layers stock_valuation_layers_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_valuation_layers
    ADD CONSTRAINT stock_valuation_layers_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: tax_rates tax_rates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: unit_conversions unit_conversions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: webhook_delivery_logs webhook_delivery_logs_webhook_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_webhook_endpoint_id_fkey FOREIGN KEY (webhook_endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.stock_lots(id) ON DELETE CASCADE;


--
-- Name: wms_pick_line_lots wms_pick_line_lots_pick_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_line_lots
    ADD CONSTRAINT wms_pick_line_lots_pick_line_id_fkey FOREIGN KEY (pick_line_id) REFERENCES public.wms_pick_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_document_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_document_line_id_fkey FOREIGN KEY (document_line_id) REFERENCES public.document_lines(id) ON DELETE CASCADE;


--
-- Name: wms_pick_lines wms_pick_lines_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.storage_locations(id) ON DELETE SET NULL;


--
-- Name: wms_pick_lines wms_pick_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_lines
    ADD CONSTRAINT wms_pick_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_session_documents wms_pick_session_documents_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_session_documents
    ADD CONSTRAINT wms_pick_session_documents_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.wms_pick_sessions(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: wms_pick_sessions wms_pick_sessions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: wms_pick_sessions wms_pick_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wms_pick_sessions
    ADD CONSTRAINT wms_pick_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


